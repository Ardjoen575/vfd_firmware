#ifndef PROTECTION_SAFETY_FUNCTIONS_H
#define PROTECTION_SAFETY_FUNCTIONS_H

/* Safety functions / STO (grp 200) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    uint8_t sto_ch1;
    uint8_t sto_ch2;
    uint8_t sto_ch1_debounced;
    uint8_t sto_ch2_debounced;
    uint8_t sto_active;
    uint8_t sto_fault_latch;
    uint8_t sto_status_out;
    uint8_t pwm_disabled;
    uint32_t sto_debounce_timer1;
    uint32_t sto_debounce_timer2;
    uint32_t sto_response_timer;
} safety_functions_state_t;

void safety_functions_init(safety_functions_state_t *state);
void safety_functions_update(safety_functions_state_t *state);
void safety_check_sto(safety_functions_state_t *state);

#endif /* PROTECTION_SAFETY_FUNCTIONS_H */
