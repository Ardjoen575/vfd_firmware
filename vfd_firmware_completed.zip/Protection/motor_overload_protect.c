#include "motor_overload_protect.h"

#define OL_CLASS_5_TRIP   5000
#define OL_CLASS_10_TRIP  10000
#define OL_CLASS_20_TRIP  20000
#define OL_CLASS_30_TRIP  30000

typedef struct {
    uint16_t motor_rated_current_mA;
    uint8_t  trip_class;
    uint16_t overload_level_mA;
    uint32_t integration_accum;
    uint32_t trip_threshold;
    uint8_t  trip_active;
    uint8_t  warning_active;
    uint32_t last_current_mA;
} olp_internal_t;

static olp_internal_t olp;

void motor_overload_protect_init(motor_overload_protect_state_t *state)
{
    state->initialized = 1;
    olp.motor_rated_current_mA = 10000;
    olp.trip_class = 10;
    olp.overload_level_mA = 11000;
    olp.integration_accum = 0;
    olp.trip_threshold = OL_CLASS_10_TRIP;
    olp.trip_active = 0;
    olp.warning_active = 0;
    olp.last_current_mA = 0;
}

void motor_overload_protect_update(motor_overload_protect_state_t *state)
{
    if (!state->initialized) return;
    (void)state;
}

void motor_overload_check(motor_overload_protect_state_t *state)
{
    (void)state;

    switch (olp.trip_class) {
        case 5:
            olp.trip_threshold = OL_CLASS_5_TRIP;
            break;
        case 10:
            olp.trip_threshold = OL_CLASS_10_TRIP;
            break;
        case 20:
            olp.trip_threshold = OL_CLASS_20_TRIP;
            break;
        case 30:
            olp.trip_threshold = OL_CLASS_30_TRIP;
            break;
        default:
            olp.trip_threshold = OL_CLASS_10_TRIP;
            break;
    }

    uint32_t rated = olp.motor_rated_current_mA;
    uint32_t current = olp.last_current_mA;

    if (current <= rated) {
        if (olp.integration_accum > 0) {
            uint32_t decay = rated * 10;
            if (decay > olp.integration_accum) {
                olp.integration_accum = 0;
            } else {
                olp.integration_accum -= decay;
            }
        }
    } else {
        uint32_t overload_sq = (current - rated) * (current - rated);
        uint32_t rated_sq = rated * rated;
        if (rated_sq > 0) {
            uint32_t inc = (overload_sq * 100) / rated_sq;
            olp.integration_accum += inc;
        }
    }

    if (olp.integration_accum >= olp.trip_threshold) {
        olp.trip_active = 1;
    }

    if (olp.integration_accum >= (olp.trip_threshold * 8 / 10)) {
        olp.warning_active = 1;
    } else {
        olp.warning_active = 0;
    }
}

uint8_t motor_overload_is_tripped(void)
{
    return olp.trip_active;
}

void motor_overload_set_current(uint16_t rms_current_mA)
{
    olp.last_current_mA = rms_current_mA;
}

uint8_t motor_overload_get_level_pct(void)
{
    if (olp.trip_threshold == 0) return 0;
    uint32_t pct = (olp.integration_accum * 100) / olp.trip_threshold;
    if (pct > 255) pct = 255;
    return (uint8_t)pct;
}

void motor_overload_reset(void)
{
    olp.integration_accum = 0;
    olp.trip_active = 0;
    olp.warning_active = 0;
}
