#include "emergency_stop.h"

typedef enum {
    ESTOP_IDLE       = 0,
    ESTOP_ACTIVE     = 1,
    ESTOP_COASTING   = 2,
    ESTOP_TRIP_LATCH = 3,
} estop_state_t;

typedef struct {
    estop_state_t state;
    uint8_t  hw_input1;
    uint8_t  hw_input2;
    uint8_t  safety_relay;
    uint8_t  restart_inhibit;
    uint32_t coast_timer;
    uint8_t  estop_acknowledged;
    uint8_t  fieldbus_estop;
    uint8_t  panel_estop;
    uint8_t  ramp_control_active;
} estop_internal_t;

static estop_internal_t est;

static void estop_safety_relay_set(uint8_t on)
{
    est.safety_relay = on;
}

static void estop_pwm_disable(void)
{
    est.ramp_control_active = 0;
}

static void estop_pwm_enable(void)
{
    est.ramp_control_active = 1;
}

void emergency_stop_init(emergency_stop_state_t *state)
{
    state->initialized = 1;
    est.state = ESTOP_IDLE;
    est.hw_input1 = 0;
    est.hw_input2 = 0;
    est.safety_relay = 1;
    est.restart_inhibit = 0;
    est.coast_timer = 0;
    est.estop_acknowledged = 0;
    est.fieldbus_estop = 0;
    est.panel_estop = 0;
    est.ramp_control_active = 1;
}

void emergency_stop_update(emergency_stop_state_t *state)
{
    if (!state->initialized) return;

    switch (est.state) {
        case ESTOP_IDLE: {
            uint8_t hw_act = (est.hw_input1 == 0) || (est.hw_input2 == 0);
            if (hw_act || est.fieldbus_estop || est.panel_estop) {
                est.state = ESTOP_ACTIVE;
                estop_pwm_disable();
                estop_safety_relay_set(0);
                est.coast_timer = 2000;
            }
            break;
        }
        case ESTOP_ACTIVE: {
            if (est.coast_timer > 0) {
                est.coast_timer--;
            } else {
                est.state = ESTOP_TRIP_LATCH;
            }
            break;
        }
        case ESTOP_COASTING:
            break;
        case ESTOP_TRIP_LATCH: {
            if (est.estop_acknowledged) {
                uint8_t hw_ok = (est.hw_input1 == 1) && (est.hw_input2 == 1);
                if (hw_ok && !est.fieldbus_estop && !est.panel_estop) {
                    estop_safety_relay_set(1);
                    estop_pwm_enable();
                    est.state = ESTOP_IDLE;
                    est.estop_acknowledged = 0;
                    est.restart_inhibit = 0;
                }
            }
            break;
        }
    }
}

void estop_trigger(emergency_stop_state_t *state)
{
    (void)state;
    est.fieldbus_estop = 1;
}

uint8_t estop_is_active(void)
{
    return (est.state != ESTOP_IDLE) ? 1 : 0;
}

uint8_t estop_is_latched(void)
{
    return (est.state == ESTOP_TRIP_LATCH) ? 1 : 0;
}

void estop_hardware_input(uint8_t ch1, uint8_t ch2)
{
    est.hw_input1 = ch1;
    est.hw_input2 = ch2;
}

void estop_acknowledge(void)
{
    est.estop_acknowledged = 1;
}

void estop_clear_fieldbus_stop(void)
{
    est.fieldbus_estop = 0;
}
