#include "protection.h"
#include <string.h>

#define PROT_FAULT_HISTORY_DEPTH 16

typedef enum {
    PROT_FAULT_OVERCURRENT   = 0x0001,
    PROT_FAULT_OVERVOLTAGE   = 0x0002,
    PROT_FAULT_UNDERVOLTAGE  = 0x0004,
    PROT_FAULT_OVERTEMP      = 0x0008,
    PROT_FAULT_OVERLOAD      = 0x0010,
    PROT_FAULT_EARTH         = 0x0020,
    PROT_FAULT_SHORT_CIRCUIT = 0x0040,
    PROT_FAULT_PHASE_LOSS    = 0x0080,
    PROT_FAULT_THERMAL       = 0x0100,
    PROT_FAULT_COM_LOSS      = 0x0200,
    PROT_FAULT_ENCODER       = 0x0400,
    PROT_FAULT_STO           = 0x0800,
    PROT_FAULT_EMERG_STOP    = 0x1000,
    PROT_FAULT_USER_LOAD     = 0x2000,
    PROT_FAULT_CABLE_THERM   = 0x4000,
    PROT_FAULT_HARDWARE      = 0x8000,
} prot_fault_code_t;

typedef struct {
    uint32_t timestamp;
    uint16_t fault_code;
    uint16_t fault_data;
} prot_fault_entry_t;

typedef struct {
    prot_fault_entry_t history[PROT_FAULT_HISTORY_DEPTH];
    uint8_t write_index;
    uint8_t count;
    uint32_t sys_tick_ms;
} prot_internal_t;

static prot_internal_t prot;

void protection_init(protection_state_t *state)
{
    state->initialized = 1;
    memset(&prot, 0, sizeof(prot));
}

static uint32_t prot_get_timestamp(void)
{
    return prot.sys_tick_ms;
}

static void prot_push_history(uint16_t fault_code, uint16_t fault_data)
{
    uint8_t idx = prot.write_index;
    prot.history[idx].timestamp = prot_get_timestamp();
    prot.history[idx].fault_code = fault_code;
    prot.history[idx].fault_data = fault_data;
    prot.write_index = (uint8_t)((idx + 1) & (PROT_FAULT_HISTORY_DEPTH - 1));
    if (prot.count < PROT_FAULT_HISTORY_DEPTH) {
        prot.count++;
    }
}

void protection_update(protection_state_t *state)
{
    if (!state->initialized) return;
    prot.sys_tick_ms++;
}

uint16_t prot_fault_detect(protection_state_t *state,
                           uint16_t current_raw, uint16_t voltage_raw,
                           uint16_t temp_raw, uint16_t overload,
                           uint16_t sto_status, uint16_t em_stop,
                           uint16_t encoder_stat, uint16_t com_status,
                           uint8_t motor_thermal_pct, uint8_t cable_thermal_pct,
                           uint8_t user_load_ok)
{
    uint16_t fault_word = 0;

    if (current_raw > 20000) {
        fault_word |= PROT_FAULT_OVERCURRENT;
    }
    if (voltage_raw > 24000) {
        fault_word |= PROT_FAULT_OVERVOLTAGE;
    }
    if (voltage_raw < 8000) {
        fault_word |= PROT_FAULT_UNDERVOLTAGE;
    }
    if (temp_raw > 1500) {
        fault_word |= PROT_FAULT_OVERTEMP;
    }
    if (overload > 1200) {
        fault_word |= PROT_FAULT_OVERLOAD;
    }
    if (current_raw > 35000) {
        fault_word |= PROT_FAULT_SHORT_CIRCUIT;
    }
    if (motor_thermal_pct >= 100) {
        fault_word |= PROT_FAULT_THERMAL;
    }
    if (cable_thermal_pct >= 100) {
        fault_word |= PROT_FAULT_CABLE_THERM;
    }
    if (com_status == 0) {
        fault_word |= PROT_FAULT_COM_LOSS;
    }
    if (encoder_stat != 0) {
        fault_word |= PROT_FAULT_ENCODER;
    }
    if (sto_status != 0) {
        fault_word |= PROT_FAULT_STO;
    }
    if (em_stop != 0) {
        fault_word |= PROT_FAULT_EMERG_STOP;
    }
    if (user_load_ok == 0) {
        fault_word |= PROT_FAULT_USER_LOAD;
    }

    if (fault_word != 0) {
        prot_push_history(fault_word, 0);
    }

    return fault_word;
}

uint8_t prot_get_fault_count(void)
{
    return prot.count;
}

const prot_fault_entry_t *prot_fault_history(uint8_t index)
{
    if (index >= prot.count) return NULL;
    uint8_t actual = (uint8_t)((prot.write_index - prot.count + index) & (PROT_FAULT_HISTORY_DEPTH - 1));
    return &prot.history[actual];
}

void prot_fault_history_dump(uint16_t *out_codes, uint32_t *out_timestamps, uint8_t max_count)
{
    uint8_t n = prot.count;
    if (n > max_count) n = max_count;
    for (uint8_t i = 0; i < n; i++) {
        uint8_t actual = (uint8_t)((prot.write_index - prot.count + i) & (PROT_FAULT_HISTORY_DEPTH - 1));
        out_codes[i] = prot.history[actual].fault_code;
        out_timestamps[i] = prot.history[actual].timestamp;
    }
}

void protection_check_all(protection_state_t *state)
{
    (void)state;
}

void protection_log_fault(protection_state_t *state)
{
    (void)state;
}
