#ifndef PROTECTION_MOTOR_OVERLOAD_PROTECT_H
#define PROTECTION_MOTOR_OVERLOAD_PROTECT_H

/* Motor overload protection */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    uint16_t motor_rated_current_mA;
    uint8_t  trip_class;
    uint16_t overload_level_mA;
    uint32_t integration_accum;
    uint32_t trip_threshold;
    uint8_t  trip_active;
    uint8_t  warning_active;
    uint32_t last_current_mA;
} motor_overload_protect_state_t;

void motor_overload_protect_init(motor_overload_protect_state_t *state);
void motor_overload_protect_update(motor_overload_protect_state_t *state);
void motor_overload_check(motor_overload_protect_state_t *state);

#endif /* PROTECTION_MOTOR_OVERLOAD_PROTECT_H */
