#include "motor_thermal_protect.h"

#define MOTOR_TEMP_AMBIENT_DEFAULT    300
#define MOTOR_TEMP_RISE_MAX           1550
#define MOTOR_TC_HEATING_MS           120000
#define MOTOR_TC_COOLING_MS           240000

typedef struct {
    uint16_t motor_nom_current_mA;
    uint8_t  fault_limit_pct;
    uint8_t  warning_limit_pct;
    uint32_t thermal_level;
    uint32_t current_sq_accum;
    uint8_t  fault_active;
    uint8_t  warning_active;
    uint32_t last_update_ms;
} mtp_internal_t;

static mtp_internal_t mtp;

void motor_thermal_protect_init(motor_thermal_protect_state_t *state)
{
    state->initialized = 1;
    mtp.motor_nom_current_mA = 10000;
    mtp.fault_limit_pct = 100;
    mtp.warning_limit_pct = 95;
    mtp.thermal_level = 0;
    mtp.current_sq_accum = 0;
    mtp.fault_active = 0;
    mtp.warning_active = 0;
    mtp.last_update_ms = 0;
}

void motor_thermal_protect_update(motor_thermal_protect_state_t *state)
{
    if (!state->initialized) return;
    mtp.last_update_ms++;
}

void motor_thermal_model_step(motor_thermal_protect_state_t *state)
{
    (void)state;

    uint32_t heating_tc = MOTOR_TC_HEATING_MS;
    uint32_t cooling_tc = MOTOR_TC_COOLING_MS;
    uint32_t nom_sq = (uint32_t)mtp.motor_nom_current_mA * mtp.motor_nom_current_mA;

    uint32_t current_sq = mtp.current_sq_accum;

    uint32_t rise_target;
    if (current_sq > 0 && nom_sq > 0) {
        rise_target = (current_sq * 1000) / nom_sq;
    } else {
        rise_target = 0;
    }

    uint32_t prev_level = mtp.thermal_level;

    if (rise_target > prev_level) {
        uint32_t diff = rise_target - prev_level;
        uint32_t delta = (diff * 10) / heating_tc;
        if (delta < 1) delta = 1;
        mtp.thermal_level += delta;
        if (mtp.thermal_level > rise_target) mtp.thermal_level = rise_target;
    } else {
        uint32_t diff = prev_level - rise_target;
        uint32_t delta = (diff * 10) / cooling_tc;
        if (delta < 1) delta = 1;
        if (delta > mtp.thermal_level) {
            mtp.thermal_level = 0;
        } else {
            mtp.thermal_level -= delta;
        }
    }

    uint8_t thermal_pct = (uint8_t)(mtp.thermal_level / 10);
    if (thermal_pct >= mtp.fault_limit_pct) {
        mtp.fault_active = 1;
    }
    if (thermal_pct >= mtp.warning_limit_pct) {
        mtp.warning_active = 1;
    }

    mtp.fault_active = (thermal_pct >= mtp.fault_limit_pct) ? 1 : 0;
    mtp.warning_active = (thermal_pct >= mtp.warning_limit_pct && thermal_pct < mtp.fault_limit_pct) ? 1 : 0;
}

uint8_t motor_thermal_get_level_pct(void)
{
    return (uint8_t)(mtp.thermal_level / 10);
}

void motor_thermal_set_current(uint16_t rms_current_mA)
{
    mtp.current_sq_accum = (uint32_t)rms_current_mA * rms_current_mA;
}

uint8_t motor_thermal_is_fault(void)
{
    return mtp.fault_active;
}

uint8_t motor_thermal_is_warning(void)
{
    return mtp.warning_active;
}

void motor_thermal_reset(void)
{
    mtp.thermal_level = 0;
    mtp.fault_active = 0;
    mtp.warning_active = 0;
}
