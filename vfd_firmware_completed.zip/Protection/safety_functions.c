#include "safety_functions.h"

#define STO_DEBOUNCE_MS     10
#define STO_RESPONSE_MS     20

typedef struct {
    uint8_t sto_ch1;
    uint8_t sto_ch2;
    uint8_t sto_ch1_debounced;
    uint8_t sto_ch2_debounced;
    uint8_t sto_active;
    uint8_t sto_fault_latch;
    uint8_t sto_status_out;
    uint8_t pwm_disabled;
    uint32_t sto_debounce_timer1;
    uint32_t sto_debounce_timer2;
    uint32_t sto_response_timer;
} sf_internal_t;

static sf_internal_t sf;

void safety_functions_init(safety_functions_state_t *state)
{
    state->initialized = 1;
    sf.sto_ch1 = 1;
    sf.sto_ch2 = 1;
    sf.sto_ch1_debounced = 1;
    sf.sto_ch2_debounced = 1;
    sf.sto_active = 0;
    sf.sto_fault_latch = 0;
    sf.sto_status_out = 1;
    sf.pwm_disabled = 0;
    sf.sto_debounce_timer1 = 0;
    sf.sto_debounce_timer2 = 0;
    sf.sto_response_timer = 0;
}

void safety_functions_update(safety_functions_state_t *state)
{
    if (!state->initialized) return;
    (void)state;
}

static void sf_pwm_enable(uint8_t on)
{
    if (on) {
        sf.sto_status_out = 1;
        sf.pwm_disabled = 0;
    } else {
        sf.sto_status_out = 0;
        sf.pwm_disabled = 1;
    }
}

static void sf_latch_sto_fault(void)
{
    sf.sto_fault_latch = 1;
    sf.sto_active = 1;
    sf_pwm_enable(0);
}

void safety_check_sto(safety_functions_state_t *state)
{
    (void)state;

    if (sf.sto_ch1 != sf.sto_ch1_debounced) {
        sf.sto_debounce_timer1++;
        if (sf.sto_debounce_timer1 >= STO_DEBOUNCE_MS) {
            sf.sto_ch1_debounced = sf.sto_ch1;
            sf.sto_debounce_timer1 = 0;
        }
    } else {
        sf.sto_debounce_timer1 = 0;
    }

    if (sf.sto_ch2 != sf.sto_ch2_debounced) {
        sf.sto_debounce_timer2++;
        if (sf.sto_debounce_timer2 >= STO_DEBOUNCE_MS) {
            sf.sto_ch2_debounced = sf.sto_ch2;
            sf.sto_debounce_timer2 = 0;
        }
    } else {
        sf.sto_debounce_timer2 = 0;
    }

    uint8_t sto_ch1_val = sf.sto_ch1_debounced;
    uint8_t sto_ch2_val = sf.sto_ch2_debounced;

    if (sto_ch1_val != sto_ch2_val) {
        sf_latch_sto_fault();
        return;
    }

    if (sto_ch1_val == 0 && sto_ch2_val == 0) {
        sf.sto_response_timer++;
        if (sf.sto_response_timer >= STO_RESPONSE_MS) {
            if (!sf.sto_active) {
                sf.sto_active = 1;
                sf_pwm_enable(0);
            }
        }
    } else if (sto_ch1_val == 1 && sto_ch2_val == 1) {
        sf.sto_response_timer = 0;
        if (sf.sto_active && !sf.sto_fault_latch) {
            sf.sto_active = 0;
            sf_pwm_enable(1);
        }
    }
}

void safety_set_sto_inputs(uint8_t ch1, uint8_t ch2)
{
    sf.sto_ch1 = ch1;
    sf.sto_ch2 = ch2;
}

uint8_t safety_sto_is_active(void)
{
    return sf.sto_active;
}

uint8_t safety_sto_is_pwm_disabled(void)
{
    return sf.pwm_disabled;
}

uint8_t safety_sto_get_status(void)
{
    return sf.sto_status_out;
}

uint8_t safety_sto_get_fault(void)
{
    return sf.sto_fault_latch;
}

void safety_sto_reset_fault(void)
{
    sf.sto_fault_latch = 0;
    if (sf.sto_ch1_debounced == 1 && sf.sto_ch2_debounced == 1) {
        sf.sto_active = 0;
        sf_pwm_enable(1);
    }
}
