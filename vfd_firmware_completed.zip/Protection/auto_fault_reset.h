#ifndef PROTECTION_AUTO_FAULT_RESET_H
#define PROTECTION_AUTO_FAULT_RESET_H

/* Automatic fault reset logic */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    uint8_t  enabled;
    uint8_t  max_retries;
    uint32_t reset_delay_ms;
    uint32_t retry_window_ms;
    uint8_t  retry_count;
    uint32_t timer_ms;
    uint32_t window_timer_ms;
    uint8_t  in_reset_sequence;
    uint8_t  reset_pending;
    uint16_t last_fault_word;
} auto_fault_reset_state_t;

void auto_fault_reset_init(auto_fault_reset_state_t *state);
void auto_fault_reset_update(auto_fault_reset_state_t *state);
void auto_reset_attempt(auto_fault_reset_state_t *state);

#endif /* PROTECTION_AUTO_FAULT_RESET_H */
