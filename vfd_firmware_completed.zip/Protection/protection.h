#ifndef PROTECTION_PROTECTION_H
#define PROTECTION_PROTECTION_H

/* Central fault detection + history */

#include <stdint.h>

#define PROT_FAULT_HISTORY_DEPTH 16

typedef struct {
    uint32_t timestamp;
    uint16_t fault_code;
    uint16_t fault_data;
} prot_fault_entry_t;

typedef struct {
    uint8_t initialized;
    prot_fault_entry_t history[PROT_FAULT_HISTORY_DEPTH];
    uint8_t write_index;
    uint8_t count;
    uint32_t sys_tick_ms;
} protection_state_t;

void protection_init(protection_state_t *state);
void protection_update(protection_state_t *state);
void protection_check_all(protection_state_t *state);
void protection_log_fault(protection_state_t *state);

#endif /* PROTECTION_PROTECTION_H */
