#ifndef PROTECTION_FAULT_FUNCTIONS_H
#define PROTECTION_FAULT_FUNCTIONS_H

/* Fault functions configuration (grp 31) */

#include <stdint.h>

#define FF_MAX_FAULTS 64

typedef struct {
    uint8_t initialized;
    uint16_t fault_mask;
    uint8_t  fault_delay_ms[FF_MAX_FAULTS];
    uint32_t fault_delay_accum[FF_MAX_FAULTS];
    uint16_t active_fault_word;
} fault_functions_state_t;

void fault_functions_init(fault_functions_state_t *state);
void fault_functions_update(fault_functions_state_t *state);
void fault_func_evaluate(fault_functions_state_t *state);

#endif /* PROTECTION_FAULT_FUNCTIONS_H */
