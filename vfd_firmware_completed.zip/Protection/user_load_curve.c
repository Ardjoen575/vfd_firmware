#include "user_load_curve.h"
#include <stddef.h>

#define ULC_MAX_POINTS      5
#define ULC_OVERRIDE_SPEED  1

typedef struct {
    uint16_t speed_rpm;
    uint16_t torque_cNm;
} ulc_point_t;

typedef struct {
    ulc_point_t points[ULC_MAX_POINTS];
    uint8_t     point_count;
    uint8_t     enabled;
    uint8_t     overspeed_override_speed;
    uint8_t     overspeed_override_torque;
    uint8_t     underspeed_override_speed;
    uint8_t     underspeed_override_torque;
    uint8_t     fault_active;
    uint8_t     warning_active;
} ulc_internal_t;

static ulc_internal_t ulc;

void user_load_curve_init(user_load_curve_state_t *state)
{
    state->initialized = 1;
    ulc.point_count = 4;
    ulc.points[0].speed_rpm = 0;    ulc.points[0].torque_cNm = 1000;
    ulc.points[1].speed_rpm = 750;  ulc.points[1].torque_cNm = 950;
    ulc.points[2].speed_rpm = 1500; ulc.points[2].torque_cNm = 800;
    ulc.points[3].speed_rpm = 3000; ulc.points[3].torque_cNm = 500;
    ulc.overspeed_override_speed = 3300;
    ulc.overspeed_override_torque = 300;
    ulc.underspeed_override_speed = 100;
    ulc.underspeed_override_torque = 1000;
    ulc.fault_active = 0;
    ulc.warning_active = 0;
}

void user_load_curve_update(user_load_curve_state_t *state)
{
    if (!state->initialized) return;
    (void)state;
}

static uint16_t ulc_interpolate_torque(uint16_t speed_rpm)
{
    if (ulc.point_count < 2) return 0;
    if (speed_rpm <= ulc.points[0].speed_rpm) return ulc.points[0].torque_cNm;
    if (speed_rpm >= ulc.points[ulc.point_count - 1].speed_rpm)
        return ulc.points[ulc.point_count - 1].torque_cNm;

    for (uint8_t i = 1; i < ulc.point_count; i++) {
        if (speed_rpm <= ulc.points[i].speed_rpm) {
            uint16_t s0 = ulc.points[i - 1].speed_rpm;
            uint16_t s1 = ulc.points[i].speed_rpm;
            uint16_t t0 = ulc.points[i - 1].torque_cNm;
            uint16_t t1 = ulc.points[i].torque_cNm;
            if (s1 == s0) return t0;
            uint32_t interp = (uint32_t)(speed_rpm - s0) * (t1 - t0) / (s1 - s0) + t0;
            return (uint16_t)interp;
        }
    }
    return ulc.points[ulc.point_count - 1].torque_cNm;
}

void load_curve_check(user_load_curve_state_t *state)
{
    (void)state;

    uint16_t current_speed = ulc.overspeed_override_speed;
    uint16_t current_torque = ulc.overspeed_override_torque;

    uint16_t limit_torque;
    if (current_speed >= ulc.overspeed_override_speed) {
        limit_torque = ulc.overspeed_override_torque;
    } else if (current_speed <= ulc.underspeed_override_speed) {
        limit_torque = ulc.underspeed_override_torque;
    } else {
        limit_torque = ulc_interpolate_torque(current_speed);
    }

    if (current_torque > limit_torque) {
        ulc.warning_active = 1;
        if (current_torque > (limit_torque * 110 / 100)) {
            ulc.fault_active = 1;
        }
    } else {
        ulc.fault_active = 0;
        ulc.warning_active = 0;
    }
}

uint8_t user_load_curve_is_fault(void)
{
    return ulc.fault_active;
}

uint8_t user_load_curve_is_warning(void)
{
    return ulc.warning_active;
}
