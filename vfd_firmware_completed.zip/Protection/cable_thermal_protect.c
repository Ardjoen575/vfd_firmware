#include "cable_thermal_protect.h"

#define CABLE_NOM_CURRENT_DEFAULT  15000
#define CABLE_TC_HEATING_MS         90000
#define CABLE_TC_COOLING_MS        180000

typedef struct {
    uint16_t cable_nom_current_mA;
    uint8_t  fault_limit_pct;
    uint8_t  warning_limit_pct;
    uint32_t thermal_level;
    uint32_t current_sq_accum;
    uint8_t  fault_active;
    uint8_t  warning_active;
    uint32_t last_update_ms;
} ctp_internal_t;

static ctp_internal_t ctp;

void cable_thermal_protect_init(cable_thermal_protect_state_t *state)
{
    state->initialized = 1;
    ctp.cable_nom_current_mA = CABLE_NOM_CURRENT_DEFAULT;
    ctp.fault_limit_pct = 100;
    ctp.warning_limit_pct = 90;
    ctp.thermal_level = 0;
    ctp.current_sq_accum = 0;
    ctp.fault_active = 0;
    ctp.warning_active = 0;
    ctp.last_update_ms = 0;
}

void cable_thermal_protect_update(cable_thermal_protect_state_t *state)
{
    if (!state->initialized) return;
    ctp.last_update_ms++;
}

void cable_thermal_check(cable_thermal_protect_state_t *state)
{
    (void)state;

    uint32_t heating_tc = CABLE_TC_HEATING_MS;
    uint32_t cooling_tc = CABLE_TC_COOLING_MS;
    uint32_t nom_sq = (uint32_t)ctp.cable_nom_current_mA * ctp.cable_nom_current_mA;

    uint32_t current_sq = ctp.current_sq_accum;
    uint32_t rise_target;
    if (current_sq > 0 && nom_sq > 0) {
        rise_target = (current_sq * 1000) / nom_sq;
    } else {
        rise_target = 0;
    }

    uint32_t prev_level = ctp.thermal_level;

    if (rise_target > prev_level) {
        uint32_t diff = rise_target - prev_level;
        uint32_t delta = (diff * 10) / heating_tc;
        if (delta < 1) delta = 1;
        ctp.thermal_level += delta;
        if (ctp.thermal_level > rise_target) ctp.thermal_level = rise_target;
    } else {
        uint32_t diff = prev_level - rise_target;
        uint32_t delta = (diff * 10) / cooling_tc;
        if (delta < 1) delta = 1;
        if (delta > ctp.thermal_level) {
            ctp.thermal_level = 0;
        } else {
            ctp.thermal_level -= delta;
        }
    }

    uint8_t thermal_pct = (uint8_t)(ctp.thermal_level / 10);
    if (thermal_pct >= ctp.fault_limit_pct) {
        ctp.fault_active = 1;
    } else {
        ctp.fault_active = 0;
    }
    if (thermal_pct >= ctp.warning_limit_pct && thermal_pct < ctp.fault_limit_pct) {
        ctp.warning_active = 1;
    } else {
        ctp.warning_active = 0;
    }
}

void cable_thermal_set_current(uint16_t rms_current_mA)
{
    ctp.current_sq_accum = (uint32_t)rms_current_mA * rms_current_mA;
}

uint8_t cable_thermal_get_level_pct(void)
{
    return (uint8_t)(ctp.thermal_level / 10);
}

uint8_t cable_thermal_is_fault(void)
{
    return ctp.fault_active;
}

uint8_t cable_thermal_is_warning(void)
{
    return ctp.warning_active;
}

void cable_thermal_reset(void)
{
    ctp.thermal_level = 0;
    ctp.fault_active = 0;
    ctp.warning_active = 0;
}
