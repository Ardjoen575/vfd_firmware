#ifndef PROTECTION_USER_LOAD_CURVE_H
#define PROTECTION_USER_LOAD_CURVE_H

/* User load curve (grp 37) */

#include <stdint.h>

#define ULC_MAX_POINTS 5

typedef struct {
    uint16_t speed_rpm;
    uint16_t torque_cNm;
} ulc_point_t;

typedef struct {
    uint8_t initialized;
    ulc_point_t points[ULC_MAX_POINTS];
    uint8_t     point_count;
    uint8_t     enabled;
    uint8_t     overspeed_override_speed;
    uint8_t     overspeed_override_torque;
    uint8_t     underspeed_override_speed;
    uint8_t     underspeed_override_torque;
    uint8_t     fault_active;
    uint8_t     warning_active;
} user_load_curve_state_t;

void user_load_curve_init(user_load_curve_state_t *state);
void user_load_curve_update(user_load_curve_state_t *state);
void load_curve_check(user_load_curve_state_t *state);

#endif /* PROTECTION_USER_LOAD_CURVE_H */
