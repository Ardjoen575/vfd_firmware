#include "fault_functions.h"

#define FF_MAX_FAULTS      64
#define FF_DELAY_DEFAULT   20
#define FF_MASK_DEFAULT    0xFFFF

typedef struct {
    uint16_t fault_mask;
    uint8_t  fault_delay_ms[FF_MAX_FAULTS];
    uint32_t fault_delay_accum[FF_MAX_FAULTS];
    uint16_t active_fault_word;
} ff_internal_t;

static ff_internal_t ff;

void fault_functions_init(fault_functions_state_t *state)
{
    state->initialized = 1;
    ff.fault_mask = FF_MASK_DEFAULT;
    ff.active_fault_word = 0;

    for (uint8_t i = 0; i < FF_MAX_FAULTS; i++) {
        ff.fault_delay_ms[i] = FF_DELAY_DEFAULT;
        ff.fault_delay_accum[i] = 0;
    }
}

void fault_functions_update(fault_functions_state_t *state)
{
    if (!state->initialized) return;
    (void)state;
}

void fault_func_evaluate(fault_functions_state_t *state)
{
    (void)state;

    uint16_t raw_fault_word = ff.active_fault_word;
    uint16_t masked_fault = raw_fault_word & ff.fault_mask;
    uint16_t confirmed_fault = 0;

    for (uint8_t b = 0; b < 16; b++) {
        uint16_t bit = (uint16_t)(1 << b);
        if (masked_fault & bit) {
            ff.fault_delay_accum[b]++;
            if (ff.fault_delay_accum[b] >= ff.fault_delay_ms[b]) {
                confirmed_fault |= bit;
            }
        } else {
            ff.fault_delay_accum[b] = 0;
        }
    }

    ff.active_fault_word = confirmed_fault;
}

void fault_func_set_raw_word(uint16_t fault_word)
{
    ff.active_fault_word = fault_word;
}

uint16_t fault_func_get_confirmed(void)
{
    return ff.active_fault_word;
}

void fault_func_set_mask(uint16_t mask)
{
    ff.fault_mask = mask;
}

void fault_func_set_delay(uint8_t fault_index, uint8_t delay_ms)
{
    if (fault_index < FF_MAX_FAULTS) {
        ff.fault_delay_ms[fault_index] = delay_ms;
    }
}

void fault_func_clear_all(void)
{
    ff.active_fault_word = 0;
    for (uint8_t i = 0; i < FF_MAX_FAULTS; i++) {
        ff.fault_delay_accum[i] = 0;
    }
}
