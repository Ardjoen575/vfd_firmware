#ifndef PROTECTION_CABLE_THERMAL_PROTECT_H
#define PROTECTION_CABLE_THERMAL_PROTECT_H

/* Thermal protection of motor cable */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    uint16_t cable_nom_current_mA;
    uint8_t  fault_limit_pct;
    uint8_t  warning_limit_pct;
    uint32_t thermal_level;
    uint32_t current_sq_accum;
    uint8_t  fault_active;
    uint8_t  warning_active;
    uint32_t last_update_ms;
} cable_thermal_protect_state_t;

void cable_thermal_protect_init(cable_thermal_protect_state_t *state);
void cable_thermal_protect_update(cable_thermal_protect_state_t *state);
void cable_thermal_check(cable_thermal_protect_state_t *state);

#endif /* PROTECTION_CABLE_THERMAL_PROTECT_H */
