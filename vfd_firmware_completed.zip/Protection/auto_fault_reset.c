#include "auto_fault_reset.h"

#define AFR_MAX_RETRIES      3
#define AFR_RESET_DELAY_MS   5000
#define AFR_RETRY_WINDOW_MS  60000

typedef struct {
    uint8_t  enabled;
    uint8_t  max_retries;
    uint32_t reset_delay_ms;
    uint32_t retry_window_ms;
    uint8_t  retry_count;
    uint32_t timer_ms;
    uint32_t window_timer_ms;
    uint8_t  in_reset_sequence;
    uint8_t  reset_pending;
    uint16_t last_fault_word;
} afr_internal_t;

static afr_internal_t afr;

void auto_fault_reset_init(auto_fault_reset_state_t *state)
{
    state->initialized = 1;
    afr.enabled = 1;
    afr.max_retries = AFR_MAX_RETRIES;
    afr.reset_delay_ms = AFR_RESET_DELAY_MS;
    afr.retry_window_ms = AFR_RETRY_WINDOW_MS;
    afr.retry_count = 0;
    afr.timer_ms = 0;
    afr.window_timer_ms = 0;
    afr.in_reset_sequence = 0;
    afr.reset_pending = 0;
    afr.last_fault_word = 0;
}

void auto_fault_reset_update(auto_fault_reset_state_t *state)
{
    if (!state->initialized) return;
    (void)state;
}

void auto_reset_attempt(auto_fault_reset_state_t *state)
{
    (void)state;

    uint16_t current_fault = afr.last_fault_word;

    if (!afr.enabled) {
        afr.reset_pending = 0;
        return;
    }

    if (current_fault != 0 && !afr.in_reset_sequence) {
        afr.in_reset_sequence = 1;
        afr.timer_ms = 0;
        afr.reset_pending = 0;
    }

    if (afr.in_reset_sequence) {
        if (current_fault == 0) {
            afr.in_reset_sequence = 0;
            afr.timer_ms = 0;
            afr.reset_pending = 0;
            return;
        }

        if (afr.retry_count >= afr.max_retries) {
            afr.in_reset_sequence = 0;
            afr.timer_ms = 0;
            afr.reset_pending = 0;
            return;
        }

        afr.timer_ms++;
        if (afr.timer_ms >= afr.reset_delay_ms) {
            afr.reset_pending = 1;
            afr.timer_ms = 0;
        }
    }
}

void auto_reset_confirm_executed(void)
{
    if (afr.reset_pending) {
        afr.retry_count++;
        afr.reset_pending = 0;
        afr.window_timer_ms = 0;
    }
}

void auto_reset_window_tick(void)
{
    if (afr.retry_count > 0) {
        afr.window_timer_ms++;
        if (afr.window_timer_ms >= afr.retry_window_ms) {
            afr.retry_count = 0;
            afr.window_timer_ms = 0;
        }
    }
}

uint8_t auto_reset_is_pending(void)
{
    return afr.reset_pending;
}

uint8_t auto_reset_get_retry_count(void)
{
    return afr.retry_count;
}

void auto_reset_set_fault_word(uint16_t fault_word)
{
    afr.last_fault_word = fault_word;
}

void auto_reset_disable(void)
{
    afr.enabled = 0;
    afr.reset_pending = 0;
    afr.in_reset_sequence = 0;
    afr.retry_count = 0;
}

void auto_reset_enable(void)
{
    afr.enabled = 1;
}
