#ifndef PROTECTION_EMERGENCY_STOP_H
#define PROTECTION_EMERGENCY_STOP_H

/* Emergency stop handling */

#include <stdint.h>

typedef enum {
    ESTOP_IDLE       = 0,
    ESTOP_ACTIVE     = 1,
    ESTOP_COASTING   = 2,
    ESTOP_TRIP_LATCH = 3,
} estop_state_t;

typedef struct {
    uint8_t initialized;
    estop_state_t state;
    uint8_t  hw_input1;
    uint8_t  hw_input2;
    uint8_t  safety_relay;
    uint8_t  restart_inhibit;
    uint32_t coast_timer;
    uint8_t  estop_acknowledged;
    uint8_t  fieldbus_estop;
    uint8_t  panel_estop;
    uint8_t  ramp_control_active;
} emergency_stop_state_t;

void emergency_stop_init(emergency_stop_state_t *state);
void emergency_stop_update(emergency_stop_state_t *state);
void estop_trigger(emergency_stop_state_t *state);

#endif /* PROTECTION_EMERGENCY_STOP_H */
