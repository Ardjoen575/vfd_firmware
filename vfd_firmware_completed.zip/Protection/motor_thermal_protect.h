#ifndef PROTECTION_MOTOR_THERMAL_PROTECT_H
#define PROTECTION_MOTOR_THERMAL_PROTECT_H

/* Motor thermal protection (grp 35) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    uint16_t motor_nom_current_mA;
    uint8_t  fault_limit_pct;
    uint8_t  warning_limit_pct;
    uint32_t thermal_level;
    uint32_t current_sq_accum;
    uint8_t  fault_active;
    uint8_t  warning_active;
    uint32_t last_update_ms;
} motor_thermal_protect_state_t;

void motor_thermal_protect_init(motor_thermal_protect_state_t *state);
void motor_thermal_protect_update(motor_thermal_protect_state_t *state);
void motor_thermal_model_step(motor_thermal_protect_state_t *state);

#endif /* PROTECTION_MOTOR_THERMAL_PROTECT_H */
