#ifndef HWCONFIG_MOTOR_CONTROL_SETTINGS_H
#define HWCONFIG_MOTOR_CONTROL_SETTINGS_H

#include <stdint.h>

typedef enum {
    CTRL_MODE_SCALAR_VF       = 0,
    CTRL_MODE_VECTOR_SPEED     = 1,
    CTRL_MODE_VECTOR_TORQUE    = 2,
    CTRL_MODE_DTC              = 3,
    CTRL_MODE_PM_SENSORLESS    = 4,
    CTRL_MODE_PM_ENCODER       = 5,
    CTRL_MODE_SYNRM            = 6,
} ctrl_mode_t;

typedef enum {
    MODULATION_SVPWM           = 0,
    MODULATION_SVPWM_5SEG      = 1,
    MODULATION_DPWM            = 2,
    MODULATION_SIX_STEP        = 3,
    MODULATION_OVERMODULATION  = 4,
} modulation_type_t;

typedef struct {
    uint8_t          initialized;
    ctrl_mode_t      control_mode;
    modulation_type_t modulation;
    uint16_t         switching_frequency_hz;
    uint16_t         current_bandwidth_hz;
    uint16_t         speed_bandwidth_hz;
    uint8_t          autotune_enabled;
    uint8_t          autotune_type;
    uint8_t          slip_compensation;
    uint8_t          ir_compensation_percent;
    uint8_t          flux_braking_enabled;
    uint8_t          flying_start_enabled;
    uint8_t          dc_hold_enabled;
    uint16_t         dc_hold_voltage_v;
    uint16_t         min_frequency_hz;
    uint16_t         max_frequency_hz;
} motor_control_settings_state_t;

void motor_control_settings_init(motor_control_settings_state_t *state);
void motor_control_settings_update(motor_control_settings_state_t *state);
void motor_ctrl_configure(motor_control_settings_state_t *state,
                           ctrl_mode_t mode, uint16_t switching_freq);

#endif
