#include "motor_control_settings.h"
#include <string.h>

void motor_ctrl_configure(motor_control_settings_state_t *state,
                           ctrl_mode_t mode, uint16_t switching_freq)
{
    if (state == 0) return;

    state->control_mode = mode;

    if (switching_freq < 1000) switching_freq = 1000;
    if (switching_freq > 16000) switching_freq = 16000;
    state->switching_frequency_hz = switching_freq;

    switch (mode) {
    case CTRL_MODE_SCALAR_VF:
        state->modulation = MODULATION_SVPWM;
        state->current_bandwidth_hz = 0;
        state->speed_bandwidth_hz = 10;
        state->slip_compensation = 1;
        state->ir_compensation_percent = 50;
        state->min_frequency_hz = 0;
        state->max_frequency_hz = 400;
        break;

    case CTRL_MODE_VECTOR_SPEED:
        state->modulation = MODULATION_SVPWM;
        state->current_bandwidth_hz = 500;
        state->speed_bandwidth_hz = 50;
        state->slip_compensation = 1;
        state->ir_compensation_percent = 80;
        state->min_frequency_hz = 0;
        state->max_frequency_hz = 500;
        break;

    case CTRL_MODE_VECTOR_TORQUE:
        state->modulation = MODULATION_SVPWM;
        state->current_bandwidth_hz = 800;
        state->speed_bandwidth_hz = 80;
        state->slip_compensation = 0;
        state->ir_compensation_percent = 100;
        state->min_frequency_hz = 0;
        state->max_frequency_hz = 500;
        break;

    case CTRL_MODE_DTC:
        state->modulation = MODULATION_SIX_STEP;
        state->current_bandwidth_hz = 1000;
        state->speed_bandwidth_hz = 100;
        state->slip_compensation = 0;
        state->ir_compensation_percent = 0;
        state->min_frequency_hz = 0;
        state->max_frequency_hz = 300;
        break;

    case CTRL_MODE_PM_SENSORLESS:
        state->modulation = MODULATION_SVPWM;
        state->current_bandwidth_hz = 600;
        state->speed_bandwidth_hz = 60;
        state->slip_compensation = 0;
        state->ir_compensation_percent = 60;
        state->min_frequency_hz = 5;
        state->max_frequency_hz = 400;
        break;

    case CTRL_MODE_PM_ENCODER:
        state->modulation = MODULATION_SVPWM;
        state->current_bandwidth_hz = 500;
        state->speed_bandwidth_hz = 100;
        state->slip_compensation = 0;
        state->ir_compensation_percent = 50;
        state->min_frequency_hz = 0;
        state->max_frequency_hz = 400;
        break;

    case CTRL_MODE_SYNRM:
        state->modulation = MODULATION_SVPWM;
        state->current_bandwidth_hz = 400;
        state->speed_bandwidth_hz = 40;
        state->slip_compensation = 0;
        state->ir_compensation_percent = 40;
        state->min_frequency_hz = 10;
        state->max_frequency_hz = 300;
        break;

    default:
        break;
    }

    state->autotune_enabled = 0;
    state->autotune_type = 0;
    state->flux_braking_enabled = 0;
    state->flying_start_enabled = 0;
    state->dc_hold_enabled = 0;
    state->dc_hold_voltage_v = 10;
}

void motor_control_settings_init(motor_control_settings_state_t *state)
{
    if (state == 0) return;

    memset(state, 0, sizeof(motor_control_settings_state_t));
    state->initialized = 1;
    motor_ctrl_configure(state, CTRL_MODE_SCALAR_VF, 4000);
}

void motor_control_settings_update(motor_control_settings_state_t *state)
{
    (void)state;
}
