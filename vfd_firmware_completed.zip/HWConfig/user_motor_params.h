#ifndef HWCONFIG_USER_MOTOR_PARAMS_H
#define HWCONFIG_USER_MOTOR_PARAMS_H

#include <stdint.h>

typedef struct {
    uint32_t rs_microohm;
    uint32_t ls_microH;
    uint32_t lm_milliH;
    uint16_t rotor_inertia_kgcm2;
} equiv_circuit_t;

typedef struct {
    uint8_t          initialized;
    uint8_t          params_valid;
    uint8_t          use_custom_params;
    equiv_circuit_t  model;
    uint16_t         saturation_inductance_lsd_mH;
    uint16_t         saturation_inductance_lsq_mH;
    uint16_t         bemf_constant_vpkprpm;
    uint16_t         thermal_time_constant_s;
    uint16_t         thermal_resistance_kW;
    uint32_t         mechanical_time_constant_ms;
} user_motor_params_state_t;

void user_motor_params_init(user_motor_params_state_t *state);
void user_motor_params_update(user_motor_params_state_t *state);
uint8_t user_motor_params_apply(user_motor_params_state_t *state,
                                 const equiv_circuit_t *circuit);

#endif
