#ifndef HWCONFIG_HW_CONFIGURATION_H
#define HWCONFIG_HW_CONFIGURATION_H

#include <stdint.h>

typedef enum {
    DRIVE_SIZE_R0     = 0,
    DRIVE_SIZE_R1     = 1,
    DRIVE_SIZE_R2     = 2,
    DRIVE_SIZE_R3     = 3,
    DRIVE_SIZE_R4     = 4,
    DRIVE_SIZE_R5     = 5,
    DRIVE_SIZE_R6     = 6,
    DRIVE_SIZE_R7     = 7,
    DRIVE_SIZE_R8     = 8,
    DRIVE_SIZE_R9     = 9,
} drive_size_t;

typedef enum {
    OPTION_SLOT_EMPTY    = 0x00,
    OPTION_FIELDBUS_PROFIBUS  = 0x01,
    OPTION_FIELDBUS_PROFINET  = 0x02,
    OPTION_FIELDBUS_ETHERCAT  = 0x03,
    OPTION_FIELDBUS_ETHERNETIP = 0x04,
    OPTION_FIELDBUS_MODBUS_TCP = 0x05,
    OPTION_FIELDBUS_CANOPEN    = 0x06,
    OPTION_FIELDBUS_DEVICENET  = 0x07,
    OPTION_FIELDBUS_POWERLINK  = 0x08,
    OPTION_ENCODER_TTL    = 0x10,
    OPTION_ENCODER_HTL    = 0x11,
    OPTION_ENCODER_RESOLVER = 0x12,
    OPTION_ENCODER_ENDAT  = 0x13,
    OPTION_ENCODER_SSI    = 0x14,
    OPTION_ENCODER_BISS   = 0x15,
    OPTION_IO_EXT_1       = 0x20,
    OPTION_IO_EXT_2       = 0x21,
    OPTION_SAFETY_STO     = 0x30,
    OPTION_SAFETY_STO_SS1 = 0x31,
    OPTION_BRAKE_CHOPPER  = 0x40,
    OPTION_EMC_FILTER     = 0x50,
    OPTION_DUDT_FILTER    = 0x51,
    OPTION_SINE_FILTER    = 0x52,
    OPTION_DC_CHOKE       = 0x60,
    OPTION_AC_CHOKE       = 0x61,
} option_type_t;

#define HW_OPTION_SLOT_COUNT  3U
#define HW_EXT_MODULE_MAX     8U

typedef struct {
    uint8_t       initialized;
    uint8_t       config_valid;
    drive_size_t  drive_size;
    uint16_t      drive_current_rating_a;
    uint16_t      drive_voltage_rating_v;
    uint8_t       hw_revision_major;
    uint8_t       hw_revision_minor;
    uint32_t      serial_number;
    char          product_code[16];
    option_type_t options[HW_OPTION_SLOT_COUNT];
    uint8_t       option_installed[HW_OPTION_SLOT_COUNT];
    uint8_t       io_ext_count;
    uint8_t       io_ext_present;
    uint8_t       brake_chopper_installed;
    uint8_t       brake_chopper_rated_kW;
    uint8_t       emc_filter_installed;
    uint8_t       dudt_filter_installed;
    uint8_t       sine_filter_installed;
    uint8_t       dc_choke_installed;
    uint8_t       ac_choke_installed;
    uint8_t       heatsink_fan_count;
} hw_configuration_state_t;

void hw_configuration_init(hw_configuration_state_t *state);
void hw_configuration_update(hw_configuration_state_t *state);
uint8_t hw_config_apply(hw_configuration_state_t *state,
                         drive_size_t size, uint32_t serial);

#endif
