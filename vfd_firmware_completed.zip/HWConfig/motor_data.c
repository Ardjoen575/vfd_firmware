#include "motor_data.h"
#include <string.h>

uint8_t motor_data_configure(motor_data_state_t *state,
                              uint16_t voltage_v, uint16_t current_a,
                              uint16_t freq_hz, uint16_t speed_rpm,
                              uint16_t power_kw, uint8_t pole_pairs,
                              uint8_t cos_phi)
{
    if (state == 0) return 0;

    if (voltage_v == 0 || voltage_v > 1000) return 0;
    if (current_a == 0 || current_a > 2000) return 0;
    if (freq_hz == 0 || freq_hz > 500) return 0;
    if (speed_rpm == 0 || speed_rpm > 30000) return 0;
    if (power_kw == 0 || power_kw > 5000) return 0;
    if (pole_pairs == 0 || pole_pairs > 32) return 0;
    if (cos_phi > 100) return 0;

    state->nominal_voltage_v   = voltage_v;
    state->nominal_current_a   = current_a;
    state->nominal_frequency_hz = freq_hz;
    state->nominal_speed_rpm   = speed_rpm;
    state->nominal_power_kw    = power_kw;
    state->pole_pairs          = pole_pairs;
    state->cos_phi_percent     = cos_phi;

    state->nominal_torque_nm = (power_kw * 9550UL) / speed_rpm;

    state->no_load_current_a = (current_a * 30UL) / 100;

    state->stall_current_a = current_a;

    state->stator_resistance_mohm = (voltage_v * 50UL) / current_a;
    state->rotor_resistance_mohm  = (voltage_v * 40UL) / current_a;
    state->stator_leakage_mH      = 10;
    state->rotor_leakage_mH       = 12;
    state->magnetizing_inductance_mH = 200;

    if (pole_pairs == 2) {
        state->moment_inertia_kgcm2 = 10;
    } else if (pole_pairs == 3) {
        state->moment_inertia_kgcm2 = 25;
    } else if (pole_pairs >= 4 && pole_pairs <= 6) {
        state->moment_inertia_kgcm2 = 50;
    } else {
        state->moment_inertia_kgcm2 = 100;
    }

    state->motor_type = 0;
    state->connection_type = 1;
    state->data_valid = 1;

    return 1;
}

void motor_data_init(motor_data_state_t *state)
{
    if (state == 0) return;

    memset(state, 0, sizeof(motor_data_state_t));
    state->initialized = 1;
    state->data_valid = 0;
}

void motor_data_update(motor_data_state_t *state)
{
    if (state == 0 || !state->initialized) return;

    if (!state->data_valid) {
        motor_data_configure(state,
                              400, 10, 50, 1500, 5, 2, 85);
    }
}
