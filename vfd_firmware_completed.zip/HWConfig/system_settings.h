#ifndef HWCONFIG_SYSTEM_SETTINGS_H
#define HWCONFIG_SYSTEM_SETTINGS_H

#include <stdint.h>

typedef enum {
    SUPPLY_1PH_230V   = 0,
    SUPPLY_3PH_230V   = 1,
    SUPPLY_3PH_400V   = 2,
    SUPPLY_3PH_500V   = 3,
    SUPPLY_3PH_690V   = 4,
    SUPPLY_DC_500V    = 5,
    SUPPLY_DC_700V    = 6,
} supply_type_t;

typedef struct {
    uint8_t       initialized;
    uint8_t       config_valid;
    supply_type_t supply_type;
    uint16_t      supply_voltage_v;
    uint8_t       supply_frequency_hz;
    uint16_t      dc_bus_nominal_v;
    uint16_t      dc_bus_undervoltage_v;
    uint16_t      dc_bus_overvoltage_v;
    uint16_t      dc_bus_braking_v;
    uint8_t       drive_type;
    uint8_t       application_macro;
    uint8_t       country_code;
    uint8_t       language;
    uint16_t      drive_power_rating_kW;
    uint8_t       cooling_type;
} system_settings_state_t;

void system_settings_init(system_settings_state_t *state);
void system_settings_update(system_settings_state_t *state);
uint8_t system_settings_apply(system_settings_state_t *state,
                               supply_type_t supply);

#endif
