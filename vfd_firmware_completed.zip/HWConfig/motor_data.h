#ifndef HWCONFIG_MOTOR_DATA_H
#define HWCONFIG_MOTOR_DATA_H

#include <stdint.h>

typedef struct {
    uint8_t  initialized;
    uint8_t  data_valid;
    uint16_t nominal_voltage_v;
    uint16_t nominal_current_a;
    uint16_t nominal_frequency_hz;
    uint16_t nominal_speed_rpm;
    uint16_t nominal_power_kw;
    uint16_t nominal_torque_nm;
    uint8_t  pole_pairs;
    uint8_t  cos_phi_percent;
    uint8_t  motor_type;
    uint8_t  connection_type;
    uint16_t no_load_current_a;
    uint16_t stall_current_a;
    uint16_t stator_resistance_mohm;
    uint16_t rotor_resistance_mohm;
    uint16_t stator_leakage_mH;
    uint16_t rotor_leakage_mH;
    uint16_t magnetizing_inductance_mH;
    uint16_t moment_inertia_kgcm2;
} motor_data_state_t;

void motor_data_init(motor_data_state_t *state);
void motor_data_update(motor_data_state_t *state);
uint8_t motor_data_configure(motor_data_state_t *state,
                              uint16_t voltage_v, uint16_t current_a,
                              uint16_t freq_hz, uint16_t speed_rpm,
                              uint16_t power_kw, uint8_t pole_pairs,
                              uint8_t cos_phi);

#endif
