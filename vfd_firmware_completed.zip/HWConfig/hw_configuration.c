#include "hw_configuration.h"
#include <string.h>

uint8_t hw_config_apply(hw_configuration_state_t *state,
                         drive_size_t size, uint32_t serial)
{
    uint8_t i;

    if (state == 0) return 0;

    state->drive_size = size;

    switch (size) {
    case DRIVE_SIZE_R0:
        state->drive_current_rating_a = 2;
        state->drive_voltage_rating_v = 230;
        state->heatsink_fan_count = 0;
        break;
    case DRIVE_SIZE_R1:
        state->drive_current_rating_a = 4;
        state->drive_voltage_rating_v = 230;
        state->heatsink_fan_count = 0;
        break;
    case DRIVE_SIZE_R2:
        state->drive_current_rating_a = 8;
        state->drive_voltage_rating_v = 400;
        state->heatsink_fan_count = 1;
        break;
    case DRIVE_SIZE_R3:
        state->drive_current_rating_a = 14;
        state->drive_voltage_rating_v = 400;
        state->heatsink_fan_count = 1;
        break;
    case DRIVE_SIZE_R4:
        state->drive_current_rating_a = 25;
        state->drive_voltage_rating_v = 400;
        state->heatsink_fan_count = 1;
        break;
    case DRIVE_SIZE_R5:
        state->drive_current_rating_a = 38;
        state->drive_voltage_rating_v = 400;
        state->heatsink_fan_count = 2;
        break;
    case DRIVE_SIZE_R6:
        state->drive_current_rating_a = 55;
        state->drive_voltage_rating_v = 400;
        state->heatsink_fan_count = 2;
        break;
    case DRIVE_SIZE_R7:
        state->drive_current_rating_a = 80;
        state->drive_voltage_rating_v = 400;
        state->heatsink_fan_count = 2;
        break;
    case DRIVE_SIZE_R8:
        state->drive_current_rating_a = 120;
        state->drive_voltage_rating_v = 500;
        state->heatsink_fan_count = 3;
        break;
    case DRIVE_SIZE_R9:
        state->drive_current_rating_a = 180;
        state->drive_voltage_rating_v = 690;
        state->heatsink_fan_count = 3;
        break;
    default:
        return 0;
    }

    state->serial_number = serial;
    state->hw_revision_major = 1;
    state->hw_revision_minor = 0;

    memcpy(state->product_code, "ACS880-R", 8);
    state->product_code[8] = (char)('0' + size);
    state->product_code[9] = '\0';

    state->io_ext_count = 0;
    state->io_ext_present = 0;
    state->brake_chopper_installed = 0;
    state->brake_chopper_rated_kW = 0;
    state->emc_filter_installed = 0;
    state->dudt_filter_installed = 0;
    state->sine_filter_installed = 0;
    state->dc_choke_installed = 0;
    state->ac_choke_installed = 0;

    for (i = 0; i < HW_OPTION_SLOT_COUNT; i++) {
        state->options[i] = OPTION_SLOT_EMPTY;
        state->option_installed[i] = 0;
    }

    state->config_valid = 1;

    return 1;
}

void hw_configuration_init(hw_configuration_state_t *state)
{
    if (state == 0) return;

    memset(state, 0, sizeof(hw_configuration_state_t));
    state->initialized = 1;
    state->config_valid = 0;
    hw_config_apply(state, DRIVE_SIZE_R2, 0x00000001UL);
}

void hw_configuration_update(hw_configuration_state_t *state)
{
    (void)state;
}
