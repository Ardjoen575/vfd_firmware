#include "system_settings.h"
#include <string.h>

uint8_t system_settings_apply(system_settings_state_t *state,
                               supply_type_t supply)
{
    uint16_t dc_nominal;

    if (state == 0) return 0;

    state->supply_type = supply;

    switch (supply) {
    case SUPPLY_1PH_230V:
        state->supply_voltage_v   = 230;
        state->supply_frequency_hz = 50;
        dc_nominal = (uint16_t)(230 * 1414UL / 1000);
        state->dc_bus_nominal_v   = dc_nominal;
        state->dc_bus_undervoltage_v = (uint16_t)(dc_nominal * 60UL / 100);
        state->dc_bus_overvoltage_v  = (uint16_t)(dc_nominal * 140UL / 100);
        state->dc_bus_braking_v      = (uint16_t)(dc_nominal * 130UL / 100);
        state->drive_power_rating_kW = 2;
        break;

    case SUPPLY_3PH_230V:
        state->supply_voltage_v   = 230;
        state->supply_frequency_hz = 60;
        dc_nominal = (uint16_t)(230 * 1414UL / 1000);
        state->dc_bus_nominal_v   = dc_nominal;
        state->dc_bus_undervoltage_v = (uint16_t)(dc_nominal * 60UL / 100);
        state->dc_bus_overvoltage_v  = (uint16_t)(dc_nominal * 140UL / 100);
        state->dc_bus_braking_v      = (uint16_t)(dc_nominal * 130UL / 100);
        state->drive_power_rating_kW = 5;
        break;

    case SUPPLY_3PH_400V:
        state->supply_voltage_v   = 400;
        state->supply_frequency_hz = 50;
        dc_nominal = (uint16_t)(400 * 1414UL / 1000);
        state->dc_bus_nominal_v   = dc_nominal;
        state->dc_bus_undervoltage_v = (uint16_t)(dc_nominal * 60UL / 100);
        state->dc_bus_overvoltage_v  = (uint16_t)(dc_nominal * 140UL / 100);
        state->dc_bus_braking_v      = (uint16_t)(dc_nominal * 130UL / 100);
        state->drive_power_rating_kW = 11;
        break;

    case SUPPLY_3PH_500V:
        state->supply_voltage_v   = 500;
        state->supply_frequency_hz = 50;
        dc_nominal = (uint16_t)(500 * 1414UL / 1000);
        state->dc_bus_nominal_v   = dc_nominal;
        state->dc_bus_undervoltage_v = (uint16_t)(dc_nominal * 55UL / 100);
        state->dc_bus_overvoltage_v  = (uint16_t)(dc_nominal * 135UL / 100);
        state->dc_bus_braking_v      = (uint16_t)(dc_nominal * 125UL / 100);
        state->drive_power_rating_kW = 15;
        break;

    case SUPPLY_3PH_690V:
        state->supply_voltage_v   = 690;
        state->supply_frequency_hz = 50;
        dc_nominal = (uint16_t)(690 * 1414UL / 1000);
        state->dc_bus_nominal_v   = dc_nominal;
        state->dc_bus_undervoltage_v = (uint16_t)(dc_nominal * 55UL / 100);
        state->dc_bus_overvoltage_v  = (uint16_t)(dc_nominal * 130UL / 100);
        state->dc_bus_braking_v      = (uint16_t)(dc_nominal * 120UL / 100);
        state->drive_power_rating_kW = 37;
        break;

    case SUPPLY_DC_500V:
        state->supply_voltage_v   = 500;
        state->supply_frequency_hz = 0;
        state->dc_bus_nominal_v   = 500;
        state->dc_bus_undervoltage_v = 300;
        state->dc_bus_overvoltage_v  = 700;
        state->dc_bus_braking_v      = 650;
        state->drive_power_rating_kW = 7;
        break;

    case SUPPLY_DC_700V:
        state->supply_voltage_v   = 700;
        state->supply_frequency_hz = 0;
        state->dc_bus_nominal_v   = 700;
        state->dc_bus_undervoltage_v = 450;
        state->dc_bus_overvoltage_v  = 850;
        state->dc_bus_braking_v      = 800;
        state->drive_power_rating_kW = 15;
        break;

    default:
        return 0;
    }

    state->application_macro = 0;
    state->country_code = 0;
    state->language = 0;
    state->cooling_type = 0;
    state->config_valid = 1;

    return 1;
}

void system_settings_init(system_settings_state_t *state)
{
    if (state == 0) return;

    memset(state, 0, sizeof(system_settings_state_t));
    state->initialized = 1;
    state->config_valid = 0;
    system_settings_apply(state, SUPPLY_3PH_400V);
}

void system_settings_update(system_settings_state_t *state)
{
    (void)state;
}
