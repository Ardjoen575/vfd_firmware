#include "user_motor_params.h"
#include <string.h>

uint8_t user_motor_params_apply(user_motor_params_state_t *state,
                                 const equiv_circuit_t *circuit)
{
    if (state == 0 || circuit == 0) return 0;

    if (circuit->rs_microohm == 0 || circuit->rs_microohm > 5000000UL) return 0;
    if (circuit->ls_microH == 0 || circuit->ls_microH > 100000UL) return 0;
    if (circuit->lm_milliH == 0 || circuit->lm_milliH > 5000) return 0;

    state->model.rs_microohm    = circuit->rs_microohm;
    state->model.ls_microH      = circuit->ls_microH;
    state->model.lm_milliH      = circuit->lm_milliH;
    state->model.rotor_inertia_kgcm2 = circuit->rotor_inertia_kgcm2;

    state->saturation_inductance_lsd_mH = (uint16_t)(circuit->ls_microH / 1000);
    state->saturation_inductance_lsq_mH = (uint16_t)(circuit->ls_microH / 1200);

    state->bemf_constant_vpkprpm = (uint16_t)((circuit->lm_milliH * 100UL) / 3300UL);

    state->thermal_time_constant_s = 60;
    state->thermal_resistance_kW   = 100;
    state->mechanical_time_constant_ms =
        (uint32_t)((circuit->rotor_inertia_kgcm2 * 1000UL) / 10UL);

    state->use_custom_params = 1;
    state->params_valid = 1;

    return 1;
}

void user_motor_params_init(user_motor_params_state_t *state)
{
    if (state == 0) return;

    memset(state, 0, sizeof(user_motor_params_state_t));
    state->initialized = 1;
    state->params_valid = 0;
    state->use_custom_params = 0;
}

void user_motor_params_update(user_motor_params_state_t *state)
{
    (void)state;
}
