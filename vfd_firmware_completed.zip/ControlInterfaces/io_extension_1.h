#ifndef CONTROLINTERFACES_IO_EXTENSION_1_H
#define CONTROLINTERFACES_IO_EXTENSION_1_H

/* I/O extension module 1 (grp 14) */

#include <stdint.h>

#define IOEXT1_NUM_DI    2
#define IOEXT1_NUM_DO    1
#define IOEXT1_NUM_AI    1
#define IOEXT1_NUM_AO    1

typedef struct {
    uint8_t raw;
    uint8_t filtered;
    uint8_t invert;
    uint16_t debounce;
    uint8_t stable;
} ioext1_di_t;

typedef struct {
    uint8_t state;
    uint8_t invert;
} ioext1_do_t;

typedef struct {
    int16_t raw_adc;
    float value;
    float offset;
    float gain;
    float filter;
} ioext1_ai_t;

typedef struct {
    float value;
    uint16_t raw_dac;
    float min_val;
    float max_val;
    uint8_t enabled;
} ioext1_ao_t;

typedef struct {
    uint8_t initialized;
    ioext1_di_t di[IOEXT1_NUM_DI];
    ioext1_do_t do_[IOEXT1_NUM_DO];
    ioext1_ai_t ai[IOEXT1_NUM_AI];
    ioext1_ao_t ao[IOEXT1_NUM_AO];
    uint8_t active;
    uint16_t comm_fault_cnt;
} io_extension_1_state_t;

void io_extension_1_init(io_extension_1_state_t *state);
void io_extension_1_update(io_extension_1_state_t *state);
void io_ext1_poll(io_extension_1_state_t *state);

#endif /* CONTROLINTERFACES_IO_EXTENSION_1_H */
