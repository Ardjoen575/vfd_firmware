#ifndef CONTROLINTERFACES_RELAY_OUTPUT_H
#define CONTROLINTERFACES_RELAY_OUTPUT_H

/* Programmable relay outputs */

#include <stdint.h>

#define RELAY_NUM_OUTPUTS      3

typedef struct {
    uint8_t output_state;
    uint8_t delay_on;
    uint8_t delay_off;
    uint16_t on_delay_counter;
    uint16_t off_delay_counter;
    uint8_t source_signal;
    uint8_t inverted;
} relay_output_t;

typedef struct {
    uint8_t initialized;
    relay_output_t relay[RELAY_NUM_OUTPUTS];

    uint8_t sig_ready;
    uint8_t sig_running;
    uint8_t sig_fault;
    uint8_t sig_alarm;
    uint8_t sig_at_speed;
    uint8_t sig_motor_reg;
    uint8_t sig_started;
    uint8_t sig_superv1;
    uint8_t sig_superv2;
    uint8_t sig_superv3;
    uint8_t sig_at_torque;
    uint8_t sig_remote;
    uint8_t sig_at_setpoint;
} relay_output_state_t;

void relay_output_init(relay_output_state_t *state);
void relay_output_update(relay_output_state_t *state);
void relay_set_state(relay_output_state_t *state);

#endif /* CONTROLINTERFACES_RELAY_OUTPUT_H */
