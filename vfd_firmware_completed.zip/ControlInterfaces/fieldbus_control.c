#include "fieldbus_control.h"

#define FB_CTRL_READY      (1 << 0)
#define FB_CTRL_START       (1 << 1)
#define FB_CTRL_STOP        (1 << 2)
#define FB_CTRL_RESET_FAULT (1 << 7)
#define FB_CTRL_JOG1        (1 << 8)
#define FB_CTRL_JOG2        (1 << 9)
#define FB_CTRL_REMOTE_CMD  (1 << 10)
#define FB_CTRL_RAMP_HOLD   (1 << 11)

#define FB_STAT_READY           (1 << 0)
#define FB_STAT_ENABLED         (1 << 1)
#define FB_STAT_STARTED         (1 << 2)
#define FB_STAT_RUNNING         (1 << 3)
#define FB_STAT_AT_SETPOINT     (1 << 8)
#define FB_STAT_FAULT           (1 << 11)
#define FB_STAT_ALARM           (1 << 12)
#define FB_STAT_ABOVE_LIMIT     (1 << 13)

static void fb_parse_control(fieldbus_control_state_t *state)
{
    state->ctrl_word = state->rx_words[0];
    state->ref1 = (float)((int16_t)state->rx_words[1]) / 163.84f;
    state->ref2 = (float)((int16_t)state->rx_words[2]) / 163.84f;

    if (state->ref1 < -100.0f) state->ref1 = -100.0f;
    if (state->ref1 > 100.0f) state->ref1 = 100.0f;
    if (state->ref2 < -100.0f) state->ref2 = -100.0f;
    if (state->ref2 > 100.0f) state->ref2 = 100.0f;
}

static void fb_build_status(fieldbus_control_state_t *state)
{
    state->tx_words[0] = state->stat_word;
    state->tx_words[1] = (uint16_t)((int16_t)(state->act1 * 163.84f));
    state->tx_words[2] = (uint16_t)((int16_t)(state->act2 * 163.84f));
    state->tx_words[3] = state->fault_word;
}

static void fb_timeout_check(fieldbus_control_state_t *state)
{
    if (state->comm_ok) {
        state->timeout_cnt = 0;
    } else {
        state->timeout_cnt++;
        if (state->timeout_cnt >= state->timeout_limit) {
            state->timeout = 1;
            state->ctrl_word = 0;
            state->ref1 = 0.0f;
            state->ref2 = 0.0f;
        }
    }
}

void fieldbus_control_init(fieldbus_control_state_t *state)
{
    int i;
    state->initialized = 1;
    state->comm_ok = 0;
    state->timeout = 1;
    state->timeout_cnt = 0;
    state->timeout_limit = 100;
    state->ctrl_word = 0;
    state->stat_word = 0;
    state->fault_word = 0;
    state->ref1 = 0.0f;
    state->ref2 = 0.0f;
    state->act1 = 0.0f;
    state->act2 = 0.0f;

    for (i = 0; i < FB_NUM_WORDS_IN; i++) {
        state->rx_words[i] = 0;
    }
    for (i = 0; i < FB_NUM_WORDS_OUT; i++) {
        state->tx_words[i] = 0;
    }
}

void fieldbus_control_update(fieldbus_control_state_t *state)
{
    if (!state->initialized) return;

    fb_timeout_check(state);

    if (state->comm_ok && !state->timeout) {
        fb_parse_control(state);
    } else {
        state->ctrl_word = 0;
        state->ref1 = 0.0f;
        state->ref2 = 0.0f;
    }

    fb_build_status(state);
}

void fbctrl_dispatch(fieldbus_control_state_t *state)
{
    uint16_t cmd;

    if (!state->initialized) return;
    if (!state->comm_ok) return;
    if (state->timeout) return;

    cmd = state->ctrl_word;

    if (cmd & FB_CTRL_RESET_FAULT) {
        state->fault_word = 0;
        state->stat_word &= ~FB_STAT_FAULT;
    }

    if (cmd & FB_CTRL_STOP) {
        state->stat_word &= ~FB_STAT_STARTED;
        state->stat_word &= ~FB_STAT_RUNNING;
    }

    if ((cmd & FB_CTRL_START) && (state->stat_word & FB_STAT_READY)) {
        state->stat_word |= FB_STAT_STARTED;
        state->stat_word |= FB_STAT_RUNNING;
    }
}
