#include "relay_output.h"

#define RELAY_SRC_NONE         0
#define RELAY_SRC_READY        1
#define RELAY_SRC_RUNNING      2
#define RELAY_SRC_FAULT        3
#define RELAY_SRC_ALARM        4
#define RELAY_SRC_AT_SPEED     5
#define RELAY_SRC_MOTOR_REG    6
#define RELAY_SRC_STARTED      7
#define RELAY_SRC_SUPERV1      8
#define RELAY_SRC_SUPERV2      9
#define RELAY_SRC_SUPERV3      10
#define RELAY_SRC_AT_TORQUE    11
#define RELAY_SRC_REMOTE       12
#define RELAY_SRC_AT_SETPOINT  13

static uint8_t relay_get_source(relay_output_state_t *state, uint8_t src)
{
    switch (src) {
        case RELAY_SRC_READY:      return state->sig_ready;
        case RELAY_SRC_RUNNING:    return state->sig_running;
        case RELAY_SRC_FAULT:      return state->sig_fault;
        case RELAY_SRC_ALARM:      return state->sig_alarm;
        case RELAY_SRC_AT_SPEED:   return state->sig_at_speed;
        case RELAY_SRC_MOTOR_REG:  return state->sig_motor_reg;
        case RELAY_SRC_STARTED:    return state->sig_started;
        case RELAY_SRC_SUPERV1:    return state->sig_superv1;
        case RELAY_SRC_SUPERV2:    return state->sig_superv2;
        case RELAY_SRC_SUPERV3:    return state->sig_superv3;
        case RELAY_SRC_AT_TORQUE:  return state->sig_at_torque;
        case RELAY_SRC_REMOTE:     return state->sig_remote;
        case RELAY_SRC_AT_SETPOINT:return state->sig_at_setpoint;
        default:                   return 0;
    }
}

void relay_output_init(relay_output_state_t *state)
{
    int i;
    state->initialized = 1;

    state->sig_ready = 0;
    state->sig_running = 0;
    state->sig_fault = 0;
    state->sig_alarm = 0;
    state->sig_at_speed = 0;
    state->sig_motor_reg = 0;
    state->sig_started = 0;
    state->sig_superv1 = 0;
    state->sig_superv2 = 0;
    state->sig_superv3 = 0;
    state->sig_at_torque = 0;
    state->sig_remote = 0;
    state->sig_at_setpoint = 0;

    for (i = 0; i < RELAY_NUM_OUTPUTS; i++) {
        state->relay[i].output_state = 0;
        state->relay[i].delay_on = 0;
        state->relay[i].delay_off = 0;
        state->relay[i].on_delay_counter = 0;
        state->relay[i].off_delay_counter = 0;
        state->relay[i].source_signal = RELAY_SRC_READY;
        state->relay[i].inverted = 0;
    }
}

void relay_output_update(relay_output_state_t *state)
{
    int i;
    if (!state->initialized) return;

    for (i = 0; i < RELAY_NUM_OUTPUTS; i++) {
        relay_output_t *r = &state->relay[i];
        uint8_t src_val = relay_get_source(state, r->source_signal);
        uint8_t desired;

        if (src_val) {
            if (r->on_delay_counter < r->delay_on) {
                r->on_delay_counter++;
                desired = 0;
            } else {
                r->off_delay_counter = 0;
                desired = 1;
            }
        } else {
            if (r->off_delay_counter < r->delay_off) {
                r->off_delay_counter++;
                desired = 1;
            } else {
                r->on_delay_counter = 0;
                desired = 0;
            }
        }

        if (r->inverted) {
            desired = (desired == 0) ? 1 : 0;
        }
        r->output_state = desired;
    }
}

void relay_set_state(relay_output_state_t *state)
{
    int i;
    if (!state->initialized) return;

    for (i = 0; i < RELAY_NUM_OUTPUTS; i++) {
        relay_output_t *r = &state->relay[i];
        uint8_t src_val = relay_get_source(state, r->source_signal);
        uint8_t desired;

        desired = src_val;
        if (r->inverted) {
            desired = (desired == 0) ? 1 : 0;
        }
        r->output_state = desired;
        r->on_delay_counter = 0;
        r->off_delay_counter = 0;
    }
}
