#ifndef CONTROLINTERFACES_DIGITAL_IO_H
#define CONTROLINTERFACES_DIGITAL_IO_H

/* Standard DI/DO (grp 10) */

#include <stdint.h>

#define DIO_NUM_INPUTS    6
#define DIO_NUM_OUTPUTS   3

typedef struct {
    uint8_t raw_state;
    uint8_t stable_state;
    uint8_t prev_state;
    uint16_t debounce_counter;
    uint8_t inverted;
} dio_input_t;

typedef struct {
    uint8_t state;
    uint8_t inverted;
} dio_output_t;

typedef struct {
    uint8_t initialized;
    dio_input_t input[DIO_NUM_INPUTS];
    dio_output_t output[DIO_NUM_OUTPUTS];
    uint32_t tick_count;
} digital_io_state_t;

void digital_io_init(digital_io_state_t *state);
void digital_io_update(digital_io_state_t *state);
void dio_read_input(digital_io_state_t *state);
void dio_write_output(digital_io_state_t *state);

#endif /* CONTROLINTERFACES_DIGITAL_IO_H */
