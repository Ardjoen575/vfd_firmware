#include "io_extension_3.h"

void io_extension_3_init(io_extension_3_state_t *state)
{
    int i;
    state->initialized = 1;
    state->active = 0;
    state->comm_fault_cnt = 0;

    for (i = 0; i < IOEXT3_NUM_DI; i++) {
        state->di[i].raw = 0;
        state->di[i].filtered = 0;
        state->di[i].invert = 0;
        state->di[i].debounce = 0;
        state->di[i].stable = 0;
    }

    for (i = 0; i < IOEXT3_NUM_DO; i++) {
        state->do_[i].state = 0;
        state->do_[i].invert = 0;
    }

    for (i = 0; i < IOEXT3_NUM_AI; i++) {
        state->ai[i].raw_adc = 0;
        state->ai[i].value = 0.0f;
        state->ai[i].offset = 0.0f;
        state->ai[i].gain = 1.0f;
        state->ai[i].filter = 0.92f;
    }

    for (i = 0; i < IOEXT3_NUM_AO; i++) {
        state->ao[i].value = 0.0f;
        state->ao[i].raw_dac = 0;
        state->ao[i].min_val = 0.0f;
        state->ao[i].max_val = 100.0f;
        state->ao[i].enabled = 0;
    }
}

void io_extension_3_update(io_extension_3_state_t *state)
{
    int i;
    if (!state->initialized) return;

    if (!state->active) {
        state->comm_fault_cnt++;
        if (state->comm_fault_cnt > 500) {
            state->comm_fault_cnt = 500;
        }
        return;
    }
    state->comm_fault_cnt = 0;

    for (i = 0; i < IOEXT3_NUM_DI; i++) {
        ioext3_di_t *d = &state->di[i];
        if (d->raw != d->filtered) {
            d->debounce++;
            if (d->debounce >= 12) {
                d->stable = d->raw;
                d->filtered = d->raw;
                d->debounce = 0;
            }
        } else {
            d->debounce = 0;
        }
    }

    for (i = 0; i < IOEXT3_NUM_AI; i++) {
        ioext3_ai_t *a = &state->ai[i];
        float raw_val = ((float)a->raw_adc / 4095.0f) * 100.0f;
        raw_val = (raw_val * a->gain) + a->offset;
        a->value = (a->filter * a->value) + ((1.0f - a->filter) * raw_val);
    }

    for (i = 0; i < IOEXT3_NUM_AO; i++) {
        ioext3_ao_t *o = &state->ao[i];
        if (o->enabled) {
            float norm = (o->value - o->min_val) / (o->max_val - o->min_val);
            if (norm < 0.0f) norm = 0.0f;
            if (norm > 1.0f) norm = 1.0f;
            o->raw_dac = (uint16_t)(norm * 4095.0f);
        } else {
            o->raw_dac = 0;
        }
    }
}

void io_ext3_poll(io_extension_3_state_t *state)
{
    if (!state->initialized) return;
    state->active = 1;
}
