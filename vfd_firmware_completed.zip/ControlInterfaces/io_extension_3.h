#ifndef CONTROLINTERFACES_IO_EXTENSION_3_H
#define CONTROLINTERFACES_IO_EXTENSION_3_H

/* I/O extension module 3 (grp 16) */

#include <stdint.h>

#define IOEXT3_NUM_DI    2
#define IOEXT3_NUM_DO    1
#define IOEXT3_NUM_AI    2
#define IOEXT3_NUM_AO    1

typedef struct {
    uint8_t raw;
    uint8_t filtered;
    uint8_t invert;
    uint16_t debounce;
    uint8_t stable;
} ioext3_di_t;

typedef struct {
    uint8_t state;
    uint8_t invert;
} ioext3_do_t;

typedef struct {
    int16_t raw_adc;
    float value;
    float offset;
    float gain;
    float filter;
} ioext3_ai_t;

typedef struct {
    float value;
    uint16_t raw_dac;
    float min_val;
    float max_val;
    uint8_t enabled;
} ioext3_ao_t;

typedef struct {
    uint8_t initialized;
    ioext3_di_t di[IOEXT3_NUM_DI];
    ioext3_do_t do_[IOEXT3_NUM_DO];
    ioext3_ai_t ai[IOEXT3_NUM_AI];
    ioext3_ao_t ao[IOEXT3_NUM_AO];
    uint8_t active;
    uint16_t comm_fault_cnt;
} io_extension_3_state_t;

void io_extension_3_init(io_extension_3_state_t *state);
void io_extension_3_update(io_extension_3_state_t *state);
void io_ext3_poll(io_extension_3_state_t *state);

#endif /* CONTROLINTERFACES_IO_EXTENSION_3_H */
