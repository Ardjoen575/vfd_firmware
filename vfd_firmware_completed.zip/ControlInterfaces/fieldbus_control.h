#ifndef CONTROLINTERFACES_FIELDBUS_CONTROL_H
#define CONTROLINTERFACES_FIELDBUS_CONTROL_H

/* Fieldbus control overview/dispatch */

#include <stdint.h>

#define FB_NUM_WORDS_IN  12
#define FB_NUM_WORDS_OUT 12

typedef struct {
    uint8_t initialized;
    uint16_t rx_words[FB_NUM_WORDS_IN];
    uint16_t tx_words[FB_NUM_WORDS_OUT];

    uint8_t comm_ok;
    uint8_t timeout;
    uint16_t timeout_cnt;
    uint16_t timeout_limit;

    float ref1;
    float ref2;
    float act1;
    float act2;

    uint16_t ctrl_word;
    uint16_t stat_word;
    uint16_t fault_word;
} fieldbus_control_state_t;

void fieldbus_control_init(fieldbus_control_state_t *state);
void fieldbus_control_update(fieldbus_control_state_t *state);
void fbctrl_dispatch(fieldbus_control_state_t *state);

#endif /* CONTROLINTERFACES_FIELDBUS_CONTROL_H */
