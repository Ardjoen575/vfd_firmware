#include "external_controller_if.h"

static void extctrl_scale_setpoint(external_controller_if_state_t *state)
{
    float range = state->setpoint_max - state->setpoint_min;
    if (range <= 0.0f) {
        state->pid_setpoint = 0.0f;
        return;
    }
    state->pid_setpoint = ((state->ext_setpoint - state->setpoint_min) / range) * 100.0f;
    if (state->pid_setpoint < 0.0f) state->pid_setpoint = 0.0f;
    if (state->pid_setpoint > 100.0f) state->pid_setpoint = 100.0f;
}

static void extctrl_scale_feedback(external_controller_if_state_t *state)
{
    float range = state->feedback_max - state->feedback_min;
    if (range <= 0.0f) {
        state->pid_feedback = 0.0f;
        return;
    }
    state->pid_feedback = ((state->ext_feedback - state->feedback_min) / range) * 100.0f;
    if (state->pid_feedback < 0.0f) state->pid_feedback = 0.0f;
    if (state->pid_feedback > 100.0f) state->pid_feedback = 100.0f;
}

static void extctrl_check_loss(external_controller_if_state_t *state)
{
    if (state->active) {
        state->comm_loss_cnt = 0;
        state->comm_loss = 0;
    } else {
        state->comm_loss_cnt++;
        if (state->comm_loss_cnt >= state->comm_loss_limit) {
            state->comm_loss = 1;
            state->pid_setpoint = 0.0f;
            state->pid_feedback = 0.0f;
            state->pid_output = 0.0f;
        }
    }
}

void external_controller_if_init(external_controller_if_state_t *state)
{
    state->initialized = 1;
    state->enabled = 0;
    state->active = 0;

    state->ext_setpoint = 0.0f;
    state->ext_feedback = 0.0f;
    state->ext_output = 0.0f;

    state->setpoint_min = 0.0f;
    state->setpoint_max = 100.0f;
    state->feedback_min = 0.0f;
    state->feedback_max = 100.0f;

    state->pid_setpoint = 0.0f;
    state->pid_feedback = 0.0f;
    state->pid_output = 0.0f;

    state->comm_loss_cnt = 0;
    state->comm_loss_limit = 500;
    state->comm_loss = 1;
}

void external_controller_if_update(external_controller_if_state_t *state)
{
    if (!state->initialized) return;
    if (!state->enabled) return;

    extctrl_check_loss(state);

    if (!state->comm_loss) {
        extctrl_scale_setpoint(state);
        extctrl_scale_feedback(state);
    } else {
        state->pid_setpoint = 0.0f;
        state->pid_feedback = 0.0f;
    }

    state->ext_output = state->pid_output;
}

void extctrl_exchange(external_controller_if_state_t *state)
{
    if (!state->initialized) return;
    state->active = 1;
}
