#include "master_follower.h"

void master_follower_init(master_follower_state_t *state)
{
    state->initialized = 1;
    state->mode = MF_MODE_MASTER;
    state->ref_select = MF_REF_SPEED;
    state->link_ok = 0;
    state->active = 0;

    state->speed_ref_out = 0.0f;
    state->torque_ref_out = 0.0f;
    state->speed_ref_in = 0.0f;
    state->torque_ref_in = 0.0f;

    state->follower_gain = 1.0f;
    state->follower_offset = 0.0f;

    state->comm_loss_cnt = 0;
    state->comm_loss_limit = 200;
    state->comm_loss = 1;

    state->master_drive_ready = 0;
    state->follower_drive_ready = 0;
    state->watchdog_active = 0;
}

void master_follower_update(master_follower_state_t *state)
{
    if (!state->initialized) return;

    if (!state->link_ok) {
        state->comm_loss_cnt++;
        if (state->comm_loss_cnt >= state->comm_loss_limit) {
            state->comm_loss = 1;
            if (state->mode == MF_MODE_FOLLOWER) {
                state->speed_ref_in = 0.0f;
                state->torque_ref_in = 0.0f;
            }
        }
    } else {
        state->comm_loss_cnt = 0;
        state->comm_loss = 0;
    }

    if (state->mode == MF_MODE_FOLLOWER && state->link_ok && !state->comm_loss) {
        if (state->ref_select == MF_REF_SPEED) {
            state->speed_ref_in = (state->speed_ref_in * state->follower_gain)
                                  + state->follower_offset;
        }
        if (state->ref_select == MF_REF_TORQUE) {
            state->torque_ref_in = (state->torque_ref_in * state->follower_gain)
                                   + state->follower_offset;
        }
    }
}

void mf_sync_step(master_follower_state_t *state)
{
    if (!state->initialized) return;

    if (state->mode == MF_MODE_MASTER && state->link_ok) {
    } else if (state->mode == MF_MODE_FOLLOWER && state->link_ok) {
    }
}
