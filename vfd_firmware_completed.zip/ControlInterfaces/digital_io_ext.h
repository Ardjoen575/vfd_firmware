#ifndef CONTROLINTERFACES_DIGITAL_IO_EXT_H
#define CONTROLINTERFACES_DIGITAL_IO_EXT_H

/* Standard DIO/FI/FO (grp 11) */

#include <stdint.h>

#define DIOE_NUM_DI     6
#define DIOE_NUM_DO     2
#define DIOE_NUM_FI     1
#define DIOE_NUM_FO     1

typedef struct {
    uint8_t state;
    uint8_t inverted;
} dioe_digital_t;

typedef struct {
    uint32_t pulse_count;
    uint32_t prev_pulse_count;
    float frequency_hz;
    float scaled_freq;
    float freq_max;
} dioe_freq_in_t;

typedef struct {
    float requested_freq;
    float actual_freq;
    float freq_max;
    uint8_t enabled;
} dioe_freq_out_t;

typedef struct {
    uint8_t initialized;
    dioe_digital_t di[DIOE_NUM_DI];
    dioe_digital_t dio[DIOE_NUM_DO];
    dioe_freq_in_t fi[DIOE_NUM_FI];
    dioe_freq_out_t fo[DIOE_NUM_FO];
    uint32_t cycle_time_us;
} digital_io_ext_state_t;

void digital_io_ext_init(digital_io_ext_state_t *state);
void digital_io_ext_update(digital_io_ext_state_t *state);
void dio_ext_configure(digital_io_ext_state_t *state);

#endif /* CONTROLINTERFACES_DIGITAL_IO_EXT_H */
