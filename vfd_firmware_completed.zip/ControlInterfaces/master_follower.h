#ifndef CONTROLINTERFACES_MASTER_FOLLOWER_H
#define CONTROLINTERFACES_MASTER_FOLLOWER_H

/* Master/follower link functionality */

#include <stdint.h>

#define MF_MODE_MASTER   0
#define MF_MODE_FOLLOWER 1
#define MF_REF_SPEED     0
#define MF_REF_TORQUE    1

typedef struct {
    uint8_t initialized;
    uint8_t mode;
    uint8_t ref_select;
    uint8_t link_ok;
    uint8_t active;

    float speed_ref_out;
    float torque_ref_out;
    float speed_ref_in;
    float torque_ref_in;

    float follower_gain;
    float follower_offset;

    uint16_t comm_loss_cnt;
    uint16_t comm_loss_limit;
    uint8_t comm_loss;

    uint8_t master_drive_ready;
    uint8_t follower_drive_ready;
    uint8_t watchdog_active;
} master_follower_state_t;

void master_follower_init(master_follower_state_t *state);
void master_follower_update(master_follower_state_t *state);
void mf_sync_step(master_follower_state_t *state);

#endif /* CONTROLINTERFACES_MASTER_FOLLOWER_H */
