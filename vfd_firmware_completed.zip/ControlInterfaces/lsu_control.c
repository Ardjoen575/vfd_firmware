#include "lsu_control.h"

#define LSU_CMD_NONE            0
#define LSU_CMD_START_CHARGE    1
#define LSU_CMD_CLOSE_MAIN      2
#define LSU_CMD_STOP            3
#define LSU_CMD_EMERGENCY_STOP  4
#define LSU_CMD_RESET_FAULT     5

static void lsu_state_machine(lsu_control_state_t *state)
{
    switch (state->state) {
        case LSU_STATE_OFF:
            if (state->cmd == LSU_CMD_START_CHARGE && state->supply_ok) {
                state->state = LSU_STATE_PRECHARGE;
                state->precharge_timer = 0;
                state->precharge_done = 0;
                state->main_contactor_closed = 0;
            }
            break;

        case LSU_STATE_PRECHARGE:
            state->precharge_timer++;
            if (state->dc_voltage >= state->dc_voltage_min * 0.85f
                && state->charge_current <= state->charge_current_max) {
                if (state->precharge_timer >= state->precharge_timeout) {
                    state->precharge_done = 1;
                    state->state = LSU_STATE_STANDBY;
                    state->main_contactor_timer = 0;
                }
            }
            if (state->precharge_timer > state->precharge_timeout * 2) {
                state->fault_active = 1;
                state->state = LSU_STATE_FAULT;
            }
            if (state->cmd == LSU_CMD_STOP || state->cmd == LSU_CMD_EMERGENCY_STOP) {
                state->state = LSU_STATE_OFF;
                state->precharge_done = 0;
            }
            break;

        case LSU_STATE_STANDBY:
            if (state->cmd == LSU_CMD_CLOSE_MAIN && state->precharge_done) {
                state->main_contactor_timer++;
                if (state->main_contactor_timer >= state->main_contactor_delay) {
                    state->main_contactor_closed = 1;
                    state->state = LSU_STATE_RUNNING;
                }
            }
            if (state->cmd == LSU_CMD_STOP) {
                state->state = LSU_STATE_OFF;
                state->main_contactor_closed = 0;
            }
            break;

        case LSU_STATE_RUNNING:
            if (state->dc_voltage > state->dc_voltage_max
                || state->dc_voltage < state->dc_voltage_min) {
                state->fault_active = 1;
                state->state = LSU_STATE_FAULT;
                state->main_contactor_closed = 0;
            }
            if (state->cmd == LSU_CMD_STOP) {
                state->main_contactor_closed = 0;
                state->state = LSU_STATE_OFF;
            }
            if (state->cmd == LSU_CMD_EMERGENCY_STOP) {
                state->main_contactor_closed = 0;
                state->state = LSU_STATE_OFF;
            }
            break;

        case LSU_STATE_FAULT:
            state->main_contactor_closed = 0;
            if (state->cmd == LSU_CMD_RESET_FAULT) {
                if (state->dc_voltage < 60.0f) {
                    state->fault_active = 0;
                    state->state = LSU_STATE_OFF;
                }
            }
            break;

        case LSU_STATE_COASTING:
            state->main_contactor_closed = 0;
            if (state->dc_voltage < 60.0f) {
                state->state = LSU_STATE_OFF;
            }
            break;

        default:
            state->state = LSU_STATE_OFF;
            break;
    }

    state->ready = (state->state == LSU_STATE_STANDBY || state->state == LSU_STATE_RUNNING);
    state->running = (state->state == LSU_STATE_RUNNING);
    state->prev_cmd = state->cmd;
}

void lsu_control_init(lsu_control_state_t *state)
{
    state->initialized = 1;
    state->state = LSU_STATE_OFF;
    state->cmd = LSU_CMD_NONE;
    state->prev_cmd = LSU_CMD_NONE;
    state->main_contactor_closed = 0;
    state->precharge_done = 0;
    state->fault_active = 0;

    state->precharge_timer = 0;
    state->precharge_timeout = 300;
    state->main_contactor_delay = 50;
    state->main_contactor_timer = 0;

    state->dc_voltage = 0.0f;
    state->dc_voltage_nom = 540.0f;
    state->dc_voltage_min = 350.0f;
    state->dc_voltage_max = 800.0f;

    state->charge_current = 0.0f;
    state->charge_current_max = 10.0f;

    state->supply_ok = 0;
    state->ready = 0;
    state->running = 0;
}

void lsu_control_update(lsu_control_state_t *state)
{
    if (!state->initialized) return;

    lsu_state_machine(state);
}

void lsu_send_command(lsu_control_state_t *state)
{
    if (!state->initialized) return;

    switch (state->state) {
        case LSU_STATE_OFF:
            state->cmd = LSU_CMD_NONE;
            break;
        case LSU_STATE_PRECHARGE:
            if (!state->precharge_done) {
                state->cmd = LSU_CMD_START_CHARGE;
            }
            break;
        case LSU_STATE_STANDBY:
            state->cmd = LSU_CMD_CLOSE_MAIN;
            break;
        case LSU_STATE_RUNNING:
            state->main_contactor_closed = 1;
            break;
        case LSU_STATE_FAULT:
            break;
        case LSU_STATE_COASTING:
            break;
        default:
            break;
    }
}
