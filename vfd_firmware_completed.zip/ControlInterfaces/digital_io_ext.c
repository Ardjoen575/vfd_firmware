#include "digital_io_ext.h"

void digital_io_ext_init(digital_io_ext_state_t *state)
{
    int i;
    state->initialized = 1;
    state->cycle_time_us = 1000;

    for (i = 0; i < DIOE_NUM_DI; i++) {
        state->di[i].state = 0;
        state->di[i].inverted = 0;
    }

    for (i = 0; i < DIOE_NUM_DO; i++) {
        state->dio[i].state = 0;
        state->dio[i].inverted = 0;
    }

    for (i = 0; i < DIOE_NUM_FI; i++) {
        state->fi[i].pulse_count = 0;
        state->fi[i].prev_pulse_count = 0;
        state->fi[i].frequency_hz = 0.0f;
        state->fi[i].scaled_freq = 0.0f;
        state->fi[i].freq_max = 30000.0f;
    }

    for (i = 0; i < DIOE_NUM_FO; i++) {
        state->fo[i].requested_freq = 0.0f;
        state->fo[i].actual_freq = 0.0f;
        state->fo[i].freq_max = 16000.0f;
        state->fo[i].enabled = 0;
    }
}

void digital_io_ext_update(digital_io_ext_state_t *state)
{
    int i;
    if (!state->initialized) return;

    for (i = 0; i < DIOE_NUM_FI; i++) {
        dioe_freq_in_t *f = &state->fi[i];
        uint32_t delta = f->pulse_count - f->prev_pulse_count;

        if (state->cycle_time_us > 0) {
            f->frequency_hz = (float)(delta * 1000000UL) / (float)state->cycle_time_us;
        }
        f->scaled_freq = (f->frequency_hz / f->freq_max) * 100.0f;
        if (f->scaled_freq > 100.0f) f->scaled_freq = 100.0f;
        if (f->scaled_freq < 0.0f) f->scaled_freq = 0.0f;

        f->prev_pulse_count = f->pulse_count;
    }
}

void dio_ext_configure(digital_io_ext_state_t *state)
{
    int i;
    if (!state->initialized) return;

    for (i = 0; i < DIOE_NUM_FI; i++) {
        state->fi[i].pulse_count = 0;
        state->fi[i].prev_pulse_count = 0;
        state->fi[i].frequency_hz = 0.0f;
        state->fi[i].scaled_freq = 0.0f;
    }

    for (i = 0; i < DIOE_NUM_FO; i++) {
        state->fo[i].actual_freq = 0.0f;
        state->fo[i].enabled = 0;
    }
}
