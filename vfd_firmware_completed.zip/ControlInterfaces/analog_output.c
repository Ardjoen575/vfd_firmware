#include "analog_output.h"

static void ao_calc_dac(ao_channel_t *ch)
{
    float norm;

    if (ch->output_range == 1) {
        norm = ch->requested_value / 100.0f;
        ch->scaled_dac = (norm * 0.8f) + 0.2f;
    } else {
        ch->scaled_dac = ch->requested_value / 100.0f;
    }

    if (ch->scaled_dac < 0.0f) ch->scaled_dac = 0.0f;
    if (ch->scaled_dac > 1.0f) ch->scaled_dac = 1.0f;

    ch->raw_dac = (uint16_t)(ch->scaled_dac * 4095.0f);
}

void analog_output_init(analog_output_state_t *state)
{
    int ch;
    state->initialized = 1;
    state->fault = 0;

    for (ch = 0; ch < AO_NUM_CHANNELS; ch++) {
        state->channel[ch].requested_value = 0.0f;
        state->channel[ch].scaled_dac = 0.0f;
        state->channel[ch].raw_dac = 0;
        state->channel[ch].output_range = 0;
        state->channel[ch].enabled = 0;
    }
}

void analog_output_update(analog_output_state_t *state)
{
    int ch;
    if (!state->initialized) return;

    for (ch = 0; ch < AO_NUM_CHANNELS; ch++) {
        ao_channel_t *c = &state->channel[ch];
        if (c->enabled && state->fault == 0) {
            ao_calc_dac(c);
        } else {
            c->raw_dac = 0;
            c->scaled_dac = 0.0f;
        }
    }
}

void ao_write_value(analog_output_state_t *state)
{
    int ch;
    if (!state->initialized) return;

    for (ch = 0; ch < AO_NUM_CHANNELS; ch++) {
        ao_channel_t *c = &state->channel[ch];
        ao_calc_dac(c);

        if (!c->enabled || state->fault) {
            c->raw_dac = 0;
        }
    }
}
