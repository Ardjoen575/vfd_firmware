#ifndef CONTROLINTERFACES_ANALOG_OUTPUT_H
#define CONTROLINTERFACES_ANALOG_OUTPUT_H

/* Programmable analog outputs (grp 13) */

#include <stdint.h>

#define AO_NUM_CHANNELS      2

typedef struct {
    float requested_value;
    float scaled_dac;
    uint16_t raw_dac;
    uint8_t output_range;
    uint8_t enabled;
} ao_channel_t;

typedef struct {
    uint8_t initialized;
    ao_channel_t channel[AO_NUM_CHANNELS];
    uint8_t fault;
} analog_output_state_t;

void analog_output_init(analog_output_state_t *state);
void analog_output_update(analog_output_state_t *state);
void ao_write_value(analog_output_state_t *state);

#endif /* CONTROLINTERFACES_ANALOG_OUTPUT_H */
