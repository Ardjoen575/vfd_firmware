#include "digital_io.h"

void digital_io_init(digital_io_state_t *state)
{
    int i;
    state->initialized = 1;
    state->tick_count = 0;

    for (i = 0; i < DIO_NUM_INPUTS; i++) {
        state->input[i].raw_state = 0;
        state->input[i].stable_state = 0;
        state->input[i].prev_state = 0;
        state->input[i].debounce_counter = 0;
        state->input[i].inverted = 0;
    }

    for (i = 0; i < DIO_NUM_OUTPUTS; i++) {
        state->output[i].state = 0;
        state->output[i].inverted = 0;
    }
}

void digital_io_update(digital_io_state_t *state)
{
    int i;
    if (!state->initialized) return;

    state->tick_count++;

    for (i = 0; i < DIO_NUM_INPUTS; i++) {
        dio_input_t *in = &state->input[i];
        if (in->raw_state != in->prev_state) {
            in->debounce_counter++;
            if (in->debounce_counter >= 10) {
                in->stable_state = in->raw_state;
                in->debounce_counter = 0;
            }
        } else {
            in->debounce_counter = 0;
        }
        in->prev_state = in->raw_state;
    }
}

void dio_read_input(digital_io_state_t *state)
{
    int i;
    if (!state->initialized) return;

    for (i = 0; i < DIO_NUM_INPUTS; i++) {
        dio_input_t *in = &state->input[i];

        if (in->raw_state != in->prev_state) {
            in->debounce_counter++;
            if (in->debounce_counter >= 10) {
                in->stable_state = in->raw_state;
                in->debounce_counter = 0;
            }
        } else {
            in->debounce_counter = 0;
        }
        in->prev_state = in->raw_state;
    }
}

void dio_write_output(digital_io_state_t *state)
{
    int i;
    if (!state->initialized) return;

    for (i = 0; i < DIO_NUM_OUTPUTS; i++) {
        uint8_t out = state->output[i].state;
        if (state->output[i].inverted) {
            out = (out == 0) ? 1 : 0;
        }
    }
}
