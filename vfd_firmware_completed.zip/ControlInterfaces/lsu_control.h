#ifndef CONTROLINTERFACES_LSU_CONTROL_H
#define CONTROLINTERFACES_LSU_CONTROL_H

/* Control of a supply unit / LSU (grp 94) */

#include <stdint.h>

#define LSU_STATE_OFF           0
#define LSU_STATE_PRECHARGE     1
#define LSU_STATE_STANDBY       2
#define LSU_STATE_RUNNING       3
#define LSU_STATE_FAULT         4
#define LSU_STATE_COASTING      5

typedef struct {
    uint8_t initialized;
    uint8_t state;
    uint8_t cmd;
    uint8_t prev_cmd;
    uint8_t main_contactor_closed;
    uint8_t precharge_done;
    uint8_t fault_active;

    uint16_t precharge_timer;
    uint16_t precharge_timeout;
    uint16_t main_contactor_delay;
    uint16_t main_contactor_timer;

    float dc_voltage;
    float dc_voltage_nom;
    float dc_voltage_min;
    float dc_voltage_max;

    float charge_current;
    float charge_current_max;

    uint8_t supply_ok;
    uint8_t ready;
    uint8_t running;
} lsu_control_state_t;

void lsu_control_init(lsu_control_state_t *state);
void lsu_control_update(lsu_control_state_t *state);
void lsu_send_command(lsu_control_state_t *state);

#endif /* CONTROLINTERFACES_LSU_CONTROL_H */
