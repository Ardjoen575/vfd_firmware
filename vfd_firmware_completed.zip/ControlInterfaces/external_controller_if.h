#ifndef CONTROLINTERFACES_EXTERNAL_CONTROLLER_IF_H
#define CONTROLINTERFACES_EXTERNAL_CONTROLLER_IF_H

/* External controller interface */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    uint8_t enabled;
    uint8_t active;

    float ext_setpoint;
    float ext_feedback;
    float ext_output;

    float setpoint_min;
    float setpoint_max;
    float feedback_min;
    float feedback_max;

    float pid_setpoint;
    float pid_feedback;
    float pid_output;

    uint16_t comm_loss_cnt;
    uint16_t comm_loss_limit;
    uint8_t comm_loss;
} external_controller_if_state_t;

void external_controller_if_init(external_controller_if_state_t *state);
void external_controller_if_update(external_controller_if_state_t *state);
void extctrl_exchange(external_controller_if_state_t *state);

#endif /* CONTROLINTERFACES_EXTERNAL_CONTROLLER_IF_H */
