#ifndef CONTROLINTERFACES_ANALOG_INPUT_H
#define CONTROLINTERFACES_ANALOG_INPUT_H

/* Programmable analog inputs (grp 12) */

#include <stdint.h>

#define AI_NUM_CHANNELS    2

typedef enum {
    AI_MODE_0_10V = 0,
    AI_MODE_4_20MA = 1
} ai_mode_t;

typedef struct {
    int16_t raw_adc;
    float scaled_value;
    float filtered_value;
    float offset;
    float gain;
    ai_mode_t mode;
} ai_channel_t;

typedef struct {
    uint8_t initialized;
    ai_channel_t channel[AI_NUM_CHANNELS];
    uint8_t fault;
} analog_input_state_t;

void analog_input_init(analog_input_state_t *state);
void analog_input_update(analog_input_state_t *state);
void ai_scale_value(analog_input_state_t *state);

#endif /* CONTROLINTERFACES_ANALOG_INPUT_H */
