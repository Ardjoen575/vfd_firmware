#ifndef CONTROLINTERFACES_IO_EXTENSION_2_H
#define CONTROLINTERFACES_IO_EXTENSION_2_H

/* I/O extension module 2 (grp 15) */

#include <stdint.h>

#define IOEXT2_NUM_DI    3
#define IOEXT2_NUM_DO    2
#define IOEXT2_NUM_AI    1

typedef struct {
    uint8_t raw;
    uint8_t filtered;
    uint8_t invert;
    uint16_t debounce;
    uint8_t stable;
} ioext2_di_t;

typedef struct {
    uint8_t state;
    uint8_t invert;
} ioext2_do_t;

typedef struct {
    int16_t raw_adc;
    float value;
    float offset;
    float gain;
    float filter;
} ioext2_ai_t;

typedef struct {
    uint8_t initialized;
    ioext2_di_t di[IOEXT2_NUM_DI];
    ioext2_do_t do_[IOEXT2_NUM_DO];
    ioext2_ai_t ai[IOEXT2_NUM_AI];
    uint8_t active;
    uint16_t comm_fault_cnt;
} io_extension_2_state_t;

void io_extension_2_init(io_extension_2_state_t *state);
void io_extension_2_update(io_extension_2_state_t *state);
void io_ext2_poll(io_extension_2_state_t *state);

#endif /* CONTROLINTERFACES_IO_EXTENSION_2_H */
