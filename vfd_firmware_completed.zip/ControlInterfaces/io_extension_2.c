#include "io_extension_2.h"

void io_extension_2_init(io_extension_2_state_t *state)
{
    int i;
    state->initialized = 1;
    state->active = 0;
    state->comm_fault_cnt = 0;

    for (i = 0; i < IOEXT2_NUM_DI; i++) {
        state->di[i].raw = 0;
        state->di[i].filtered = 0;
        state->di[i].invert = 0;
        state->di[i].debounce = 0;
        state->di[i].stable = 0;
    }

    for (i = 0; i < IOEXT2_NUM_DO; i++) {
        state->do_[i].state = 0;
        state->do_[i].invert = 0;
    }

    for (i = 0; i < IOEXT2_NUM_AI; i++) {
        state->ai[i].raw_adc = 0;
        state->ai[i].value = 0.0f;
        state->ai[i].offset = 0.0f;
        state->ai[i].gain = 1.0f;
        state->ai[i].filter = 0.88f;
    }
}

void io_extension_2_update(io_extension_2_state_t *state)
{
    int i;
    if (!state->initialized) return;

    if (!state->active) {
        state->comm_fault_cnt++;
        if (state->comm_fault_cnt > 500) {
            state->comm_fault_cnt = 500;
        }
        return;
    }
    state->comm_fault_cnt = 0;

    for (i = 0; i < IOEXT2_NUM_DI; i++) {
        ioext2_di_t *d = &state->di[i];
        if (d->raw != d->filtered) {
            d->debounce++;
            if (d->debounce >= 8) {
                d->stable = d->raw;
                d->filtered = d->raw;
                d->debounce = 0;
            }
        } else {
            d->debounce = 0;
        }
    }

    for (i = 0; i < IOEXT2_NUM_AI; i++) {
        ioext2_ai_t *a = &state->ai[i];
        float raw_val = ((float)a->raw_adc / 4095.0f) * 100.0f;
        raw_val = (raw_val * a->gain) + a->offset;
        a->value = (a->filter * a->value) + ((1.0f - a->filter) * raw_val);
    }
}

void io_ext2_poll(io_extension_2_state_t *state)
{
    if (!state->initialized) return;
    state->active = 1;
}
