#include "analog_input.h"

static float ai_convert_raw(int16_t raw, ai_mode_t mode, float offset, float gain)
{
    float norm = (float)raw / 4095.0f;
    float eng;

    if (mode == AI_MODE_4_20MA) {
        if (norm < 0.004f) {
            return 0.0f;
        }
        eng = ((norm - 0.2f) / 0.8f) * 100.0f;
    } else {
        eng = norm * 100.0f;
    }
    eng = (eng * gain) + offset;
    if (eng < 0.0f) eng = 0.0f;
    if (eng > 100.0f) eng = 100.0f;
    return eng;
}

void analog_input_init(analog_input_state_t *state)
{
    int ch;
    state->initialized = 1;
    state->fault = 0;

    for (ch = 0; ch < AI_NUM_CHANNELS; ch++) {
        state->channel[ch].raw_adc = 0;
        state->channel[ch].scaled_value = 0.0f;
        state->channel[ch].filtered_value = 0.0f;
        state->channel[ch].offset = 0.0f;
        state->channel[ch].gain = 1.0f;
        state->channel[ch].mode = AI_MODE_0_10V;
    }
}

void analog_input_update(analog_input_state_t *state)
{
    int ch;
    if (!state->initialized) return;

    for (ch = 0; ch < AI_NUM_CHANNELS; ch++) {
        ai_channel_t *c = &state->channel[ch];

        c->scaled_value = ai_convert_raw(c->raw_adc, c->mode, c->offset, c->gain);

        if (state->fault == 0) {
            c->filtered_value = (0.85f * c->filtered_value) +
                                ((1.0f - 0.85f) * c->scaled_value);
        } else {
            c->filtered_value = 0.0f;
        }
    }
}

void ai_scale_value(analog_input_state_t *state)
{
    int ch;
    if (!state->initialized) return;

    for (ch = 0; ch < AI_NUM_CHANNELS; ch++) {
        ai_channel_t *c = &state->channel[ch];

        if (c->mode == AI_MODE_4_20MA && c->raw_adc < 164) {
            state->fault = 1;
        }
        c->filtered_value = ai_convert_raw(c->raw_adc, c->mode, c->offset, c->gain);
    }
}
