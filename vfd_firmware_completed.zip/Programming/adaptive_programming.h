#ifndef PROGRAMMING_ADAPTIVE_PROGRAMMING_H
#define PROGRAMMING_ADAPTIVE_PROGRAMMING_H

#include <stdint.h>

#define ADPT_MAX_BLOCKS    32U
#define ADPT_BLOCK_CODE_SIZE 64U

typedef enum {
    ADPT_OP_NOP           = 0x00,
    ADPT_OP_ADD           = 0x01,
    ADPT_OP_SUB           = 0x02,
    ADPT_OP_MUL           = 0x03,
    ADPT_OP_DIV           = 0x04,
    ADPT_OP_CMP           = 0x05,
    ADPT_OP_AND           = 0x06,
    ADPT_OP_OR            = 0x07,
    ADPT_OP_XOR           = 0x08,
    ADPT_OP_NOT           = 0x09,
    ADPT_OP_MOV           = 0x0A,
    ADPT_OP_JMP           = 0x0B,
    ADPT_OP_TIMER_ON      = 0x10,
    ADPT_OP_TIMER_OFF     = 0x11,
    ADPT_OP_COUNTER_UP    = 0x12,
    ADPT_OP_COUNTER_DOWN  = 0x13,
    ADPT_OP_COMPARATOR    = 0x20,
    ADPT_OP_LIMIT         = 0x21,
    ADPT_OP_FILTER        = 0x22,
    ADPT_OP_RAMP          = 0x23,
    ADPT_OP_PID           = 0x30,
    ADPT_OP_END           = 0xFF,
} adpt_opcode_t;

typedef struct {
    uint8_t   opcode;
    uint8_t   operand_a;
    uint8_t   operand_b;
    uint8_t   operand_c;
    int32_t   value_i;
    float     value_f;
} adpt_instruction_t;

typedef struct {
    uint8_t        initialized;
    uint8_t        active;
    uint8_t        running;
    uint8_t        fault;
    uint16_t       block_count;
    uint32_t       scan_counter;
    uint32_t       cycle_time_us;
    int32_t        registers[64];
    uint16_t       timer_presets[8];
    uint16_t       timer_current[8];
    uint8_t        timer_enabled[8];
    uint32_t       counter_current[4];
    uint32_t       counter_presets[4];
    adpt_instruction_t program[ADPT_MAX_BLOCKS][ADPT_BLOCK_CODE_SIZE];
    uint16_t       program_length[ADPT_MAX_BLOCKS];
} adaptive_programming_state_t;

void adaptive_programming_init(adaptive_programming_state_t *state);
void adaptive_programming_update(adaptive_programming_state_t *state);
void adaptive_prog_update(adaptive_programming_state_t *state, uint16_t block_id);

#endif
