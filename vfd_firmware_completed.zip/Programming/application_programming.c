#include "application_programming.h"
#include <string.h>

static uint32_t app_prog_get_tick(void)
{
    volatile uint32_t *systick = (volatile uint32_t *)0xE000E018UL;
    return *systick;
}

static void app_prog_advance_step(application_programming_state_t *state, uint16_t next)
{
    state->current_step = next;
    state->step_start_tick = app_prog_get_tick();
    state->elapsed_ms = 0;
}

static uint8_t app_prog_evaluate_condition(application_programming_state_t *state,
                                            uint8_t condition)
{
    switch (condition) {
    case 0x00: return 1;
    case 0x01: return (state->outputs[0] > 0) ? 1 : 0;
    case 0x02: return (state->outputs[1] > 0) ? 1 : 0;
    case 0x10: return (state->outputs[0] == 0) ? 1 : 0;
    case 0x20: return (state->outputs[1] == 0) ? 1 : 0;
    default:   return 1;
    }
}

void app_prog_scan(application_programming_state_t *state)
{
    app_prog_step_t *step;
    uint32_t now;

    if (state == 0) return;
    if (state->run_state != APP_STATE_RUNNING) return;
    if (state->current_step >= APP_PROG_MAX_STEPS) {
        state->run_state = APP_STATE_FAULTED;
        return;
    }

    step = &state->steps[state->current_step];

    now = app_prog_get_tick();
    state->elapsed_ms = now - state->step_start_tick;

    switch (step->step_type) {

    case APP_STEP_WAIT:
    case APP_STEP_END:
        break;

    case APP_STEP_SET_SPEED:
        state->outputs[0] = step->param_value;
        app_prog_advance_step(state, step->next_step);
        break;

    case APP_STEP_SET_TORQUE:
        state->outputs[1] = step->param_value;
        app_prog_advance_step(state, step->next_step);
        break;

    case APP_STEP_SET_FREQUENCY:
        state->outputs[2] = step->param_value;
        app_prog_advance_step(state, step->next_step);
        break;

    case APP_STEP_SET_DC_VOLT:
        state->outputs[3] = step->param_value;
        app_prog_advance_step(state, step->next_step);
        break;

    case APP_STEP_RAMP:
        state->outputs[4] = step->param_value;
        app_prog_advance_step(state, step->next_step);
        break;

    case APP_STEP_DELAY:
        if (state->elapsed_ms >= step->delay_ms) {
            app_prog_advance_step(state, step->next_step);
        }
        break;

    case APP_STEP_BRANCH:
        if (app_prog_evaluate_condition(state, step->condition)) {
            app_prog_advance_step(state, step->branch_step);
        } else {
            app_prog_advance_step(state, step->next_step);
        }
        break;

    case APP_STEP_SET_ANALOG_OUT:
        state->outputs[6] = step->param_value;
        app_prog_advance_step(state, step->next_step);
        break;

    case APP_STEP_SET_DIGITAL_OUT:
        state->outputs[7] = step->param_value;
        app_prog_advance_step(state, step->next_step);
        break;

    case APP_STEP_WAIT_DI:
        break;

    case APP_STEP_WAIT_AI:
        break;

    case APP_STEP_LOOP_START:
        if (state->loop_depth < 8) {
            state->loop_stack[state->loop_depth] = state->current_step;
            state->loop_depth++;
        }
        app_prog_advance_step(state, step->next_step);
        break;

    case APP_STEP_LOOP_END:
        if (state->loop_depth > 0) {
            state->loop_depth--;
            app_prog_advance_step(state, state->loop_stack[state->loop_depth]);
        } else {
            app_prog_advance_step(state, step->next_step);
        }
        break;

    case APP_STEP_SUBROUTINE_CALL:
        if (state->subroutine_depth < 8) {
            state->subroutine_stack[state->subroutine_depth] = state->current_step + 1;
            state->subroutine_depth++;
            app_prog_advance_step(state, (uint16_t)step->param_value);
        }
        break;

    case APP_STEP_SUBROUTINE_RET:
        if (state->subroutine_depth > 0) {
            state->subroutine_depth--;
            app_prog_advance_step(state, state->subroutine_stack[state->subroutine_depth]);
        }
        break;

    default:
        state->run_state = APP_STATE_FAULTED;
        break;
    }

    if (step->step_type == APP_STEP_END) {
        state->run_state = APP_STATE_COMPLETED;
    }
}

void application_programming_init(application_programming_state_t *state)
{
    if (state == 0) return;

    memset(state, 0, sizeof(application_programming_state_t));
    state->initialized = 1;
    state->active = 0;
    state->run_state = APP_STATE_IDLE;
    state->current_step = 0;
    state->loop_depth = 0;
    state->subroutine_depth = 0;
}

void application_programming_update(application_programming_state_t *state)
{
    if (state == 0 || !state->initialized) return;
    if (state->active && state->run_state == APP_STATE_RUNNING) {
        app_prog_scan(state);
    }
}
