#ifndef PROGRAMMING_APPLICATION_PROGRAMMING_H
#define PROGRAMMING_APPLICATION_PROGRAMMING_H

#include <stdint.h>

#define APP_PROG_MAX_STEPS    128U
#define APP_PROG_MAX_OUTPUTS   32U

typedef enum {
    APP_STEP_WAIT           = 0x00,
    APP_STEP_SET_SPEED      = 0x01,
    APP_STEP_SET_TORQUE     = 0x02,
    APP_STEP_SET_FREQUENCY  = 0x03,
    APP_STEP_SET_DC_VOLT    = 0x04,
    APP_STEP_RAMP           = 0x05,
    APP_STEP_DELAY          = 0x06,
    APP_STEP_BRANCH         = 0x07,
    APP_STEP_SET_ANALOG_OUT = 0x08,
    APP_STEP_SET_DIGITAL_OUT = 0x09,
    APP_STEP_WAIT_DI        = 0x0A,
    APP_STEP_WAIT_AI        = 0x0B,
    APP_STEP_LOOP_START     = 0x0C,
    APP_STEP_LOOP_END       = 0x0D,
    APP_STEP_SUBROUTINE_CALL = 0x0E,
    APP_STEP_SUBROUTINE_RET = 0x0F,
    APP_STEP_END            = 0xFF,
} app_step_type_t;

typedef enum {
    APP_STATE_IDLE      = 0,
    APP_STATE_RUNNING   = 1,
    APP_STATE_PAUSED    = 2,
    APP_STATE_COMPLETED = 3,
    APP_STATE_FAULTED   = 4,
} app_prog_state_t;

typedef struct {
    uint8_t  step_type;
    int32_t  param_value;
    uint32_t delay_ms;
    uint8_t  next_step;
    uint8_t  branch_step;
    uint8_t  condition;
} app_prog_step_t;

typedef struct {
    uint8_t         initialized;
    uint8_t         active;
    app_prog_state_t run_state;
    uint16_t        current_step;
    uint32_t        step_start_tick;
    uint32_t        elapsed_ms;
    uint16_t        step_count;
    uint16_t        loop_stack[8];
    uint8_t         loop_depth;
    uint16_t        subroutine_stack[8];
    uint8_t         subroutine_depth;
    int32_t         outputs[APP_PROG_MAX_OUTPUTS];
    app_prog_step_t steps[APP_PROG_MAX_STEPS];
} application_programming_state_t;

void application_programming_init(application_programming_state_t *state);
void application_programming_update(application_programming_state_t *state);
void app_prog_scan(application_programming_state_t *state);

#endif
