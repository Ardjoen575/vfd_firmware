#include "adaptive_programming.h"
#include <string.h>

static int32_t adpt_execute_instruction(adaptive_programming_state_t *state,
                                         const adpt_instruction_t *inst)
{
    int32_t result = 0;
    int32_t a_val, b_val;

    a_val = (inst->operand_a < 64) ? state->registers[inst->operand_a] : 0;
    b_val = (inst->operand_b < 64) ? state->registers[inst->operand_b] : 0;

    switch (inst->opcode) {
    case ADPT_OP_NOP:
        break;

    case ADPT_OP_ADD:
        result = a_val + b_val;
        break;

    case ADPT_OP_SUB:
        result = a_val - b_val;
        break;

    case ADPT_OP_MUL:
        result = (int32_t)((int64_t)a_val * (int64_t)b_val / 1000LL);
        break;

    case ADPT_OP_DIV:
        result = (b_val != 0) ? (a_val * 1000 / b_val) : 0;
        break;

    case ADPT_OP_CMP:
        result = (a_val > b_val) ? 1 : ((a_val < b_val) ? -1 : 0);
        break;

    case ADPT_OP_AND:
        result = a_val & b_val;
        break;

    case ADPT_OP_OR:
        result = a_val | b_val;
        break;

    case ADPT_OP_XOR:
        result = a_val ^ b_val;
        break;

    case ADPT_OP_NOT:
        result = ~a_val;
        break;

    case ADPT_OP_MOV:
        result = inst->value_i;
        break;

    case ADPT_OP_COMPARATOR:
        result = (a_val >= b_val) ? 1 : 0;
        break;

    case ADPT_OP_LIMIT: {
        int32_t upper = inst->value_i;
        int32_t lower = b_val;
        result = a_val;
        if (result > upper) result = upper;
        if (result < lower) result = lower;
        break;
    }

    case ADPT_OP_FILTER: {
        int32_t filter_k = inst->value_i;
        result = a_val + ((b_val - a_val) * filter_k) / 1000;
        break;
    }

    case ADPT_OP_RAMP: {
        int32_t ramp_rate = inst->value_i;
        int32_t diff = b_val - a_val;
        if (diff > ramp_rate)      result = a_val + ramp_rate;
        else if (diff < -ramp_rate) result = a_val - ramp_rate;
        else                        result = b_val;
        break;
    }

    default:
        result = 0;
        break;
    }

    return result;
}

void adaptive_prog_update(adaptive_programming_state_t *state, uint16_t block_id)
{
    uint16_t i;
    int32_t reg_c;
    const adpt_instruction_t *inst;

    if (state == 0) return;
    if (!state->running) return;
    if (block_id >= ADPT_MAX_BLOCKS) return;
    if (state->program_length[block_id] == 0) return;

    for (i = 0; i < state->program_length[block_id]; i++) {
        inst = &state->program[block_id][i];

        if (inst->opcode == ADPT_OP_END) {
            break;
        }

        if (inst->opcode == ADPT_OP_JMP) {
            i = (uint16_t)inst->value_i;
            if (i >= state->program_length[block_id]) break;
            continue;
        }

        reg_c = adpt_execute_instruction(state, inst);

        if (inst->operand_c < 64) {
            state->registers[inst->operand_c] = reg_c;
        }
    }

    state->scan_counter++;
}

void adaptive_programming_init(adaptive_programming_state_t *state)
{
    if (state == 0) return;

    memset(state, 0, sizeof(adaptive_programming_state_t));
    state->initialized = 1;
    state->running = 0;
    state->fault = 0;
    state->block_count = 0;
    state->scan_counter = 0;
    state->cycle_time_us = 0;
}

void adaptive_programming_update(adaptive_programming_state_t *state)
{
    uint16_t blk;

    if (state == 0 || !state->initialized) return;

    for (blk = 0; blk < ADPT_MAX_BLOCKS; blk++) {
        adaptive_prog_update(state, blk);
    }
}
