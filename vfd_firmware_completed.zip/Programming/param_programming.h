#ifndef PROGRAMMING_PARAM_PROGRAMMING_H
#define PROGRAMMING_PARAM_PROGRAMMING_H

#include <stdint.h>

#define PARAM_PROG_MAX_OPS    64U
#define PARAM_MAX_ID         65535U

typedef enum {
    PARAM_OP_NOP            = 0x00,
    PARAM_OP_SET            = 0x01,
    PARAM_OP_SET_IF_EQUAL   = 0x02,
    PARAM_OP_SET_IF_GT      = 0x03,
    PARAM_OP_SET_IF_LT      = 0x04,
    PARAM_OP_SET_IF_RANGE   = 0x05,
    PARAM_OP_COPY           = 0x06,
    PARAM_OP_ADD            = 0x07,
    PARAM_OP_SUBTRACT       = 0x08,
    PARAM_OP_MULTIPLY       = 0x09,
    PARAM_OP_DIVIDE         = 0x0A,
    PARAM_OP_SCALE          = 0x0B,
    PARAM_OP_MAP            = 0x0C,
    PARAM_OP_END            = 0xFF,
} param_opcode_t;

typedef struct {
    uint8_t   opcode;
    uint16_t  target_param;
    uint16_t  source_param;
    int32_t   value;
    int32_t   compare_value;
    int32_t   range_low;
    int32_t   range_high;
    int32_t   scale_num;
    int32_t   scale_den;
} param_prog_op_t;

typedef struct {
    uint8_t         initialized;
    uint8_t         active;
    uint8_t         execute_once;
    uint8_t         executing;
    uint16_t        op_count;
    uint16_t        current_op;
    uint16_t        last_result;
    param_prog_op_t operations[PARAM_PROG_MAX_OPS];
} param_programming_state_t;

void param_programming_init(param_programming_state_t *state);
void param_programming_update(param_programming_state_t *state);
void param_prog_execute(param_programming_state_t *state);

#endif
