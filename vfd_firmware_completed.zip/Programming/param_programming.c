#include "param_programming.h"
#include <string.h>

typedef struct {
    int32_t values[PARAM_MAX_ID + 1];
} param_registry_t;

static param_registry_t g_params;

static int32_t param_op_read_value(uint16_t param_id, uint8_t *ok)
{
    if (param_id <= PARAM_MAX_ID) {
        *ok = 1;
        return g_params.values[param_id];
    }
    *ok = 0;
    return 0;
}

static void param_op_write_value(uint16_t param_id, int32_t value)
{
    if (param_id <= PARAM_MAX_ID) {
        g_params.values[param_id] = value;
    }
}

static uint8_t param_op_process(param_programming_state_t *state,
                                 const param_prog_op_t *op)
{
    int32_t src_val, tgt_val, result;
    uint8_t ok;

    switch (op->opcode) {

    case PARAM_OP_NOP:
        return 1;

    case PARAM_OP_SET:
        param_op_write_value(op->target_param, op->value);
        return 1;

    case PARAM_OP_SET_IF_EQUAL:
        src_val = param_op_read_value(op->source_param, &ok);
        if (!ok) return 0;
        if (src_val == op->compare_value) {
            param_op_write_value(op->target_param, op->value);
        }
        return 1;

    case PARAM_OP_SET_IF_GT:
        src_val = param_op_read_value(op->source_param, &ok);
        if (!ok) return 0;
        if (src_val > op->compare_value) {
            param_op_write_value(op->target_param, op->value);
        }
        return 1;

    case PARAM_OP_SET_IF_LT:
        src_val = param_op_read_value(op->source_param, &ok);
        if (!ok) return 0;
        if (src_val < op->compare_value) {
            param_op_write_value(op->target_param, op->value);
        }
        return 1;

    case PARAM_OP_SET_IF_RANGE:
        src_val = param_op_read_value(op->source_param, &ok);
        if (!ok) return 0;
        if (src_val >= op->range_low && src_val <= op->range_high) {
            param_op_write_value(op->target_param, op->value);
        }
        return 1;

    case PARAM_OP_COPY:
        tgt_val = param_op_read_value(op->source_param, &ok);
        if (!ok) return 0;
        param_op_write_value(op->target_param, tgt_val);
        return 1;

    case PARAM_OP_ADD:
        src_val = param_op_read_value(op->source_param, &ok);
        if (!ok) return 0;
        tgt_val = param_op_read_value(op->target_param, &ok);
        if (!ok) return 0;
        param_op_write_value(op->target_param, tgt_val + src_val);
        return 1;

    case PARAM_OP_SUBTRACT:
        src_val = param_op_read_value(op->source_param, &ok);
        if (!ok) return 0;
        tgt_val = param_op_read_value(op->target_param, &ok);
        if (!ok) return 0;
        param_op_write_value(op->target_param, tgt_val - src_val);
        return 1;

    case PARAM_OP_MULTIPLY:
        src_val = param_op_read_value(op->source_param, &ok);
        if (!ok) return 0;
        tgt_val = param_op_read_value(op->target_param, &ok);
        if (!ok) return 0;
        result = (int32_t)(((int64_t)tgt_val * (int64_t)src_val) / 1000LL);
        param_op_write_value(op->target_param, result);
        return 1;

    case PARAM_OP_DIVIDE:
        src_val = param_op_read_value(op->source_param, &ok);
        if (!ok) return 0;
        tgt_val = param_op_read_value(op->target_param, &ok);
        if (!ok) return 0;
        if (src_val != 0) {
            param_op_write_value(op->target_param, (tgt_val * 1000) / src_val);
        }
        return 1;

    case PARAM_OP_SCALE:
        tgt_val = param_op_read_value(op->target_param, &ok);
        if (!ok) return 0;
        if (op->scale_den != 0) {
            result = (int32_t)(((int64_t)tgt_val * op->scale_num) / op->scale_den);
            param_op_write_value(op->target_param, result);
        }
        return 1;

    case PARAM_OP_MAP:
        src_val = param_op_read_value(op->source_param, &ok);
        if (!ok) return 0;
        if (op->range_high != op->range_low) {
            result = op->range_low +
                     ((src_val - op->scale_num) * (op->range_high - op->range_low))
                     / (op->scale_den - op->scale_num);
            param_op_write_value(op->target_param, result);
        }
        return 1;

    default:
        return 0;
    }
}

void param_prog_execute(param_programming_state_t *state)
{
    uint16_t i;

    if (state == 0) return;
    if (!state->active) return;

    state->executing = 1;

    for (i = 0; i < state->op_count; i++) {
        const param_prog_op_t *op = &state->operations[i];

        if (op->opcode == PARAM_OP_END) {
            state->executing = 0;
            if (state->execute_once) {
                state->active = 0;
            }
            return;
        }

        if (!param_op_process(state, op)) {
            state->last_result = 0xFFFF;
            state->executing = 0;
            return;
        }
        state->current_op = i;
    }

    state->last_result = 0;
    state->executing = 0;
    if (state->execute_once) {
        state->active = 0;
    }
}

void param_programming_init(param_programming_state_t *state)
{
    if (state == 0) return;

    memset(state, 0, sizeof(param_programming_state_t));
    memset(&g_params, 0, sizeof(g_params));
    state->initialized = 1;
}

void param_programming_update(param_programming_state_t *state)
{
    if (state == 0 || !state->initialized) return;
    if (state->active) {
        param_prog_execute(state);
    }
}
