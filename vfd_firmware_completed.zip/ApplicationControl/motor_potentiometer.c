#include "motor_potentiometer.h"

static void motpot_ramp(motor_potentiometer_state_t *state)
{
    float delta;
    float ramp_step_acc;

    if (state->up_input && !state->down_input) {
        delta = (float)state->cycle_time_ms / (float)state->ramp_up_time;
        ramp_step_acc = state->output_max / delta;

        if (state->step_up < ramp_step_acc) {
            state->step_up += 1.0f;
        }
        state->output_value += state->step_up;
        state->step_down = 0.0f;

        if (state->output_value > state->output_max) {
            state->output_value = state->output_max;
        }
    } else if (state->down_input && !state->up_input) {
        delta = (float)state->cycle_time_ms / (float)state->ramp_down_time;
        ramp_step_acc = state->output_max / delta;

        if (state->step_down < ramp_step_acc) {
            state->step_down += 1.0f;
        }
        state->output_value -= state->step_down;
        state->step_up = 0.0f;

        if (state->output_value < state->output_min) {
            state->output_value = state->output_min;
        }
    } else {
        state->step_up = 0.0f;
        state->step_down = 0.0f;
    }
}

void motor_potentiometer_init(motor_potentiometer_state_t *state)
{
    state->initialized = 1;
    state->enabled = 0;
    state->up_input = 0;
    state->down_input = 0;
    state->prev_up = 0;
    state->prev_down = 0;

    state->output_value = 0.0f;
    state->output_min = 0.0f;
    state->output_max = 100.0f;
    state->ramp_step = 0.5f;

    state->step_up = 0.0f;
    state->step_down = 0.0f;

    state->store_active = 0;
    state->restore_active = 0;
    state->stored_value = 0.0f;

    state->ramp_up_time = 10000;
    state->ramp_down_time = 10000;
    state->cycle_time_ms = 10;
}

void motor_potentiometer_update(motor_potentiometer_state_t *state)
{
    if (!state->initialized) return;
    if (!state->enabled) return;

    state->prev_up = state->up_input;
    state->prev_down = state->down_input;

    if (state->store_active) {
        state->stored_value = state->output_value;
        state->store_active = 0;
    }

    if (state->restore_active) {
        state->output_value = state->stored_value;
        state->restore_active = 0;
    }

    motpot_ramp(state);
}

void motpot_step(motor_potentiometer_state_t *state)
{
    if (!state->initialized) return;
    if (!state->enabled) return;

    if (state->up_input && !state->down_input) {
        state->output_value += state->ramp_step;
        if (state->output_value > state->output_max) {
            state->output_value = state->output_max;
        }
    } else if (state->down_input && !state->up_input) {
        state->output_value -= state->ramp_step;
        if (state->output_value < state->output_min) {
            state->output_value = state->output_min;
        }
    }
}
