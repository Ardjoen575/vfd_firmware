#include "macro_fieldbus.h"

void macro_fieldbus_init(macro_fieldbus_state_t *state)
{
    state->initialized = 1;
    state->applied = 0;

    state->cfg.fb_par = 0;
    state->cfg.ext1_cmd = 10;
    state->cfg.ext2_cmd = 10;
    state->cfg.run_enable = 1;

    state->cfg.ref1_select = 10;
    state->cfg.ref2_select = 10;
    state->cfg.fb_ref1 = 1;
    state->cfg.fb_ref2 = 2;

    state->cfg.di1_func = 0;
    state->cfg.di2_func = 0;
    state->cfg.di3_func = 0;
    state->cfg.di4_func = 0;
    state->cfg.di5_func = 0;
    state->cfg.di6_func = 0;

    state->cfg.dio1_func = 2;
    state->cfg.dio2_func = 3;

    state->cfg.ai1_select = 0;
    state->cfg.ai2_select = 0;
    state->cfg.ao1_select = 2;
    state->cfg.ao2_select = 3;

    state->cfg.ro1_source = 1;
    state->cfg.ro2_source = 2;
    state->cfg.ro3_source = 3;

    state->cfg.fb_comm_loss_time = 3;
    state->cfg.fb_comm_loss_func = 1;
    state->cfg.fb_profile = 0;
}

void macro_fieldbus_update(macro_fieldbus_state_t *state)
{
    if (!state->initialized) return;
}

void macro_fieldbus_apply(macro_fieldbus_state_t *state)
{
    if (!state->initialized) return;

    state->cfg.ext1_cmd = 10;
    state->cfg.ext2_cmd = 10;
    state->cfg.ref1_select = 10;
    state->cfg.ref2_select = 10;
    state->cfg.run_enable = 1;

    state->cfg.fb_comm_loss_time = 3;
    state->cfg.fb_comm_loss_func = 1;

    state->cfg.di1_func = 0;
    state->cfg.di2_func = 0;
    state->cfg.di3_func = 0;
    state->cfg.di4_func = 0;
    state->cfg.di5_func = 0;
    state->cfg.di6_func = 0;

    state->cfg.dio1_func = 2;
    state->cfg.dio2_func = 3;

    state->cfg.ai1_select = 0;
    state->cfg.ai2_select = 0;
    state->cfg.ao1_select = 2;
    state->cfg.ao2_select = 3;

    state->cfg.ro1_source = 1;
    state->cfg.ro2_source = 2;
    state->cfg.ro3_source = 3;

    state->applied = 1;
}
