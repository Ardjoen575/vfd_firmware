#include "macro_torque_control.h"

void macro_torque_control_init(macro_torque_control_state_t *state)
{
    state->initialized = 1;
    state->applied = 0;

    state->cfg.ext1_start = 0;
    state->cfg.ext2_start = 0;
    state->cfg.ext1_dir = 0;
    state->cfg.ext2_dir = 0;
    state->cfg.run_enable = 1;
    state->cfg.local_ctrl = 1;

    state->cfg.trq_ref_sel = 1;
    state->cfg.trq_ref_min = 0;
    state->cfg.trq_ref_max = 150;
    state->cfg.trq_ramp_up = 10;
    state->cfg.trq_ramp_down = 10;
    state->cfg.speed_window_high = 5;
    state->cfg.speed_window_low = 5;

    state->cfg.di1_func = 1;
    state->cfg.di2_func = 2;
    state->cfg.di3_func = 3;
    state->cfg.di4_func = 4;
    state->cfg.di5_func = 0;
    state->cfg.di6_func = 0;

    state->cfg.dio1_func = 2;
    state->cfg.dio2_func = 3;

    state->cfg.ai1_select = 1;
    state->cfg.ai2_select = 0;
    state->cfg.ao1_select = 4;
    state->cfg.ao2_select = 3;

    state->cfg.ro1_source = 1;
    state->cfg.ro2_source = 2;
    state->cfg.ro3_source = 3;

    state->cfg.speed_limit = 50;
}

void macro_torque_control_update(macro_torque_control_state_t *state)
{
    if (!state->initialized) return;
}

void macro_torque_apply(macro_torque_control_state_t *state)
{
    if (!state->initialized) return;

    state->cfg.di1_func = 1;
    state->cfg.di2_func = 2;
    state->cfg.di3_func = 3;
    state->cfg.di4_func = 4;
    state->cfg.di5_func = 0;
    state->cfg.di6_func = 0;

    state->cfg.dio1_func = 2;
    state->cfg.dio2_func = 3;

    state->cfg.ai1_select = 1;
    state->cfg.ai2_select = 0;
    state->cfg.ao1_select = 4;
    state->cfg.ao2_select = 3;

    state->cfg.ro1_source = 2;
    state->cfg.ro2_source = 3;
    state->cfg.ro3_source = 11;

    state->cfg.trq_ref_sel = 1;
    state->cfg.local_ctrl = 1;
    state->cfg.trq_ramp_up = 10;
    state->cfg.trq_ramp_down = 10;

    state->applied = 1;
}
