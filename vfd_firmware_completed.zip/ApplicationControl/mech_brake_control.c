#include "mech_brake_control.h"

void mech_brake_control_init(mech_brake_control_state_t *state)
{
    state->initialized = 1;
    state->brake_state = BRAKE_STATE_CLOSED;
    state->brake_command = 0;
    state->brake_ack = 0;
    state->torque_proving_active = 0;
    state->raise_request = 0;
    state->lower_request = 0;

    state->brake_torque_ref = 0.0f;
    state->brake_torque_limit = 50.0f;
    state->brake_torque_actual = 0.0f;

    state->open_delay_ms = 200;
    state->close_delay_ms = 300;
    state->open_delay_timer = 0;
    state->close_delay_timer = 0;

    state->torque_prove_time = 50;
    state->torque_prove_timer = 0;

    state->fault_active = 0;
    state->fault_code = 0;
}

void mech_brake_control_update(mech_brake_control_state_t *state)
{
    if (!state->initialized) return;

    if (state->fault_active) {
        state->brake_state = BRAKE_STATE_CLOSED;
        state->raise_request = 0;
        state->lower_request = 1;
        return;
    }

    switch (state->brake_state) {
        case BRAKE_STATE_CLOSED:
            if (state->raise_request) {
                state->brake_state = BRAKE_STATE_OPENING;
                state->open_delay_timer = 0;
                state->torque_prove_timer = 0;
                state->torque_proving_active = 1;
            }
            break;

        case BRAKE_STATE_OPENING:
            if (state->torque_proving_active) {
                if (state->brake_torque_actual >= state->brake_torque_limit) {
                    state->torque_prove_timer++;
                    if (state->torque_prove_timer >= state->torque_prove_time) {
                        state->torque_proving_active = 0;
                        state->open_delay_timer = 0;
                    }
                }
            } else {
                state->open_delay_timer++;
                if (state->open_delay_timer >= state->open_delay_ms) {
                    state->brake_state = BRAKE_STATE_OPEN;
                    state->brake_ack = 1;
                }
            }
            if (!state->raise_request) {
                state->brake_state = BRAKE_STATE_CLOSING;
                state->close_delay_timer = 0;
            }
            break;

        case BRAKE_STATE_OPEN:
            state->brake_ack = 1;
            if (state->lower_request) {
                state->brake_state = BRAKE_STATE_CLOSING;
                state->close_delay_timer = 0;
            }
            break;

        case BRAKE_STATE_CLOSING:
            state->close_delay_timer++;
            if (state->close_delay_timer >= state->close_delay_ms) {
                state->brake_state = BRAKE_STATE_CLOSED;
                state->brake_ack = 0;
            }
            if (state->raise_request) {
                state->lower_request = 0;
                state->brake_state = BRAKE_STATE_OPENING;
                state->torque_proving_active = 1;
                state->torque_prove_timer = 0;
            }
            break;

        default:
            state->brake_state = BRAKE_STATE_CLOSED;
            break;
    }
}

void mech_brake_open(mech_brake_control_state_t *state)
{
    if (!state->initialized) return;
    if (state->fault_active) return;

    state->raise_request = 1;
    state->lower_request = 0;
}

void mech_brake_close(mech_brake_control_state_t *state)
{
    if (!state->initialized) return;

    state->raise_request = 0;
    state->lower_request = 1;
}
