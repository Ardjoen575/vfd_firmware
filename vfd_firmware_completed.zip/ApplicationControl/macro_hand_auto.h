#ifndef APPLICATIONCONTROL_MACRO_HAND_AUTO_H
#define APPLICATIONCONTROL_MACRO_HAND_AUTO_H

/* Hand/Auto macro defaults + wiring */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    uint8_t applied;
    uint8_t hand_active;
    uint8_t auto_active;

    struct {
        uint16_t ext1_start;
        uint16_t ext2_start;
        uint16_t ext1_dir;
        uint16_t ext2_dir;
        uint16_t hand_ref_sel;
        uint16_t auto_ref_sel;
        uint16_t hand_start_src;
        uint16_t auto_start_src;
        uint16_t hand_stop_src;
        uint16_t auto_stop_src;

        uint16_t di1_func;
        uint16_t di2_func;
        uint16_t di3_func;
        uint16_t di4_func;
        uint16_t di5_func;
        uint16_t di6_func;

        uint16_t dio1_func;
        uint16_t dio2_func;

        uint16_t ai1_select;
        uint16_t ai2_select;
        uint16_t ao1_select;
        uint16_t ao2_select;

        uint16_t ro1_source;
        uint16_t ro2_source;
        uint16_t ro3_source;

        uint16_t accel_time_h;
        uint16_t decel_time_h;
        uint16_t accel_time_a;
        uint16_t decel_time_a;
        uint16_t hand_speed;
        uint16_t auto_speed;
    } cfg;
} macro_hand_auto_state_t;

void macro_hand_auto_init(macro_hand_auto_state_t *state);
void macro_hand_auto_update(macro_hand_auto_state_t *state);
void macro_hand_auto_apply(macro_hand_auto_state_t *state);

#endif /* APPLICATIONCONTROL_MACRO_HAND_AUTO_H */
