#ifndef APPLICATIONCONTROL_PID_SET1_H
#define APPLICATIONCONTROL_PID_SET1_H

/* Process PID set 1 (grp 40) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    uint8_t enabled;

    float setpoint;
    float feedback;
    float error;
    float prev_error;

    float gain;
    float integral_time;
    float derivative_time;
    float filter_time;

    float p_term;
    float i_term;
    float d_term;
    float output;
    float output_raw;

    float i_term_limit;
    float output_max;
    float output_min;

    float dt;
    uint8_t sleep_active;
    float sleep_level;
    uint16_t sleep_delay;
    uint16_t sleep_counter;
    float wakeup_level;

    float fb_filter;
    float fb_filtered;
    float err_prev1;
    float err_prev2;
} pid_set1_state_t;

void pid_set1_init(pid_set1_state_t *state);
void pid_set1_update(pid_set1_state_t *state);
void pid1_compute(pid_set1_state_t *state);

#endif /* APPLICATIONCONTROL_PID_SET1_H */
