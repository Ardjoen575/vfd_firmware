#include "app_macros.h"

static void macro_set_default_params(app_macros_state_t *state, uint8_t macro_id)
{
    switch (macro_id) {
        case MACRO_FACTORY:
            state->params.param_1001 = 0;
            state->params.param_1002 = 1;
            state->params.param_1003 = 2;
            state->params.param_1102 = 1;
            state->params.param_1103 = 0;
            state->params.param_1201 = 1;
            state->params.param_1301 = 2;
            state->params.param_1401 = 3;
            state->params.param_1501 = 4;
            state->params.param_1601 = 5;
            state->params.param_2001 = 0;
            state->params.param_2002 = 10;
            state->params.param_2101 = 1;
            state->params.param_2102 = 3;
            break;

        case MACRO_HAND_AUTO:
            state->params.param_1001 = 0;
            state->params.param_1002 = 2;
            state->params.param_1003 = 8;
            state->params.param_1102 = 1;
            state->params.param_1103 = 0;
            state->params.param_1201 = 3;
            state->params.param_1301 = 2;
            state->params.param_1401 = 4;
            state->params.param_1501 = 5;
            state->params.param_1601 = 6;
            state->params.param_2001 = 1;
            state->params.param_2002 = 5;
            state->params.param_2101 = 2;
            state->params.param_2102 = 0;
            break;

        case MACRO_PID_CTRL:
            state->params.param_1001 = 1;
            state->params.param_1002 = 6;
            state->params.param_1003 = 9;
            state->params.param_1102 = 1;
            state->params.param_1103 = 0;
            state->params.param_1201 = 2;
            state->params.param_1301 = 2;
            state->params.param_1401 = 3;
            state->params.param_1501 = 4;
            state->params.param_1601 = 5;
            state->params.param_2001 = 2;
            state->params.param_2002 = 3;
            state->params.param_2101 = 1;
            state->params.param_2102 = 0;
            break;

        case MACRO_TORQUE:
            state->params.param_1001 = 0;
            state->params.param_1002 = 1;
            state->params.param_1003 = 2;
            state->params.param_1102 = 0;
            state->params.param_1103 = 2;
            state->params.param_1201 = 8;
            state->params.param_1301 = 2;
            state->params.param_1401 = 3;
            state->params.param_1501 = 4;
            state->params.param_1601 = 5;
            state->params.param_2001 = 1;
            state->params.param_2002 = 2;
            state->params.param_2101 = 1;
            state->params.param_2102 = 0;
            break;

        case MACRO_FIELDBUS:
            state->params.param_1001 = 0;
            state->params.param_1002 = 1;
            state->params.param_1003 = 2;
            state->params.param_1102 = 1;
            state->params.param_1103 = 0;
            state->params.param_1201 = 10;
            state->params.param_1301 = 11;
            state->params.param_1401 = 12;
            state->params.param_1501 = 13;
            state->params.param_1601 = 14;
            state->params.param_2001 = 0;
            state->params.param_2002 = 0;
            state->params.param_2101 = 1;
            state->params.param_2102 = 0;
            break;

        case MACRO_SEQUENTIAL:
            state->params.param_1001 = 0;
            state->params.param_1002 = 1;
            state->params.param_1003 = 2;
            state->params.param_1102 = 0;
            state->params.param_1103 = 0;
            state->params.param_1201 = 5;
            state->params.param_1301 = 2;
            state->params.param_1401 = 3;
            state->params.param_1501 = 6;
            state->params.param_1601 = 7;
            state->params.param_2001 = 3;
            state->params.param_2002 = 5;
            state->params.param_2101 = 1;
            state->params.param_2102 = 0;
            break;

        default:
            break;
    }
}

void app_macros_init(app_macros_state_t *state)
{
    state->initialized = 1;
    state->selected_macro = MACRO_FACTORY;
    state->macro_applied = 0;
    state->macro_changed = 0;

    state->params.param_1001 = 0;
    state->params.param_1002 = 0;
    state->params.param_1003 = 0;
    state->params.param_1102 = 0;
    state->params.param_1103 = 0;
    state->params.param_1201 = 0;
    state->params.param_1301 = 0;
    state->params.param_1401 = 0;
    state->params.param_1501 = 0;
    state->params.param_1601 = 0;
    state->params.param_2001 = 0;
    state->params.param_2002 = 0;
    state->params.param_2101 = 0;
    state->params.param_2102 = 0;
}

void app_macros_update(app_macros_state_t *state)
{
    if (!state->initialized) return;

    if (state->macro_changed) {
        macro_set_default_params(state, state->selected_macro);
        state->macro_applied = 1;
        state->macro_changed = 0;
    }
}

void macro_apply_selected(app_macros_state_t *state)
{
    if (!state->initialized) return;

    if (state->selected_macro >= MACRO_COUNT) {
        state->selected_macro = MACRO_FACTORY;
    }

    state->macro_changed = 1;
}
