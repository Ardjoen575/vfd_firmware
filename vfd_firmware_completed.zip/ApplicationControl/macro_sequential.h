#ifndef APPLICATIONCONTROL_MACRO_SEQUENTIAL_H
#define APPLICATIONCONTROL_MACRO_SEQUENTIAL_H

/* Sequential control macro + constant-speed sequencing */

#include <stdint.h>

#define SEQ_MAX_SPEEDS 7

typedef struct {
    uint8_t initialized;
    uint8_t applied;
    uint8_t active_speed;
    uint8_t di_state[3];

    struct {
        uint16_t ext1_start;
        uint16_t ext2_start;
        uint16_t ext1_dir;
        uint16_t ext2_dir;
        uint16_t run_enable;

        uint16_t const_speed[SEQ_MAX_SPEEDS];
        uint16_t speed_sel_inputs;

        uint16_t di1_func;
        uint16_t di2_func;
        uint16_t di3_func;
        uint16_t di4_func;
        uint16_t di5_func;
        uint16_t di6_func;

        uint16_t dio1_func;
        uint16_t dio2_func;

        uint16_t ai1_select;
        uint16_t ai2_select;
        uint16_t ao1_select;
        uint16_t ao2_select;

        uint16_t ro1_source;
        uint16_t ro2_source;
        uint16_t ro3_source;

        uint16_t accel_time;
        uint16_t decel_time;
    } cfg;
} macro_sequential_state_t;

void macro_sequential_init(macro_sequential_state_t *state);
void macro_sequential_update(macro_sequential_state_t *state);
void macro_sequential_apply(macro_sequential_state_t *state);

#endif /* APPLICATIONCONTROL_MACRO_SEQUENTIAL_H */
