#ifndef APPLICATIONCONTROL_MACRO_TORQUE_CONTROL_H
#define APPLICATIONCONTROL_MACRO_TORQUE_CONTROL_H

/* Torque control macro defaults + wiring */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    uint8_t applied;

    struct {
        uint16_t ext1_start;
        uint16_t ext2_start;
        uint16_t ext1_dir;
        uint16_t ext2_dir;
        uint16_t run_enable;
        uint16_t local_ctrl;

        uint16_t trq_ref_sel;
        uint16_t trq_ref_min;
        uint16_t trq_ref_max;
        uint16_t trq_ramp_up;
        uint16_t trq_ramp_down;
        uint16_t speed_window_high;
        uint16_t speed_window_low;

        uint16_t di1_func;
        uint16_t di2_func;
        uint16_t di3_func;
        uint16_t di4_func;
        uint16_t di5_func;
        uint16_t di6_func;

        uint16_t dio1_func;
        uint16_t dio2_func;

        uint16_t ai1_select;
        uint16_t ai2_select;
        uint16_t ao1_select;
        uint16_t ao2_select;

        uint16_t ro1_source;
        uint16_t ro2_source;
        uint16_t ro3_source;

        uint16_t speed_limit;
    } cfg;
} macro_torque_control_state_t;

void macro_torque_control_init(macro_torque_control_state_t *state);
void macro_torque_control_update(macro_torque_control_state_t *state);
void macro_torque_apply(macro_torque_control_state_t *state);

#endif /* APPLICATIONCONTROL_MACRO_TORQUE_CONTROL_H */
