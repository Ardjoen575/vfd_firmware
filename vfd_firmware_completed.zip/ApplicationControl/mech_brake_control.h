#ifndef APPLICATIONCONTROL_MECH_BRAKE_CONTROL_H
#define APPLICATIONCONTROL_MECH_BRAKE_CONTROL_H

/* Mechanical brake control (grp 44) */

#include <stdint.h>

#define BRAKE_STATE_CLOSED      0
#define BRAKE_STATE_OPENING     1
#define BRAKE_STATE_OPEN        2
#define BRAKE_STATE_CLOSING     3
#define BRAKE_STATE_FAULT       4

typedef struct {
    uint8_t initialized;
    uint8_t brake_state;
    uint8_t brake_command;
    uint8_t brake_ack;

    uint8_t torque_proving_active;
    uint8_t raise_request;
    uint8_t lower_request;

    float brake_torque_ref;
    float brake_torque_limit;
    float brake_torque_actual;

    uint16_t open_delay_ms;
    uint16_t close_delay_ms;
    uint16_t open_delay_timer;
    uint16_t close_delay_timer;

    uint16_t torque_prove_time;
    uint16_t torque_prove_timer;

    uint8_t fault_active;
    uint16_t fault_code;
} mech_brake_control_state_t;

void mech_brake_control_init(mech_brake_control_state_t *state);
void mech_brake_control_update(mech_brake_control_state_t *state);
void mech_brake_open(mech_brake_control_state_t *state);
void mech_brake_close(mech_brake_control_state_t *state);

#endif /* APPLICATIONCONTROL_MECH_BRAKE_CONTROL_H */
