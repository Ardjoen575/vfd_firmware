#ifndef APPLICATIONCONTROL_APP_MACROS_H
#define APPLICATIONCONTROL_APP_MACROS_H

/* Application macro dispatcher */

#include <stdint.h>

#define MACRO_NONE       0
#define MACRO_FACTORY    1
#define MACRO_HAND_AUTO  2
#define MACRO_PID_CTRL   3
#define MACRO_TORQUE     4
#define MACRO_SEQUENTIAL 5
#define MACRO_FIELDBUS   6
#define MACRO_COUNT      7

typedef struct {
    uint8_t initialized;
    uint8_t selected_macro;
    uint8_t macro_applied;
    uint8_t macro_changed;

    struct {
        uint16_t param_1001;
        uint16_t param_1002;
        uint16_t param_1003;
        uint16_t param_1102;
        uint16_t param_1103;
        uint16_t param_1201;
        uint16_t param_1301;
        uint16_t param_1401;
        uint16_t param_1501;
        uint16_t param_1601;
        uint16_t param_2001;
        uint16_t param_2002;
        uint16_t param_2101;
        uint16_t param_2102;
    } params;
} app_macros_state_t;

void app_macros_init(app_macros_state_t *state);
void app_macros_update(app_macros_state_t *state);
void macro_apply_selected(app_macros_state_t *state);

#endif /* APPLICATIONCONTROL_APP_MACROS_H */
