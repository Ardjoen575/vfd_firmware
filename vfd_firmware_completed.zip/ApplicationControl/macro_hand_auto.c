#include "macro_hand_auto.h"

void macro_hand_auto_init(macro_hand_auto_state_t *state)
{
    state->initialized = 1;
    state->applied = 0;
    state->hand_active = 0;
    state->auto_active = 0;

    state->cfg.ext1_start = 0;
    state->cfg.ext2_start = 0;
    state->cfg.ext1_dir = 0;
    state->cfg.ext2_dir = 0;
    state->cfg.hand_ref_sel = 1;
    state->cfg.auto_ref_sel = 12;
    state->cfg.hand_start_src = 1;
    state->cfg.auto_start_src = 8;

    state->cfg.di1_func = 1;
    state->cfg.di2_func = 2;
    state->cfg.di3_func = 3;
    state->cfg.di4_func = 4;
    state->cfg.di5_func = 8;
    state->cfg.di6_func = 9;

    state->cfg.dio1_func = 2;
    state->cfg.dio2_func = 3;

    state->cfg.ai1_select = 1;
    state->cfg.ai2_select = 0;
    state->cfg.ao1_select = 2;
    state->cfg.ao2_select = 3;

    state->cfg.ro1_source = 1;
    state->cfg.ro2_source = 2;
    state->cfg.ro3_source = 3;

    state->cfg.accel_time_h = 10;
    state->cfg.decel_time_h = 10;
    state->cfg.accel_time_a = 30;
    state->cfg.decel_time_a = 30;
    state->cfg.hand_speed = 0;
    state->cfg.auto_speed = 0;
}

void macro_hand_auto_update(macro_hand_auto_state_t *state)
{
    if (!state->initialized) return;

    if (state->hand_active && !state->auto_active) {
        state->cfg.ext1_start = state->cfg.hand_start_src;
        state->cfg.ext1_dir = state->cfg.di5_func;
    } else if (!state->hand_active && state->auto_active) {
        state->cfg.ext1_start = state->cfg.auto_start_src;
        state->cfg.ext1_dir = state->cfg.di6_func;
    }
}

void macro_hand_auto_apply(macro_hand_auto_state_t *state)
{
    if (!state->initialized) return;

    state->cfg.di1_func = 1;
    state->cfg.di2_func = 2;
    state->cfg.di3_func = 3;
    state->cfg.di4_func = 4;
    state->cfg.di5_func = 8;
    state->cfg.di6_func = 9;

    state->cfg.dio1_func = 2;
    state->cfg.dio2_func = 3;

    state->cfg.ai1_select = 1;
    state->cfg.ai2_select = 0;
    state->cfg.ao1_select = 2;
    state->cfg.ao2_select = 3;

    state->cfg.ro1_source = 1;
    state->cfg.ro2_source = 2;
    state->cfg.ro3_source = 3;

    state->cfg.hand_ref_sel = 1;
    state->cfg.auto_ref_sel = 12;
    state->cfg.accel_time_h = 10;
    state->cfg.decel_time_h = 10;
    state->cfg.accel_time_a = 30;
    state->cfg.decel_time_a = 30;

    state->applied = 1;
}
