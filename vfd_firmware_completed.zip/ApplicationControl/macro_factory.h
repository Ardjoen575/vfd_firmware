#ifndef APPLICATIONCONTROL_MACRO_FACTORY_H
#define APPLICATIONCONTROL_MACRO_FACTORY_H

/* Factory macro defaults + wiring */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    uint8_t applied;

    struct {
        uint16_t ext1_start;
        uint16_t ext2_start;
        uint16_t ext1_dir;
        uint16_t ext2_dir;
        uint16_t run_enable;
        uint16_t start_mode;
        uint16_t stop_mode;

        uint16_t ref1_select;
        uint16_t ref1_min;
        uint16_t ref1_max;
        uint16_t ref2_select;

        uint16_t di1_func;
        uint16_t di2_func;
        uint16_t di3_func;
        uint16_t di4_func;
        uint16_t di5_func;
        uint16_t di6_func;

        uint16_t dio1_func;
        uint16_t dio2_func;

        uint16_t ai1_select;
        uint16_t ai2_select;
        uint16_t ao1_select;
        uint16_t ao2_select;

        uint16_t ro1_source;
        uint16_t ro2_source;
        uint16_t ro3_source;

        uint16_t accel_time;
        uint16_t decel_time;
        uint16_t max_freq;
        uint16_t min_freq;
        uint16_t nom_freq;
        uint16_t nom_voltage;
        uint16_t nom_current;
        uint16_t nom_speed;
        uint16_t nom_power;
    } cfg;
} macro_factory_state_t;

void macro_factory_init(macro_factory_state_t *state);
void macro_factory_update(macro_factory_state_t *state);
void macro_factory_apply(macro_factory_state_t *state);

#endif /* APPLICATIONCONTROL_MACRO_FACTORY_H */
