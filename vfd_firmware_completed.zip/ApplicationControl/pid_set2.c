#include "pid_set2.h"

void pid_set2_init(pid_set2_state_t *state)
{
    state->initialized = 1;
    state->enabled = 0;

    state->setpoint = 0.0f;
    state->feedback = 0.0f;
    state->error = 0.0f;
    state->prev_error = 0.0f;

    state->gain = 1.0f;
    state->integral_time = 30.0f;
    state->derivative_time = 0.0f;
    state->filter_time = 0.0f;

    state->p_term = 0.0f;
    state->i_term = 0.0f;
    state->d_term = 0.0f;
    state->output = 0.0f;
    state->output_raw = 0.0f;

    state->i_term_limit = 100.0f;
    state->output_max = 100.0f;
    state->output_min = -100.0f;

    state->dt = 0.01f;
    state->sleep_active = 0;
    state->sleep_level = 0.0f;
    state->sleep_delay = 0;
    state->sleep_counter = 0;
    state->wakeup_level = 1.0f;

    state->fb_filter = 0.0f;
    state->fb_filtered = 0.0f;
    state->err_prev1 = 0.0f;
    state->err_prev2 = 0.0f;
}

void pid_set2_update(pid_set2_state_t *state)
{
    if (!state->initialized) return;

    if (state->fb_filter > 0.001f) {
        state->fb_filtered = (state->fb_filter * state->fb_filtered)
                           + ((1.0f - state->fb_filter) * state->feedback);
    } else {
        state->fb_filtered = state->feedback;
    }

    state->error = state->setpoint - state->fb_filtered;

    if (state->sleep_delay > 0) {
        if (state->fb_filtered <= state->sleep_level) {
            state->sleep_counter++;
            if (state->sleep_counter >= state->sleep_delay) {
                state->sleep_active = 1;
            }
        } else if (state->fb_filtered >= state->wakeup_level) {
            state->sleep_counter = 0;
            state->sleep_active = 0;
        }
    }
}

void pid2_compute(pid_set2_state_t *state)
{
    if (!state->initialized) return;
    if (!state->enabled) {
        state->output = 0.0f;
        state->i_term = 0.0f;
        return;
    }

    if (state->sleep_active) {
        state->output = 0.0f;
        return;
    }

    state->p_term = state->gain * state->error;

    if (state->integral_time > 0.001f) {
        float ki = state->dt / state->integral_time;
        state->i_term += state->gain * ki * state->error;

        if (state->i_term > state->i_term_limit) {
            state->i_term = state->i_term_limit;
        }
        if (state->i_term < -state->i_term_limit) {
            state->i_term = -state->i_term_limit;
        }
    } else {
        state->i_term = 0.0f;
    }

    if (state->derivative_time > 0.001f) {
        if (state->filter_time > 0.001f) {
            float alpha = state->filter_time / (state->filter_time + state->dt);
            state->d_term = alpha * state->d_term
                          + (1.0f - alpha) * state->gain * state->derivative_time
                          * (state->error - state->err_prev1) / state->dt;
        } else {
            state->d_term = state->gain * state->derivative_time
                          * (state->error - state->err_prev1) / state->dt;
        }
    } else {
        state->d_term = 0.0f;
    }

    state->err_prev2 = state->err_prev1;
    state->err_prev1 = state->error;

    state->output_raw = state->p_term + state->i_term + state->d_term;

    if (state->output_raw > state->output_max) {
        state->output_raw = state->output_max;
        if (state->error > 0.0f) {
            state->i_term -= state->gain * state->error * state->dt;
        }
    }
    if (state->output_raw < state->output_min) {
        state->output_raw = state->output_min;
        if (state->error < 0.0f) {
            state->i_term -= state->gain * state->error * state->dt;
        }
    }

    state->output = state->output_raw;
}
