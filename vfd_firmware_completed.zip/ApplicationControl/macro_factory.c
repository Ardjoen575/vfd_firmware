#include "macro_factory.h"

void macro_factory_init(macro_factory_state_t *state)
{
    state->initialized = 1;
    state->applied = 0;

    state->cfg.ext1_start = 0;
    state->cfg.ext2_start = 0;
    state->cfg.ext1_dir = 0;
    state->cfg.ext2_dir = 0;
    state->cfg.run_enable = 1;
    state->cfg.start_mode = 1;
    state->cfg.stop_mode = 1;

    state->cfg.ref1_select = 1;
    state->cfg.ref1_min = 0;
    state->cfg.ref1_max = 50;
    state->cfg.ref2_select = 0;

    state->cfg.di1_func = 1;
    state->cfg.di2_func = 2;
    state->cfg.di3_func = 3;
    state->cfg.di4_func = 4;
    state->cfg.di5_func = 5;
    state->cfg.di6_func = 6;

    state->cfg.dio1_func = 2;
    state->cfg.dio2_func = 3;

    state->cfg.ai1_select = 1;
    state->cfg.ai2_select = 2;
    state->cfg.ao1_select = 2;
    state->cfg.ao2_select = 3;

    state->cfg.ro1_source = 1;
    state->cfg.ro2_source = 2;
    state->cfg.ro3_source = 3;

    state->cfg.accel_time = 30;
    state->cfg.decel_time = 30;
    state->cfg.max_freq = 50;
    state->cfg.min_freq = 0;
    state->cfg.nom_freq = 50;
    state->cfg.nom_voltage = 400;
    state->cfg.nom_current = 10;
    state->cfg.nom_speed = 1450;
    state->cfg.nom_power = 5;
}

void macro_factory_update(macro_factory_state_t *state)
{
    if (!state->initialized) return;
}

void macro_factory_apply(macro_factory_state_t *state)
{
    if (!state->initialized) return;

    state->cfg.di1_func = 1;
    state->cfg.di2_func = 2;
    state->cfg.di3_func = 3;
    state->cfg.di4_func = 4;
    state->cfg.di5_func = 5;
    state->cfg.di6_func = 6;

    state->cfg.dio1_func = 2;
    state->cfg.dio2_func = 3;

    state->cfg.ai1_select = 1;
    state->cfg.ai2_select = 0;
    state->cfg.ao1_select = 2;
    state->cfg.ao2_select = 3;

    state->cfg.ro1_source = 1;
    state->cfg.ro2_source = 2;
    state->cfg.ro3_source = 3;

    state->cfg.ref1_select = 1;
    state->cfg.ext1_start = 1;
    state->cfg.run_enable = 1;
    state->cfg.start_mode = 1;
    state->cfg.stop_mode = 1;

    state->applied = 1;
}
