#include "macro_sequential.h"

void macro_sequential_init(macro_sequential_state_t *state)
{
    int i;
    state->initialized = 1;
    state->applied = 0;
    state->active_speed = 0;

    for (i = 0; i < 3; i++) {
        state->di_state[i] = 0;
    }

    state->cfg.ext1_start = 0;
    state->cfg.ext2_start = 0;
    state->cfg.ext1_dir = 0;
    state->cfg.ext2_dir = 0;
    state->cfg.run_enable = 1;

    state->cfg.const_speed[0] = 5;
    state->cfg.const_speed[1] = 10;
    state->cfg.const_speed[2] = 15;
    state->cfg.const_speed[3] = 20;
    state->cfg.const_speed[4] = 25;
    state->cfg.const_speed[5] = 35;
    state->cfg.const_speed[6] = 50;
    state->cfg.speed_sel_inputs = 3;

    state->cfg.di1_func = 1;
    state->cfg.di2_func = 2;
    state->cfg.di3_func = 3;
    state->cfg.di4_func = 9;
    state->cfg.di5_func = 10;
    state->cfg.di6_func = 11;

    state->cfg.dio1_func = 2;
    state->cfg.dio2_func = 3;

    state->cfg.ai1_select = 0;
    state->cfg.ai2_select = 0;
    state->cfg.ao1_select = 2;
    state->cfg.ao2_select = 3;

    state->cfg.ro1_source = 1;
    state->cfg.ro2_source = 2;
    state->cfg.ro3_source = 3;

    state->cfg.accel_time = 20;
    state->cfg.decel_time = 20;
}

void macro_sequential_update(macro_sequential_state_t *state)
{
    if (!state->initialized) return;

    state->active_speed = (state->di_state[2] << 2)
                        | (state->di_state[1] << 1)
                        | (state->di_state[0]);

    if (state->active_speed >= SEQ_MAX_SPEEDS) {
        state->active_speed = 0;
    }
}

void macro_sequential_apply(macro_sequential_state_t *state)
{
    if (!state->initialized) return;

    state->cfg.di1_func = 1;
    state->cfg.di2_func = 2;
    state->cfg.di3_func = 3;
    state->cfg.di4_func = 9;
    state->cfg.di5_func = 10;
    state->cfg.di6_func = 11;

    state->cfg.dio1_func = 2;
    state->cfg.dio2_func = 3;

    state->cfg.ai1_select = 0;
    state->cfg.ai2_select = 0;
    state->cfg.ao1_select = 2;
    state->cfg.ao2_select = 3;

    state->cfg.ro1_source = 1;
    state->cfg.ro2_source = 2;
    state->cfg.ro3_source = 3;

    state->cfg.speed_sel_inputs = 3;
    state->cfg.accel_time = 20;
    state->cfg.decel_time = 20;

    state->applied = 1;
}
