#ifndef APPLICATIONCONTROL_MACRO_FIELDBUS_H
#define APPLICATIONCONTROL_MACRO_FIELDBUS_H

/* Fieldbus control macro defaults + wiring */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    uint8_t applied;

    struct {
        uint16_t ext1_cmd;
        uint16_t ext2_cmd;
        uint16_t run_enable;
        uint16_t fb_par;

        uint16_t ref1_select;
        uint16_t ref2_select;
        uint16_t fb_ref1;
        uint16_t fb_ref2;

        uint16_t di1_func;
        uint16_t di2_func;
        uint16_t di3_func;
        uint16_t di4_func;
        uint16_t di5_func;
        uint16_t di6_func;

        uint16_t dio1_func;
        uint16_t dio2_func;

        uint16_t ai1_select;
        uint16_t ai2_select;
        uint16_t ao1_select;
        uint16_t ao2_select;

        uint16_t ro1_source;
        uint16_t ro2_source;
        uint16_t ro3_source;

        uint16_t fb_comm_loss_time;
        uint16_t fb_comm_loss_func;
        uint16_t fb_profile;
    } cfg;
} macro_fieldbus_state_t;

void macro_fieldbus_init(macro_fieldbus_state_t *state);
void macro_fieldbus_update(macro_fieldbus_state_t *state);
void macro_fieldbus_apply(macro_fieldbus_state_t *state);

#endif /* APPLICATIONCONTROL_MACRO_FIELDBUS_H */
