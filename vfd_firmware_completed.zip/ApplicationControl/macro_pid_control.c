#include "macro_pid_control.h"

void macro_pid_control_init(macro_pid_control_state_t *state)
{
    state->initialized = 1;
    state->applied = 0;

    state->cfg.ext1_start = 0;
    state->cfg.ext2_start = 0;
    state->cfg.ext1_dir = 0;
    state->cfg.ext2_dir = 0;
    state->cfg.run_enable = 1;

    state->cfg.pid_ref_sel = 1;
    state->cfg.pid_fb_sel = 1;
    state->cfg.pid_act_sel = 2;
    state->cfg.pid_output_max = 100;
    state->cfg.pid_output_min = 0;
    state->cfg.pid_gain = 10;
    state->cfg.pid_itime = 30;
    state->cfg.pid_dtime = 0;
    state->cfg.pid_filter = 5;
    state->cfg.pid_sleep_level = 0;
    state->cfg.pid_sleep_delay = 0;
    state->cfg.pid_wakeup_level = 0;

    state->cfg.di1_func = 1;
    state->cfg.di2_func = 2;
    state->cfg.di3_func = 3;
    state->cfg.di4_func = 4;
    state->cfg.di5_func = 0;
    state->cfg.di6_func = 0;

    state->cfg.dio1_func = 2;
    state->cfg.dio2_func = 3;

    state->cfg.ai1_select = 1;
    state->cfg.ai2_select = 2;
    state->cfg.ao1_select = 2;
    state->cfg.ao2_select = 3;

    state->cfg.ro1_source = 1;
    state->cfg.ro2_source = 2;
    state->cfg.ro3_source = 3;

    state->cfg.accel_time = 30;
    state->cfg.decel_time = 30;
}

void macro_pid_control_update(macro_pid_control_state_t *state)
{
    if (!state->initialized) return;
}

void macro_pid_apply(macro_pid_control_state_t *state)
{
    if (!state->initialized) return;

    state->cfg.di1_func = 1;
    state->cfg.di2_func = 2;
    state->cfg.di3_func = 11;
    state->cfg.di4_func = 4;
    state->cfg.di5_func = 0;
    state->cfg.di6_func = 0;

    state->cfg.dio1_func = 2;
    state->cfg.dio2_func = 3;

    state->cfg.ai1_select = 1;
    state->cfg.ai2_select = 2;
    state->cfg.ao1_select = 2;
    state->cfg.ao2_select = 3;

    state->cfg.ro1_source = 1;
    state->cfg.ro2_source = 2;
    state->cfg.ro3_source = 3;

    state->cfg.pid_ref_sel = 1;
    state->cfg.pid_fb_sel = 2;
    state->cfg.pid_gain = 10;
    state->cfg.pid_itime = 30;
    state->cfg.pid_dtime = 0;
    state->cfg.pid_output_max = 100;
    state->cfg.pid_output_min = 0;

    state->applied = 1;
}
