#ifndef APPLICATIONCONTROL_MOTOR_POTENTIOMETER_H
#define APPLICATIONCONTROL_MOTOR_POTENTIOMETER_H

/* Motor potentiometer function */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    uint8_t enabled;
    uint8_t up_input;
    uint8_t down_input;
    uint8_t prev_up;
    uint8_t prev_down;

    float output_value;
    float output_min;
    float output_max;
    float ramp_step;

    float step_up;
    float step_down;

    uint8_t store_active;
    uint8_t restore_active;
    float stored_value;

    uint16_t ramp_up_time;
    uint16_t ramp_down_time;
    uint16_t cycle_time_ms;
} motor_potentiometer_state_t;

void motor_potentiometer_init(motor_potentiometer_state_t *state);
void motor_potentiometer_update(motor_potentiometer_state_t *state);
void motpot_step(motor_potentiometer_state_t *state);

#endif /* APPLICATIONCONTROL_MOTOR_POTENTIOMETER_H */
