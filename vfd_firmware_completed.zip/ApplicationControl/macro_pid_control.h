#ifndef APPLICATIONCONTROL_MACRO_PID_CONTROL_H
#define APPLICATIONCONTROL_MACRO_PID_CONTROL_H

/* PID control macro defaults + wiring */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    uint8_t applied;

    struct {
        uint16_t ext1_start;
        uint16_t ext2_start;
        uint16_t ext1_dir;
        uint16_t ext2_dir;
        uint16_t run_enable;

        uint16_t pid_ref_sel;
        uint16_t pid_fb_sel;
        uint16_t pid_act_sel;
        uint16_t pid_output_max;
        uint16_t pid_output_min;
        uint16_t pid_gain;
        uint16_t pid_itime;
        uint16_t pid_dtime;
        uint16_t pid_filter;
        uint16_t pid_sleep_level;
        uint16_t pid_sleep_delay;
        uint16_t pid_wakeup_level;

        uint16_t di1_func;
        uint16_t di2_func;
        uint16_t di3_func;
        uint16_t di4_func;
        uint16_t di5_func;
        uint16_t di6_func;

        uint16_t dio1_func;
        uint16_t dio2_func;

        uint16_t ai1_select;
        uint16_t ai2_select;
        uint16_t ao1_select;
        uint16_t ao2_select;

        uint16_t ro1_source;
        uint16_t ro2_source;
        uint16_t ro3_source;

        uint16_t accel_time;
        uint16_t decel_time;
    } cfg;
} macro_pid_control_state_t;

void macro_pid_control_init(macro_pid_control_state_t *state);
void macro_pid_control_update(macro_pid_control_state_t *state);
void macro_pid_apply(macro_pid_control_state_t *state);

#endif /* APPLICATIONCONTROL_MACRO_PID_CONTROL_H */
