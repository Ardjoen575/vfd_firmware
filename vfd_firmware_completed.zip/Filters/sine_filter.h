#ifndef FILTERS_SINE_FILTER_H
#define FILTERS_SINE_FILTER_H

#include <stdint.h>

#define SINE_TEMP_MAX_C         110
#define SINE_TEMP_WARN_C         90
#define SINE_OVERCURRENT_A      250
#define SINE_OVERVOLTAGE_V      850
#define SINE_SAMPLE_COUNT         8
#define SINE_RESONANCE_FREQ_HZ   50

typedef enum {
    SINE_STATUS_OK             = 0,
    SINE_STATUS_TEMP_WARNING   = 1,
    SINE_STATUS_OVERCURRENT    = 2,
    SINE_STATUS_RESONANCE      = 3,
    SINE_STATUS_COMM_FAIL      = 4,
    SINE_STATUS_CAP_DEGRADED   = 5,
    SINE_STATUS_FAULT          = 6,
    SINE_STATUS_DISABLED       = 7,
    SINE_STATUS_NOT_INSTALLED  = 8,
} sine_status_t;

typedef struct {
    uint8_t        initialized;
    uint8_t        installed;
    uint8_t        enabled;
    sine_status_t  status;
    int16_t        inductor_temp_c;
    int16_t        capacitor_temp_c;
    int16_t        temp_samples[SINE_SAMPLE_COUNT];
    uint8_t        temp_sample_idx;
    uint32_t       output_voltage_v;
    uint32_t       output_current_a;
    uint32_t       output_frequency_hz;
    uint32_t       resonance_hits;
    uint32_t       fault_code;
    uint32_t       run_hours;
    uint32_t       overload_count;
    uint32_t       capacitor_esr_milliohm;
    uint32_t       capacitor_capacity_uF;
} sine_filter_state_t;

void sine_filter_init(sine_filter_state_t *state);
void sine_filter_update(sine_filter_state_t *state);
sine_status_t sine_filter_check(sine_filter_state_t *state);

#endif
