#include "dudt_filter.h"
#include <string.h>

dudt_status_t dudt_filter_check(dudt_filter_state_t *state)
{
    int32_t dv, di;
    int32_t sum;
    int16_t avg_temp;
    uint8_t i;

    if (state == 0) return DUDT_STATUS_DISABLED;
    if (!state->installed || !state->enabled) {
        state->status = DUDT_STATUS_DISABLED;
        return state->status;
    }

    avg_temp = state->temperature_c;
    if (state->temp_sample_idx > 0) {
        sum = 0;
        for (i = 0; i < DUDT_SAMPLE_COUNT; i++) {
            sum += state->temp_samples[i];
        }
        avg_temp = (int16_t)(sum / DUDT_SAMPLE_COUNT);
    }

    dv = state->output_voltage_v - state->prev_voltage_v;
    if (dv < 0) dv = -dv;
    state->dv_dt_v_us = (uint32_t)dv;

    di = state->output_current_a - state->prev_current_a;
    if (di < 0) di = -di;
    state->di_dt_a_ms = (uint32_t)di;

    if (avg_temp >= DUDT_TEMP_MAX_C) {
        state->status = DUDT_STATUS_FAULT;
        state->fault_code = 0x4201;
    } else if (avg_temp >= DUDT_TEMP_WARN_C) {
        state->status = DUDT_STATUS_WARNING;
        state->fault_code = 0x4202;
    } else if (state->dv_dt_v_us > DUDT_MAX_DV_DT_V_US) {
        state->status = DUDT_STATUS_FAULT;
        state->fault_code = 0x4203;
    } else if (state->di_dt_a_ms > DUDT_MAX_DI_DT_A_MS) {
        state->status = DUDT_STATUS_WARNING;
        state->fault_code = 0x4204;
    } else if (avg_temp < 0) {
        state->status = DUDT_STATUS_COMM_FAIL;
        state->fault_code = 0x4205;
    } else {
        state->status = DUDT_STATUS_OK;
        state->fault_code = 0;
    }

    if (state->status == DUDT_STATUS_FAULT) {
        state->overload_count++;
    }

    state->prev_voltage_v = state->output_voltage_v;
    state->prev_current_a = state->output_current_a;

    return state->status;
}

void dudt_filter_init(dudt_filter_state_t *state)
{
    if (state == 0) return;

    memset(state, 0, sizeof(dudt_filter_state_t));
    state->initialized = 1;
    state->installed   = 1;
    state->enabled     = 0;
    state->status      = DUDT_STATUS_DISABLED;
}

void dudt_filter_update(dudt_filter_state_t *state)
{
    if (state == 0 || !state->initialized) return;

    state->temp_samples[state->temp_sample_idx] = state->temperature_c;
    state->temp_sample_idx++;
    if (state->temp_sample_idx >= DUDT_SAMPLE_COUNT) {
        state->temp_sample_idx = 0;
    }

    state->run_hours++;

    dudt_filter_check(state);
}
