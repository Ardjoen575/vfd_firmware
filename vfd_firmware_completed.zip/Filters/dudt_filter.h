#ifndef FILTERS_DUDT_FILTER_H
#define FILTERS_DUDT_FILTER_H

#include <stdint.h>

#define DUDT_TEMP_MAX_C         100
#define DUDT_TEMP_WARN_C         85
#define DUDT_CURRENT_MAX_A      200
#define DUDT_VOLTAGE_MAX_V      800
#define DUDT_SAMPLE_COUNT         8
#define DUDT_MAX_DV_DT_V_US    1000
#define DUDT_MAX_DI_DT_A_MS     500

typedef enum {
    DUDT_STATUS_OK        = 0,
    DUDT_STATUS_WARNING   = 1,
    DUDT_STATUS_FAULT     = 2,
    DUDT_STATUS_DISABLED  = 3,
    DUDT_STATUS_COMM_FAIL = 4,
} dudt_status_t;

typedef struct {
    uint8_t       initialized;
    uint8_t       installed;
    uint8_t       enabled;
    dudt_status_t status;
    int16_t       temperature_c;
    int16_t       temp_samples[DUDT_SAMPLE_COUNT];
    uint8_t       temp_sample_idx;
    int32_t       output_voltage_v;
    int32_t       output_current_a;
    int32_t       prev_voltage_v;
    int32_t       prev_current_a;
    uint32_t      dv_dt_v_us;
    uint32_t      di_dt_a_ms;
    uint32_t      fault_code;
    uint32_t      run_hours;
    uint32_t      overload_count;
} dudt_filter_state_t;

void dudt_filter_init(dudt_filter_state_t *state);
void dudt_filter_update(dudt_filter_state_t *state);
dudt_status_t dudt_filter_check(dudt_filter_state_t *state);

#endif
