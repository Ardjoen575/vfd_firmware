#include "sine_filter.h"
#include <string.h>

sine_status_t sine_filter_check(sine_filter_state_t *state)
{
    int32_t sum;
    int16_t avg_temp;
    uint8_t i;

    if (state == 0) return SINE_STATUS_NOT_INSTALLED;
    if (!state->installed) {
        state->status = SINE_STATUS_NOT_INSTALLED;
        return state->status;
    }
    if (!state->enabled) {
        state->status = SINE_STATUS_DISABLED;
        return state->status;
    }

    avg_temp = state->inductor_temp_c;
    if (state->temp_sample_idx > 0) {
        sum = 0;
        for (i = 0; i < SINE_SAMPLE_COUNT; i++) {
            sum += state->temp_samples[i];
        }
        avg_temp = (int16_t)(sum / SINE_SAMPLE_COUNT);
    }

    if (avg_temp < -50) {
        state->status = SINE_STATUS_COMM_FAIL;
        state->fault_code = 0x4301;
    } else if (avg_temp >= SINE_TEMP_MAX_C) {
        state->status = SINE_STATUS_FAULT;
        state->fault_code = 0x4302;
    } else if (avg_temp >= SINE_TEMP_WARN_C) {
        state->status = SINE_STATUS_TEMP_WARNING;
        state->fault_code = 0x4303;
    } else if (state->capacitor_temp_c >= SINE_TEMP_MAX_C) {
        state->status = SINE_STATUS_FAULT;
        state->fault_code = 0x4304;
    } else if (state->output_current_a >= SINE_OVERCURRENT_A) {
        state->status = SINE_STATUS_OVERCURRENT;
        state->fault_code = 0x4305;
    } else if (state->output_voltage_v >= SINE_OVERVOLTAGE_V) {
        state->status = SINE_STATUS_OVERCURRENT;
        state->fault_code = 0x4306;
    } else if (state->capacitor_esr_milliohm > 500) {
        state->status = SINE_STATUS_CAP_DEGRADED;
        state->fault_code = 0x4307;
    } else if (state->output_frequency_hz >= 120 &&
               state->output_frequency_hz <= 200) {
        state->resonance_hits++;
        state->status = SINE_STATUS_RESONANCE;
        state->fault_code = 0x4308;
    } else {
        state->status = SINE_STATUS_OK;
        state->fault_code = 0;
    }

    if (state->status == SINE_STATUS_FAULT ||
        state->status == SINE_STATUS_OVERCURRENT) {
        state->overload_count++;
    }

    return state->status;
}

void sine_filter_init(sine_filter_state_t *state)
{
    if (state == 0) return;

    memset(state, 0, sizeof(sine_filter_state_t));
    state->initialized = 1;
    state->installed   = 0;
    state->enabled     = 0;
    state->status      = SINE_STATUS_NOT_INSTALLED;
    state->capacitor_capacity_uF = 330;
}

void sine_filter_update(sine_filter_state_t *state)
{
    if (state == 0 || !state->initialized) return;

    state->temp_samples[state->temp_sample_idx] = state->inductor_temp_c;
    state->temp_sample_idx++;
    if (state->temp_sample_idx >= SINE_SAMPLE_COUNT) {
        state->temp_sample_idx = 0;
    }

    state->run_hours++;

    sine_filter_check(state);
}
