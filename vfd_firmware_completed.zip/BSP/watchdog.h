#ifndef BSP_WATCHDOG_H
#define BSP_WATCHDOG_H
void watchdog_init(void);
void watchdog_kick(void);
#endif
