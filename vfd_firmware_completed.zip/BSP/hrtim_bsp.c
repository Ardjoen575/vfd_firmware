#include "hrtim_bsp.h"
#include <stdint.h>

typedef struct {
    volatile uint32_t CR1;
    volatile uint32_t CR2;
    volatile uint32_t SMCR;
    volatile uint32_t DIER;
    volatile uint32_t SR;
    volatile uint32_t EGR;
    volatile uint32_t CCMR1;
    volatile uint32_t CCMR2;
    volatile uint32_t CCER;
    volatile uint32_t CNT;
    volatile uint32_t PSC;
    volatile uint32_t ARR;
    volatile uint32_t RCR;
    volatile uint32_t CCR1;
    volatile uint32_t CCR2;
    volatile uint32_t CCR3;
    volatile uint32_t CCR4;
    volatile uint32_t BDTR;
    volatile uint32_t DCR;
    volatile uint32_t DMAR;
} tim_advanced_t;

typedef struct {
    volatile uint16_t CR1;
    uint16_t _pad0;
    volatile uint16_t CR2;
    uint16_t _pad1;
    volatile uint16_t SMCR;
    uint16_t _pad2;
    volatile uint16_t DIER;
    uint16_t _pad3;
    volatile uint16_t SR;
    uint16_t _pad4;
    volatile uint16_t EGR;
    uint16_t _pad5;
    volatile uint16_t CCMR1;
    uint16_t _pad6;
    volatile uint16_t CCMR2;
    uint16_t _pad7;
    volatile uint16_t CCER;
    uint16_t _pad8;
    volatile uint16_t CNT;
    uint16_t _pad9;
    volatile uint16_t PSC;
    uint16_t _pad10;
    volatile uint16_t ARR;
    uint16_t _pad11;
    volatile uint16_t RCR;
    uint16_t _pad12;
    volatile uint16_t CCR1;
    uint16_t _pad13;
    volatile uint16_t CCR2;
    uint16_t _pad14;
    volatile uint16_t CCR3;
    uint16_t _pad15;
    volatile uint16_t CCR4;
    uint16_t _pad16;
    volatile uint16_t BDTR;
    uint16_t _pad17;
    volatile uint16_t DCR;
    uint16_t _pad18;
    volatile uint16_t DMAR;
    uint16_t _pad19;
} tim_gen_t;

#define TIM1_BASE ((tim_advanced_t *)0x40010000UL)
#define TIM8_BASE ((tim_advanced_t *)0x40010400UL)
#define TIM1      (TIM1_BASE)
#define TIM8      (TIM8_BASE)

#define TIM2_BASE ((tim_gen_t *)0x40000000UL)
#define TIM3_BASE ((tim_gen_t *)0x40000400UL)
#define TIM4_BASE ((tim_gen_t *)0x40000800UL)

#define TIM_CR1_CEN         (1UL << 0)
#define TIM_CR1_UDIS        (1UL << 1)
#define TIM_CR1_ARPE        (1UL << 7)
#define TIM_CR1_CMS_CENTER1 (0x1UL << 5)
#define TIM_CR1_CMS_CENTER2 (0x2UL << 5)
#define TIM_CR1_CMS_CENTER3 (0x3UL << 5)

#define TIM_CR2_OIS1        (1UL << 8)
#define TIM_CR2_OIS1N       (1UL << 9)
#define TIM_CR2_OIS2        (1UL << 10)
#define TIM_CR2_OIS2N       (1UL << 11)
#define TIM_CR2_OIS3        (1UL << 12)
#define TIM_CR2_OIS3N       (1UL << 13)
#define TIM_CR2_OIS4        (1UL << 14)
#define TIM_CR2_CCPC        (1UL << 0)

#define TIM_CCMR1_OC1M_PWM2 (0x7UL << 4)
#define TIM_CCMR1_OC2M_PWM2 (0x7UL << 12)
#define TIM_CCMR1_OC1PE     (1UL << 3)
#define TIM_CCMR1_OC2PE     (1UL << 11)
#define TIM_CCMR2_OC3M_PWM2 (0x7UL << 4)
#define TIM_CCMR2_OC4M_PWM2 (0x7UL << 12)
#define TIM_CCMR2_OC3PE     (1UL << 3)
#define TIM_CCMR2_OC4PE     (1UL << 11)

#define TIM_CCER_CC1E       (1UL << 0)
#define TIM_CCER_CC1NE      (1UL << 2)
#define TIM_CCER_CC2E       (1UL << 4)
#define TIM_CCER_CC2NE      (1UL << 6)
#define TIM_CCER_CC3E       (1UL << 8)
#define TIM_CCER_CC3NE      (1UL << 10)
#define TIM_CCER_CC4E       (1UL << 12)
#define TIM_CCER_CC1P       (1UL << 1)
#define TIM_CCER_CC1NP      (1UL << 3)
#define TIM_CCER_CC2P       (1UL << 5)
#define TIM_CCER_CC2NP      (1UL << 7)
#define TIM_CCER_CC3P       (1UL << 9)
#define TIM_CCER_CC3NP      (1UL << 11)

#define TIM_BDTR_MOE        (1UL << 15)
#define TIM_BDTR_AOE        (1UL << 14)
#define TIM_BDTR_BKP        (1UL << 13)
#define TIM_BDTR_BKE        (1UL << 12)
#define TIM_BDTR_OSSR       (1UL << 11)
#define TIM_BDTR_OSSI       (1UL << 10)
#define TIM_BDTR_LOCK_1     (0x1UL << 8)

#define TIM_BDTR_DTG_Msk    (0xFFUL)
#define TIM_BDTR_DTG_250NS  (50UL)

#define TIM_DIER_UDE        (1UL << 8)
#define TIM_DIER_CC4DE      (1UL << 12)
#define TIM_DIER_COMDE      (1UL << 13)
#define TIM_DIER_UIE        (1UL << 0)

#define TIM_EGR_UG          (1UL << 0)

#define TIM_SMCR_MSM        (1UL << 7)
#define TIM_SMCR_TS_ITR0    (0x0UL << 4)
#define TIM_SMCR_TS_ITR1    (0x1UL << 4)

#define PWM_FREQUENCY    16000     /* 16 kHz PWM */
#define TIM1_CLK         168000000 /* TIM1 on APB2 -> 168 MHz (APB2 / 1 when prescaler != 1; actually 168 MHz) */
#define TIM1_PSC         0         /* no prescaler -> 168 MHz timer clock */
#define TIM1_PERIOD      ((TIM1_CLK / (PWM_FREQUENCY * 2)) - 1) /* center-aligned -> half-period */

#define DEADTIME_NS      1000      /* 1 us dead time */
/* DTG = deadtime_ns / (1 / TIM1_CLK) = deadtime_ns * TIM1_CLK / 1e9
 * For 1 us at 168 MHz -> 168 ticks.
 * DTG[7:5]=0xx: DTG[7:0] = deadtime * tDTS, tDTS = 1/168M ~= 5.95 ns
 * 1000 / 5.95 ~= 168.
 * For > 127, need DTG[7:5] = 110 (range: (64+dtg[5:0])*2*tDTS, 64..127*2*tDTS)
 * 168/2 = 84, 84-64 = 20 -> DTG = 0x74 (110b << 5 | 20)
 * Actually simpler: DTG[7:5]=111 -> (32+dtg[4:0])*16*tDTS, range: 32*16=512..63*16=1008
 * 1000ns / 95.2ns = 10.5 -> not enough.
 * DTG[7:5]=110 -> (64+dtg[5:0])*2*tDTS, range: 128..254 ticks = 762..1511 ns
 * 168 ticks -> 999.6 ns. DTG = 0x60 | (168-64)/2 = 0x60 | 52 = 0x74
 */

#define DEADTIME_DTG     (0x74UL)   /* ~1 us deadtime at 168 MHz */

static void tim1_configure(void)
{
    tim_advanced_t *t = TIM1;

    /*
     * Disable timer and wait for it to stop.
     */
    t->CR1 &= ~TIM_CR1_CEN;

    t->CR1 = 0;

    /*
     * Center-aligned mode 1 (up-down counting, interrupt on underflow = center of PWM).
     * Auto-reload preload enabled.
     */
    t->CR1 = TIM_CR1_ARPE | TIM_CR1_CMS_CENTER1;

    /*
     * Transfer control: preloaded registers, idle state PWM outputs low.
     */
    t->CR2 = TIM_CR2_CCPC
           | TIM_CR2_OIS1
           | TIM_CR2_OIS1N
           | TIM_CR2_OIS2
           | TIM_CR2_OIS2N
           | TIM_CR2_OIS3
           | TIM_CR2_OIS3N
           | TIM_CR2_OIS4;

    /*
     * PWM mode 2 on all channels: OCxREF = 1 when CNT > CCRx
     * (active high for high-side, low true for low-side since inverted).
     * Preload enabled on all channels.
     */
    t->CCMR1 = TIM_CCMR1_OC1PE | TIM_CCMR1_OC1M_PWM2
             | TIM_CCMR1_OC2PE | TIM_CCMR1_OC2M_PWM2;

    t->CCMR2 = TIM_CCMR2_OC3PE | TIM_CCMR2_OC3M_PWM2
             | TIM_CCMR2_OC4PE | TIM_CCMR2_OC4M_PWM2;

    /*
     * All 6 PWM channels and CH4 enabled.
     *   CH1(CH1N) on PE9/PE8, CH2(CH2N) on PE11/PE10, CH3(CH3N) on PE13/PE12
     *   CH4 on PE14 (brake chopper).
     * All active high; complementary outputs also active high
     * (PWM low-side will be inverted in commutation logic later).
     */
    t->CCER = TIM_CCER_CC1E | TIM_CCER_CC1NE
            | TIM_CCER_CC2E | TIM_CCER_CC2NE
            | TIM_CCER_CC3E | TIM_CCER_CC3NE
            | TIM_CCER_CC4E;

    /*
     * Period register: half-period for center-aligned.
     */
    t->ARR = TIM1_PERIOD;

    /*
     * All CCRs to 50% duty (safe disabled state, zero voltage vector).
     */
    t->CCR1 = TIM1_PERIOD / 2;
    t->CCR2 = TIM1_PERIOD / 2;
    t->CCR3 = TIM1_PERIOD / 2;
    t->CCR4 = 0;

    /*
     * Dead-time insertion:
     *   DTG = ~1 us
     *   Lock level 1 (BDTR locked until next reset)
     *   Automatic output enable, break polarity active high
     *   OSSR = 1 (off-state for inactive channels = idle level)
     *   OSSI = 1 (off-state during idle = idle level)
     */
    t->BDTR = DEADTIME_DTG
            | TIM_BDTR_LOCK_1
            | TIM_BDTR_OSSR
            | TIM_BDTR_OSSI
            | TIM_BDTR_AOE
            | TIM_BDTR_MOE;

    /*
     * Prescaler = 0 (direct 168 MHz timer clock).
     */
    t->PSC = TIM1_PSC;

    /*
     * Repetition counter = 0 (update event every period).
     */
    t->RCR = 0;

    /*
     * Generate update event to load shadow registers.
     */
    t->EGR = TIM_EGR_UG;

    /*
     * DMA requests on update and COM events.
     */
    t->DIER |= TIM_DIER_UDE | TIM_DIER_COMDE;

    /*
     * Enable timer.
     */
    t->CR1 |= TIM_CR1_CEN;
}

static void tim8_configure(void)
{
    tim_advanced_t *t = TIM8;

    t->CR1 = 0;

    /*
     * TIM8 slaved to TIM1 trigger (ITR0 connection).
     * Center-aligned, same ARR as TIM1.
     */
    t->SMCR = TIM_SMCR_TS_ITR0 | TIM_SMCR_MSM;

    t->CR1 = TIM_CR1_ARPE | TIM_CR1_CMS_CENTER1;

    t->CR2 = TIM_CR2_CCPC;

    /*
     * TIM8 provides ADC trigger: CC4 event at center of PWM cycle.
     */
    t->CCMR2 = TIM_CCMR2_OC4PE | TIM_CCMR2_OC4M_PWM2;

    t->CCER = TIM_CCER_CC4E;

    t->ARR = TIM1_PERIOD;

    /*
     * CC4 = 0 (trigger at bottom of center-aligned cycle for ADC).
     */
    t->CCR4 = 0;

    t->PSC = TIM1_PSC;
    t->RCR = 0;

    t->BDTR = TIM_BDTR_MOE;

    t->EGR = TIM_EGR_UG;

    t->CR1 |= TIM_CR1_CEN;
}

void hrtim_bsp_init(void)
{
    tim1_configure();
    tim8_configure();
}
