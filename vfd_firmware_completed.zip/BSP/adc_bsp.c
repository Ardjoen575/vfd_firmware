#include "adc_bsp.h"
#include <stdint.h>

typedef struct {
    volatile uint32_t SR;
    volatile uint32_t CR1;
    volatile uint32_t CR2;
    volatile uint32_t SMPR1;
    volatile uint32_t SMPR2;
    volatile uint32_t JOFR1;
    volatile uint32_t JOFR2;
    volatile uint32_t JOFR3;
    volatile uint32_t JOFR4;
    volatile uint32_t HTR;
    volatile uint32_t LTR;
    volatile uint32_t SQR1;
    volatile uint32_t SQR2;
    volatile uint32_t SQR3;
    volatile uint32_t JSQR;
    volatile uint32_t JDR1;
    volatile uint32_t JDR2;
    volatile uint32_t JDR3;
    volatile uint32_t JDR4;
    volatile uint32_t DR;
    uint32_t _pad0;
    volatile uint32_t CSR;
    volatile uint32_t CCR;
    volatile uint32_t CDR;
} adc_t;

#define ADC1_BASE  ((adc_t *)0x40012000UL)
#define ADC2_BASE  ((adc_t *)0x40012100UL)
#define ADC3_BASE  ((adc_t *)0x40012200UL)
#define ADC_COMMON ((adc_t *)0x40012300UL)

#define ADC1 (ADC1_BASE)
#define ADC2 (ADC2_BASE)
#define ADC3 (ADC3_BASE)
#define ADC_CO (ADC_COMMON)

#define ADC_CR1_SCAN           (1UL << 8)
#define ADC_CR1_JAUTO          (1UL << 14)
#define ADC_CR1_JDISCEN        (1UL << 12)
#define ADC_CR1_AWDEN          (1UL << 23)
#define ADC_CR1_AWDSGL         (1UL << 22)
#define ADC_CR1_OVRIE          (1UL << 26)
#define ADC_CR1_RES_12BIT      (0x0UL << 24)

#define ADC_CR2_ADON           (1UL << 0)
#define ADC_CR2_CONT           (1UL << 1)
#define ADC_CR2_DMA            (1UL << 8)
#define ADC_CR2_DDS            (1UL << 9)
#define ADC_CR2_EOCS           (1UL << 10)
#define ADC_CR2_JEXTEN_RISING  (0x1UL << 12)
#define ADC_CR2_JEXTSEL_TIM1_TRGO (0x4UL << 16)
#define ADC_CR2_EXTEN_RISING   (0x1UL << 28)
#define ADC_CR2_EXTSEL_TIM1_CC4 (0x4UL << 24)
#define ADC_CR2_SWSTART        (1UL << 30)
#define ADC_CR2_JSWSTART       (1UL << 22)

#define ADC_SMPR_15CYCLES      (0x1UL)     /* 15 ADC cycles */
#define ADC_SMPR_28CYCLES      (0x2UL)     /* 28 ADC cycles */
#define ADC_SMPR_56CYCLES      (0x3UL)     /* 56 ADC cycles */
#define ADC_SMPR_84CYCLES      (0x4UL)     /* 84 ADC cycles */
#define ADC_SMPR_112CYCLES     (0x5UL)     /* 112 ADC cycles */
#define ADC_SMPR_144CYCLES     (0x6UL)     /* 144 ADC cycles */
#define ADC_SMPR_480CYCLES     (0x7UL)     /* 480 ADC cycles */

#define ADC_CSR_MULTI_MSK      (0x3UL << 16)
#define ADC_CSR_MULTI_DUAL_SIM_INJ_SIM  (0x1UL << 16) /* DMA mode 1 */

#define ADC_CCR_ADCPRE_DIV2    (0x0UL << 16)
#define ADC_CCR_ADCPRE_DIV4    (0x1UL << 16)
#define ADC_CCR_ADCPRE_DIV6    (0x2UL << 16)
#define ADC_CCR_ADCPRE_DIV8    (0x3UL << 16)
#define ADC_CCR_TSVREFE        (1UL << 23)
#define ADC_CCR_VBATE          (1UL << 22)

#define ADC_SR_OVR             (1UL << 5)

static void adc_common_configure(void)
{
    /*
     * Dual simultaneous regular + injected mode.
     * ADC1 master, ADC2 slave.
     * ADC clock = APB2 / 4 = 84 MHz / 4 = 21 MHz (max 36 MHz).
     */
    ADC_CO->CCR |= ADC_CCR_ADCPRE_DIV4;
    ADC_CO->CCR &= ~ADC_CCR_TSVREFE;

    /*
     * Multi mode:
     *   DMA mode 1: Dual simultaneous regular + injected simultaneous
     *   DMA request from ADC1, one 32-bit word per conversion pair
     *   (ADC2 result in upper halfword, ADC1 in lower)
     */
    uint32_t csr = ADC_CO->CSR;
    csr &= ~ADC_CSR_MULTI_MSK;
    csr |= ADC_CSR_MULTI_DUAL_SIM_INJ_SIM;
    ADC_CO->CSR = csr;
}

static void adc1_configure(void)
{
    adc_t *a = ADC1;

    a->CR1 = ADC_CR1_SCAN | ADC_CR1_JAUTO | ADC_CR1_RES_12BIT;

    /*
     * Sample times — use 144 cycles for analog inputs
     * SMPR channels 0..7: PA0-PA7
     */
    a->SMPR2 = (ADC_SMPR_144CYCLES << 0)   /* ch0 */
             | (ADC_SMPR_144CYCLES << 3)   /* ch1 */
             | (ADC_SMPR_144CYCLES << 6)   /* ch2 */
             | (ADC_SMPR_144CYCLES << 9)   /* ch3 */
             | (ADC_SMPR_144CYCLES << 12)  /* ch4 */
             | (ADC_SMPR_144CYCLES << 15)  /* ch5 */
             | (ADC_SMPR_144CYCLES << 18)  /* ch6 */
             | (ADC_SMPR_144CYCLES << 21)  /* ch7 */
             | (ADC_SMPR_480CYCLES << 24)  /* ch8  (internal temp sensor) */
             | (ADC_SMPR_480CYCLES << 27); /* ch9 */

    /*
     * Regular sequence: 5 conversions
     *   ch3 (ADC1_IN3 = DC bus, from PA3),
     *   ch4 (temp), ch5 (ain1), ch6 (ain2), ch7 (pot)
     */
    a->SQR1 = ((5UL - 1) << 20);         /* L = 5 conversions */

    /* SQ1..SQ5 in SQR3 */
    a->SQR3 = (3UL << 0)                 /* SQ1 = ch3 */
            | (4UL << 5)                 /* SQ2 = ch4 */
            | (5UL << 10)                /* SQ3 = ch5 */
            | (6UL << 15)                /* SQ4 = ch6 */
            | (7UL << 20);               /* SQ5 = ch7 */

    /*
     * Injected sequence: 3 conversions (phase currents)
     *   ch0 (current U), ch1 (current V), ch2 (current W)
     *   jl = 3
     */
    a->JSQR = ((3UL - 1) << 20)         /* JL = 3 */
            | (0UL << 15)                /* JSQ1 = ch0 */
            | (1UL << 10)                /* JSQ2 = ch1 */
            | (2UL << 5);                /* JSQ3 = ch2 */

    /*
     * Injected trigger from TIM1_TRGO (update event or OC4),
     * rising edge. Regular trigger from TIM1_CC4.
     */
    a->CR2 = ADC_CR2_ADON
           | ADC_CR2_CONT
           | ADC_CR2_DMA
           | ADC_CR2_DDS
           | ADC_CR2_EOCS
           | ADC_CR2_JEXTEN_RISING
           | ADC_CR2_JEXTSEL_TIM1_TRGO
           | ADC_CR2_EXTEN_RISING
           | ADC_CR2_EXTSEL_TIM1_CC4;

    while (!(a->SR & (1UL << 6))) { __asm__ volatile("nop"); } /* wait EOC */
}

static void adc2_configure(void)
{
    adc_t *a = ADC2;

    a->CR1 = ADC_CR1_RES_12BIT;

    a->SMPR2 = (ADC_SMPR_144CYCLES << 6); /* ch2 (ADC2_IN2 = current W redundant) */

    a->SQR1 = ((1UL - 1) << 20);
    a->SQR3 = (2UL << 0);                /* SQ1 = ch2 */

    a->JSQR = ((3UL - 1) << 20)
            | (0UL << 15)
            | (1UL << 10)
            | (2UL << 5);

    a->CR2 = ADC_CR2_ADON
           | ADC_CR2_CONT
           | ADC_CR2_EOCS;

    while (!(a->SR & (1UL << 6))) { __asm__ volatile("nop"); }
}

static void adc3_configure(void)
{
    adc_t *a = ADC3;

    a->CR1 = ADC_CR1_RES_12BIT;

    a->SMPR2 = (ADC_SMPR_144CYCLES << 9); /* ch3 = DC bus redundant */

    a->SQR1 = ((1UL - 1) << 20);
    a->SQR3 = (3UL << 0);                /* SQ1 = ch3 */

    a->CR2 = ADC_CR2_ADON
           | ADC_CR2_CONT
           | ADC_CR2_EOCS;

    while (!(a->SR & (1UL << 6))) { __asm__ volatile("nop"); }
}

void adc_bsp_init(void)
{
    adc_common_configure();

    adc1_configure();
    adc2_configure();
    adc3_configure();

    /*
     * Clear overflow flags across all ADCs before enabling.
     */
    ADC1->SR &= ~ADC_SR_OVR;
    ADC2->SR &= ~ADC_SR_OVR;
    ADC3->SR &= ~ADC_SR_OVR;
}
