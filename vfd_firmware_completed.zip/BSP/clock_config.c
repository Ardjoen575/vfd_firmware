#include "clock_config.h"
#include <stdint.h>

#define RCC_BASE            ((volatile uint32_t *)0x40023800UL)
#define RCC_CR              (*(volatile uint32_t *)(RCC_BASE + 0x00))
#define RCC_PLLCFGR         (*(volatile uint32_t *)(RCC_BASE + 0x04))
#define RCC_CFGR            (*(volatile uint32_t *)(RCC_BASE + 0x08))
#define RCC_CIR             (*(volatile uint32_t *)(RCC_BASE + 0x0C))

#define RCC_APB1RSTR        (*(volatile uint32_t *)(RCC_BASE + 0x20))
#define RCC_APB2RSTR        (*(volatile uint32_t *)(RCC_BASE + 0x24))

#define RCC_AHB1ENR         (*(volatile uint32_t *)(RCC_BASE + 0x30))
#define RCC_AHB2ENR         (*(volatile uint32_t *)(RCC_BASE + 0x34))
#define RCC_AHB3ENR         (*(volatile uint32_t *)(RCC_BASE + 0x38))
#define RCC_APB1ENR         (*(volatile uint32_t *)(RCC_BASE + 0x40))
#define RCC_APB2ENR         (*(volatile uint32_t *)(RCC_BASE + 0x44))

#define RCC_AHB1LPENR       (*(volatile uint32_t *)(RCC_BASE + 0x50))
#define RCC_APB1LPENR       (*(volatile uint32_t *)(RCC_BASE + 0x60))
#define RCC_APB2LPENR       (*(volatile uint32_t *)(RCC_BASE + 0x64))

#define RCC_BDCR            (*(volatile uint32_t *)(RCC_BASE + 0x70))
#define RCC_CSR             (*(volatile uint32_t *)(RCC_BASE + 0x74))

#define RCC_SSCGR           (*(volatile uint32_t *)(RCC_BASE + 0x80))
#define RCC_PLLI2SCFGR      (*(volatile uint32_t *)(RCC_BASE + 0x84))
#define RCC_PLLSAICFGR      (*(volatile uint32_t *)(RCC_BASE + 0x88))
#define RCC_DCKCFGR         (*(volatile uint32_t *)(RCC_BASE + 0x8C))

#define FLASH_BASE          ((volatile uint32_t *)0x40023C00UL)
#define FLASH_ACR           (*(volatile uint32_t *)(FLASH_BASE + 0x00))

#define PWR_BASE            ((volatile uint32_t *)0x40007000UL)
#define PWR_CR              (*(volatile uint32_t *)(PWR_BASE + 0x00))

#define RCC_CR_HSION        (1UL << 0)
#define RCC_CR_HSIRDY       (1UL << 1)
#define RCC_CR_HSEON        (1UL << 16)
#define RCC_CR_HSERDY       (1UL << 17)
#define RCC_CR_HSEBYP       (1UL << 18)
#define RCC_CR_PLLON        (1UL << 24)
#define RCC_CR_PLLRDY       (1UL << 25)
#define RCC_CR_PLLI2SON     (1UL << 26)
#define RCC_CR_PLLI2SRDY    (1UL << 27)
#define RCC_CR_PLLSAION     (1UL << 28)
#define RCC_CR_PLLSAIRDY    (1UL << 29)

#define RCC_PLLCFGR_PLLSRC      (1UL << 22)
#define RCC_PLLCFGR_PLLSRC_HSE  0x00400000UL

#define RCC_CFGR_SW_Msk     (0x3UL << 0)
#define RCC_CFGR_SW_PLL     (0x2UL << 0)
#define RCC_CFGR_SWS_Msk    (0x3UL << 2)
#define RCC_CFGR_SWS_PLL    (0x2UL << 2)

#define RCC_CFGR_HPRE_DIV1  (0x0UL << 4)

#define RCC_CFGR_PPRE1_DIV4 (0x5UL << 10)
#define RCC_CFGR_PPRE2_DIV2 (0x4UL << 13)

#define FLASH_ACR_LATENCY_5WS   (0x5UL << 0)
#define FLASH_ACR_PRFTEN        (1UL << 8)
#define FLASH_ACR_ICEN          (1UL << 9)
#define FLASH_ACR_DCEN          (1UL << 10)

static void flash_set_latency(void)
{
    FLASH_ACR |= FLASH_ACR_PRFTEN | FLASH_ACR_ICEN | FLASH_ACR_DCEN;
    FLASH_ACR = (FLASH_ACR & ~0x7UL) | FLASH_ACR_LATENCY_5WS;
}

static void hse_enable(void)
{
    RCC_CR |= RCC_CR_HSEON;
    while (!(RCC_CR & RCC_CR_HSERDY)) { __asm__ volatile("nop"); }
}

static void pll_configure_168mhz(void)
{
    /*
     * HSE = 8 MHz (external crystal)
     * PLLM = 8   -> VCO input = 1 MHz
     * PLLN = 336 -> VCO output = 336 MHz
     * PLLP = 2   -> SYSCLK = 168 MHz
     * PLLQ = 7   -> USB / SDIO clock = 48 MHz
     */

    uint32_t pllcfgr = 0;

    pllcfgr |= (8UL << 0);          /* PLLM = 8 */
    pllcfgr |= (336UL << 6);        /* PLLN = 336 */
    pllcfgr |= (0x0UL << 16);       /* PLLP = 2 */
    pllcfgr |= RCC_PLLCFGR_PLLSRC_HSE; /* PLL source = HSE */
    pllcfgr |= (7UL << 24);         /* PLLQ = 7 */

    RCC_PLLCFGR = pllcfgr;

    RCC_CR |= RCC_CR_PLLON;
    while (!(RCC_CR & RCC_CR_PLLRDY)) { __asm__ volatile("nop"); }
}

static void set_system_clocks(void)
{
    /*
     * AHB  = SYSCLK / 1 = 168 MHz
     * APB1 = SYSCLK / 4 = 42 MHz  (max 42 MHz)
     * APB2 = SYSCLK / 2 = 84 MHz  (max 84 MHz)
     */

    uint32_t cfgr = RCC_CFGR;

    cfgr &= ~(0xFUL << 4);        /* clear HPRE[3:0] */
    cfgr |= RCC_CFGR_HPRE_DIV1;   /* AHB prescaler = 1 */

    cfgr &= ~(0x7UL << 10);       /* clear PPRE1[2:0] */
    cfgr |= RCC_CFGR_PPRE1_DIV4;  /* APB1 prescaler = 4 */

    cfgr &= ~(0x7UL << 13);       /* clear PPRE2[2:0] */
    cfgr |= RCC_CFGR_PPRE2_DIV2;  /* APB2 prescaler = 2 */

    RCC_CFGR = cfgr;
}

static void switch_to_pll(void)
{
    uint32_t cfgr = RCC_CFGR;

    cfgr &= ~RCC_CFGR_SW_Msk;
    cfgr |= RCC_CFGR_SW_PLL;

    RCC_CFGR = cfgr;

    while ((RCC_CFGR & RCC_CFGR_SWS_Msk) != RCC_CFGR_SWS_PLL) {
        __asm__ volatile("nop");
    }
}

static void enable_peripheral_clocks(void)
{
    /*
     * AHB1: GPIOA, GPIOB, GPIOC, GPIOD, GPIOE, DMA1, DMA2, CRC
     * AHB2: (none used directly by BSP, available for peripherals)
     * APB1: TIM2-TIM7, USART2, I2C1, SPI2, IWDG
     * APB2: TIM1, TIM8, USART1, USART6, ADC1/2/3, SPI1, SYSCFG
     */
    RCC_AHB1ENR |= (1UL << 0);   /* GPIOA */
    RCC_AHB1ENR |= (1UL << 1);   /* GPIOB */
    RCC_AHB1ENR |= (1UL << 2);   /* GPIOC */
    RCC_AHB1ENR |= (1UL << 3);   /* GPIOD */
    RCC_AHB1ENR |= (1UL << 4);   /* GPIOE */
    RCC_AHB1ENR |= (1UL << 21);  /* DMA1 */
    RCC_AHB1ENR |= (1UL << 22);  /* DMA2 */

    RCC_APB1ENR |= (1UL << 9);   /* IWDG */
    RCC_APB1ENR |= (1UL << 1);   /* TIM3 */
    RCC_APB1ENR |= (1UL << 2);   /* TIM4 */

    RCC_APB2ENR |= (1UL << 4);   /* USART1 */
    RCC_APB2ENR |= (1UL << 8);   /* ADC1 */
    RCC_APB2ENR |= (1UL << 9);   /* ADC2 */
    RCC_APB2ENR |= (1UL << 10);  /* ADC3 */
    RCC_APB2ENR |= (1UL << 11);  /* TIM1 */
    RCC_APB2ENR |= (1UL << 13);  /* TIM8 */
    RCC_APB2ENR |= (1UL << 14);  /* SYSCFG */
}

void clock_config_init(void)
{
    flash_set_latency();

    hse_enable();

    pll_configure_168mhz();

    set_system_clocks();

    switch_to_pll();

    enable_peripheral_clocks();
}
