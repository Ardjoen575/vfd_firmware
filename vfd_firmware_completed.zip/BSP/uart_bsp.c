#include "uart_bsp.h"
#include <stdint.h>

typedef struct {
    volatile uint32_t SR;
    volatile uint32_t DR;
    volatile uint32_t BRR;
    volatile uint32_t CR1;
    volatile uint32_t CR2;
    volatile uint32_t CR3;
    volatile uint32_t GTPR;
} usart_t;

typedef struct {
    volatile uint32_t SxCR;   /* stream configuration */
    volatile uint32_t SxNDTR; /* number of data to transfer */
    volatile uint32_t SxPAR;  /* peripheral address */
    volatile uint32_t SxM0AR; /* memory 0 address */
    volatile uint32_t SxM1AR; /* memory 1 address */
    volatile uint32_t SxFCR;  /* FIFO control */
} dma_stream_t;

#define USART1_BASE ((usart_t *)0x40011000UL)
#define USART1      (USART1_BASE)

#define DMA2_BASE   ((volatile uint32_t *)0x40026400UL)
#define DMA2_S0     ((dma_stream_t *)(0x40026400UL + 0x10UL))  /* stream 0 */
#define DMA2_S1     ((dma_stream_t *)(0x40026400UL + 0x18UL))  /* not used */
#define DMA2_S2     ((dma_stream_t *)(0x40026400UL + 0x20UL))  /* not used */
#define DMA2_S3     ((dma_stream_t *)(0x40026400UL + 0x28UL))  /* not used */
#define DMA2_S4     ((dma_stream_t *)(0x40026400UL + 0x30UL))  /* not used */
#define DMA2_S5     ((dma_stream_t *)(0x40026400UL + 0x38UL))  /* USART1_RX stream 5 */
#define DMA2_S6     ((dma_stream_t *)(0x40026400UL + 0x40UL))  /* not used */
#define DMA2_S7     ((dma_stream_t *)(0x40026400UL + 0x48UL))  /* USART1_TX stream 7 */

#define DMA_LIFCR   (*(volatile uint32_t *)(0x40026400UL + 0x08UL))  /* low streams */
#define DMA_HIFCR   (*(volatile uint32_t *)(0x40026400UL + 0x0CUL))  /* high streams 4-7 */

#define USART_CR1_UE         (1UL << 13)
#define USART_CR1_RE         (1UL << 2)
#define USART_CR1_TE         (1UL << 3)
#define USART_CR1_RXNEIE     (1UL << 5)
#define USART_CR1_IDLEIE     (1UL << 4)

#define USART_CR3_DMAT       (1UL << 7)
#define USART_CR3_DMAR       (1UL << 6)

#define USART_SR_TXE         (1UL << 7)
#define USART_SR_TC          (1UL << 6)
#define USART_SR_RXNE        (1UL << 5)
#define USART_SR_IDLE        (1UL << 4)

/*
 * DMA stream configuration register bits.
 */
#define DMA_SxCR_EN          (1UL << 0)
#define DMA_SxCR_DMEIE       (1UL << 1)
#define DMA_SxCR_TEIE        (1UL << 2)
#define DMA_SxCR_HTIE        (1UL << 3)
#define DMA_SxCR_TCIE        (1UL << 4)
#define DMA_SxCR_PFCTRL      (1UL << 5)
#define DMA_SxCR_DIR_P2M     (0x0UL << 6)
#define DMA_SxCR_DIR_M2P     (0x1UL << 6)
#define DMA_SxCR_CIRC        (1UL << 8)
#define DMA_SxCR_PINC        (1UL << 9)
#define DMA_SxCR_MINC        (1UL << 10)
#define DMA_SxCR_PSIZE_8     (0x0UL << 11)
#define DMA_SxCR_MSIZE_8     (0x0UL << 13)
#define DMA_SxCR_PINCOS      (1UL << 15)
#define DMA_SxCR_PL_LOW      (0x0UL << 16)
#define DMA_SxCR_PL_MEDIUM   (0x1UL << 16)
#define DMA_SxCR_PL_HIGH     (0x2UL << 16)
#define DMA_SxCR_PL_VERY_HIGH (0x3UL << 16)
#define DMA_SxCR_DBM         (1UL << 18)
#define DMA_SxCR_CT          (1UL << 19)
#define DMA_SxCR_CHSEL_4     (0x4UL << 25)

#define DMA_SxFCR_DMDIS      (1UL << 2)

#define UART_BAUD         115200
#define APB2_CLOCK        84000000UL

static void dma_stream_configure_tx(void)
{
    dma_stream_t *s = DMA2_S7;

    /*
     * DMA2 Stream 7, Channel 4 -> USART1_TX.
     * Memory-to-peripheral, normal mode (non-circular).
     * 8-bit size, increment memory, no increment peripheral.
     */
    s->SxCR = DMA_SxCR_CHSEL_4
            | DMA_SxCR_DIR_M2P
            | DMA_SxCR_MINC
            | DMA_SxCR_PSIZE_8
            | DMA_SxCR_MSIZE_8
            | DMA_SxCR_PL_HIGH
            | DMA_SxCR_TCIE;

    s->SxFCR = DMA_SxFCR_DMDIS;

    s->SxPAR = (uint32_t)&USART1->DR;
}

static void dma_stream_configure_rx(void)
{
    dma_stream_t *s = DMA2_S5;

    /*
     * DMA2 Stream 5, Channel 4 -> USART1_RX.
     * Peripheral-to-memory, circular mode.
     * 8-bit size, increment memory, no increment peripheral.
     */
    s->SxCR = DMA_SxCR_CHSEL_4
            | DMA_SxCR_DIR_P2M
            | DMA_SxCR_MINC
            | DMA_SxCR_CIRC
            | DMA_SxCR_PSIZE_8
            | DMA_SxCR_MSIZE_8
            | DMA_SxCR_PL_HIGH
            | DMA_SxCR_HTIE
            | DMA_SxCR_TCIE;

    s->SxFCR = DMA_SxFCR_DMDIS;

    s->SxPAR = (uint32_t)&USART1->DR;
}

void uart_bsp_init(void)
{
    usart_t *u = USART1;

    /*
     * Disable USART before configuration.
     */
    u->CR1 &= ~USART_CR1_UE;

    /*
     * Baud rate:
     *   USARTDIV = APB2_CLOCK / (16 * baud)
     *            = 84000000 / (16 * 115200)
     *            = 84000000 / 1843200
     *            = 45.5729
     *
     *   Mantissa = 45  (integer part)
     *   Fraction = 16 * 0.5729 = 9.1664 -> 0x9
     *
     *   BRR = (45 << 4) | 0x9 = 0x2D9
     */
    u->BRR = 0x2D9UL;

    /*
     * 8 data bits, 1 stop bit, no parity, oversampling by 16.
     */
    u->CR1 = USART_CR1_RE | USART_CR1_TE | USART_CR1_RXNEIE;

    u->CR2 = 0;

    /*
     * Enable DMA for TX and RX.
     */
    u->CR3 = USART_CR3_DMAT | USART_CR3_DMAR;

    /*
     * Configure DMA streams.
     */
    dma_stream_configure_tx();
    dma_stream_configure_rx();

    /*
     * Enable USART.
     */
    u->CR1 |= USART_CR1_UE;
}
