#include "gpio_map.h"
#include <stdint.h>

typedef struct {
    volatile uint32_t MODER;
    volatile uint32_t OTYPER;
    volatile uint32_t OSPEEDR;
    volatile uint32_t PUPDR;
    volatile uint32_t IDR;
    volatile uint32_t ODR;
    volatile uint32_t BSRR;
    volatile uint32_t LCKR;
    volatile uint32_t AFRL;
    volatile uint32_t AFRH;
} gpio_t;

#define GPIOA  ((gpio_t *)0x40020000UL)
#define GPIOB  ((gpio_t *)0x40020400UL)
#define GPIOC  ((gpio_t *)0x40020800UL)
#define GPIOD  ((gpio_t *)0x40020C00UL)
#define GPIOE  ((gpio_t *)0x40021000UL)

#define MODE_INPUT      (0x0UL)
#define MODE_OUTPUT     (0x1UL)
#define MODE_ALT        (0x2UL)
#define MODE_ANALOG     (0x3UL)

#define OSPEED_LOW      (0x0UL)
#define OSPEED_MEDIUM   (0x1UL)
#define OSPEED_HIGH     (0x2UL)
#define OSPEED_VERY_HIGH (0x3UL)

#define PUPD_NONE       (0x0UL)
#define PUPD_UP         (0x1UL)
#define PUPD_DOWN       (0x2UL)

#define OTYPE_PP        (0x0UL)
#define OTYPE_OD        (0x1UL)

#define AF1             (0x1UL)   /* TIM1 / TIM2 */
#define AF2             (0x2UL)   /* TIM3 / TIM4 / TIM5 */
#define AF3             (0x3UL)   /* TIM8 / TIM9 / TIM10 / TIM11 */
#define AF7             (0x7UL)   /* USART1-3 */
#define AF12            (0xCUL)   /* FMC / SDIO / OTG_FS */

static uint32_t mask_pair(uint32_t val, int pin)
{
    return val << (pin * 2);
}

static void gpio_write_mode(gpio_t *g, int pin, uint32_t mode)
{
    uint32_t tmp = g->MODER;
    tmp &= ~(0x3UL << (pin * 2));
    tmp |= mask_pair(mode, pin);
    g->MODER = tmp;
}

static void gpio_write_speed(gpio_t *g, int pin, uint32_t speed)
{
    uint32_t tmp = g->OSPEEDR;
    tmp &= ~(0x3UL << (pin * 2));
    tmp |= mask_pair(speed, pin);
    g->OSPEEDR = tmp;
}

static void gpio_write_pupd(gpio_t *g, int pin, uint32_t pupd)
{
    uint32_t tmp = g->PUPDR;
    tmp &= ~(0x3UL << (pin * 2));
    tmp |= mask_pair(pupd, pin);
    g->PUPDR = tmp;
}

static void gpio_set_otype(gpio_t *g, int pin, uint32_t type)
{
    if (type == OTYPE_OD) {
        g->OTYPER |= (1UL << pin);
    } else {
        g->OTYPER &= ~(1UL << pin);
    }
}

static void gpio_set_af(gpio_t *g, int pin, uint32_t af)
{
    if (pin < 8) {
        uint32_t tmp = g->AFRL;
        tmp &= ~(0xFUL << (pin * 4));
        tmp |= (af << (pin * 4));
        g->AFRL = tmp;
    } else {
        uint32_t tmp = g->AFRH;
        tmp &= ~(0xFUL << ((pin - 8) * 4));
        tmp |= (af << ((pin - 8) * 4));
        g->AFRH = tmp;
    }
}

static void pwm_outputs_init(void)
{
    /*
     * PE8  -> TIM1_CH1N (AF1)  - Phase A low-side
     * PE9  -> TIM1_CH1  (AF1)  - Phase A high-side
     * PE10 -> TIM1_CH2N (AF1)  - Phase B low-side
     * PE11 -> TIM1_CH2  (AF1)  - Phase B high-side
     * PE12 -> TIM1_CH3N (AF1)  - Phase C low-side
     * PE13 -> TIM1_CH3  (AF1)  - Phase C high-side
     */

    int pins[] = {8, 9, 10, 11, 12, 13};
    for (int i = 0; i < 6; i++) {
        gpio_write_mode(GPIOE,  pins[i], MODE_ALT);
        gpio_write_speed(GPIOE, pins[i], OSPEED_VERY_HIGH);
        gpio_write_pupd(GPIOE,  pins[i], PUPD_DOWN);
        gpio_set_otype(GPIOE,   pins[i], OTYPE_PP);
        gpio_set_af(GPIOE,     pins[i], AF1);
    }

    /*
     * Brake chopper output: PE14 -> TIM1_CH4 (AF1)
     */
    gpio_write_mode(GPIOE,  14, MODE_ALT);
    gpio_write_speed(GPIOE, 14, OSPEED_VERY_HIGH);
    gpio_write_pupd(GPIOE,  14, PUPD_DOWN);
    gpio_set_otype(GPIOE,   14, OTYPE_PP);
    gpio_set_af(GPIOE,     14, AF1);
}

static void adc_inputs_init(void)
{
    /*
     * PA0 -> ADC1_IN0  (current U, injected)
     * PA1 -> ADC1_IN1  (current V, injected)
     * PA2 -> ADC2_IN2  (current W, injected)
     * PA3 -> ADC3_IN3  (DC bus voltage, regular)
     * PA4 -> ADC1_IN4  (heatsink temp)
     * PA5 -> ADC1_IN5  (analog input 1)
     * PA6 -> ADC1_IN6  (analog input 2)
     * PA7 -> ADC1_IN7  (analog pot)
     */

    int pins[] = {0, 1, 2, 3, 4, 5, 6, 7};
    for (int i = 0; i < 8; i++) {
        gpio_write_mode(GPIOA,  pins[i], MODE_ANALOG);
        gpio_write_pupd(GPIOA,  pins[i], PUPD_NONE);
    }
}

static void uart_pins_init(void)
{
    /*
     * PA9  -> USART1_TX (AF7)
     * PA10 -> USART1_RX (AF7)
     */
    gpio_write_mode(GPIOA,  9, MODE_ALT);
    gpio_write_speed(GPIOA, 9, OSPEED_HIGH);
    gpio_write_pupd(GPIOA,  9, PUPD_UP);
    gpio_set_otype(GPIOA,   9, OTYPE_PP);
    gpio_set_af(GPIOA,     9, AF7);

    gpio_write_mode(GPIOA,  10, MODE_ALT);
    gpio_write_speed(GPIOA, 10, OSPEED_HIGH);
    gpio_write_pupd(GPIOA,  10, PUPD_UP);
    gpio_set_otype(GPIOA,   10, OTYPE_PP);
    gpio_set_af(GPIOA,     10, AF7);
}

static void fault_brake_relay_pins_init(void)
{
    /*
     * PB0 -> Fault input (active low, pull-up)
     * PB1 -> External brake input (active low, pull-up)
     * PC0 -> Relay output (PP, no pull, low init)
     * PD12 -> Fault LED (open-drain, pull-up, active low)
     * PD13 -> Status LED (PP, no pull)
     */
    gpio_write_mode(GPIOB, 0, MODE_INPUT);
    gpio_write_pupd(GPIOB, 0, PUPD_UP);

    gpio_write_mode(GPIOB, 1, MODE_INPUT);
    gpio_write_pupd(GPIOB, 1, PUPD_UP);

    gpio_write_mode(GPIOC, 0, MODE_OUTPUT);
    gpio_write_speed(GPIOC, 0, OSPEED_LOW);
    gpio_write_pupd(GPIOC, 0, PUPD_NONE);
    gpio_set_otype(GPIOC, 0, OTYPE_PP);
    GPIOC->BSRR = (1UL << (0 + 16));

    gpio_write_mode(GPIOD, 12, MODE_OUTPUT);
    gpio_write_speed(GPIOD, 12, OSPEED_LOW);
    gpio_write_pupd(GPIOD, 12, PUPD_UP);
    gpio_set_otype(GPIOD, 12, OTYPE_OD);
    GPIOD->BSRR = (1UL << (12 + 16));

    gpio_write_mode(GPIOD, 13, MODE_OUTPUT);
    gpio_write_speed(GPIOD, 13, OSPEED_LOW);
    gpio_write_pupd(GPIOD, 13, PUPD_NONE);
    gpio_set_otype(GPIOD, 13, OTYPE_PP);
    GPIOD->BSRR = (1UL << (13 + 16));
}

static void encoder_pins_init(void)
{
    /*
     * PD0 -> Encoder A (TIM4_CH1, AF2)
     * PD1 -> Encoder B (TIM4_CH2, AF2)
     * PD2 -> Encoder Z index (EXTI, input with pull-up)
     */
    gpio_write_mode(GPIOD, 0, MODE_ALT);
    gpio_write_speed(GPIOD, 0, OSPEED_HIGH);
    gpio_write_pupd(GPIOD, 0, PUPD_UP);
    gpio_set_af(GPIOD, 0, AF2);

    gpio_write_mode(GPIOD, 1, MODE_ALT);
    gpio_write_speed(GPIOD, 1, OSPEED_HIGH);
    gpio_write_pupd(GPIOD, 1, PUPD_UP);
    gpio_set_af(GPIOD, 1, AF2);

    gpio_write_mode(GPIOD, 2, MODE_INPUT);
    gpio_write_pupd(GPIOD, 2, PUPD_UP);
}

void gpio_map_init(void)
{
    pwm_outputs_init();
    adc_inputs_init();
    uart_pins_init();
    fault_brake_relay_pins_init();
    encoder_pins_init();
}
