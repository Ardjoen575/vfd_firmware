#include "watchdog.h"
#include <stdint.h>

typedef struct {
    volatile uint32_t KR;
    volatile uint32_t PR;
    volatile uint32_t RLR;
    volatile uint32_t SR;
    volatile uint32_t WINR;
} iwdg_t;

#define IWDG_BASE ((iwdg_t *)0x40003000UL)
#define IWDG      (IWDG_BASE)

#define IWDG_KR_UNLOCK  (0x5555UL)
#define IWDG_KR_RELOAD  (0xAAA4UL)
#define IWDG_KR_START   (0xCCCCUL)
#define IWDG_KR_ACCESS  (0x5555UL)

#define IWDG_PR_DIV32   (0x3UL << 0)
#define IWDG_PR_DIV64   (0x4UL << 0)
#define IWDG_PR_DIV128  (0x5UL << 0)
#define IWDG_PR_DIV256  (0x6UL << 0)

#define IWDG_SR_PVU     (1UL << 0)
#define IWDG_SR_RVU     (1UL << 1)

/*
 * IWDG clock = 32 kHz LSI
 *
 * Target timeout ~1 second:
 *   Reload value = timeout * LSI_freq / prescaler - 1
 *
 * With prescaler = 64:
 *   reload = 1 * 32000 / 64 - 1 = 500 - 1 = 499
 *
 * Actual timeout = (prescaler / LSI) * (reload + 1)
 *                = (64 / 32000) * 500
 *                = 0.002 * 500 = 1.0 second
 */

#define IWDG_TIMEOUT_RELOAD  499UL

static void iwdg_write_access_enable(void)
{
    IWDG->KR = IWDG_KR_UNLOCK;
}

static void iwdg_set_prescaler(uint32_t pr)
{
    while (IWDG->SR & IWDG_SR_PVU) {
        __asm__ volatile("nop");
    }
    IWDG->PR = pr;
}

static void iwdg_set_reload(uint32_t rlr)
{
    while (IWDG->SR & IWDG_SR_RVU) {
        __asm__ volatile("nop");
    }
    IWDG->RLR = rlr;
}

static void iwdg_start(void)
{
    IWDG->KR = IWDG_KR_START;
}

static void iwdg_reload_counter(void)
{
    IWDG->KR = IWDG_KR_RELOAD;
}

void watchdog_init(void)
{
    iwdg_write_access_enable();

    iwdg_set_prescaler(IWDG_PR_DIV64);

    iwdg_set_reload(IWDG_TIMEOUT_RELOAD);

    iwdg_reload_counter();

    iwdg_start();
}

void watchdog_kick(void)
{
    iwdg_reload_counter();
}
