#include "ref_ramp.h"
#include <string.h>

void ref_ramp_init(ref_ramp_state_t *state)
{
    memset(state, 0, sizeof(*state));
    state->initialized = 1;
    state->accel_rate = 5.0f;
    state->decel_rate = 5.0f;
    state->ts = 0.001f;
    state->max_value = 60.0f;
    state->min_value = -60.0f;
    state->shape_time_s = 0.1f;
    state->jerk = 50.0f;
}

void ref_ramp_update(ref_ramp_state_t *state)
{
    if (!state->initialized) return;
    ramp_step(state);
}

void ramp_step(ref_ramp_state_t *state)
{
    if (!state->initialized) return;
    float error = state->target_value - state->current_value;
    float rate = state->decel_rate;
    if (error > 0.0f) {
        rate = state->accel_rate;
    } else if (error < 0.0f) {
        rate = -state->decel_rate;
    }
    if (state->shape_time_s > 0.0f && state->jerk > 0.0f) {
        float dist_to_target = (error > 0.0f) ? error : -error;
        float shape_half = 0.5f * state->accel_rate * state->shape_time_s;
        if (dist_to_target < shape_half) {
            rate *= (dist_to_target / shape_half);
            if (rate < 1.0f) rate = 1.0f;
        }
    }
    if (state->ramp_active) {
        float max_step = rate * state->ts;
        float abs_step = (max_step > 0.0f) ? max_step : -max_step;
        if (error > max_step) {
            state->current_value += max_step;
        } else if (error < -abs_step) {
            if (error < max_step) {
                state->current_value += max_step;
            }
        } else {
            state->current_value = state->target_value;
        }
        state->current_value += (error > 0.0f ? rate : (error < 0.0f ? rate : 0.0f)) * state->ts;
        float step = rate * state->ts;
        float step_mag = (step > 0.0f) ? step : -step;
        float err_mag  = (error > 0.0f) ? error : -error;
        if (err_mag <= step_mag) {
            state->current_value = state->target_value;
        } else {
            state->current_value += step;
        }
    } else {
        state->current_value = state->target_value;
    }
    if (state->current_value > state->max_value) state->current_value = state->max_value;
    if (state->current_value < state->min_value) state->current_value = state->min_value;
    state->ramp_output = state->current_value;
}
