#include "oscillation_damping.h"
#include <string.h>
#include <math.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif

void oscillation_damping_init(oscillation_damping_state_t *state)
{
    memset(state, 0, sizeof(*state));
    state->initialized = 1;
    state->notch_freq_hz = 50.0f;
    state->notch_bandwidth_hz = 5.0f;
    state->damping_gain = 1.0f;
    state->ts = 0.001f;
}

static void compute_notch_coeffs(oscillation_damping_state_t *state)
{
    float w0 = 2.0f * M_PI * state->notch_freq_hz * state->ts;
    float bw = 2.0f * M_PI * state->notch_bandwidth_hz * state->ts;
    float cos_w0 = cosf(w0);
    float alpha = sinf(w0) * sinf(bw / 2.0f); /* approximate 3dB bandwidth */
    if (alpha < 0.0001f) alpha = 0.0001f;
    float b0 = 1.0f;
    float b1 = -2.0f * cos_w0;
    float b2 = 1.0f;
    float a0 = 1.0f + alpha;
    float a1 = -2.0f * cos_w0;
    float a2 = 1.0f - alpha;
    state->b0 = b0 / a0;
    state->b1 = b1 / a0;
    state->b2 = b2 / a0;
    state->a1 = a1 / a0;
    state->a2 = a2 / a0;
    state->coeffs_computed = 1;
}

void oscillation_damping_update(oscillation_damping_state_t *state)
{
    if (!state->initialized) return;
    osc_damp_apply(state);
}

void osc_damp_apply(oscillation_damping_state_t *state)
{
    if (!state->initialized) return;
    if (!state->active) {
        state->torque_out = state->torque_in;
        return;
    }
    if (state->notch_freq_hz > 0.0f && !state->coeffs_computed) {
        compute_notch_coeffs(state);
    }
    if (state->notch_freq_hz <= 0.0f) {
        state->torque_out = state->torque_in;
        return;
    }
    float y = state->b0 * state->torque_in
            + state->b1 * state->input_prev[0]
            + state->b2 * state->input_prev[1]
            - state->a1 * state->output_prev[0]
            - state->a2 * state->output_prev[1];
    float damped = state->torque_in + state->damping_gain * (y - state->torque_in);
    state->input_prev[1]  = state->input_prev[0];
    state->input_prev[0]  = state->torque_in;
    state->output_prev[1] = state->output_prev[0];
    state->output_prev[0] = y;
    state->torque_out = damped;
}
