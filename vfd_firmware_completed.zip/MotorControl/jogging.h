#ifndef MOTORCONTROL_JOGGING_H
#define MOTORCONTROL_JOGGING_H

/* Jog control */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    uint8_t jog_active;
    uint8_t jog_direction; /* 0=forward, 1=reverse */
    float jog_speed_ref;
    float jog_accel_rate;
    float jog_decel_rate;
    float current_speed_ref;
    float target_speed;
    float ts;
    float max_speed;
    float min_speed;
} jogging_state_t;

void jogging_init(jogging_state_t *state);
void jogging_update(jogging_state_t *state);
void jog_start(jogging_state_t *state);
void jog_stop(jogging_state_t *state);

#endif /* MOTORCONTROL_JOGGING_H */
