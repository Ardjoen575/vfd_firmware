#include "hexagonal_flux.h"
#include <string.h>
#include <math.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif

void hexagonal_flux_init(hexagonal_flux_state_t *state)
{
    memset(state, 0, sizeof(*state));
    state->initialized = 1;
    state->flux_magnitude = 1.0f;
    state->modulation_idx = 0.95f;
    state->hex_gain = 1.0f;
    state->ts = 0.0001f;
}

void hexagonal_flux_update(hexagonal_flux_state_t *state)
{
    if (!state->initialized) return;
    hex_flux_apply(state);
}

static float hex_clamp(float val, float lo, float hi)
{
    if (val > hi) return hi;
    if (val < lo) return lo;
    return val;
}

void hex_flux_apply(hexagonal_flux_state_t *state)
{
    if (!state->initialized || !state->active) {
        state->flux_alpha_ref = state->flux_alpha_circular;
        state->flux_beta_ref = state->flux_beta_circular;
        return;
    }
    float alpha_c = state->flux_alpha_circular;
    float beta_c  = state->flux_beta_circular;
    float alpha = alpha_c;
    float beta  = beta_c;
    float bound = state->flux_magnitude * state->hex_gain;
    beta  = hex_clamp(beta, -bound, bound);
    float b2 = bound * 0.8660254f;
    float a_up = b2 - 0.5773503f * (beta - bound);
    float a_lo = -b2 - 0.5773503f * (beta + bound);
    alpha = hex_clamp(alpha, a_lo, a_up);
    state->flux_alpha_ref = alpha;
    state->flux_beta_ref  = beta;
}
