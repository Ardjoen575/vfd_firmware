#include "autophasing.h"
#include <string.h>
#include <math.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif
#ifndef M_2PI
#define M_2PI (2.0f * M_PI)
#endif

static const float AUTOPHASE_DEFAULT_AMPLITUDE = 0.15f;
static const float AUTOPHASE_DEFAULT_FREQ_HZ   = 500.0f;
static const float AUTOPHASE_LPF_ALPHA         = 0.05f;
static const float AUTOPHASE_PLL_KP_DEF        = 20.0f;
static const float AUTOPHASE_PLL_KI_DEF        = 400.0f;

void autophasing_init(autophasing_state_t *state)
{
    memset(state, 0, sizeof(*state));
    state->initialized = 1;
    state->phase = AUTOPHASE_IDLE;
    state->hf_amplitude = AUTOPHASE_DEFAULT_AMPLITUDE;
    state->hf_frequency = AUTOPHASE_DEFAULT_FREQ_HZ;
    state->pll_kp = AUTOPHASE_PLL_KP_DEF;
    state->pll_ki = AUTOPHASE_PLL_KI_DEF;
    state->ts = 0.0001f;
}

static float wrap_angle(float angle)
{
    while (angle > M_PI) angle -= M_2PI;
    while (angle < -M_PI) angle += M_2PI;
    return angle;
}

void autophasing_update(autophasing_state_t *state)
{
    if (!state->initialized) return;
    if (state->phase == AUTOPHASE_IDLE || state->phase == AUTOPHASE_DONE || state->phase == AUTOPHASE_FAULT) {
        return;
    }
    if (state->phase == AUTOPHASE_INJECTING) {
        if (state->timer > 0) {
            state->timer--;
            state->hf_angle += state->hf_frequency * state->ts;
            if (state->hf_angle > 1.0f) state->hf_angle -= 2.0f;
            state->i_alpha_hf = state->hf_amplitude * cosf(state->hf_angle * M_PI * 2.0f);
            state->i_beta_hf = state->hf_amplitude * sinf(state->hf_angle * M_PI * 2.0f);
            return;
        }
        state->phase = AUTOPHASE_MEASURING;
        state->timer = 0;
        return;
    }
    if (state->phase == AUTOPHASE_MEASURING) {
        float i_d = state->i_d_response;
        float i_q = state->i_q_response;
        float sin_2hf = sinf(2.0f * state->hf_angle * M_PI * 2.0f);
        float cos_2hf = cosf(2.0f * state->hf_angle * M_PI * 2.0f);
        float demod = i_q * sin_2hf - i_d * cos_2hf;
        state->phase_error = AUTOPHASE_LPF_ALPHA * demod + (1.0f - AUTOPHASE_LPF_ALPHA) * state->phase_error;
        float pll_out = state->phase_error * state->pll_kp + state->pll_integrator;
        state->pll_integrator += state->phase_error * state->pll_ki * state->ts;
        state->pll_integrator = fmaxf(-M_PI, fminf(M_PI, state->pll_integrator));
        state->found_angle += pll_out * state->ts;
        state->found_angle = wrap_angle(state->found_angle);
        if (fabsf(state->phase_error) < 0.01f) {
            state->rotor_angle = state->found_angle;
            state->phase = AUTOPHASE_DONE;
        }
        if (state->timer++ > 50000) {
            state->phase = AUTOPHASE_FAULT;
        }
    }
}

void autophase_run(autophasing_state_t *state)
{
    if (!state->initialized) return;
    if (state->phase != AUTOPHASE_IDLE && state->phase != AUTOPHASE_DONE) return;
    state->phase = AUTOPHASE_INJECTING;
    state->hf_angle = 0.0f;
    state->phase_error = 0.0f;
    state->pll_integrator = 0.0f;
    state->found_angle = 0.0f;
    state->rotor_angle = 0.0f;
    state->timer = state->injection_duration;
}
