#include "critical_speeds.h"
#include <string.h>

void critical_speeds_init(critical_speeds_state_t *state)
{
    memset(state, 0, sizeof(*state));
    state->initialized = 1;
    state->hysteresis = 1.0f;
    state->min_speed = -3000.0f;
    state->max_speed = 3000.0f;
}

void critical_speeds_update(critical_speeds_state_t *state)
{
    if (!state->initialized) return;
    critical_speed_filter(state);
}

void critical_speed_filter(critical_speeds_state_t *state)
{
    if (!state->initialized) return;
    float speed = state->input_speed;
    int inside_band = 0;
    for (int i = 0; i < CRITICAL_BANDS_COUNT; i++) {
        if (!state->band_enabled[i]) continue;
        float lo = state->band_lo[i];
        float hi = state->band_hi[i];
        if (lo >= hi) continue;
        float hyst_lo = lo - state->hysteresis;
        float hyst_hi = hi + state->hysteresis;
        if (speed > lo && speed < hi) {
            inside_band = 1;
            if (state->entering_band[i] == 0.0f) {
                state->entering_band[i] = (speed - lo) < (hi - speed) ? -1.0f : 1.0f;
            }
            speed = (state->entering_band[i] < 0.0f) ? lo : hi;
            break;
        } else if (speed >= hyst_lo && speed <= hyst_hi) {
            if (state->entering_band[i] != 0.0f) {
                speed = (state->entering_band[i] < 0.0f) ? lo : hi;
                inside_band = 1;
                break;
            }
        } else {
            state->entering_band[i] = 0.0f;
        }
    }
    if (!inside_band) {
        for (int i = 0; i < CRITICAL_BANDS_COUNT; i++) {
            state->entering_band[i] = 0.0f;
        }
    }
    if (speed > state->max_speed) speed = state->max_speed;
    if (speed < state->min_speed) speed = state->min_speed;
    state->output_speed = speed;
}
