#include "resonance_elimination.h"
#include <string.h>

void resonance_elimination_init(resonance_elimination_state_t *state)
{
    memset(state, 0, sizeof(*state));
    state->initialized = 1;
    state->hysteresis = 2.0f;
    state->min_speed = -3000.0f;
    state->max_speed = 3000.0f;
}

void resonance_elimination_update(resonance_elimination_state_t *state)
{
    if (!state->initialized) return;
    resonance_filter_apply(state);
}

void resonance_filter_apply(resonance_elimination_state_t *state)
{
    if (!state->initialized) return;
    float speed = state->input_speed;
    for (int i = 0; i < RESONANCE_BANDS_COUNT; i++) {
        if (!state->band_enabled[i]) continue;
        float lo = state->band_lo[i];
        float hi = state->band_hi[i];
        if (lo >= hi) continue;
        float hyst_lo = lo - state->hysteresis;
        float hyst_hi = hi + state->hysteresis;
        if (speed > lo && speed < hi) {
            float mid = (lo + hi) * 0.5f;
            speed = (speed > mid) ? hi : lo;
            break;
        }
        if (speed >= hyst_lo && speed <= hyst_hi) {
            float prev_speed = state->output_speed;
            if (prev_speed >= lo && prev_speed <= hi) {
                speed = prev_speed;
                break;
            }
        }
    }
    if (speed > state->max_speed) speed = state->max_speed;
    if (speed < state->min_speed) speed = state->min_speed;
    state->output_speed = speed;
}
