#include "flux_braking.h"
#include <string.h>

void flux_braking_init(flux_braking_state_t *state)
{
    memset(state, 0, sizeof(*state));
    state->initialized = 1;
    state->flux_nominal = 1.0f;
    state->flux_boost_factor = 1.3f;
    state->dc_link_max = 800.0f;
    state->dc_link_threshold = 750.0f;
    state->ramp_up_rate = 0.1f;
    state->ramp_down_rate = 0.2f;
    state->ts = 0.001f;
    state->flux_ref = state->flux_nominal;
}

void flux_braking_update(flux_braking_state_t *state)
{
    if (!state->initialized) return;
    flux_brake_apply(state);
}

void flux_brake_apply(flux_braking_state_t *state)
{
    if (!state->initialized) return;
    if (!state->active || !state->decelerating) {
        if (state->flux_output > state->flux_nominal) {
            state->flux_output -= state->ramp_down_rate * state->ts;
            if (state->flux_output < state->flux_nominal)
                state->flux_output = state->flux_nominal;
        } else {
            state->flux_output = state->flux_nominal;
        }
        return;
    }
    if (state->dc_link_voltage > state->dc_link_threshold) {
        float target_flux = state->flux_nominal * state->flux_boost_factor;
        if (state->flux_output < target_flux) {
            state->flux_output += state->ramp_up_rate * state->ts;
            if (state->flux_output > target_flux) state->flux_output = target_flux;
        }
        if (state->flux_output > state->flux_ref) {
            state->flux_output = state->flux_ref;
        }
    } else {
        if (state->flux_output > state->flux_nominal) {
            state->flux_output -= state->ramp_down_rate * state->ts;
            if (state->flux_output < state->flux_nominal)
                state->flux_output = state->flux_nominal;
        }
    }
    state->flux_ref = state->flux_output;
}
