#include "dc_magnetization.h"
#include <string.h>

void dc_magnetization_init(dc_magnetization_state_t *state)
{
    memset(state, 0, sizeof(*state));
    state->initialized = 1;
    state->ts = 0.001f;
    state->max_voltage = 400.0f;
    state->current_tolerance = 0.05f;
    state->stable_required = 100;
    state->mag_current_ref = 0.5f;
    state->mag_time_s = 2.0f;
}

void dc_magnetization_update(dc_magnetization_state_t *state)
{
    if (!state->initialized || !state->active) {
        state->mag_voltage = 0.0f;
        return;
    }
    if (state->complete) {
        state->mag_voltage = 0.0f;
        return;
    }
    state->elapsed_time_s += state->ts;
    float v_out = state->mag_current_ref * 10.0f;
    if (v_out > state->max_voltage) v_out = state->max_voltage;
    if (v_out < 0.0f) v_out = 0.0f;
    state->mag_voltage = v_out;
    float current_error = state->mag_current_measured - state->mag_current_ref;
    if (current_error < 0.0f) current_error = -current_error;
    if (current_error < state->current_tolerance * state->mag_current_ref) {
        state->stable_count++;
    } else {
        state->stable_count = 0;
    }
    if (state->stable_count >= state->stable_required ||
        (state->mag_time_s > 0.0f && state->elapsed_time_s >= state->mag_time_s)) {
        state->complete = 1;
        state->active = 0;
        state->mag_voltage = 0.0f;
    }
}

void dc_mag_apply(dc_magnetization_state_t *state)
{
    if (!state->initialized) return;
    state->active = 1;
    state->complete = 0;
    state->elapsed_time_s = 0.0f;
    state->stable_count = 0;
    state->mag_voltage = 0.0f;
}
