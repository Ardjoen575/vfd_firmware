#include "constant_speeds.h"
#include <string.h>

void constant_speeds_init(constant_speeds_state_t *state)
{
    memset(state, 0, sizeof(*state));
    state->initialized = 1;
    state->active_index = 0;
}

void constant_speeds_update(constant_speeds_state_t *state)
{
    if (!state->initialized) return;
    if (state->input_selection != state->previous_selection) {
        state->previous_selection = state->input_selection;
        const_speed_select(state);
    }
}

void const_speed_select(constant_speeds_state_t *state)
{
    if (!state->initialized) return;
    uint8_t sel = state->input_selection;
    if (sel >= CONST_SPEEDS_COUNT) {
        state->active_index = 0;
        state->speed_output = 0.0f;
        return;
    }
    state->active_index = sel;
    state->active_speed = state->speeds[sel];
    state->speed_output = state->active_speed;
}
