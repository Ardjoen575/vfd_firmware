#ifndef MOTORCONTROL_AUTOPHASING_H
#define MOTORCONTROL_AUTOPHASING_H

/* Autophasing routine */

#include <stdint.h>

typedef enum {
    AUTOPHASE_IDLE = 0,
    AUTOPHASE_INJECTING,
    AUTOPHASE_MEASURING,
    AUTOPHASE_LOCKING,
    AUTOPHASE_DONE,
    AUTOPHASE_FAULT
} autophase_phase_t;

typedef struct {
    uint8_t initialized;
    autophase_phase_t phase;
    float rotor_angle;
    float hf_amplitude;
    float hf_frequency;
    float hf_angle;
    float i_alpha_hf;
    float i_beta_hf;
    float i_d_response;
    float i_q_response;
    float phase_error;
    float pll_integrator;
    float pll_kp;
    float pll_ki;
    uint32_t timer;
    uint32_t injection_duration;
    float ts;
    float found_angle;
} autophasing_state_t;

void autophasing_init(autophasing_state_t *state);
void autophasing_update(autophasing_state_t *state);
void autophase_run(autophasing_state_t *state);

#endif /* MOTORCONTROL_AUTOPHASING_H */
