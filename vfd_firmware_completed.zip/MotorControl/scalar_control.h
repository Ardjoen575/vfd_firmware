#ifndef MOTORCONTROL_SCALAR_CONTROL_H
#define MOTORCONTROL_SCALAR_CONTROL_H

/* Scalar (V/f) motor control */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    float freq_ref;
    float freq_output;
    float voltage_magnitude;
    float v_alpha;
    float v_beta;
    float v_u;
    float v_v;
    float v_w;
    float angle;
    float angle_accum;
    float nominal_freq;
    float nominal_voltage;
    float boost_voltage;
    float boost_freq;
    float ir_comp_gain;
    float ir_comp_voltage;
    float current_magnitude;
    float rs;
    float field_weakening_freq;
    float max_voltage;
    float max_frequency;
    float min_frequency;
    float ts;
    float slip_freq;
    uint8_t slip_comp_enable;
    float rated_slip;
    float rated_current;
} scalar_control_state_t;

void scalar_control_init(scalar_control_state_t *state);
void scalar_control_update(scalar_control_state_t *state);
void scalar_ctrl_step(scalar_control_state_t *state);

#endif /* MOTORCONTROL_SCALAR_CONTROL_H */
