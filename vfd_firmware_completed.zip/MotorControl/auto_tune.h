#ifndef MOTORCONTROL_AUTO_TUNE_H
#define MOTORCONTROL_AUTO_TUNE_H

/* Stator resistance measurement / motor ID run */

#include <stdint.h>

typedef enum {
    AUTO_TUNE_IDLE = 0,
    AUTO_TUNE_INJECTING,
    AUTO_TUNE_MEASURING,
    AUTO_TUNE_DONE,
    AUTO_TUNE_FAULT
} auto_tune_phase_t;

typedef struct {
    uint8_t initialized;
    auto_tune_phase_t phase;
    float dc_current_ref;
    float dc_current_measured;
    float v_dc_measured;
    float rs_measured;
    float v_sample_accum;
    float i_sample_accum;
    uint32_t sample_count;
    uint32_t settle_timer;
    uint32_t total_samples;
    float v_threshold;
    float rs_rated_max;
    float rs_rated_min;
    float inject_level_pu;
} auto_tune_state_t;

void auto_tune_init(auto_tune_state_t *state);
void auto_tune_update(auto_tune_state_t *state);
void autotune_run_id_run(auto_tune_state_t *state);

#endif /* MOTORCONTROL_AUTO_TUNE_H */
