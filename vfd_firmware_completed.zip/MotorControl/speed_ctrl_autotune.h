#ifndef MOTORCONTROL_SPEED_CTRL_AUTOTUNE_H
#define MOTORCONTROL_SPEED_CTRL_AUTOTUNE_H

/* Speed controller autotune routine */

#include <stdint.h>

typedef enum {
    SPAUTOTUNE_IDLE = 0,
    SPAUTOTUNE_ACCEL,
    SPAUTOTUNE_MEASURING,
    SPAUTOTUNE_DECEL,
    SPAUTOTUNE_CALCULATING,
    SPAUTOTUNE_DONE,
    SPAUTOTUNE_FAULT
} speed_autotune_phase_t;

typedef struct {
    uint8_t initialized;
    speed_autotune_phase_t phase;
    float kp;
    float ki;
    float step_magnitude;
    float speed_ref;
    float speed_actual;
    float torque_ref;
    float measured_rise_time;
    float measured_overshoot;
    float measured_settling_time;
    float inertia_estimate;
    float bandwidth_target;
    float damping_target;
    float peak_speed;
    float steady_state_speed;
    float elapsed_s;
    float settling_threshold;
    float sample_time_s;
    uint32_t sample_count;
    float ts;
    float max_torque;
    float min_torque;
} speed_ctrl_autotune_state_t;

void speed_ctrl_autotune_init(speed_ctrl_autotune_state_t *state);
void speed_ctrl_autotune_update(speed_ctrl_autotune_state_t *state);
void speed_autotune_run(speed_ctrl_autotune_state_t *state);

#endif /* MOTORCONTROL_SPEED_CTRL_AUTOTUNE_H */
