#ifndef MOTORCONTROL_ENCODER_MODULE_SETTINGS_H
#define MOTORCONTROL_ENCODER_MODULE_SETTINGS_H

/* Encoder module settings (grp 91) */

#include <stdint.h>

typedef enum {
    ENC_MODULE_TYPE_NONE = 0,
    ENC_MODULE_TYPE_TTL,
    ENC_MODULE_TYPE_HTL,
    ENC_MODULE_TYPE_RESOLVER,
    ENC_MODULE_TYPE_SINCOS,
    ENC_MODULE_TYPE_TTL_3CH,
    ENC_MODULE_TYPE_HTL_3CH
} enc_module_type_t;

typedef struct {
    uint8_t initialized;
    enc_module_type_t module_type;
    uint8_t channel_a_enabled;
    uint8_t channel_b_enabled;
    uint8_t channel_z_enabled;
    uint8_t termination_enabled;
    float filter_time_ms;
    float filter_alpha;
    uint16_t resolution_bits;
    float supply_voltage;
    uint8_t encoder_present;
    uint8_t fault_code;
    float ts;
} encoder_module_settings_state_t;

void encoder_module_settings_init(encoder_module_settings_state_t *state);
void encoder_module_settings_update(encoder_module_settings_state_t *state);
void enc_module_configure(encoder_module_settings_state_t *state);

#endif /* MOTORCONTROL_ENCODER_MODULE_SETTINGS_H */
