#include "speed_ctrl_autotune.h"
#include <string.h>

void speed_ctrl_autotune_init(speed_ctrl_autotune_state_t *state)
{
    memset(state, 0, sizeof(*state));
    state->initialized = 1;
    state->phase = SPAUTOTUNE_IDLE;
    state->step_magnitude = 10.0f;
    state->bandwidth_target = 20.0f;
    state->damping_target = 0.8f;
    state->settling_threshold = 0.02f;
    state->sample_time_s = 1.0f;
    state->ts = 0.001f;
    state->max_torque = 1.5f;
    state->min_torque = -1.5f;
}

void speed_ctrl_autotune_update(speed_ctrl_autotune_state_t *state)
{
    if (!state->initialized) return;
    if (state->phase == SPAUTOTUNE_IDLE || state->phase == SPAUTOTUNE_DONE || state->phase == SPAUTOTUNE_FAULT) {
        return;
    }
    state->elapsed_s += state->ts;
    if (state->phase == SPAUTOTUNE_ACCEL) {
        state->speed_ref = state->step_magnitude;
        state->torque_ref = state->max_torque;
        state->sample_count++;
        if (state->speed_actual > state->peak_speed) {
            state->peak_speed = state->speed_actual;
        }
        if (state->speed_actual >= state->step_magnitude * 0.9f) {
            state->phase = SPAUTOTUNE_MEASURING;
            state->steady_state_speed = state->speed_actual;
            state->elapsed_s = 0.0f;
        }
        return;
    }
    if (state->phase == SPAUTOTUNE_MEASURING) {
        if (state->speed_actual > state->peak_speed) {
            state->peak_speed = state->speed_actual;
        }
        if (state->elapsed_s < state->sample_time_s) {
            return;
        }
        float overshoot = state->peak_speed - state->step_magnitude;
        state->measured_overshoot = (state->step_magnitude > 0.1f) ? overshoot / state->step_magnitude : 0.0f;
        state->phase = SPAUTOTUNE_DECEL;
        state->torque_ref = state->min_torque;
        state->speed_ref = 0.0f;
        return;
    }
    if (state->phase == SPAUTOTUNE_DECEL) {
        if (state->speed_actual < state->step_magnitude * state->settling_threshold) {
            state->phase = SPAUTOTUNE_CALCULATING;
        }
        return;
    }
    if (state->phase == SPAUTOTUNE_CALCULATING) {
        float rise_time = state->measured_rise_time * state->ts;
        if (rise_time < 0.0001f) rise_time = 0.01f;
        float J_est = state->max_torque * rise_time / state->step_magnitude;
        state->inertia_estimate = J_est;
        float wb = state->bandwidth_target;
        float xi = state->damping_target;
        state->kp = 2.0f * xi * wb * J_est;
        state->ki = wb * wb * J_est;
        if (state->kp > 100.0f) state->kp = 100.0f;
        if (state->ki > 1000.0f) state->ki = 1000.0f;
        if (state->kp < 0.01f) state->kp = 0.01f;
        if (state->ki < 0.1f) state->ki = 0.1f;
        state->phase = SPAUTOTUNE_DONE;
        state->torque_ref = 0.0f;
        state->speed_ref = 0.0f;
    }
}

void speed_autotune_run(speed_ctrl_autotune_state_t *state)
{
    if (!state->initialized) return;
    if (state->phase != SPAUTOTUNE_IDLE && state->phase != SPAUTOTUNE_DONE) return;
    state->phase = SPAUTOTUNE_ACCEL;
    state->elapsed_s = 0.0f;
    state->peak_speed = 0.0f;
    state->steady_state_speed = 0.0f;
    state->measured_rise_time = 0;
    state->measured_overshoot = 0.0f;
    state->measured_settling_time = 0.0f;
    state->sample_count = 0;
}
