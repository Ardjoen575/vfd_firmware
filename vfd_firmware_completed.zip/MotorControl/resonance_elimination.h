#ifndef MOTORCONTROL_RESONANCE_ELIMINATION_H
#define MOTORCONTROL_RESONANCE_ELIMINATION_H

/* Resonance frequency elimination */

#include <stdint.h>

#define RESONANCE_BANDS_COUNT 3

typedef struct {
    uint8_t initialized;
    float band_lo[RESONANCE_BANDS_COUNT];
    float band_hi[RESONANCE_BANDS_COUNT];
    uint8_t band_enabled[RESONANCE_BANDS_COUNT];
    float input_speed;
    float output_speed;
    float hysteresis;
    float band_state[RESONANCE_BANDS_COUNT]; /* -1=below, 0=outside, 1=above */
    float max_speed;
    float min_speed;
} resonance_elimination_state_t;

void resonance_elimination_init(resonance_elimination_state_t *state);
void resonance_elimination_update(resonance_elimination_state_t *state);
void resonance_filter_apply(resonance_elimination_state_t *state);

#endif /* MOTORCONTROL_RESONANCE_ELIMINATION_H */
