#ifndef MOTORCONTROL_REF_RAMP_H
#define MOTORCONTROL_REF_RAMP_H

/* Reference ramping engine */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    uint8_t ramp_active;
    float current_value;
    float target_value;
    float accel_rate;
    float decel_rate;
    float ramp_output;
    float ts;
    float max_value;
    float min_value;
    float shape_time_s; /* S-curve rounding time */
    float jerk;
    float current_rate;
} ref_ramp_state_t;

void ref_ramp_init(ref_ramp_state_t *state);
void ref_ramp_update(ref_ramp_state_t *state);
void ramp_step(ref_ramp_state_t *state);

#endif /* MOTORCONTROL_REF_RAMP_H */
