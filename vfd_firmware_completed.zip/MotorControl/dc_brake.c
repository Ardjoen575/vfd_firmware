#include "dc_brake.h"
#include <string.h>

void dc_brake_init(dc_brake_state_t *state)
{
    memset(state, 0, sizeof(*state));
    state->initialized = 1;
    state->ts = 0.001f;
    state->max_dc_voltage = 400.0f;
}

void dc_brake_update(dc_brake_state_t *state)
{
    if (!state->initialized || !state->active) {
        state->brake_voltage = 0.0f;
        return;
    }
    state->elapsed_time_s += state->ts;
    if (state->elapsed_time_s >= state->brake_time_s && state->brake_time_s > 0.0f) {
        state->active = 0;
        state->brake_voltage = 0.0f;
        state->elapsed_time_s = 0.0f;
        return;
    }
    float v_brake = state->brake_current * 10.0f;
    if (v_brake > state->max_dc_voltage) v_brake = state->max_dc_voltage;
    if (v_brake < 0.0f) v_brake = 0.0f;
    state->brake_voltage = v_brake;
}

void dc_brake_engage(dc_brake_state_t *state)
{
    if (!state->initialized) return;
    state->active = 1;
    state->elapsed_time_s = 0.0f;
    state->brake_voltage = 0.0f;
}
