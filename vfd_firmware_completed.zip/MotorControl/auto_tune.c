#include "auto_tune.h"
#include <string.h>

static const float AUTO_TUNE_SETTLE_MS   = 250.0f;
static const float AUTO_TUNE_SAMPLE_MS   = 100.0f;
static const float AUTO_TUNE_TS_MS       = 1.0f;
static const float AUTO_TUNE_DC_LEVEL_PU = 0.5f;

void auto_tune_init(auto_tune_state_t *state)
{
    memset(state, 0, sizeof(*state));
    state->initialized = 1;
    state->phase = AUTO_TUNE_IDLE;
    state->inject_level_pu = AUTO_TUNE_DC_LEVEL_PU;
    state->total_samples = (uint32_t)(AUTO_TUNE_SAMPLE_MS / AUTO_TUNE_TS_MS);
}

void auto_tune_update(auto_tune_state_t *state)
{
    if (!state->initialized || state->phase == AUTO_TUNE_IDLE) {
        return;
    }
    if (state->phase == AUTO_TUNE_DONE || state->phase == AUTO_TUNE_FAULT) {
        return;
    }
    if (state->phase == AUTO_TUNE_INJECTING) {
        if (state->settle_timer > 0) {
            state->settle_timer--;
            state->v_sample_accum = 0.0f;
            state->i_sample_accum = 0.0f;
            state->sample_count = 0;
            return;
        }
        state->phase = AUTO_TUNE_MEASURING;
        state->sample_count = 0;
        state->v_sample_accum = 0.0f;
        state->i_sample_accum = 0.0f;
        return;
    }
    if (state->phase == AUTO_TUNE_MEASURING) {
        if (state->sample_count < state->total_samples) {
            state->v_sample_accum += state->v_dc_measured;
            state->i_sample_accum += state->dc_current_measured;
            state->sample_count++;
            return;
        }
        float v_avg = state->v_sample_accum / (float)state->total_samples;
        float i_avg = state->i_sample_accum / (float)state->total_samples;
        if (i_avg < 0.001f) {
            state->phase = AUTO_TUNE_FAULT;
            state->rs_measured = 0.0f;
            return;
        }
        float rs_calc = v_avg / i_avg;
        if (rs_calc > state->rs_rated_max || rs_calc < state->rs_rated_min) {
            state->phase = AUTO_TUNE_FAULT;
        } else {
            state->rs_measured = rs_calc;
            state->phase = AUTO_TUNE_DONE;
        }
        state->dc_current_ref = 0.0f;
    }
}

void autotune_run_id_run(auto_tune_state_t *state)
{
    if (!state->initialized) return;
    if (state->phase != AUTO_TUNE_IDLE && state->phase != AUTO_TUNE_DONE) return;
    state->phase = AUTO_TUNE_INJECTING;
    state->rs_measured = 0.0f;
    state->v_sample_accum = 0.0f;
    state->i_sample_accum = 0.0f;
    state->sample_count = 0;
    state->settle_timer = (uint32_t)(AUTO_TUNE_SETTLE_MS / AUTO_TUNE_TS_MS);
    state->dc_current_ref = state->inject_level_pu * state->dc_current_measured;
    state->dc_current_measured = 0.0f;
    state->v_dc_measured = 0.0f;
}
