#ifndef MOTORCONTROL_ENCODER_1_CONFIG_H
#define MOTORCONTROL_ENCODER_1_CONFIG_H

/* Encoder 1 configuration (grp 92) */

#include <stdint.h>

typedef enum {
    ENC1_TYPE_QUADRATURE = 0,
    ENC1_TYPE_HALL,
    ENC1_TYPE_RESOLVER,
    ENC1_TYPE_SINCOS,
    ENC1_TYPE_ENDAT,
    ENC1_TYPE_BISS,
    ENC1_TYPE_SSI
} encoder1_type_t;

typedef struct {
    uint8_t initialized;
    uint32_t pulses_per_rev;
    encoder1_type_t type;
    uint8_t direction; /* 0=normal, 1=inverted */
    int32_t raw_count;
    int32_t prev_raw_count;
    float position;      /* electrical radians */
    float position_mech; /* mechanical radians */
    float speed_electrical;
    float speed_mechanical;
    float ts;
    float gear_ratio;
    uint8_t absolute_enabled;
    int32_t absolute_offset;
} encoder_1_config_state_t;

void encoder_1_config_init(encoder_1_config_state_t *state);
void encoder_1_config_update(encoder_1_config_state_t *state);
void enc1_read_position(encoder_1_config_state_t *state);

#endif /* MOTORCONTROL_ENCODER_1_CONFIG_H */
