#ifndef MOTORCONTROL_DC_MAGNETIZATION_H
#define MOTORCONTROL_DC_MAGNETIZATION_H

/* DC magnetization */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    uint8_t active;
    uint8_t complete;
    float mag_current_ref;
    float mag_current_measured;
    float mag_time_s;
    float elapsed_time_s;
    float mag_voltage;
    float ts;
    float current_tolerance;
    uint32_t stable_count;
    uint32_t stable_required;
    float max_voltage;
} dc_magnetization_state_t;

void dc_magnetization_init(dc_magnetization_state_t *state);
void dc_magnetization_update(dc_magnetization_state_t *state);
void dc_mag_apply(dc_magnetization_state_t *state);

#endif /* MOTORCONTROL_DC_MAGNETIZATION_H */
