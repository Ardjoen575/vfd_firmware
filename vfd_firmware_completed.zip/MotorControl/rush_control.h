#ifndef MOTORCONTROL_RUSH_CONTROL_H
#define MOTORCONTROL_RUSH_CONTROL_H

/* Rush control */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    uint8_t magnetizing;
    float current_limit_max;
    float current_limit_min;
    float current_limit_out;
    float ramp_up_rate;
    float ramp_down_rate;
    float current_in;
    float current_out;
    float ts;
    float timer_s;
    uint8_t ramping_up;
} rush_control_state_t;

void rush_control_init(rush_control_state_t *state);
void rush_control_update(rush_control_state_t *state);
void rush_control_apply(rush_control_state_t *state);

#endif /* MOTORCONTROL_RUSH_CONTROL_H */
