#ifndef MOTORCONTROL_FLYING_START_H
#define MOTORCONTROL_FLYING_START_H

/* Catch a spinning motor */

#include <stdint.h>

typedef enum {
    FLYSTART_IDLE = 0,
    FLYSTART_SCANNING,
    FLYSTART_MEASURING_BEMF,
    FLYSTART_LOCKING,
    FLYSTART_SYNCHRONIZING,
    FLYSTART_DONE,
    FLYSTART_FAULT
} flying_start_phase_t;

typedef struct {
    uint8_t initialized;
    flying_start_phase_t phase;
    float scan_frequency;
    float scan_start_freq;
    float scan_end_freq;
    float scan_step;
    float scan_direction; /* 1.0 = downward, -1.0 = upward */
    float found_speed;
    float bemf_threshold;
    float bemf_magnitude;
    float bemf_angle;
    float i_d_measured;
    float i_q_measured;
    float v_d_ref;
    float v_q_ref;
    float current_limit;
    float sync_duration_s;
    float elapsed_s;
    uint32_t timer;
    float ts;
    float nominal_freq;
    float max_scan_time_s;
} flying_start_state_t;

void flying_start_init(flying_start_state_t *state);
void flying_start_update(flying_start_state_t *state);
void flying_start_search_speed(flying_start_state_t *state);

#endif /* MOTORCONTROL_FLYING_START_H */
