#include "dtc_control.h"
#include <string.h>
#include <math.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif

static const float SQRT3_DIV_2  = 0.8660254037844386f;

static const int SWITCHING_TABLE[6][4] = {
 /*  sector:0  1  2  3  4  5  */
    { 5, 6, 2, 1 },  /* flux_hi, torque_hi */
    { 4, 5, 1, 0 },  /* flux_hi, torque_lo */
    { 6, 1, 3, 2 },  /* flux_lo, torque_hi */
    { 1, 0, 4, 3 },  /* flux_lo, torque_lo */
    /* sector lookup by row: flux_up/down, torque_up/down */
};

static const float VDC_ALPHA[7] = { 0.0f, 0.6667f, 0.3333f, -0.3333f, -0.6667f, -0.3333f, 0.3333f };
static const float VDC_BETA[7]  = { 0.0f, 0.0f, SQRT3_DIV_2, SQRT3_DIV_2, 0.0f, -SQRT3_DIV_2, -SQRT3_DIV_2 };

void dtc_control_init(dtc_control_state_t *state)
{
    memset(state, 0, sizeof(*state));
    state->initialized = 1;
    state->flux_ref = 1.0f;
    state->torque_ref = 0.0f;
    state->flux_hyst_band = 0.01f;
    state->torque_hyst_band = 0.01f;
    state->rs = 1.0f;
    state->ls = 0.01f;
    state->ts = 0.0001f;
    state->v_dc = 540.0f;
    state->maximum_flux = 1.5f;
    state->rated_torque = 10.0f;
    state->sector = 0;
}

static int find_sector(float f_alpha, float f_beta)
{
    float angle = atan2f(f_beta, f_alpha);
    if (angle < 0.0f) angle += 2.0f * M_PI;
    int sec = (int)(angle / (M_PI / 3.0f));
    if (sec >= 6) sec = 0;
    return sec;
}

void dtc_flux_estimate(dtc_control_state_t *state)
{
    float u_alpha = state->v_dc * VDC_ALPHA[state->switching_state];
    float u_beta  = state->v_dc * VDC_BETA[state->switching_state];
    float r_drop_alpha = state->rs * state->i_alpha;
    float r_drop_beta  = state->rs * state->i_beta;
    state->flux_alpha += (u_alpha - r_drop_alpha) * state->ts;
    state->flux_beta  += (u_beta  - r_drop_beta)  * state->ts;
    float f_mag_sq = state->flux_alpha * state->flux_alpha + state->flux_beta * state->flux_beta;
    state->flux_magnitude = sqrtf(f_mag_sq > 0.0f ? f_mag_sq : 0.0f);
    float Ls_f = state->ls;
    if (Ls_f < 0.00001f) Ls_f = 0.00001f;
    state->torque_estimated = 1.5f * 1.0f * (
        state->flux_alpha * state->i_beta - state->flux_beta * state->i_alpha
    );
    state->sector = find_sector(state->flux_alpha, state->flux_beta);
}

void dtc_compute_torque_step(dtc_control_state_t *state)
{
    float flux_err = state->flux_ref - state->flux_magnitude;
    float torque_err = state->torque_ref - state->torque_estimated;
    int flux_idx = (flux_err > state->flux_hyst_band) ? 0 : 1;
    flux_idx = (flux_err < -state->flux_hyst_band) ? 2 : flux_idx;
    int torque_idx = (torque_err > state->torque_hyst_band) ? 0 : 1;
    int table_row;
    if (flux_idx == 0 && torque_idx == 0) table_row = 0;
    else if (flux_idx == 0 && torque_idx == 1) table_row = 1;
    else if (flux_idx == 1 && torque_idx == 0) table_row = 2;
    else table_row = 3;
    state->switching_state = SWITCHING_TABLE[table_row][state->sector];
    state->u_alpha = state->v_dc * VDC_ALPHA[state->switching_state];
    state->u_beta  = state->v_dc * VDC_BETA[state->switching_state];
}

void dtc_control_update(dtc_control_state_t *state)
{
    if (!state->initialized) return;
    dtc_flux_estimate(state);
    dtc_compute_torque_step(state);

    float f_mag = state->flux_magnitude;
    float t_est = state->torque_estimated;
    if (f_mag > 2.0f * state->maximum_flux) {
        state->flux_alpha *= 0.5f;
        state->flux_beta  *= 0.5f;
    }
    if (t_est > 3.0f * state->rated_torque) {
        state->torque_ref = state->rated_torque;
    }
}
