#ifndef MOTORCONTROL_FEEDBACK_SELECTION_H
#define MOTORCONTROL_FEEDBACK_SELECTION_H

/* Motor feedback source selection (grp 90) */

#include <stdint.h>

typedef enum {
    FEEDBACK_SPEED_ENCODER1 = 0,
    FEEDBACK_SPEED_ENCODER2,
    FEEDBACK_SPEED_SENSORLESS,
    FEEDBACK_SPEED_ENCODER1_RED,
    FEEDBACK_SPEED_ENCODER2_RED
} feedback_speed_source_t;

typedef enum {
    FEEDBACK_TORQUE_SENSORLESS = 0,
    FEEDBACK_TORQUE_SHAFT_SENSOR,
    FEEDBACK_TORQUE_ESTIMATED
} feedback_torque_source_t;

typedef struct {
    uint8_t initialized;
    feedback_speed_source_t speed_source;
    feedback_torque_source_t torque_source;
    uint8_t source_locked;
    float speed_feedback;
    float torque_feedback;
    float encoder1_speed;
    float encoder2_speed;
    float sensorless_speed;
    float shaft_torque_val;
    float estimated_torque_val;
} feedback_selection_state_t;

void feedback_selection_init(feedback_selection_state_t *state);
void feedback_selection_update(feedback_selection_state_t *state);
void feedback_select_source(feedback_selection_state_t *state);

#endif /* MOTORCONTROL_FEEDBACK_SELECTION_H */
