#ifndef MOTORCONTROL_DC_BRAKE_H
#define MOTORCONTROL_DC_BRAKE_H

/* DC injection braking */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    uint8_t active;
    float brake_current;
    float brake_time_s;
    float elapsed_time_s;
    float brake_voltage;
    float ts;
    uint32_t timer_ticks;
    uint32_t max_ticks;
    float max_dc_voltage;
} dc_brake_state_t;

void dc_brake_init(dc_brake_state_t *state);
void dc_brake_update(dc_brake_state_t *state);
void dc_brake_engage(dc_brake_state_t *state);

#endif /* MOTORCONTROL_DC_BRAKE_H */
