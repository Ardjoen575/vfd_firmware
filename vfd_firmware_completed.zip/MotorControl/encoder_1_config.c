#include "encoder_1_config.h"
#include <string.h>
#include <math.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif
#ifndef M_2PI
#define M_2PI (2.0f * M_PI)
#endif

void encoder_1_config_init(encoder_1_config_state_t *state)
{
    memset(state, 0, sizeof(*state));
    state->initialized = 1;
    state->pulses_per_rev = 1024;
    state->type = ENC1_TYPE_QUADRATURE;
    state->direction = 0;
    state->ts = 0.001f;
    state->gear_ratio = 1.0f;
}

void encoder_1_config_update(encoder_1_config_state_t *state)
{
    if (!state->initialized) return;
    enc1_read_position(state);
}

void enc1_read_position(encoder_1_config_state_t *state)
{
    if (!state->initialized) return;
    int32_t delta = state->raw_count - state->prev_raw_count;
    state->prev_raw_count = state->raw_count;
    if (state->direction) delta = -delta;
    uint32_t ppr = state->pulses_per_rev;
    if (ppr < 1) ppr = 1024;
    float delta_elec = ((float)delta * M_2PI) / (float)ppr;
    state->speed_electrical = delta_elec / state->ts;
    state->position_mech += delta_elec / state->gear_ratio;
    while (state->position_mech > M_2PI) state->position_mech -= M_2PI;
    while (state->position_mech < 0.0f) state->position_mech += M_2PI;
    if (state->absolute_enabled) {
        state->position = ((float)(state->raw_count - state->absolute_offset) * M_2PI) / (float)ppr;
    } else {
        state->position = state->position_mech;
    }
    while (state->position > M_2PI) state->position -= M_2PI;
    while (state->position < 0.0f) state->position += M_2PI;
    state->speed_mechanical = state->speed_electrical / state->gear_ratio;
}
