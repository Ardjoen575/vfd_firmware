#ifndef MOTORCONTROL_CONSTANT_SPEEDS_H
#define MOTORCONTROL_CONSTANT_SPEEDS_H

/* Constant speeds/frequencies */

#include <stdint.h>

#define CONST_SPEEDS_COUNT 7

typedef struct {
    uint8_t initialized;
    float speeds[CONST_SPEEDS_COUNT];
    uint8_t active_index;
    float active_speed;
    uint8_t input_selection;
    uint8_t previous_selection;
    float speed_output;
} constant_speeds_state_t;

void constant_speeds_init(constant_speeds_state_t *state);
void constant_speeds_update(constant_speeds_state_t *state);
void const_speed_select(constant_speeds_state_t *state);

#endif /* MOTORCONTROL_CONSTANT_SPEEDS_H */
