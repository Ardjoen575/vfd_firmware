#include "feedback_selection.h"
#include <string.h>

void feedback_selection_init(feedback_selection_state_t *state)
{
    memset(state, 0, sizeof(*state));
    state->initialized = 1;
    state->speed_source = FEEDBACK_SPEED_ENCODER1;
    state->torque_source = FEEDBACK_TORQUE_ESTIMATED;
    state->source_locked = 0;
}

void feedback_selection_update(feedback_selection_state_t *state)
{
    if (!state->initialized) return;
    feedback_select_source(state);
}

void feedback_select_source(feedback_selection_state_t *state)
{
    if (!state->initialized) return;
    if (state->source_locked) return;
    switch (state->speed_source) {
    case FEEDBACK_SPEED_ENCODER1:
        state->speed_feedback = state->encoder1_speed;
        break;
    case FEEDBACK_SPEED_ENCODER2:
        state->speed_feedback = state->encoder2_speed;
        break;
    case FEEDBACK_SPEED_SENSORLESS:
        state->speed_feedback = state->sensorless_speed;
        break;
    case FEEDBACK_SPEED_ENCODER1_RED:
        state->speed_feedback = state->encoder1_speed;
        break;
    case FEEDBACK_SPEED_ENCODER2_RED:
        state->speed_feedback = state->encoder2_speed;
        break;
    default:
        state->speed_feedback = 0.0f;
        break;
    }
    switch (state->torque_source) {
    case FEEDBACK_TORQUE_SENSORLESS:
        state->torque_feedback = state->estimated_torque_val;
        break;
    case FEEDBACK_TORQUE_SHAFT_SENSOR:
        state->torque_feedback = state->shaft_torque_val;
        break;
    case FEEDBACK_TORQUE_ESTIMATED:
        state->torque_feedback = state->estimated_torque_val;
        break;
    default:
        state->torque_feedback = 0.0f;
        break;
    }
}
