#include "encoder_module_settings.h"
#include <string.h>
#include <math.h>

void encoder_module_settings_init(encoder_module_settings_state_t *state)
{
    memset(state, 0, sizeof(*state));
    state->initialized = 1;
    state->module_type = ENC_MODULE_TYPE_TTL;
    state->channel_a_enabled = 1;
    state->channel_b_enabled = 1;
    state->channel_z_enabled = 1;
    state->termination_enabled = 1;
    state->filter_time_ms = 1.0f;
    state->filter_alpha = 0.0f;
    state->resolution_bits = 12;
    state->supply_voltage = 5.0f;
    state->ts = 0.001f;
}

void encoder_module_settings_update(encoder_module_settings_state_t *state)
{
    if (!state->initialized) return;
    if (state->filter_time_ms > 0.0f && state->ts > 0.0f) {
        float tau = state->filter_time_ms / 1000.0f;
        state->filter_alpha = state->ts / (tau + state->ts);
        if (state->filter_alpha > 1.0f) state->filter_alpha = 1.0f;
    }
}

void enc_module_configure(encoder_module_settings_state_t *state)
{
    if (!state->initialized) return;
    switch (state->module_type) {
    case ENC_MODULE_TYPE_TTL:
        state->supply_voltage = 5.0f;
        state->termination_enabled = 1;
        state->resolution_bits = 12;
        break;
    case ENC_MODULE_TYPE_HTL:
        state->supply_voltage = 24.0f;
        state->termination_enabled = 0;
        state->resolution_bits = 14;
        break;
    case ENC_MODULE_TYPE_RESOLVER:
        state->supply_voltage = 7.0f;
        state->termination_enabled = 0;
        state->resolution_bits = 16;
        break;
    case ENC_MODULE_TYPE_SINCOS:
        state->supply_voltage = 5.0f;
        state->termination_enabled = 1;
        state->resolution_bits = 16;
        break;
    case ENC_MODULE_TYPE_TTL_3CH:
        state->supply_voltage = 5.0f;
        state->termination_enabled = 1;
        state->resolution_bits = 12;
        state->channel_z_enabled = 1;
        break;
    case ENC_MODULE_TYPE_HTL_3CH:
        state->supply_voltage = 24.0f;
        state->termination_enabled = 0;
        state->resolution_bits = 14;
        state->channel_z_enabled = 1;
        break;
    default:
        state->supply_voltage = 0.0f;
        state->encoder_present = 0;
        break;
    }
    state->encoder_present = (state->module_type != ENC_MODULE_TYPE_NONE) ? 1 : 0;
    state->fault_code = 0;
}
