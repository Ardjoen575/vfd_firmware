#ifndef MOTORCONTROL_CRITICAL_SPEEDS_H
#define MOTORCONTROL_CRITICAL_SPEEDS_H

/* Critical speeds/frequencies avoidance */

#include <stdint.h>

#define CRITICAL_BANDS_COUNT 3

typedef struct {
    uint8_t initialized;
    float band_lo[CRITICAL_BANDS_COUNT];
    float band_hi[CRITICAL_BANDS_COUNT];
    uint8_t band_enabled[CRITICAL_BANDS_COUNT];
    float input_speed;
    float output_speed;
    float hysteresis;
    float entering_band[CRITICAL_BANDS_COUNT];
    float max_speed;
    float min_speed;
} critical_speeds_state_t;

void critical_speeds_init(critical_speeds_state_t *state);
void critical_speeds_update(critical_speeds_state_t *state);
void critical_speed_filter(critical_speeds_state_t *state);

#endif /* MOTORCONTROL_CRITICAL_SPEEDS_H */
