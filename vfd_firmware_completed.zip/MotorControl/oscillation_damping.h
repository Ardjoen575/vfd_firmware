#ifndef MOTORCONTROL_OSCILLATION_DAMPING_H
#define MOTORCONTROL_OSCILLATION_DAMPING_H

/* Mechanical oscillation damping */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    uint8_t active;
    float notch_freq_hz;
    float notch_bandwidth_hz;
    float damping_gain;
    float torque_in;
    float torque_out;
    float input_prev[2];
    float output_prev[2];
    float b0;
    float b1;
    float b2;
    float a1;
    float a2;
    uint8_t coeffs_computed;
    float ts;
} oscillation_damping_state_t;

void oscillation_damping_init(oscillation_damping_state_t *state);
void oscillation_damping_update(oscillation_damping_state_t *state);
void osc_damp_apply(oscillation_damping_state_t *state);

#endif /* MOTORCONTROL_OSCILLATION_DAMPING_H */
