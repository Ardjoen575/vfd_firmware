#include "flying_start.h"
#include <string.h>

void flying_start_init(flying_start_state_t *state)
{
    memset(state, 0, sizeof(*state));
    state->initialized = 1;
    state->phase = FLYSTART_IDLE;
    state->scan_start_freq = 60.0f;
    state->scan_end_freq = 5.0f;
    state->scan_step = 1.0f;
    state->bemf_threshold = 10.0f;
    state->scan_direction = -1.0f;
    state->current_limit = 0.2f;
    state->sync_duration_s = 0.5f;
    state->ts = 0.001f;
    state->nominal_freq = 60.0f;
    state->max_scan_time_s = 10.0f;
}

void flying_start_update(flying_start_state_t *state)
{
    if (!state->initialized) return;
    if (state->phase == FLYSTART_IDLE || state->phase == FLYSTART_DONE || state->phase == FLYSTART_FAULT) {
        return;
    }
    state->elapsed_s += state->ts;
    if (state->elapsed_s > state->max_scan_time_s) {
        state->phase = FLYSTART_FAULT;
        return;
    }
    if (state->phase == FLYSTART_SCANNING) {
        state->scan_frequency += state->scan_step * state->scan_direction * state->ts * 10.0f;
        if (state->scan_direction < 0.0f) {
            if (state->scan_frequency <= state->scan_end_freq) {
                state->scan_frequency = state->scan_start_freq;
            }
        } else {
            if (state->scan_frequency >= state->scan_end_freq) {
                state->scan_frequency = state->scan_start_freq;
            }
        }
        state->v_d_ref = 0.0f;
        state->v_q_ref = 0.0f;
        return;
    }
    if (state->phase == FLYSTART_MEASURING_BEMF) {
        float bemf = state->bemf_magnitude;
        if (bemf > state->bemf_threshold) {
            state->found_speed = state->scan_frequency;
            state->phase = FLYSTART_LOCKING;
            state->timer = 0;
        }
        return;
    }
    if (state->phase == FLYSTART_LOCKING) {
        state->v_d_ref = 0.0f;
        state->v_q_ref = state->found_speed / state->nominal_freq * 100.0f;
        if (state->v_q_ref > 100.0f) state->v_q_ref = 100.0f;
        state->timer++;
        if (state->timer > 1000) {
            state->phase = FLYSTART_DONE;
        }
        return;
    }
}

void flying_start_search_speed(flying_start_state_t *state)
{
    if (!state->initialized) return;
    if (state->phase != FLYSTART_IDLE && state->phase != FLYSTART_DONE && state->phase != FLYSTART_FAULT) {
        return;
    }
    state->phase = FLYSTART_SCANNING;
    state->scan_frequency = state->scan_start_freq;
    state->found_speed = 0.0f;
    state->bemf_magnitude = 0.0f;
    state->bemf_angle = 0.0f;
    state->elapsed_s = 0.0f;
    state->timer = 0;
    state->v_d_ref = 0.0f;
    state->v_q_ref = 0.0f;
}
