#ifndef MOTORCONTROL_ENCODER_2_CONFIG_H
#define MOTORCONTROL_ENCODER_2_CONFIG_H

/* Encoder 2 configuration (grp 93) */

#include <stdint.h>

typedef enum {
    ENC2_TYPE_QUADRATURE = 0,
    ENC2_TYPE_HALL,
    ENC2_TYPE_RESOLVER,
    ENC2_TYPE_SINCOS,
    ENC2_TYPE_ENDAT,
    ENC2_TYPE_BISS,
    ENC2_TYPE_SSI
} encoder2_type_t;

typedef struct {
    uint8_t initialized;
    uint32_t pulses_per_rev;
    encoder2_type_t type;
    uint8_t direction;
    int32_t raw_count;
    int32_t prev_raw_count;
    float position;
    float position_mech;
    float speed_electrical;
    float speed_mechanical;
    float ts;
    float gear_ratio;
    uint8_t absolute_enabled;
    int32_t absolute_offset;
} encoder_2_config_state_t;

void encoder_2_config_init(encoder_2_config_state_t *state);
void encoder_2_config_update(encoder_2_config_state_t *state);
void enc2_read_position(encoder_2_config_state_t *state);

#endif /* MOTORCONTROL_ENCODER_2_CONFIG_H */
