#include "jogging.h"
#include <string.h>

void jogging_init(jogging_state_t *state)
{
    memset(state, 0, sizeof(*state));
    state->initialized = 1;
    state->jog_active = 0;
    state->jog_speed_ref = 10.0f;
    state->jog_accel_rate = 5.0f;
    state->jog_decel_rate = 5.0f;
    state->ts = 0.001f;
    state->max_speed = 60.0f;
    state->min_speed = -60.0f;
}

void jogging_update(jogging_state_t *state)
{
    if (!state->initialized) return;
    if (state->jog_active) {
        float rate = state->jog_accel_rate * state->ts;
        float diff = state->target_speed - state->current_speed_ref;
        if (diff > rate) {
            state->current_speed_ref += rate;
        } else if (diff < -rate) {
            state->current_speed_ref -= rate;
        } else {
            state->current_speed_ref = state->target_speed;
        }
    } else {
        float rate = state->jog_decel_rate * state->ts;
        if (state->current_speed_ref > rate) {
            state->current_speed_ref -= rate;
        } else if (state->current_speed_ref < -rate) {
            state->current_speed_ref += rate;
        } else {
            state->current_speed_ref = 0.0f;
        }
    }
    if (state->current_speed_ref > state->max_speed) state->current_speed_ref = state->max_speed;
    if (state->current_speed_ref < state->min_speed) state->current_speed_ref = state->min_speed;
}

void jog_start(jogging_state_t *state)
{
    if (!state->initialized) return;
    state->jog_active = 1;
    if (state->jog_direction) {
        state->target_speed = -state->jog_speed_ref;
    } else {
        state->target_speed = state->jog_speed_ref;
    }
}

void jog_stop(jogging_state_t *state)
{
    if (!state->initialized) return;
    state->jog_active = 0;
    state->target_speed = 0.0f;
}
