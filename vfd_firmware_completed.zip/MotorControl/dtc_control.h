#ifndef MOTORCONTROL_DTC_CONTROL_H
#define MOTORCONTROL_DTC_CONTROL_H

/* Direct Torque Control core */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    float flux_alpha;
    float flux_beta;
    float flux_magnitude;
    float flux_ref;
    float torque_estimated;
    float torque_ref;
    float v_alpha;
    float v_beta;
    float v_dc;
    float i_alpha;
    float i_beta;
    float u_alpha;
    float u_beta;
    float rs;
    float ls;
    float ts;
    float flux_hyst;
    float torque_hyst;
    float flux_hyst_band;
    float torque_hyst_band;
    int sector;
    int switching_state;
    float maximum_flux;
    float rated_torque;
} dtc_control_state_t;

void dtc_control_init(dtc_control_state_t *state);
void dtc_control_update(dtc_control_state_t *state);
void dtc_compute_torque_step(dtc_control_state_t *state);
void dtc_flux_estimate(dtc_control_state_t *state);

#endif /* MOTORCONTROL_DTC_CONTROL_H */
