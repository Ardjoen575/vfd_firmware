#ifndef MOTORCONTROL_FLUX_BRAKING_H
#define MOTORCONTROL_FLUX_BRAKING_H

/* Flux braking */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    uint8_t active;
    uint8_t decelerating;
    float flux_boost_factor;
    float flux_nominal;
    float flux_ref;
    float flux_output;
    float dc_link_voltage;
    float dc_link_max;
    float dc_link_threshold;
    float ramp_up_rate;
    float ramp_down_rate;
    float ts;
} flux_braking_state_t;

void flux_braking_init(flux_braking_state_t *state);
void flux_braking_update(flux_braking_state_t *state);
void flux_brake_apply(flux_braking_state_t *state);

#endif /* MOTORCONTROL_FLUX_BRAKING_H */
