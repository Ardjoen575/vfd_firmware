#include "rush_control.h"
#include <string.h>

void rush_control_init(rush_control_state_t *state)
{
    memset(state, 0, sizeof(*state));
    state->initialized = 1;
    state->current_limit_max = 2.0f;
    state->current_limit_min = 0.5f;
    state->ramp_up_rate = 0.5f;
    state->ramp_down_rate = 2.0f;
    state->ts = 0.001f;
}

void rush_control_update(rush_control_state_t *state)
{
    if (!state->initialized) return;
    rush_control_apply(state);
}

void rush_control_apply(rush_control_state_t *state)
{
    if (!state->initialized) return;
    if (state->magnetizing) {
        state->timer_s += state->ts;
        if (state->ramping_up) {
            state->current_limit_out += state->ramp_up_rate * state->ts;
            if (state->current_limit_out >= state->current_limit_max) {
                state->current_limit_out = state->current_limit_max;
                state->ramping_up = 0;
            }
        }
        float clamped = state->current_in;
        if (clamped > state->current_limit_out) clamped = state->current_limit_out;
        if (clamped < -state->current_limit_out) clamped = -state->current_limit_out;
        state->current_out = clamped;
    } else {
        state->current_limit_out = state->current_limit_min;
        state->ramping_up = 1;
        state->timer_s = 0.0f;
        state->current_out = state->current_in;
    }
}
