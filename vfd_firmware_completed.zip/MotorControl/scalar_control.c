#include "scalar_control.h"
#include <string.h>
#include <math.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif
#ifndef M_2PI
#define M_2PI (2.0f * M_PI)
#endif
#ifndef M_SQRT3
#define M_SQRT3 1.7320508075688772f
#endif

void scalar_control_init(scalar_control_state_t *state)
{
    memset(state, 0, sizeof(*state));
    state->initialized = 1;
    state->nominal_freq = 60.0f;
    state->nominal_voltage = 400.0f;
    state->boost_voltage = 15.0f;
    state->boost_freq = 3.0f;
    state->ir_comp_gain = 0.1f;
    state->rs = 1.5f;
    state->field_weakening_freq = 60.0f;
    state->max_voltage = 400.0f;
    state->max_frequency = 120.0f;
    state->min_frequency = 0.5f;
    state->ts = 0.001f;
    state->rated_slip = 1.5f;
    state->rated_current = 10.0f;
}

void scalar_control_update(scalar_control_state_t *state)
{
    if (!state->initialized) return;
    scalar_ctrl_step(state);
}

void scalar_ctrl_step(scalar_control_state_t *state)
{
    if (!state->initialized) return;
    float freq = state->freq_ref;
    float freq_abs = (freq > 0.0f) ? freq : -freq;
    float voltage;
    float fn = state->nominal_freq;
    float vn = state->nominal_voltage;
    float vb = state->boost_voltage;
    float fb = state->boost_freq;
    if (fn < 1.0f) fn = 60.0f;
    if (fb < 0.1f) fb = 0.1f;
    if (freq_abs < state->min_frequency) freq_abs = 0.0f;
    /* V/Hz linear curve with boost */
    if (freq_abs <= fb) {
        voltage = vb * (freq_abs / fb);
    } else if (freq_abs <= state->field_weakening_freq) {
        float slope = (vn - vb) / (state->field_weakening_freq - fb);
        if (slope < 0.0f) slope = 0.0f;
        voltage = vb + slope * (freq_abs - fb);
    } else {
        /* Field weakening: constant voltage, flux drops as 1/f */
        voltage = state->max_voltage;
    }
    /* IR compensation */
    float ir_drop = state->rs * state->current_magnitude * state->ir_comp_gain;
    voltage += ir_drop;
    if (voltage > state->max_voltage) voltage = state->max_voltage;
    if (voltage < 0.0f) voltage = 0.0f;
    state->voltage_magnitude = voltage;
    if (state->slip_comp_enable && freq_abs > 0.0f) {
        float slip = state->rated_slip * (state->current_magnitude / state->rated_current);
        if (freq > 0.0f) {
            freq += slip;
        } else {
            freq -= slip;
        }
    }
    /* Integrate angle */
    state->angle_accum += freq * state->ts * M_2PI;
    state->angle = state->angle_accum;
    while (state->angle > M_2PI) state->angle -= M_2PI;
    while (state->angle < 0.0f) state->angle += M_2PI;
    /* Inverse Clarke: magnitude -> alpha/beta */
    state->v_alpha = voltage * cosf(state->angle);
    state->v_beta  = voltage * sinf(state->angle);
    float v_u = state->v_alpha;
    float v_v = -0.5f * state->v_alpha + M_SQRT3 * 0.5f * state->v_beta;
    float v_w = -0.5f * state->v_alpha - M_SQRT3 * 0.5f * state->v_beta;
    state->v_u = v_u;
    state->v_v = v_v;
    state->v_w = v_w;
    state->freq_output = freq;
}
