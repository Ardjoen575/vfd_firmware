#ifndef MOTORCONTROL_HEXAGONAL_FLUX_H
#define MOTORCONTROL_HEXAGONAL_FLUX_H

/* Hexagonal motor flux pattern */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    uint8_t active;
    float angle;
    float flux_magnitude;
    float flux_alpha_ref;
    float flux_beta_ref;
    float flux_alpha_circular;
    float flux_beta_circular;
    float modulation_idx;
    float ts;
    float electrical_speed;
    float hex_gain;
} hexagonal_flux_state_t;

void hexagonal_flux_init(hexagonal_flux_state_t *state);
void hexagonal_flux_update(hexagonal_flux_state_t *state);
void hex_flux_apply(hexagonal_flux_state_t *state);

#endif /* MOTORCONTROL_HEXAGONAL_FLUX_H */
