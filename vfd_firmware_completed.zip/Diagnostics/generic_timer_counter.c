#include "generic_timer_counter.h"

#define GTC_MAX_TIMERS   8
#define GTC_MAX_COUNTERS 8

typedef struct {
    uint32_t value_ms;
    uint32_t preset_ms;
    uint8_t  running;
    uint8_t  done;
    uint8_t  direction;
} gtc_timer_t;

typedef struct {
    uint32_t value;
    uint32_t preset;
    uint8_t  running;
    uint8_t  done;
    uint8_t  direction;
} gtc_counter_t;

typedef struct {
    gtc_timer_t   timers[GTC_MAX_TIMERS];
    gtc_counter_t counters[GTC_MAX_COUNTERS];
    uint32_t      tick_count;
} gtc_internal_t;

static gtc_internal_t gtc;

void generic_timer_counter_init(generic_timer_counter_state_t *state)
{
    state->initialized = 1;

    for (uint8_t i = 0; i < GTC_MAX_TIMERS; i++) {
        gtc.timers[i].value_ms = 0;
        gtc.timers[i].preset_ms = 0;
        gtc.timers[i].running = 0;
        gtc.timers[i].done = 0;
        gtc.timers[i].direction = 0;
    }

    for (uint8_t i = 0; i < GTC_MAX_COUNTERS; i++) {
        gtc.counters[i].value = 0;
        gtc.counters[i].preset = 0;
        gtc.counters[i].running = 0;
        gtc.counters[i].done = 0;
        gtc.counters[i].direction = 0;
    }

    gtc.tick_count = 0;
}

void generic_timer_counter_update(generic_timer_counter_state_t *state)
{
    if (!state->initialized) return;
    gtc.tick_count++;
}

void gtc_tick(generic_timer_counter_state_t *state)
{
    (void)state;

    for (uint8_t i = 0; i < GTC_MAX_TIMERS; i++) {
        if (!gtc.timers[i].running) continue;

        if (gtc.timers[i].direction == 0) {
            gtc.timers[i].value_ms++;
            if (gtc.timers[i].value_ms >= gtc.timers[i].preset_ms) {
                gtc.timers[i].value_ms = gtc.timers[i].preset_ms;
                gtc.timers[i].done = 1;
                gtc.timers[i].running = 0;
            }
        } else {
            if (gtc.timers[i].value_ms > 0) {
                gtc.timers[i].value_ms--;
            }
            if (gtc.timers[i].value_ms == 0) {
                gtc.timers[i].done = 1;
                gtc.timers[i].running = 0;
            }
        }
    }
}

void gtc_timer_start(uint8_t index, uint32_t preset_ms, uint8_t dir_up)
{
    if (index >= GTC_MAX_TIMERS) return;
    gtc.timers[index].preset_ms = preset_ms;
    gtc.timers[index].value_ms = (dir_up) ? 0 : preset_ms;
    gtc.timers[index].running = 1;
    gtc.timers[index].done = 0;
    gtc.timers[index].direction = dir_up;
}

void gtc_timer_stop(uint8_t index)
{
    if (index >= GTC_MAX_TIMERS) return;
    gtc.timers[index].running = 0;
}

void gtc_timer_reset(uint8_t index)
{
    if (index >= GTC_MAX_TIMERS) return;
    gtc.timers[index].value_ms = (gtc.timers[index].direction == 0) ? 0 : gtc.timers[index].preset_ms;
    gtc.timers[index].done = 0;
}

uint32_t gtc_timer_get_value(uint8_t index)
{
    if (index >= GTC_MAX_TIMERS) return 0;
    return gtc.timers[index].value_ms;
}

uint8_t gtc_timer_is_done(uint8_t index)
{
    if (index >= GTC_MAX_TIMERS) return 0;
    return gtc.timers[index].done;
}

uint8_t gtc_timer_is_running(uint8_t index)
{
    if (index >= GTC_MAX_TIMERS) return 0;
    return gtc.timers[index].running;
}

void gtc_counter_set_preset(uint8_t index, uint32_t preset)
{
    if (index >= GTC_MAX_COUNTERS) return;
    gtc.counters[index].preset = preset;
}

void gtc_counter_increment(uint8_t index)
{
    if (index >= GTC_MAX_COUNTERS) return;
    if (!gtc.counters[index].running) return;

    if (gtc.counters[index].direction == 0) {
        gtc.counters[index].value++;
        if (gtc.counters[index].value >= gtc.counters[index].preset) {
            gtc.counters[index].done = 1;
            gtc.counters[index].running = 0;
        }
    }
}

void gtc_counter_decrement(uint8_t index)
{
    if (index >= GTC_MAX_COUNTERS) return;
    if (!gtc.counters[index].running) return;

    if (gtc.counters[index].direction == 1) {
        if (gtc.counters[index].value > 0) {
            gtc.counters[index].value--;
        }
        if (gtc.counters[index].value == 0) {
            gtc.counters[index].done = 1;
            gtc.counters[index].running = 0;
        }
    }
}

void gtc_counter_start(uint8_t index, uint8_t dir_up)
{
    if (index >= GTC_MAX_COUNTERS) return;
    gtc.counters[index].value = (dir_up) ? 0 : gtc.counters[index].preset;
    gtc.counters[index].running = 1;
    gtc.counters[index].done = 0;
    gtc.counters[index].direction = dir_up;
}

void gtc_counter_stop(uint8_t index)
{
    if (index >= GTC_MAX_COUNTERS) return;
    gtc.counters[index].running = 0;
}

void gtc_counter_reset(uint8_t index)
{
    if (index >= GTC_MAX_COUNTERS) return;
    gtc.counters[index].value = (gtc.counters[index].direction == 0) ? 0 : gtc.counters[index].preset;
    gtc.counters[index].done = 0;
}

uint32_t gtc_counter_get_value(uint8_t index)
{
    if (index >= GTC_MAX_COUNTERS) return 0;
    return gtc.counters[index].value;
}

uint8_t gtc_counter_is_done(uint8_t index)
{
    if (index >= GTC_MAX_COUNTERS) return 0;
    return gtc.counters[index].done;
}
