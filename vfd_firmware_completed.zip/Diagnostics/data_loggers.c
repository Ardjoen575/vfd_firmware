#include "data_loggers.h"
#include <string.h>

#define DL_MAX_SIGNALS     8
#define DL_BUFFER_DEPTH    256

typedef struct {
    uint16_t buffer[DL_MAX_SIGNALS][DL_BUFFER_DEPTH];
    uint16_t write_idx;
    uint16_t sample_count;
    uint16_t interval_ms;
    uint32_t interval_timer;
    uint8_t  enabled;
    uint8_t  trigger_signal;
    uint8_t  trigger_limit;
    uint8_t  trigger_edge;
    uint8_t  trigger_fired;
    uint8_t  signal_count;
    uint8_t  signal_select[DL_MAX_SIGNALS];
} dl_internal_t;

static dl_internal_t dl;

void data_loggers_init(data_loggers_state_t *state)
{
    state->initialized = 1;
    memset(&dl, 0, sizeof(dl));
    dl.interval_ms = 100;
}

void data_loggers_update(data_loggers_state_t *state)
{
    if (!state->initialized) return;
    dl.interval_timer++;
}

void data_logger_capture(data_loggers_state_t *state)
{
    (void)state;

    if (!dl.enabled) return;

    if (dl.trigger_fired && dl.sample_count < DL_BUFFER_DEPTH) {
        if (dl.interval_timer >= dl.interval_ms) {
            dl.interval_timer = 0;

            for (uint8_t s = 0; s < dl.signal_count && s < DL_MAX_SIGNALS; s++) {
                dl.buffer[s][dl.write_idx] = 0;
            }

            dl.write_idx = (uint16_t)((dl.write_idx + 1) % DL_BUFFER_DEPTH);
            dl.sample_count++;
        }

        if (dl.sample_count >= DL_BUFFER_DEPTH) {
            dl.trigger_fired = 0;
        }
    }
}

void data_logger_set_interval(uint16_t ms)
{
    dl.interval_ms = ms;
}

void data_logger_set_signal_select(uint8_t signal_index, uint8_t param_id)
{
    if (signal_index < DL_MAX_SIGNALS) {
        dl.signal_select[signal_index] = param_id;
    }
}

void data_logger_set_signal_count(uint8_t count)
{
    if (count <= DL_MAX_SIGNALS) {
        dl.signal_count = count;
    }
}

void data_logger_set_trigger(uint8_t signal, uint8_t limit, uint8_t edge)
{
    dl.trigger_signal = signal;
    dl.trigger_limit = limit;
    dl.trigger_edge = edge;
}

void data_logger_arm(void)
{
    dl.enabled = 1;
    dl.trigger_fired = 0;
    dl.write_idx = 0;
    dl.sample_count = 0;
    dl.interval_timer = 0;
}

void data_logger_stop(void)
{
    dl.enabled = 0;
    dl.trigger_fired = 0;
}

void data_logger_feed_signal(uint8_t signal_idx, uint16_t value)
{
    if (!dl.trigger_fired && dl.enabled) {
        if (signal_idx == dl.trigger_signal) {
            if (dl.trigger_edge == 0) {
                if (value >= dl.trigger_limit) {
                    dl.trigger_fired = 1;
                    dl.write_idx = 0;
                    dl.interval_timer = 0;
                }
            } else {
                if (value <= dl.trigger_limit) {
                    dl.trigger_fired = 1;
                    dl.write_idx = 0;
                    dl.interval_timer = 0;
                }
            }
        }
    }
}

uint16_t data_logger_read_sample(uint8_t signal_idx, uint16_t sample_idx)
{
    if (signal_idx >= dl.signal_count || sample_idx >= dl.sample_count) return 0;
    return dl.buffer[signal_idx][sample_idx];
}

uint16_t data_logger_get_sample_count(void)
{
    return dl.sample_count;
}

uint8_t data_logger_is_running(void)
{
    return dl.enabled && dl.trigger_fired;
}
