#include "runtime_stats.h"

typedef struct {
    uint32_t power_on_seconds;
    uint32_t run_seconds;
    uint32_t motor_run_seconds;
    uint32_t fan_run_seconds;
    uint32_t energy_kWh_thousandths;
    uint32_t energy_mWh_accum;
    uint32_t tick_ms;
    uint8_t  drive_running;
    uint8_t  motor_running;
    uint8_t  fan_running;
    uint8_t  initialized_ok;
} rs_internal_t;

static rs_internal_t rs;

void runtime_stats_init(runtime_stats_state_t *state)
{
    state->initialized = 1;
    rs.power_on_seconds = 0;
    rs.run_seconds = 0;
    rs.motor_run_seconds = 0;
    rs.fan_run_seconds = 0;
    rs.energy_kWh_thousandths = 0;
    rs.energy_mWh_accum = 0;
    rs.tick_ms = 0;
    rs.drive_running = 0;
    rs.motor_running = 0;
    rs.fan_running = 0;
    rs.initialized_ok = 1;
}

void runtime_stats_update(runtime_stats_state_t *state)
{
    if (!state->initialized) return;
    if (!rs.initialized_ok) return;
    (void)state;
}

void runtime_stats_tick(runtime_stats_state_t *state)
{
    (void)state;

    if (!rs.initialized_ok) return;

    rs.tick_ms++;

    if (rs.tick_ms >= 1000) {
        rs.tick_ms = 0;

        rs.power_on_seconds++;

        if (rs.drive_running) {
            rs.run_seconds++;
        }
        if (rs.motor_running) {
            rs.motor_run_seconds++;
        }
        if (rs.fan_running) {
            rs.fan_run_seconds++;
        }

        rs.energy_mWh_accum += 100;
        rs.energy_kWh_thousandths = rs.energy_mWh_accum / 3600;
    }
}

void runtime_stats_set_drive_running(uint8_t running)
{
    rs.drive_running = running;
}

void runtime_stats_set_motor_running(uint8_t running)
{
    rs.motor_running = running;
}

void runtime_stats_set_fan_running(uint8_t running)
{
    rs.fan_running = running;
}

void runtime_stats_add_energy(uint32_t power_kW_tenths)
{
    rs.energy_mWh_accum += (uint32_t)power_kW_tenths * 100;
}

uint32_t runtime_stats_get_power_on_hours(void)
{
    return rs.power_on_seconds / 3600;
}

uint32_t runtime_stats_get_run_hours(void)
{
    return rs.run_seconds / 3600;
}

uint32_t runtime_stats_get_motor_run_hours(void)
{
    return rs.motor_run_seconds / 3600;
}

uint32_t runtime_stats_get_fan_run_hours(void)
{
    return rs.fan_run_seconds / 3600;
}

uint32_t runtime_stats_get_energy_kWh(void)
{
    return rs.energy_kWh_thousandths / 1000;
}

uint32_t runtime_stats_get_energy_mWh(void)
{
    return rs.energy_mWh_accum;
}

void runtime_stats_reset_energy(void)
{
    rs.energy_kWh_thousandths = 0;
    rs.energy_mWh_accum = 0;
}
