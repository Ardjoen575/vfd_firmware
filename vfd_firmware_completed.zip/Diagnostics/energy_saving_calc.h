#ifndef DIAGNOSTICS_ENERGY_SAVING_CALC_H
#define DIAGNOSTICS_ENERGY_SAVING_CALC_H

/* Energy saving calculators (grp 45) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    int32_t actual_energy_kWh_milli;
    int32_t baseline_energy_kWh_milli;
    int32_t saved_energy_kWh_milli;
    int32_t saved_cost_thousandths;
    int32_t saved_co2_kg_milli;
    uint32_t energy_per_hour_baseline;
    uint32_t energy_per_hour_actual;
    uint16_t cost_per_kWh_thousandths;
    uint16_t co2_per_kWh_milli;
    uint32_t tick_ms;
    uint32_t hour_accum_ms;
    uint8_t  baseline_configured;
    uint8_t  motor_running;
} energy_saving_calc_state_t;

void energy_saving_calc_init(energy_saving_calc_state_t *state);
void energy_saving_calc_update(energy_saving_calc_state_t *state);
void energy_calc_update(energy_saving_calc_state_t *state);

#endif /* DIAGNOSTICS_ENERGY_SAVING_CALC_H */
