#ifndef DIAGNOSTICS_GENERIC_TIMER_COUNTER_H
#define DIAGNOSTICS_GENERIC_TIMER_COUNTER_H

/* Generic timer & counter (grp 33) */

#include <stdint.h>

#define GTC_MAX_TIMERS   8
#define GTC_MAX_COUNTERS 8

typedef struct {
    uint32_t value_ms;
    uint32_t preset_ms;
    uint8_t  running;
    uint8_t  done;
    uint8_t  direction;
} gtc_timer_t;

typedef struct {
    uint32_t value;
    uint32_t preset;
    uint8_t  running;
    uint8_t  done;
    uint8_t  direction;
} gtc_counter_t;

typedef struct {
    uint8_t initialized;
    gtc_timer_t   timers[GTC_MAX_TIMERS];
    gtc_counter_t counters[GTC_MAX_COUNTERS];
    uint32_t      tick_count;
} generic_timer_counter_state_t;

void generic_timer_counter_init(generic_timer_counter_state_t *state);
void generic_timer_counter_update(generic_timer_counter_state_t *state);
void gtc_tick(generic_timer_counter_state_t *state);

#endif /* DIAGNOSTICS_GENERIC_TIMER_COUNTER_H */
