#include "event_logs.h"
#include <string.h>

#define EL_BUFFER_SIZE  64

typedef struct {
    uint32_t timestamp;
    uint16_t event_code;
    uint16_t event_data;
    uint32_t aux_data;
} el_entry_t;

typedef struct {
    el_entry_t buffer[EL_BUFFER_SIZE];
    uint8_t    write_idx;
    uint8_t    entry_count;
    uint32_t   total_count;
    uint32_t   systick_ms;
} el_internal_t;

static el_internal_t el;

void event_logs_init(event_logs_state_t *state)
{
    state->initialized = 1;
    memset(&el, 0, sizeof(el));
}

void event_logs_update(event_logs_state_t *state)
{
    if (!state->initialized) return;
    el.systick_ms++;
}

void event_log_append(event_logs_state_t *state)
{
    (void)state;

    el_entry_t entry;
    entry.timestamp = el.systick_ms;
    entry.event_code = 0;
    entry.event_data = 0;
    entry.aux_data = 0;

    el.buffer[el.write_idx] = entry;
    el.write_idx = (uint8_t)((el.write_idx + 1) & (EL_BUFFER_SIZE - 1));
    el.total_count++;

    if (el.entry_count < EL_BUFFER_SIZE) {
        el.entry_count++;
    }
}

void event_log_append_with_data(uint16_t event_code, uint16_t event_data, uint32_t aux_data)
{
    el_entry_t entry;
    entry.timestamp = el.systick_ms;
    entry.event_code = event_code;
    entry.event_data = event_data;
    entry.aux_data = aux_data;

    el.buffer[el.write_idx] = entry;
    el.write_idx = (uint8_t)((el.write_idx + 1) & (EL_BUFFER_SIZE - 1));
    el.total_count++;

    if (el.entry_count < EL_BUFFER_SIZE) {
        el.entry_count++;
    }
}

uint8_t event_log_get_count(void)
{
    return el.entry_count;
}

uint32_t event_log_get_total_count(void)
{
    return el.total_count;
}

const el_entry_t *event_log_get_entry(uint8_t index)
{
    if (index >= el.entry_count) return NULL;
    uint8_t actual = (uint8_t)((el.write_idx - el.entry_count + index) & (EL_BUFFER_SIZE - 1));
    return &el.buffer[actual];
}

void event_log_get_entry_fields(uint8_t index, uint32_t *timestamp,
                                uint16_t *event_code, uint16_t *event_data,
                                uint32_t *aux_data)
{
    const el_entry_t *entry = event_log_get_entry(index);
    if (entry) {
        *timestamp = entry->timestamp;
        *event_code = entry->event_code;
        *event_data = entry->event_data;
        *aux_data = entry->aux_data;
    }
}

void event_log_clear(void)
{
    memset(&el.buffer, 0, sizeof(el.buffer));
    el.write_idx = 0;
    el.entry_count = 0;
}
