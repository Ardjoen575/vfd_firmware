#ifndef DIAGNOSTICS_SYSTEM_INFO_H
#define DIAGNOSTICS_SYSTEM_INFO_H

/* System info (grp 07) */

#include <stdint.h>

#define SI_SERIAL_LEN   16
#define SI_FW_LEN       16
#define SI_TYPE_LEN     16
#define SI_NAME_LEN     32

typedef struct {
    uint8_t initialized;
    char     serial_number[SI_SERIAL_LEN];
    char     firmware_version[SI_FW_LEN];
    char     drive_type_code[SI_TYPE_LEN];
    char     drive_name[SI_NAME_LEN];
    uint32_t firmware_checksum;
    uint16_t firmware_revision;
    uint16_t hardware_revision;
    uint16_t drive_rating_current_A;
    uint16_t drive_rating_voltage_V;
    uint16_t drive_rating_power_kW;
    uint8_t  drive_type;
    uint8_t  supply_phases;
    uint8_t  control_unit_type;
    uint8_t  power_unit_type;
    uint32_t boot_count;
    uint32_t uptime_seconds;
    uint32_t installation_date_epoch;
    uint16_t dc_link_rating_V;
    uint16_t switching_freq_default_kHz;
    uint8_t  data_valid;
} system_info_state_t;

void system_info_init(system_info_state_t *state);
void system_info_update(system_info_state_t *state);
void sysinfo_update(system_info_state_t *state);

#endif /* DIAGNOSTICS_SYSTEM_INFO_H */
