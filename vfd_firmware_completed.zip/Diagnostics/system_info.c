#include "system_info.h"
#include <string.h>

#define SI_SERIAL_LEN   16
#define SI_FW_LEN       16
#define SI_TYPE_LEN     16
#define SI_NAME_LEN     32

typedef struct {
    char     serial_number[SI_SERIAL_LEN];
    char     firmware_version[SI_FW_LEN];
    char     drive_type_code[SI_TYPE_LEN];
    char     drive_name[SI_NAME_LEN];
    uint32_t firmware_checksum;
    uint16_t firmware_revision;
    uint16_t hardware_revision;
    uint16_t drive_rating_current_A;
    uint16_t drive_rating_voltage_V;
    uint16_t drive_rating_power_kW;
    uint8_t  drive_type;
    uint8_t  supply_phases;
    uint8_t  control_unit_type;
    uint8_t  power_unit_type;
    uint32_t boot_count;
    uint32_t uptime_seconds;
    uint32_t installation_date_epoch;
    uint16_t dc_link_rating_V;
    uint16_t switching_freq_default_kHz;
    uint8_t  data_valid;
} si_internal_t;

static si_internal_t si;

void system_info_init(system_info_state_t *state)
{
    state->initialized = 1;
    memset(&si, 0, sizeof(si));

    strncpy(si.serial_number, "S25120001", SI_SERIAL_LEN - 1);
    strncpy(si.firmware_version, "FW 2.14.3.0", SI_FW_LEN - 1);
    strncpy(si.drive_type_code, "ACS580-01-12A6-4", SI_TYPE_LEN - 1);
    strncpy(si.drive_name, "Pump Drive 1", SI_NAME_LEN - 1);
    si.firmware_checksum = 0xA5C3E100;
    si.firmware_revision = 0x2143;
    si.hardware_revision = 0x0102;
    si.drive_rating_current_A = 126;
    si.drive_rating_voltage_V = 400;
    si.drive_rating_power_kW = 55;
    si.drive_type = 1;
    si.supply_phases = 3;
    si.control_unit_type = 0x02;
    si.power_unit_type = 0x01;
    si.boot_count = 1;
    si.uptime_seconds = 0;
    si.installation_date_epoch = 1700000000;
    si.dc_link_rating_V = 650;
    si.switching_freq_default_kHz = 4;
    si.data_valid = 1;
}

void system_info_update(system_info_state_t *state)
{
    if (!state->initialized) return;
    si.uptime_seconds++;
}

void sysinfo_update(system_info_state_t *state)
{
    (void)state;
    si.uptime_seconds++;
}

const char *sysinfo_get_serial(void)
{
    return si.serial_number;
}

const char *sysinfo_get_firmware_version(void)
{
    return si.firmware_version;
}

const char *sysinfo_get_drive_type_code(void)
{
    return si.drive_type_code;
}

const char *sysinfo_get_drive_name(void)
{
    return si.drive_name;
}

uint32_t sysinfo_get_firmware_checksum(void)
{
    return si.firmware_checksum;
}

uint16_t sysinfo_get_firmware_revision(void)
{
    return si.firmware_revision;
}

uint16_t sysinfo_get_hardware_revision(void)
{
    return si.hardware_revision;
}

uint16_t sysinfo_get_rating_current(void)
{
    return si.drive_rating_current_A;
}

uint16_t sysinfo_get_rating_voltage(void)
{
    return si.drive_rating_voltage_V;
}

uint16_t sysinfo_get_rating_power(void)
{
    return si.drive_rating_power_kW;
}

uint8_t sysinfo_get_drive_type(void)
{
    return si.drive_type;
}

uint8_t sysinfo_get_supply_phases(void)
{
    return si.supply_phases;
}

uint32_t sysinfo_get_boot_count(void)
{
    return si.boot_count;
}

uint32_t sysinfo_get_uptime_seconds(void)
{
    return si.uptime_seconds;
}

uint32_t sysinfo_get_uptime_hours(void)
{
    return si.uptime_seconds / 3600;
}

void sysinfo_increment_boot_count(void)
{
    si.boot_count++;
}

void sysinfo_set_drive_name(const char *name)
{
    strncpy(si.drive_name, name, SI_NAME_LEN - 1);
    si.drive_name[SI_NAME_LEN - 1] = '\0';
}

void sysinfo_reset_uptime(void)
{
    si.uptime_seconds = 0;
}

void sysinfo_set_rating(uint16_t current_A, uint16_t voltage_V, uint16_t power_kW)
{
    si.drive_rating_current_A = current_A;
    si.drive_rating_voltage_V = voltage_V;
    si.drive_rating_power_kW = power_kW;
}
