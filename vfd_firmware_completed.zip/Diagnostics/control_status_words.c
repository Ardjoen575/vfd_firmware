#include "control_status_words.h"

#define CW_OFF1_BIT           0
#define CW_OFF2_BIT           1
#define CW_OFF3_BIT           2
#define CW_RUN_BIT            3
#define CW_RAMP_ZERO_BIT      4
#define CW_RAMP_HOLD_BIT      5
#define CW_RAMP_IN_ZERO_BIT   6
#define CW_FAULT_RESET_BIT    7
#define CW_JOG1_BIT           8
#define CW_JOG2_BIT           9
#define CW_REMOTE_CMD_BIT     10
#define CW_EXT_CTRL_LOC_BIT   11
#define CW_REV_BIT            12

#define SW_READY_ON_BIT       0
#define SW_READY_RUN_BIT      1
#define SW_READY_REF_BIT      2
#define SW_TRIPPED_BIT        3
#define SW_OFF2_ACTIVE_BIT    4
#define SW_OFF3_ACTIVE_BIT    5
#define SW_SWITCH_INHIBIT_BIT 6
#define SW_WARNING_BIT        7
#define SW_AT_SETPOINT_BIT    8
#define SW_REMOTE_BIT         9
#define SW_ABOVE_LIMIT_BIT    10
#define SW_EXT_CTRL_LOC_BIT   11
#define SW_EXT_RUN_EN_BIT     12
#define SW_FAULT_BIT          13
#define SW_ALARM_BIT          14
#define SW_REV_BIT            15

typedef struct {
    uint16_t control_word;
    uint16_t status_word;
    uint8_t  cw_start;
    uint8_t  cw_stop;
    uint8_t  cw_reverse;
    uint8_t  cw_fault_reset;
    uint8_t  sw_ready;
    uint8_t  sw_running;
    uint8_t  sw_faulted;
    uint8_t  sw_warning;
    uint8_t  sw_at_setpoint;
    uint8_t  sw_off2_active;
    uint8_t  sw_off3_active;
    uint8_t  drive_running;
    uint8_t  drive_fault;
    uint8_t  drive_warning;
} csw_internal_t;

static csw_internal_t csw;

void control_status_words_init(control_status_words_state_t *state)
{
    state->initialized = 1;
    csw.control_word = 0;
    csw.status_word = (1 << SW_SWITCH_INHIBIT_BIT);
    csw.cw_start = 0;
    csw.cw_stop = 1;
    csw.cw_reverse = 0;
    csw.cw_fault_reset = 0;
    csw.sw_ready = 0;
    csw.sw_running = 0;
    csw.sw_faulted = 0;
    csw.sw_warning = 0;
    csw.sw_at_setpoint = 0;
    csw.sw_off2_active = 0;
    csw.sw_off3_active = 0;
    csw.drive_running = 0;
    csw.drive_fault = 0;
    csw.drive_warning = 0;
}

void control_status_words_update(control_status_words_state_t *state)
{
    if (!state->initialized) return;
    (void)state;
}

void ctrlstatus_update(control_status_words_state_t *state)
{
    (void)state;

    csw.control_word = 0;

    if (!csw.cw_stop) {
        csw.control_word |= (1 << CW_OFF1_BIT);
    }
    if (csw.sw_off2_active) {
        csw.control_word |= (1 << CW_OFF2_BIT);
    }
    if (csw.sw_off3_active) {
        csw.control_word |= (1 << CW_OFF3_BIT);
    }
    if (csw.cw_start) {
        csw.control_word |= (1 << CW_RUN_BIT);
    }
    if (csw.cw_fault_reset) {
        csw.control_word |= (1 << CW_FAULT_RESET_BIT);
    }
    if (csw.cw_reverse) {
        csw.control_word |= (1 << CW_REV_BIT);
    }

    csw.status_word = 0;

    if (csw.sw_ready) {
        csw.status_word |= (1 << SW_READY_ON_BIT);
    }
    if (csw.drive_running) {
        csw.status_word |= (1 << SW_READY_RUN_BIT);
    }
    if (csw.sw_faulted) {
        csw.status_word |= (1 << SW_TRIPPED_BIT);
    }
    if (csw.sw_off2_active) {
        csw.status_word |= (1 << SW_OFF2_ACTIVE_BIT);
    }
    if (csw.sw_off3_active) {
        csw.status_word |= (1 << SW_OFF3_ACTIVE_BIT);
    }
    if (csw.sw_warning) {
        csw.status_word |= (1 << SW_WARNING_BIT);
    }
    if (csw.sw_at_setpoint) {
        csw.status_word |= (1 << SW_AT_SETPOINT_BIT);
    }
    if (csw.cw_reverse) {
        csw.status_word |= (1 << SW_REV_BIT);
    }
}

uint16_t ctrlstatus_get_control_word(void)
{
    return csw.control_word;
}

uint16_t ctrlstatus_get_status_word(void)
{
    return csw.status_word;
}

void ctrlstatus_set_control_word(uint16_t cw)
{
    csw.cw_start = (cw >> CW_RUN_BIT) & 1;
    csw.cw_stop = !((cw >> CW_OFF1_BIT) & 1);
    csw.cw_reverse = (cw >> CW_REV_BIT) & 1;
    csw.cw_fault_reset = (cw >> CW_FAULT_RESET_BIT) & 1;
}

void ctrlstatus_set_drive_state(uint8_t running, uint8_t faulted, uint8_t warning)
{
    csw.drive_running = running;
    csw.drive_fault = faulted;
    csw.drive_warning = warning;
    csw.sw_ready = !faulted;
    csw.sw_running = running;
    csw.sw_faulted = faulted;
    csw.sw_warning = warning;
}

void ctrlstatus_set_ready(uint8_t ready)
{
    csw.sw_ready = ready;
}

void ctrlstatus_set_at_setpoint(uint8_t at_sp)
{
    csw.sw_at_setpoint = at_sp;
}
