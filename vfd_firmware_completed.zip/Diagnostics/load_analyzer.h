#ifndef DIAGNOSTICS_LOAD_ANALYZER_H
#define DIAGNOSTICS_LOAD_ANALYZER_H

/* Load analyzer (grp 36) */

#include <stdint.h>

#define LA_AMPLITUDE_LOG_DEPTH 10

typedef struct {
    uint32_t timestamp;
    int16_t  current;
    int16_t  power;
} la_log_entry_t;

typedef struct {
    uint8_t initialized;
    la_log_entry_t amplitude_log[LA_AMPLITUDE_LOG_DEPTH];
    uint8_t  log_idx;
    int16_t  peak_current_A;
    int16_t  peak_power_kW;
    int16_t  min_current_A;
    int16_t  avg_current_A;
    int16_t  avg_power_kW;
    uint32_t sample_count;
    uint32_t current_sum;
    uint32_t power_sum;
    uint8_t  enabled;
    uint32_t interval_ms;
    uint32_t interval_timer;
    uint32_t sample_window_ms;
    uint32_t window_timer;
} load_analyzer_state_t;

void load_analyzer_init(load_analyzer_state_t *state);
void load_analyzer_update(load_analyzer_state_t *state);
void load_analyzer_sample(load_analyzer_state_t *state);

#endif /* DIAGNOSTICS_LOAD_ANALYZER_H */
