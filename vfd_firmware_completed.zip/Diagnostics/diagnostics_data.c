#include "diagnostics_data.h"

typedef struct {
    uint16_t control_word;
    uint16_t status_word;
    uint16_t warning_word1;
    uint16_t warning_word2;
    uint16_t fault_word1;
    uint16_t fault_word2;
    int16_t  motor_speed_rpm;
    int16_t  motor_torque_cNm;
    int16_t  motor_current_A_tenths;
    int16_t  motor_power_kW_tenths;
    int16_t  dc_voltage_V;
    int16_t  output_voltage_V;
    int16_t  heatsink_temp_C;
    int16_t  motor_temp_C;
    int16_t  output_freq_hz_tenths;
    uint32_t energy_kWh;
    uint32_t run_hours;
    uint32_t fan_hours;
    uint8_t  di_status[8];
    uint8_t  ro_status[4];
    int16_t  ai_value[4];
    int16_t  ao_value[2];
    uint8_t  drive_state;
    uint8_t  last_fault_code;
    uint8_t  data_ready;
} dd_internal_t;

static dd_internal_t dd;

void diagnostics_data_init(diagnostics_data_state_t *state)
{
    state->initialized = 1;
    dd.control_word = 0;
    dd.status_word = 0;
    dd.warning_word1 = 0;
    dd.warning_word2 = 0;
    dd.fault_word1 = 0;
    dd.fault_word2 = 0;
    dd.motor_speed_rpm = 0;
    dd.motor_torque_cNm = 0;
    dd.motor_current_A_tenths = 0;
    dd.motor_power_kW_tenths = 0;
    dd.dc_voltage_V = 0;
    dd.output_voltage_V = 0;
    dd.heatsink_temp_C = 0;
    dd.motor_temp_C = 0;
    dd.output_freq_hz_tenths = 0;
    dd.energy_kWh = 0;
    dd.run_hours = 0;
    dd.fan_hours = 0;
    dd.drive_state = 0;
    dd.last_fault_code = 0;
    dd.data_ready = 0;

    for (uint8_t i = 0; i < 8; i++) dd.di_status[i] = 0;
    for (uint8_t i = 0; i < 4; i++) dd.ro_status[i] = 0;
    for (uint8_t i = 0; i < 4; i++) dd.ai_value[i] = 0;
    for (uint8_t i = 0; i < 2; i++) dd.ao_value[i] = 0;
}

void diagnostics_data_update(diagnostics_data_state_t *state)
{
    if (!state->initialized) return;
    (void)state;
}

void diag_update(diagnostics_data_state_t *state)
{
    (void)state;

    dd.data_ready = 1;
}

uint16_t diag_get_control_word(void)       { return dd.control_word; }
uint16_t diag_get_status_word(void)        { return dd.status_word; }
uint16_t diag_get_warning_word1(void)      { return dd.warning_word1; }
uint16_t diag_get_warning_word2(void)      { return dd.warning_word2; }
uint16_t diag_get_fault_word1(void)        { return dd.fault_word1; }
uint16_t diag_get_fault_word2(void)        { return dd.fault_word2; }

void diag_set_control_word(uint16_t v)     { dd.control_word = v; }
void diag_set_status_word(uint16_t v)      { dd.status_word = v; }
void diag_set_warning_word1(uint16_t v)    { dd.warning_word1 = v; }
void diag_set_warning_word2(uint16_t v)    { dd.warning_word2 = v; }
void diag_set_fault_word1(uint16_t v)      { dd.fault_word1 = v; }
void diag_set_fault_word2(uint16_t v)      { dd.fault_word2 = v; }

void diag_set_speed(int16_t v)             { dd.motor_speed_rpm = v; }
void diag_set_torque(int16_t v)            { dd.motor_torque_cNm = v; }
void diag_set_current(int16_t v)           { dd.motor_current_A_tenths = v; }
void diag_set_power(int16_t v)             { dd.motor_power_kW_tenths = v; }
void diag_set_dc_voltage(int16_t v)        { dd.dc_voltage_V = v; }
void diag_set_output_voltage(int16_t v)    { dd.output_voltage_V = v; }
void diag_set_heatsink_temp(int16_t v)     { dd.heatsink_temp_C = v; }
void diag_set_motor_temp(int16_t v)        { dd.motor_temp_C = v; }
void diag_set_output_freq(int16_t v)       { dd.output_freq_hz_tenths = v; }
void diag_set_energy(uint32_t v)           { dd.energy_kWh = v; }
void diag_set_run_hours(uint32_t v)        { dd.run_hours = v; }
void diag_set_fan_hours(uint32_t v)        { dd.fan_hours = v; }

void diag_set_di_status(uint8_t idx, uint8_t v) { if (idx < 8) dd.di_status[idx] = v; }
void diag_set_ro_status(uint8_t idx, uint8_t v) { if (idx < 4) dd.ro_status[idx] = v; }
void diag_set_ai_value(uint8_t idx, int16_t v)  { if (idx < 4) dd.ai_value[idx] = v; }
void diag_set_ao_value(uint8_t idx, int16_t v)  { if (idx < 2) dd.ao_value[idx] = v; }
void diag_set_drive_state(uint8_t v)            { dd.drive_state = v; }
void diag_set_last_fault(uint8_t v)             { dd.last_fault_code = v; }

uint8_t diag_is_data_ready(void)           { return dd.data_ready; }

int16_t diag_get_speed(void)               { return dd.motor_speed_rpm; }
int16_t diag_get_torque(void)              { return dd.motor_torque_cNm; }
int16_t diag_get_current(void)             { return dd.motor_current_A_tenths; }
int16_t diag_get_power(void)               { return dd.motor_power_kW_tenths; }
int16_t diag_get_dc_voltage(void)          { return dd.dc_voltage_V; }
int16_t diag_get_output_voltage(void)      { return dd.output_voltage_V; }
int16_t diag_get_heatsink_temp(void)       { return dd.heatsink_temp_C; }
int16_t diag_get_motor_temp(void)          { return dd.motor_temp_C; }
int16_t diag_get_output_freq(void)         { return dd.output_freq_hz_tenths; }
uint32_t diag_get_energy(void)             { return dd.energy_kWh; }
uint32_t diag_get_run_hours(void)          { return dd.run_hours; }
uint32_t diag_get_fan_hours(void)          { return dd.fan_hours; }
uint8_t diag_get_di_status(uint8_t idx)    { return (idx < 8) ? dd.di_status[idx] : 0; }
uint8_t diag_get_ro_status(uint8_t idx)    { return (idx < 4) ? dd.ro_status[idx] : 0; }
int16_t diag_get_ai_value(uint8_t idx)     { return (idx < 4) ? dd.ai_value[idx] : 0; }
int16_t diag_get_ao_value(uint8_t idx)     { return (idx < 2) ? dd.ao_value[idx] : 0; }
uint8_t diag_get_drive_state(void)         { return dd.drive_state; }
uint8_t diag_get_last_fault(void)          { return dd.last_fault_code; }
