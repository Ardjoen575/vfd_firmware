#include "energy_saving_calc.h"

typedef struct {
    int32_t actual_energy_kWh_milli;
    int32_t baseline_energy_kWh_milli;
    int32_t saved_energy_kWh_milli;
    int32_t saved_cost_thousandths;
    int32_t saved_co2_kg_milli;
    uint32_t energy_per_hour_baseline;
    uint32_t energy_per_hour_actual;
    uint16_t cost_per_kWh_thousandths;
    uint16_t co2_per_kWh_milli;
    uint32_t tick_ms;
    uint32_t hour_accum_ms;
    uint8_t  baseline_configured;
    uint8_t  motor_running;
} esc_internal_t;

static esc_internal_t esc;

void energy_saving_calc_init(energy_saving_calc_state_t *state)
{
    state->initialized = 1;
    esc.actual_energy_kWh_milli = 0;
    esc.baseline_energy_kWh_milli = 0;
    esc.saved_energy_kWh_milli = 0;
    esc.saved_cost_thousandths = 0;
    esc.saved_co2_kg_milli = 0;
    esc.energy_per_hour_baseline = 15000;
    esc.energy_per_hour_actual = 8000;
    esc.cost_per_kWh_thousandths = 120;
    esc.co2_per_kWh_milli = 500;
    esc.tick_ms = 0;
    esc.hour_accum_ms = 0;
    esc.baseline_configured = 0;
    esc.motor_running = 0;
}

void energy_saving_calc_update(energy_saving_calc_state_t *state)
{
    if (!state->initialized) return;
    (void)state;
}

void energy_calc_update(energy_saving_calc_state_t *state)
{
    (void)state;

    if (!esc.motor_running) return;

    esc.tick_ms += 10;

    uint32_t inc_baseline = (uint32_t)(esc.energy_per_hour_baseline * (uint64_t)10 / 3600000);
    uint32_t inc_actual = (uint32_t)(esc.energy_per_hour_actual * (uint64_t)10 / 3600000);

    esc.baseline_energy_kWh_milli += (int32_t)inc_baseline;
    esc.actual_energy_kWh_milli += (int32_t)inc_actual;

    esc.hour_accum_ms += 10;
    if (esc.hour_accum_ms >= 3600000) {
        esc.hour_accum_ms = 0;
    }

    int32_t saved = esc.baseline_energy_kWh_milli - esc.actual_energy_kWh_milli;
    if (saved > 0) {
        esc.saved_energy_kWh_milli = saved;
        esc.saved_cost_thousandths = (int32_t)((int64_t)saved * esc.cost_per_kWh_thousandths / 1000);
        esc.saved_co2_kg_milli = (int32_t)((int64_t)saved * esc.co2_per_kWh_milli / 1000);
    }
}

void energy_saving_set_baseline_power(uint32_t power_kW_tenths)
{
    esc.energy_per_hour_baseline = power_kW_tenths * 100;
    esc.baseline_configured = 1;
}

void energy_saving_set_actual_power(uint32_t power_kW_tenths)
{
    esc.energy_per_hour_actual = power_kW_tenths * 100;
}

void energy_saving_set_motor_running(uint8_t running)
{
    esc.motor_running = running;
}

int32_t energy_saving_get_saved_energy_kWh_milli(void)
{
    return esc.saved_energy_kWh_milli;
}

int32_t energy_saving_get_saved_cost_thousandths(void)
{
    return esc.saved_cost_thousandths;
}

int32_t energy_saving_get_saved_co2_kg_milli(void)
{
    return esc.saved_co2_kg_milli;
}

int32_t energy_saving_get_baseline_energy_kWh_milli(void)
{
    return esc.baseline_energy_kWh_milli;
}

int32_t energy_saving_get_actual_energy_kWh_milli(void)
{
    return esc.actual_energy_kWh_milli;
}

void energy_saving_reset_counters(void)
{
    esc.actual_energy_kWh_milli = 0;
    esc.baseline_energy_kWh_milli = 0;
    esc.saved_energy_kWh_milli = 0;
    esc.saved_cost_thousandths = 0;
    esc.saved_co2_kg_milli = 0;
}
