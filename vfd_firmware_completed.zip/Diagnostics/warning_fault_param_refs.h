#ifndef DIAGNOSTICS_WARNING_FAULT_PARAM_REFS_H
#define DIAGNOSTICS_WARNING_FAULT_PARAM_REFS_H

/* Parameters that contain warning/fault information */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    uint16_t warning_ref_param;
    uint16_t fault_ref_param;
    uint16_t last_warning_code;
    uint16_t last_fault_code;
    uint32_t last_warning_timestamp;
    uint32_t last_fault_timestamp;
    uint32_t systick_ms;
} warning_fault_param_refs_state_t;

void warning_fault_param_refs_init(warning_fault_param_refs_state_t *state);
void warning_fault_param_refs_update(warning_fault_param_refs_state_t *state);
void warnfault_param_get(warning_fault_param_refs_state_t *state);

#endif /* DIAGNOSTICS_WARNING_FAULT_PARAM_REFS_H */
