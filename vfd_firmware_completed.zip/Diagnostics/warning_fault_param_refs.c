#include "warning_fault_param_refs.h"

#define WFPR_MAX_REFS  32

typedef struct {
    uint16_t warning_ref_param;
    uint16_t fault_ref_param;
    uint16_t last_warning_code;
    uint16_t last_fault_code;
    uint32_t last_warning_timestamp;
    uint32_t last_fault_timestamp;
    uint32_t systick_ms;
} wfpr_internal_t;

static wfpr_internal_t wfpr;

void warning_fault_param_refs_init(warning_fault_param_refs_state_t *state)
{
    state->initialized = 1;
    wfpr.warning_ref_param = 0;
    wfpr.fault_ref_param = 0;
    wfpr.last_warning_code = 0;
    wfpr.last_fault_code = 0;
    wfpr.last_warning_timestamp = 0;
    wfpr.last_fault_timestamp = 0;
    wfpr.systick_ms = 0;
}

void warning_fault_param_refs_update(warning_fault_param_refs_state_t *state)
{
    if (!state->initialized) return;
    wfpr.systick_ms++;
}

void warnfault_param_get(warning_fault_param_refs_state_t *state)
{
    (void)state;
}

void wfpr_set_warning_code(uint16_t code)
{
    wfpr.last_warning_code = code;
    wfpr.last_warning_timestamp = wfpr.systick_ms;
}

void wfpr_set_fault_code(uint16_t code)
{
    wfpr.last_fault_code = code;
    wfpr.last_fault_timestamp = wfpr.systick_ms;
}

uint16_t wfpr_get_warning_code(void)
{
    return wfpr.last_warning_code;
}

uint16_t wfpr_get_fault_code(void)
{
    return wfpr.last_fault_code;
}

uint32_t wfpr_get_warning_timestamp(void)
{
    return wfpr.last_warning_timestamp;
}

uint32_t wfpr_get_fault_timestamp(void)
{
    return wfpr.last_fault_timestamp;
}

void wfpr_set_warning_ref_param(uint16_t param)
{
    wfpr.warning_ref_param = param;
}

void wfpr_set_fault_ref_param(uint16_t param)
{
    wfpr.fault_ref_param = param;
}

uint16_t wfpr_get_warning_ref_param(void)
{
    return wfpr.warning_ref_param;
}

uint16_t wfpr_get_fault_ref_param(void)
{
    return wfpr.fault_ref_param;
}

void wfpr_clear_all(void)
{
    wfpr.last_warning_code = 0;
    wfpr.last_fault_code = 0;
    wfpr.last_warning_timestamp = 0;
    wfpr.last_fault_timestamp = 0;
}
