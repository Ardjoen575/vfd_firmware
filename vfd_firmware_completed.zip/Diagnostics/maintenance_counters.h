#ifndef DIAGNOSTICS_MAINTENANCE_COUNTERS_H
#define DIAGNOSTICS_MAINTENANCE_COUNTERS_H

/* Maintenance timers and counters */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    uint32_t fan_run_hours;
    uint32_t capacitor_hours;
    uint32_t contactor_cycles;
    uint32_t dc_charge_cycles;
    uint32_t heatsink_cleaning_days;
    uint8_t  fan_alarm_sent;
    uint8_t  cap_alarm_sent;
    uint8_t  contactor_alarm_sent;
    uint8_t  heatsink_alarm_sent;
    uint8_t  fan_running;
    uint8_t  contactor_closed;
    uint8_t  dc_charged;
    uint32_t tick_seconds;
    uint32_t last_fan_hours;
    uint32_t last_cap_hours;
} maintenance_counters_state_t;

void maintenance_counters_init(maintenance_counters_state_t *state);
void maintenance_counters_update(maintenance_counters_state_t *state);
void maint_counter_tick(maintenance_counters_state_t *state);

#endif /* DIAGNOSTICS_MAINTENANCE_COUNTERS_H */
