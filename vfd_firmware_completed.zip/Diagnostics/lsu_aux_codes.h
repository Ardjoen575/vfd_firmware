#ifndef DIAGNOSTICS_LSU_AUX_CODES_H
#define DIAGNOSTICS_LSU_AUX_CODES_H

/* Auxiliary codes for LSU warnings/faults */

#include <stdint.h>

#define LSU_MAX_CODES  64
#define LSU_MSG_LEN    32

typedef struct {
    uint16_t main_code;
    uint16_t aux_code;
    char     description[LSU_MSG_LEN];
} lsu_code_entry_t;

typedef struct {
    uint8_t initialized;
    lsu_code_entry_t entries[LSU_MAX_CODES];
    uint8_t          entry_count;
    uint16_t         last_main;
    uint16_t         last_aux;
    char             last_result[LSU_MSG_LEN];
} lsu_aux_codes_state_t;

void lsu_aux_codes_init(lsu_aux_codes_state_t *state);
void lsu_aux_codes_update(lsu_aux_codes_state_t *state);
void lsu_aux_code_lookup(lsu_aux_codes_state_t *state);

#endif /* DIAGNOSTICS_LSU_AUX_CODES_H */
