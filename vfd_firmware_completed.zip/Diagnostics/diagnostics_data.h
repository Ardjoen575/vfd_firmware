#ifndef DIAGNOSTICS_DIAGNOSTICS_DATA_H
#define DIAGNOSTICS_DIAGNOSTICS_DATA_H

/* Diagnostics data (grp 05) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    uint16_t control_word;
    uint16_t status_word;
    uint16_t warning_word1;
    uint16_t warning_word2;
    uint16_t fault_word1;
    uint16_t fault_word2;
    int16_t  motor_speed_rpm;
    int16_t  motor_torque_cNm;
    int16_t  motor_current_A_tenths;
    int16_t  motor_power_kW_tenths;
    int16_t  dc_voltage_V;
    int16_t  output_voltage_V;
    int16_t  heatsink_temp_C;
    int16_t  motor_temp_C;
    int16_t  output_freq_hz_tenths;
    uint32_t energy_kWh;
    uint32_t run_hours;
    uint32_t fan_hours;
    uint8_t  di_status[8];
    uint8_t  ro_status[4];
    int16_t  ai_value[4];
    int16_t  ao_value[2];
    uint8_t  drive_state;
    uint8_t  last_fault_code;
    uint8_t  data_ready;
} diagnostics_data_state_t;

void diagnostics_data_init(diagnostics_data_state_t *state);
void diagnostics_data_update(diagnostics_data_state_t *state);
void diag_update(diagnostics_data_state_t *state);

#endif /* DIAGNOSTICS_DIAGNOSTICS_DATA_H */
