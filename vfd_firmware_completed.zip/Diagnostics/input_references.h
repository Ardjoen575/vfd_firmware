#ifndef DIAGNOSTICS_INPUT_REFERENCES_H
#define DIAGNOSTICS_INPUT_REFERENCES_H

/* Input references (grp 03) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    int16_t ai1_scaled;
    int16_t ai2_scaled;
    int16_t ai3_scaled;
    int16_t fieldbus_ref1;
    int16_t fieldbus_ref2;
    int16_t panel_ref;
    int16_t motor_pot_ref;
    int16_t pid_setpoint;
    int16_t pid_feedback;
    int16_t selected_ref;
    uint8_t ref_source;
    uint8_t ref_ramped;
} input_references_state_t;

void input_references_init(input_references_state_t *state);
void input_references_update(input_references_state_t *state);
void inputref_update(input_references_state_t *state);

#endif /* DIAGNOSTICS_INPUT_REFERENCES_H */
