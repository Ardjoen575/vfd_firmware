#ifndef DIAGNOSTICS_EDITABLE_MESSAGES_H
#define DIAGNOSTICS_EDITABLE_MESSAGES_H

/* Editable message support */

#include <stdint.h>

#define EM_MAX_MESSAGES  4
#define EM_MSG_LEN       32

typedef struct {
    char     message[EM_MSG_LEN];
    uint8_t  modified;
    uint8_t  active;
} em_entry_t;

typedef struct {
    uint8_t initialized;
    em_entry_t entries[EM_MAX_MESSAGES];
    uint8_t    edit_index;
    uint8_t    dirty;
} editable_messages_state_t;

void editable_messages_init(editable_messages_state_t *state);
void editable_messages_update(editable_messages_state_t *state);
void editable_msg_set(editable_messages_state_t *state);

#endif /* DIAGNOSTICS_EDITABLE_MESSAGES_H */
