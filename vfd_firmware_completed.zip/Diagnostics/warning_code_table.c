#include "warning_code_table.h"
#include <string.h>

#define WCT_MAX_CODES  128
#define WCT_MSG_LEN    32

typedef struct {
    uint16_t code;
    char     message[WCT_MSG_LEN];
} wct_entry_t;

typedef struct {
    wct_entry_t entries[WCT_MAX_CODES];
    uint8_t     entry_count;
    uint16_t    last_lookup_code;
    char        last_lookup_result[WCT_MSG_LEN];
} wct_internal_t;

static wct_internal_t wct;

void warning_code_table_init(warning_code_table_state_t *state)
{
    state->initialized = 1;
    memset(&wct, 0, sizeof(wct));

    static const char *default_warnings[] = {
        "No Warning",
        "Motor Overload",
        "Motor Thermal",
        "Underload",
        "Current Limit",
        "Torque Limit",
        "Speed Limit",
        "DC Overvoltage Warn",
        "DC Undervoltage Warn",
        "Overtemperature Warn",
        "Fan Life",
        "Capacitor Life",
        "Motor Temp Warn",
        "AI Lost",
        "Fieldbus Lost",
        "Parameter Conflict",
        "Autophasing",
        "Power Fail Save",
        "Backup/Restore",
        "Earth Leakage",
        "PTC/PT100",
        "Safe Torque Off",
        "Braking",
        "Mechanical Brake",
    };

    uint8_t count = sizeof(default_warnings) / sizeof(default_warnings[0]);
    for (uint8_t i = 0; i < count && i < WCT_MAX_CODES; i++) {
        wct.entries[i].code = (uint16_t)(i == 0 ? 0 : (0x2000 + i));
        strncpy(wct.entries[i].message, default_warnings[i], WCT_MSG_LEN - 1);
    }
    wct.entry_count = count;
}

void warning_code_table_update(warning_code_table_state_t *state)
{
    if (!state->initialized) return;
    (void)state;
}

void warning_code_lookup(warning_code_table_state_t *state)
{
    (void)state;
}

const char *warning_code_string(uint16_t code)
{
    wct.last_lookup_code = code;

    for (uint8_t i = 0; i < wct.entry_count; i++) {
        if (wct.entries[i].code == code) {
            strncpy(wct.last_lookup_result, wct.entries[i].message, WCT_MSG_LEN - 1);
            wct.last_lookup_result[WCT_MSG_LEN - 1] = '\0';
            return wct.last_lookup_result;
        }
    }

    strncpy(wct.last_lookup_result, "Unknown Warning", WCT_MSG_LEN - 1);
    wct.last_lookup_result[WCT_MSG_LEN - 1] = '\0';
    return wct.last_lookup_result;
}

uint8_t warning_code_exists(uint16_t code)
{
    for (uint8_t i = 0; i < wct.entry_count; i++) {
        if (wct.entries[i].code == code) {
            return 1;
        }
    }
    return 0;
}

void warning_code_add_entry(uint16_t code, const char *message)
{
    if (wct.entry_count < WCT_MAX_CODES) {
        wct.entries[wct.entry_count].code = code;
        strncpy(wct.entries[wct.entry_count].message, message, WCT_MSG_LEN - 1);
        wct.entries[wct.entry_count].message[WCT_MSG_LEN - 1] = '\0';
        wct.entry_count++;
    }
}
