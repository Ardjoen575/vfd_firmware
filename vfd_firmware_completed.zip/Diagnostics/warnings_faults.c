#include "warnings_faults.h"

#define WF_MAX_SOURCES 32

typedef struct {
    uint16_t warning_word_1;
    uint16_t warning_word_2;
    uint16_t fault_word_1;
    uint16_t fault_word_2;
    uint16_t active_warnings;
    uint16_t active_faults;
    uint16_t warning_sources[WF_MAX_SOURCES];
    uint16_t fault_sources[WF_MAX_SOURCES];
    uint8_t  warning_count;
    uint8_t  fault_count;
    uint8_t  warning_active_any;
    uint8_t  fault_active_any;
} wf_internal_t;

static wf_internal_t wf;

void warnings_faults_init(warnings_faults_state_t *state)
{
    state->initialized = 1;
    wf.warning_word_1 = 0;
    wf.warning_word_2 = 0;
    wf.fault_word_1 = 0;
    wf.fault_word_2 = 0;
    wf.active_warnings = 0;
    wf.active_faults = 0;
    wf.warning_count = 0;
    wf.fault_count = 0;
    wf.warning_active_any = 0;
    wf.fault_active_any = 0;

    for (uint8_t i = 0; i < WF_MAX_SOURCES; i++) {
        wf.warning_sources[i] = 0;
        wf.fault_sources[i] = 0;
    }
}

void warnings_faults_update(warnings_faults_state_t *state)
{
    if (!state->initialized) return;
    (void)state;
}

void warnfault_update(warnings_faults_state_t *state)
{
    (void)state;

    wf.warning_word_1 = 0;
    wf.warning_word_2 = 0;
    wf.fault_word_1 = 0;
    wf.fault_word_2 = 0;
    wf.warning_count = 0;
    wf.fault_count = 0;

    for (uint8_t i = 0; i < 16; i++) {
        uint16_t bit = (uint16_t)(1 << i);
        if (wf.warning_sources[i] != 0) {
            wf.warning_word_1 |= bit;
            wf.warning_count++;
        }
        if (wf.fault_sources[i] != 0) {
            wf.fault_word_1 |= bit;
            wf.fault_count++;
        }
    }

    for (uint8_t i = 16; i < 32; i++) {
        uint16_t bit = (uint16_t)(1 << (i - 16));
        if (wf.warning_sources[i] != 0) {
            wf.warning_word_2 |= bit;
            wf.warning_count++;
        }
        if (wf.fault_sources[i] != 0) {
            wf.fault_word_2 |= bit;
            wf.fault_count++;
        }
    }

    wf.warning_active_any = (wf.warning_word_1 || wf.warning_word_2) ? 1 : 0;
    wf.fault_active_any = (wf.fault_word_1 || wf.fault_word_2) ? 1 : 0;

    wf.active_warnings = wf.warning_word_1 | wf.warning_word_2;
    wf.active_faults = wf.fault_word_1 | wf.fault_word_2;
}

void warnfault_set_warning_source(uint8_t index, uint16_t code)
{
    if (index < WF_MAX_SOURCES) {
        wf.warning_sources[index] = code;
    }
}

void warnfault_set_fault_source(uint8_t index, uint16_t code)
{
    if (index < WF_MAX_SOURCES) {
        wf.fault_sources[index] = code;
    }
}

void warnfault_clear_warning(uint8_t index)
{
    if (index < WF_MAX_SOURCES) {
        wf.warning_sources[index] = 0;
    }
}

void warnfault_clear_fault(uint8_t index)
{
    if (index < WF_MAX_SOURCES) {
        wf.fault_sources[index] = 0;
    }
}

uint16_t warnfault_get_warning_word1(void)  { return wf.warning_word_1; }
uint16_t warnfault_get_warning_word2(void)  { return wf.warning_word_2; }
uint16_t warnfault_get_fault_word1(void)    { return wf.fault_word_1; }
uint16_t warnfault_get_fault_word2(void)    { return wf.fault_word_2; }
uint8_t  warnfault_any_warning(void)         { return wf.warning_active_any; }
uint8_t  warnfault_any_fault(void)           { return wf.fault_active_any; }
uint8_t  warnfault_get_warning_count(void)   { return wf.warning_count; }
uint8_t  warnfault_get_fault_count(void)     { return wf.fault_count; }

void warnfault_clear_all_faults(void)
{
    for (uint8_t i = 0; i < WF_MAX_SOURCES; i++) {
        wf.fault_sources[i] = 0;
    }
    wf.fault_word_1 = 0;
    wf.fault_word_2 = 0;
    wf.fault_active_any = 0;
    wf.fault_count = 0;
}
