#include "maintenance_counters.h"

#define MC_FAN_LIFE_HOURS       40000
#define MC_CAP_LIFE_HOURS       90000
#define MC_CONTACTOR_CYCLES     100000
#define MC_BATTERY_LIFE_MONTHS  24

typedef struct {
    uint32_t fan_run_hours;
    uint32_t capacitor_hours;
    uint32_t contactor_cycles;
    uint32_t dc_charge_cycles;
    uint32_t heatsink_cleaning_days;
    uint8_t  fan_alarm_sent;
    uint8_t  cap_alarm_sent;
    uint8_t  contactor_alarm_sent;
    uint8_t  heatsink_alarm_sent;
    uint8_t  fan_running;
    uint8_t  contactor_closed;
    uint8_t  dc_charged;
    uint32_t tick_seconds;
    uint32_t last_fan_hours;
    uint32_t last_cap_hours;
} mc_internal_t;

static mc_internal_t mc;

void maintenance_counters_init(maintenance_counters_state_t *state)
{
    state->initialized = 1;
    mc.fan_run_hours = 0;
    mc.capacitor_hours = 0;
    mc.contactor_cycles = 0;
    mc.dc_charge_cycles = 0;
    mc.heatsink_cleaning_days = 0;
    mc.fan_alarm_sent = 0;
    mc.cap_alarm_sent = 0;
    mc.contactor_alarm_sent = 0;
    mc.heatsink_alarm_sent = 0;
    mc.fan_running = 0;
    mc.contactor_closed = 0;
    mc.dc_charged = 0;
    mc.tick_seconds = 0;
    mc.last_fan_hours = 0;
    mc.last_cap_hours = 0;
}

void maintenance_counters_update(maintenance_counters_state_t *state)
{
    if (!state->initialized) return;
    (void)state;
}

static void mc_check_alarms(void)
{
    if (mc.fan_run_hours >= MC_FAN_LIFE_HOURS && !mc.fan_alarm_sent) {
        mc.fan_alarm_sent = 1;
    }
    if (mc.capacitor_hours >= MC_CAP_LIFE_HOURS && !mc.cap_alarm_sent) {
        mc.cap_alarm_sent = 1;
    }
    if (mc.contactor_cycles >= MC_CONTACTOR_CYCLES && !mc.contactor_alarm_sent) {
        mc.contactor_alarm_sent = 1;
    }
}

void maint_counter_tick(maintenance_counters_state_t *state)
{
    (void)state;

    mc.tick_seconds++;

    if (mc.tick_seconds >= 60) {
        mc.tick_seconds = 0;

        if (mc.fan_running) {
            mc.fan_run_hours++;
        }
        mc.capacitor_hours++;
        mc.heatsink_cleaning_days++;

        if (mc.heatsink_cleaning_days % 1440 == 0) {
        }
    }

    mc_check_alarms();
}

void maint_counter_fan_set_running(uint8_t running)
{
    mc.fan_running = running;
}

void maint_counter_contactor_toggle(void)
{
    mc.contactor_cycles++;
}

void maint_counter_dc_charge_toggle(void)
{
    mc.dc_charge_cycles++;
}

uint32_t maint_counter_get_fan_hours(void)
{
    return mc.fan_run_hours;
}

uint32_t maint_counter_get_capacitor_hours(void)
{
    return mc.capacitor_hours;
}

uint32_t maint_counter_get_contactor_cycles(void)
{
    return mc.contactor_cycles;
}

uint8_t maint_counter_get_fan_alarm(void)
{
    return mc.fan_alarm_sent;
}

uint8_t maint_counter_get_cap_alarm(void)
{
    return mc.cap_alarm_sent;
}

uint8_t maint_counter_get_contactor_alarm(void)
{
    return mc.contactor_alarm_sent;
}

void maint_counter_reset_fan(void)
{
    mc.fan_run_hours = 0;
    mc.fan_alarm_sent = 0;
}

void maint_counter_reset_capacitor(void)
{
    mc.capacitor_hours = 0;
    mc.cap_alarm_sent = 0;
}
