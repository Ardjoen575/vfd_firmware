#include "editable_messages.h"
#include <string.h>

#define EM_MAX_MESSAGES  4
#define EM_MSG_LEN       32

typedef struct {
    char     message[EM_MSG_LEN];
    uint8_t  modified;
    uint8_t  active;
} em_entry_t;

typedef struct {
    em_entry_t entries[EM_MAX_MESSAGES];
    uint8_t    edit_index;
    uint8_t    dirty;
} em_internal_t;

static em_internal_t em;

void editable_messages_init(editable_messages_state_t *state)
{
    state->initialized = 1;
    memset(&em, 0, sizeof(em));

    strncpy(em.entries[0].message, "Maintenance Due", EM_MSG_LEN - 1);
    strncpy(em.entries[1].message, "Check Bearings", EM_MSG_LEN - 1);
    strncpy(em.entries[2].message, "Filter Change", EM_MSG_LEN - 1);
    strncpy(em.entries[3].message, "User Msg 4", EM_MSG_LEN - 1);

    for (uint8_t i = 0; i < EM_MAX_MESSAGES; i++) {
        em.entries[i].modified = 0;
        em.entries[i].active = 1;
    }

    em.edit_index = 0;
    em.dirty = 0;
}

void editable_messages_update(editable_messages_state_t *state)
{
    if (!state->initialized) return;
    (void)state;
}

void editable_msg_set(editable_messages_state_t *state)
{
    (void)state;
}

uint8_t editable_msg_set_string(uint8_t index, const char *msg)
{
    if (index >= EM_MAX_MESSAGES) return 0;
    strncpy(em.entries[index].message, msg, EM_MSG_LEN - 1);
    em.entries[index].message[EM_MSG_LEN - 1] = '\0';
    em.entries[index].modified = 1;
    em.dirty = 1;
    return 1;
}

const char *editable_msg_get_string(uint8_t index)
{
    if (index >= EM_MAX_MESSAGES) return NULL;
    return em.entries[index].message;
}

uint8_t editable_msg_activate(uint8_t index)
{
    if (index >= EM_MAX_MESSAGES) return 0;
    em.entries[index].active = 1;
    em.dirty = 1;
    return 1;
}

uint8_t editable_msg_deactivate(uint8_t index)
{
    if (index >= EM_MAX_MESSAGES) return 0;
    em.entries[index].active = 0;
    em.dirty = 1;
    return 1;
}

uint8_t editable_msg_is_active(uint8_t index)
{
    if (index >= EM_MAX_MESSAGES) return 0;
    return em.entries[index].active;
}

uint8_t editable_msg_is_modified(uint8_t index)
{
    if (index >= EM_MAX_MESSAGES) return 0;
    return em.entries[index].modified;
}

void editable_msg_clear_modified(uint8_t index)
{
    if (index < EM_MAX_MESSAGES) {
        em.entries[index].modified = 0;
    }
}

uint8_t editable_msg_get_count(void)
{
    return EM_MAX_MESSAGES;
}

void editable_msg_restore_defaults(void)
{
    strncpy(em.entries[0].message, "Maintenance Due", EM_MSG_LEN - 1);
    strncpy(em.entries[1].message, "Check Bearings", EM_MSG_LEN - 1);
    strncpy(em.entries[2].message, "Filter Change", EM_MSG_LEN - 1);
    strncpy(em.entries[3].message, "User Msg 4", EM_MSG_LEN - 1);

    for (uint8_t i = 0; i < EM_MAX_MESSAGES; i++) {
        em.entries[i].modified = 1;
        em.entries[i].active = 1;
    }
    em.dirty = 1;
}

uint8_t editable_msg_is_dirty(void)
{
    return em.dirty;
}

void editable_msg_clear_dirty(void)
{
    em.dirty = 0;
}
