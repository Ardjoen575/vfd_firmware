#ifndef DIAGNOSTICS_EVENT_LOGS_H
#define DIAGNOSTICS_EVENT_LOGS_H

/* Event logs (faults/warnings/pure events) */

#include <stdint.h>

#define EL_BUFFER_SIZE  64

typedef struct {
    uint32_t timestamp;
    uint16_t event_code;
    uint16_t event_data;
    uint32_t aux_data;
} el_entry_t;

typedef struct {
    uint8_t initialized;
    el_entry_t buffer[EL_BUFFER_SIZE];
    uint8_t    write_idx;
    uint8_t    entry_count;
    uint32_t   total_count;
    uint32_t   systick_ms;
} event_logs_state_t;

void event_logs_init(event_logs_state_t *state);
void event_logs_update(event_logs_state_t *state);
void event_log_append(event_logs_state_t *state);

#endif /* DIAGNOSTICS_EVENT_LOGS_H */
