#ifndef DIAGNOSTICS_FAULT_CODE_TABLE_H
#define DIAGNOSTICS_FAULT_CODE_TABLE_H

/* Fault message code table */

#include <stdint.h>

#define FCT_MAX_CODES  128
#define FCT_MSG_LEN    32

typedef struct {
    uint16_t code;
    char     message[FCT_MSG_LEN];
} fct_entry_t;

typedef struct {
    uint8_t initialized;
    fct_entry_t entries[FCT_MAX_CODES];
    uint8_t     entry_count;
    uint16_t    last_lookup_code;
    char        last_lookup_result[FCT_MSG_LEN];
} fault_code_table_state_t;

void fault_code_table_init(fault_code_table_state_t *state);
void fault_code_table_update(fault_code_table_state_t *state);
void fault_code_lookup(fault_code_table_state_t *state);

#endif /* DIAGNOSTICS_FAULT_CODE_TABLE_H */
