#ifndef DIAGNOSTICS_WARNING_CODE_TABLE_H
#define DIAGNOSTICS_WARNING_CODE_TABLE_H

/* Warning message code table */

#include <stdint.h>

#define WCT_MAX_CODES  128
#define WCT_MSG_LEN    32

typedef struct {
    uint16_t code;
    char     message[WCT_MSG_LEN];
} wct_entry_t;

typedef struct {
    uint8_t initialized;
    wct_entry_t entries[WCT_MAX_CODES];
    uint8_t     entry_count;
    uint16_t    last_lookup_code;
    char        last_lookup_result[WCT_MSG_LEN];
} warning_code_table_state_t;

void warning_code_table_init(warning_code_table_state_t *state);
void warning_code_table_update(warning_code_table_state_t *state);
void warning_code_lookup(warning_code_table_state_t *state);

#endif /* DIAGNOSTICS_WARNING_CODE_TABLE_H */
