#ifndef DIAGNOSTICS_ACTUAL_VALUES_H
#define DIAGNOSTICS_ACTUAL_VALUES_H

/* Actual values group (grp 01) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    int16_t motor_speed_rpm;
    int16_t motor_speed_pct;
    int16_t motor_torque_cNm;
    int16_t motor_torque_pct;
    int16_t motor_current_A_tenths;
    int16_t motor_current_pct;
    int16_t motor_power_kW_tenths;
    int16_t motor_power_pct;
    int16_t motor_voltage_V;
    int16_t dc_bus_voltage_V;
    int16_t heatsink_temp_C;
    int16_t igbt_temp_C;
    int16_t motor_temp_C;
    int16_t output_freq_hz_tenths;
    int32_t energy_kWh_thousandths;
    int16_t power_factor_tenths;
    int16_t process_value1;
    int16_t process_value2;
} actual_values_state_t;

void actual_values_init(actual_values_state_t *state);
void actual_values_update(actual_values_state_t *state);
void actval_update_all(actual_values_state_t *state);

#endif /* DIAGNOSTICS_ACTUAL_VALUES_H */
