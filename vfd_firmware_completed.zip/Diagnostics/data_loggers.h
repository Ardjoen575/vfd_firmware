#ifndef DIAGNOSTICS_DATA_LOGGERS_H
#define DIAGNOSTICS_DATA_LOGGERS_H

/* Other data loggers */

#include <stdint.h>

#define DL_MAX_SIGNALS     8
#define DL_BUFFER_DEPTH    256

typedef struct {
    uint8_t initialized;
    uint16_t buffer[DL_MAX_SIGNALS][DL_BUFFER_DEPTH];
    uint16_t write_idx;
    uint16_t sample_count;
    uint16_t interval_ms;
    uint32_t interval_timer;
    uint8_t  enabled;
    uint8_t  trigger_signal;
    uint8_t  trigger_limit;
    uint8_t  trigger_edge;
    uint8_t  trigger_fired;
    uint8_t  signal_count;
    uint8_t  signal_select[DL_MAX_SIGNALS];
} data_loggers_state_t;

void data_loggers_init(data_loggers_state_t *state);
void data_loggers_update(data_loggers_state_t *state);
void data_logger_capture(data_loggers_state_t *state);

#endif /* DIAGNOSTICS_DATA_LOGGERS_H */
