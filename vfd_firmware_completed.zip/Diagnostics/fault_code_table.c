#include "fault_code_table.h"
#include <string.h>

#define FCT_MAX_CODES  128
#define FCT_MSG_LEN    32

typedef struct {
    uint16_t code;
    char     message[FCT_MSG_LEN];
} fct_entry_t;

typedef struct {
    fct_entry_t entries[FCT_MAX_CODES];
    uint8_t     entry_count;
    uint16_t    last_lookup_code;
    char        last_lookup_result[FCT_MSG_LEN];
} fct_internal_t;

static fct_internal_t fct;

void fault_code_table_init(fault_code_table_state_t *state)
{
    state->initialized = 1;
    memset(&fct, 0, sizeof(fct));

    static const char *default_faults[] = {
        "No Fault",
        "Overcurrent",
        "DC Overvoltage",
        "DC Undervoltage",
        "Short Circuit",
        "Motor Overload",
        "Motor Thermal",
        "Earth Fault",
        "Phase Loss",
        "Com Loss",
        "Encoder Error",
        "Overtemperature",
        "STO Active",
        "Emergency Stop",
        "User Load Curve",
        "Cable Thermal",
        "Hardware Fault",
        "Internal SW Error",
        "Supply Phase Loss",
        "Charging Fault",
        "AI Supervision",
        "ID Run Failed",
        "Configuration Error",
        "Overspeed",
    };

    uint8_t count = sizeof(default_faults) / sizeof(default_faults[0]);
    for (uint8_t i = 0; i < count && i < FCT_MAX_CODES; i++) {
        fct.entries[i].code = (uint16_t)(i == 0 ? 0 : (0x1000 + i));
        strncpy(fct.entries[i].message, default_faults[i], FCT_MSG_LEN - 1);
    }
    fct.entry_count = count;
}

void fault_code_table_update(fault_code_table_state_t *state)
{
    if (!state->initialized) return;
    (void)state;
}

void fault_code_lookup(fault_code_table_state_t *state)
{
    (void)state;
}

const char *fault_code_string(uint16_t code)
{
    fct.last_lookup_code = code;

    for (uint8_t i = 0; i < fct.entry_count; i++) {
        if (fct.entries[i].code == code) {
            strncpy(fct.last_lookup_result, fct.entries[i].message, FCT_MSG_LEN - 1);
            fct.last_lookup_result[FCT_MSG_LEN - 1] = '\0';
            return fct.last_lookup_result;
        }
    }

    strncpy(fct.last_lookup_result, "Unknown Fault", FCT_MSG_LEN - 1);
    fct.last_lookup_result[FCT_MSG_LEN - 1] = '\0';
    return fct.last_lookup_result;
}

uint8_t fault_code_exists(uint16_t code)
{
    for (uint8_t i = 0; i < fct.entry_count; i++) {
        if (fct.entries[i].code == code) {
            return 1;
        }
    }
    return 0;
}

void fault_code_add_entry(uint16_t code, const char *message)
{
    if (fct.entry_count < FCT_MAX_CODES) {
        fct.entries[fct.entry_count].code = code;
        strncpy(fct.entries[fct.entry_count].message, message, FCT_MSG_LEN - 1);
        fct.entries[fct.entry_count].message[FCT_MSG_LEN - 1] = '\0';
        fct.entry_count++;
    }
}
