#include "lsu_aux_codes.h"
#include <string.h>

#define LSU_MAX_CODES  64
#define LSU_MSG_LEN    32

typedef struct {
    uint16_t main_code;
    uint16_t aux_code;
    char     description[LSU_MSG_LEN];
} lsu_code_entry_t;

typedef struct {
    lsu_code_entry_t entries[LSU_MAX_CODES];
    uint8_t          entry_count;
    uint16_t         last_main;
    uint16_t         last_aux;
    char             last_result[LSU_MSG_LEN];
} lsu_internal_t;

static lsu_internal_t lsu;

void lsu_aux_codes_init(lsu_aux_codes_state_t *state)
{
    state->initialized = 1;
    memset(&lsu, 0, sizeof(lsu));

    static const struct { uint16_t aux; const char *msg; } aux_codes[] = {
        { 0x01, "LSU Overtemperature" },
        { 0x02, "LSU Overcurrent" },
        { 0x03, "LSU Charging Fault" },
        { 0x04, "LSU Supply Phase Loss" },
        { 0x05, "LSU DC Link Ripple" },
        { 0x06, "LSU Ground Fault" },
        { 0x07, "LSU Control Fault" },
        { 0x08, "LSU Thermal Model" },
        { 0x09, "LSU IGBT Fault" },
        { 0x0A, "LSU Comm Loss" },
        { 0x0B, "LSU Voltage Imbalance" },
        { 0x0C, "LSU Frequency Error" },
        { 0x0D, "LSU Precharge Fault" },
        { 0x0E, "LSU Fan Fault" },
        { 0x0F, "LSU EEPROM Fault" },
        { 0x10, "LSU DC Overvoltage" },
        { 0x11, "LSU DC Undervoltage" },
        { 0x12, "LSU Sync Error" },
        { 0x13, "LSU HW Config Mismatch" },
        { 0x14, "LSU Internal SW Error" },
    };

    uint8_t count = sizeof(aux_codes) / sizeof(aux_codes[0]);
    for (uint8_t i = 0; i < count && i < LSU_MAX_CODES; i++) {
        lsu.entries[i].main_code = 0x3100;
        lsu.entries[i].aux_code = aux_codes[i].aux;
        strncpy(lsu.entries[i].description, aux_codes[i].msg, LSU_MSG_LEN - 1);
    }
    lsu.entry_count = count;
}

void lsu_aux_codes_update(lsu_aux_codes_state_t *state)
{
    if (!state->initialized) return;
    (void)state;
}

void lsu_aux_code_lookup(lsu_aux_codes_state_t *state)
{
    (void)state;
}

const char *lsu_aux_code_string(uint16_t main_code, uint16_t aux_code)
{
    lsu.last_main = main_code;
    lsu.last_aux = aux_code;

    for (uint8_t i = 0; i < lsu.entry_count; i++) {
        if (lsu.entries[i].main_code == main_code && lsu.entries[i].aux_code == aux_code) {
            strncpy(lsu.last_result, lsu.entries[i].description, LSU_MSG_LEN - 1);
            lsu.last_result[LSU_MSG_LEN - 1] = '\0';
            return lsu.last_result;
        }
    }

    if (aux_code == 0) {
        strncpy(lsu.last_result, "No Aux Code", LSU_MSG_LEN - 1);
    } else {
        strncpy(lsu.last_result, "Unknown LSU Aux", LSU_MSG_LEN - 1);
    }
    lsu.last_result[LSU_MSG_LEN - 1] = '\0';
    return lsu.last_result;
}

const char *lsu_aux_code_string_short(uint16_t aux_code)
{
    return lsu_aux_code_string(0x3100, aux_code);
}

uint8_t lsu_aux_code_exists(uint16_t main_code, uint16_t aux_code)
{
    for (uint8_t i = 0; i < lsu.entry_count; i++) {
        if (lsu.entries[i].main_code == main_code && lsu.entries[i].aux_code == aux_code) {
            return 1;
        }
    }
    return 0;
}

void lsu_aux_code_add(uint16_t main_code, uint16_t aux_code, const char *description)
{
    if (lsu.entry_count < LSU_MAX_CODES) {
        lsu.entries[lsu.entry_count].main_code = main_code;
        lsu.entries[lsu.entry_count].aux_code = aux_code;
        strncpy(lsu.entries[lsu.entry_count].description, description, LSU_MSG_LEN - 1);
        lsu.entries[lsu.entry_count].description[LSU_MSG_LEN - 1] = '\0';
        lsu.entry_count++;
    }
}
