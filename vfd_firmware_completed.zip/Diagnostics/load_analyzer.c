#include "load_analyzer.h"

#define LA_AMPLITUDE_LOG_DEPTH 10

typedef struct {
    uint32_t timestamp;
    int16_t  current;
    int16_t  power;
} la_log_entry_t;

typedef struct {
    la_log_entry_t amplitude_log[LA_AMPLITUDE_LOG_DEPTH];
    uint8_t  log_idx;
    int16_t  peak_current_A;
    int16_t  peak_power_kW;
    int16_t  min_current_A;
    int16_t  avg_current_A;
    int16_t  avg_power_kW;
    uint32_t sample_count;
    uint32_t current_sum;
    uint32_t power_sum;
    uint8_t  enabled;
    uint32_t interval_ms;
    uint32_t interval_timer;
    uint32_t sample_window_ms;
    uint32_t window_timer;
} la_internal_t;

static la_internal_t la;

void load_analyzer_init(load_analyzer_state_t *state)
{
    state->initialized = 1;
    la.peak_current_A = 0;
    la.peak_power_kW = 0;
    la.min_current_A = 32767;
    la.avg_current_A = 0;
    la.avg_power_kW = 0;
    la.sample_count = 0;
    la.current_sum = 0;
    la.power_sum = 0;
    la.enabled = 1;
    la.interval_ms = 100;
    la.interval_timer = 0;
    la.sample_window_ms = 60000;
    la.window_timer = 0;
    la.log_idx = 0;
}

void load_analyzer_update(load_analyzer_state_t *state)
{
    if (!state->initialized) return;
    la.interval_timer++;
    la.window_timer++;
}

void load_analyzer_sample(load_analyzer_state_t *state)
{
    (void)state;

    if (!la.enabled) return;

    if (la.interval_timer >= la.interval_ms) {
        la.interval_timer = 0;

        int16_t curr = 0;
        int16_t powr = 0;

        if (curr > la.peak_current_A) {
            la.peak_current_A = curr;
        }
        if (curr < la.min_current_A && curr > 0) {
            la.min_current_A = curr;
        }
        if (powr > la.peak_power_kW) {
            la.peak_power_kW = powr;
        }

        la.current_sum += (uint32_t)curr;
        la.power_sum += (uint32_t)powr;
        la.sample_count++;

        if (la.window_timer >= la.sample_window_ms) {
            la.window_timer = 0;

            la.amplitude_log[la.log_idx].timestamp = la.window_timer;
            la.amplitude_log[la.log_idx].current = la.peak_current_A;
            la.amplitude_log[la.log_idx].power = la.peak_power_kW;
            la.log_idx = (uint8_t)((la.log_idx + 1) % LA_AMPLITUDE_LOG_DEPTH);

            if (la.sample_count > 0) {
                la.avg_current_A = (int16_t)(la.current_sum / la.sample_count);
                la.avg_power_kW = (int16_t)(la.power_sum / la.sample_count);
            }

            la.peak_current_A = 0;
            la.peak_power_kW = 0;
            la.min_current_A = 32767;
            la.sample_count = 0;
            la.current_sum = 0;
            la.power_sum = 0;
        }
    }
}

int16_t load_analyzer_get_peak_current(void)   { return la.peak_current_A; }
int16_t load_analyzer_get_peak_power(void)     { return la.peak_power_kW; }
int16_t load_analyzer_get_avg_current(void)    { return la.avg_current_A; }
int16_t load_analyzer_get_avg_power(void)      { return la.avg_power_kW; }
int16_t load_analyzer_get_min_current(void)    { return la.min_current_A; }

void load_analyzer_get_log_entry(uint8_t index, uint32_t *ts, int16_t *current, int16_t *power)
{
    if (index < LA_AMPLITUDE_LOG_DEPTH) {
        *ts = la.amplitude_log[index].timestamp;
        *current = la.amplitude_log[index].current;
        *power = la.amplitude_log[index].power;
    }
}
