#include "input_references.h"

typedef struct {
    int16_t ai1_scaled;
    int16_t ai2_scaled;
    int16_t ai3_scaled;
    int16_t fieldbus_ref1;
    int16_t fieldbus_ref2;
    int16_t panel_ref;
    int16_t motor_pot_ref;
    int16_t pid_setpoint;
    int16_t pid_feedback;
    int16_t selected_ref;
    uint8_t ref_source;
    uint8_t ref_ramped;
} ir_internal_t;

static ir_internal_t ir;

void input_references_init(input_references_state_t *state)
{
    state->initialized = 1;
    ir.ai1_scaled = 0;
    ir.ai2_scaled = 0;
    ir.ai3_scaled = 0;
    ir.fieldbus_ref1 = 0;
    ir.fieldbus_ref2 = 0;
    ir.panel_ref = 0;
    ir.motor_pot_ref = 0;
    ir.pid_setpoint = 0;
    ir.pid_feedback = 0;
    ir.selected_ref = 0;
    ir.ref_source = 0;
    ir.ref_ramped = 0;
}

void input_references_update(input_references_state_t *state)
{
    if (!state->initialized) return;
    (void)state;
}

static int16_t ir_scale_ai(int16_t raw, int16_t eng_min, int16_t eng_max)
{
    if (raw < 4000) return eng_min;
    if (raw > 20000) return eng_max;
    return (int16_t)((int32_t)(raw - 4000) * (eng_max - eng_min) / 16000 + eng_min);
}

void inputref_update(input_references_state_t *state)
{
    (void)state;

    static int16_t raw_ai1, raw_ai2, raw_ai3;

    ir.ai1_scaled = ir_scale_ai(raw_ai1, 0, 3000);
    ir.ai2_scaled = ir_scale_ai(raw_ai2, 0, 1000);
    ir.ai3_scaled = ir_scale_ai(raw_ai3, -1000, 1000);

    switch (ir.ref_source) {
        case 0:
            ir.selected_ref = ir.ai1_scaled;
            break;
        case 1:
            ir.selected_ref = ir.ai2_scaled;
            break;
        case 2:
            ir.selected_ref = ir.fieldbus_ref1;
            break;
        case 3:
            ir.selected_ref = ir.panel_ref;
            break;
        case 4:
            ir.selected_ref = ir.motor_pot_ref;
            break;
        case 5:
            ir.selected_ref = ir.fieldbus_ref2;
            break;
        case 6:
            ir.selected_ref = ir.pid_setpoint;
            break;
        default:
            ir.selected_ref = ir.ai1_scaled;
            break;
    }

    ir.ref_ramped = ir.selected_ref;

    (void)raw_ai1; (void)raw_ai2; (void)raw_ai3;
}

int16_t inputref_get_ai1(void)            { return ir.ai1_scaled; }
int16_t inputref_get_ai2(void)            { return ir.ai2_scaled; }
int16_t inputref_get_fieldbus_ref1(void)  { return ir.fieldbus_ref1; }
int16_t inputref_get_fieldbus_ref2(void)  { return ir.fieldbus_ref2; }
int16_t inputref_get_panel_ref(void)      { return ir.panel_ref; }
int16_t inputref_get_selected_ref(void)   { return ir.selected_ref; }
int16_t inputref_get_ramped_ref(void)     { return ir.ref_ramped; }
uint8_t inputref_get_source(void)         { return ir.ref_source; }

void inputref_set_fieldbus_ref1(int16_t ref)
{
    ir.fieldbus_ref1 = ref;
}

void inputref_set_fieldbus_ref2(int16_t ref)
{
    ir.fieldbus_ref2 = ref;
}

void inputref_set_panel_ref(int16_t ref)
{
    ir.panel_ref = ref;
}

void inputref_set_motor_pot(int16_t ref)
{
    ir.motor_pot_ref = ref;
}

void inputref_set_pid(int16_t setpoint, int16_t feedback)
{
    ir.pid_setpoint = setpoint;
    ir.pid_feedback = feedback;
}

void inputref_set_source(uint8_t source)
{
    ir.ref_source = source;
}
