#ifndef DIAGNOSTICS_RUNTIME_STATS_H
#define DIAGNOSTICS_RUNTIME_STATS_H

/* kWh, hours, run counters */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    uint32_t power_on_seconds;
    uint32_t run_seconds;
    uint32_t motor_run_seconds;
    uint32_t fan_run_seconds;
    uint32_t energy_kWh_thousandths;
    uint32_t energy_mWh_accum;
    uint32_t tick_ms;
    uint8_t  drive_running;
    uint8_t  motor_running;
    uint8_t  fan_running;
    uint8_t  initialized_ok;
} runtime_stats_state_t;

void runtime_stats_init(runtime_stats_state_t *state);
void runtime_stats_update(runtime_stats_state_t *state);
void runtime_stats_tick(runtime_stats_state_t *state);

#endif /* DIAGNOSTICS_RUNTIME_STATS_H */
