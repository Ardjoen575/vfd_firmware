#include "signal_supervision.h"

#define SS_MAX_SIGNALS      8
#define SS_MIN_CURRENT_MA   4
#define SS_MAX_CURRENT_MA   20
#define SS_OPEN_CIRCUIT_MA  1

typedef struct {
    int16_t raw_value[SS_MAX_SIGNALS];
    int16_t scaled_value[SS_MAX_SIGNALS];
    int16_t min_limit[SS_MAX_SIGNALS];
    int16_t max_limit[SS_MAX_SIGNALS];
    int16_t under_range_threshold;
    int16_t over_range_threshold;
    uint8_t signal_type[SS_MAX_SIGNALS];
    uint8_t fault_active[SS_MAX_SIGNALS];
    uint8_t warning_active[SS_MAX_SIGNALS];
    uint8_t enabled[SS_MAX_SIGNALS];
    uint8_t open_circuit[SS_MAX_SIGNALS];
    uint32_t fault_delay_accum[SS_MAX_SIGNALS];
    uint16_t fault_delay_ms;
} ss_internal_t;

static ss_internal_t ss;

void signal_supervision_init(signal_supervision_state_t *state)
{
    state->initialized = 1;

    for (uint8_t i = 0; i < SS_MAX_SIGNALS; i++) {
        ss.raw_value[i] = 0;
        ss.scaled_value[i] = 0;
        ss.min_limit[i] = -1000;
        ss.max_limit[i] = 10000;
        ss.signal_type[i] = 0;
        ss.fault_active[i] = 0;
        ss.warning_active[i] = 0;
        ss.enabled[i] = 1;
        ss.open_circuit[i] = 0;
        ss.fault_delay_accum[i] = 0;
    }

    ss.under_range_threshold = 2048;
    ss.over_range_threshold = 18432;
    ss.fault_delay_ms = 100;
}

void signal_supervision_update(signal_supervision_state_t *state)
{
    if (!state->initialized) return;
    (void)state;
}

void supervision_check(signal_supervision_state_t *state)
{
    (void)state;

    for (uint8_t i = 0; i < SS_MAX_SIGNALS; i++) {
        if (!ss.enabled[i]) continue;

        int16_t raw = ss.raw_value[i];

        if (raw <= 0 || raw < 100) {
            ss.open_circuit[i] = 1;
            ss.fault_active[i] = 1;
            ss.warning_active[i] = 0;
            continue;
        } else {
            ss.open_circuit[i] = 0;
        }

        if (raw < ss.under_range_threshold) {
            ss.fault_delay_accum[i]++;
            if (ss.fault_delay_accum[i] >= ss.fault_delay_ms) {
                ss.warning_active[i] = 1;
                if (raw < (ss.under_range_threshold / 2)) {
                    ss.fault_active[i] = 1;
                }
            }
        } else if (raw > ss.over_range_threshold) {
            ss.fault_delay_accum[i]++;
            if (ss.fault_delay_accum[i] >= ss.fault_delay_ms) {
                ss.warning_active[i] = 1;
                ss.fault_active[i] = 1;
            }
        } else {
            ss.fault_delay_accum[i] = 0;
            ss.fault_active[i] = 0;
            ss.warning_active[i] = 0;

            int16_t scaled = (int16_t)((int32_t)(raw - 4000) * (ss.max_limit[i] - ss.min_limit[i]) / 16000 + ss.min_limit[i]);
            ss.scaled_value[i] = scaled;
        }
    }
}

void signal_supervision_set_raw(uint8_t index, int16_t raw_value)
{
    if (index < SS_MAX_SIGNALS) {
        ss.raw_value[index] = raw_value;
    }
}

int16_t signal_supervision_get_scaled(uint8_t index)
{
    if (index >= SS_MAX_SIGNALS) return 0;
    return ss.scaled_value[index];
}

uint8_t signal_supervision_is_fault(uint8_t index)
{
    if (index >= SS_MAX_SIGNALS) return 0;
    return ss.fault_active[index];
}

uint8_t signal_supervision_is_open_circuit(uint8_t index)
{
    if (index >= SS_MAX_SIGNALS) return 0;
    return ss.open_circuit[index];
}

uint8_t signal_supervision_is_warning(uint8_t index)
{
    if (index >= SS_MAX_SIGNALS) return 0;
    return ss.warning_active[index];
}

void signal_supervision_set_limits(uint8_t index, int16_t min_val, int16_t max_val)
{
    if (index < SS_MAX_SIGNALS) {
        ss.min_limit[index] = min_val;
        ss.max_limit[index] = max_val;
    }
}
