#include "actual_values.h"

typedef struct {
    int16_t motor_speed_rpm;
    int16_t motor_speed_pct;
    int16_t motor_torque_cNm;
    int16_t motor_torque_pct;
    int16_t motor_current_A_tenths;
    int16_t motor_current_pct;
    int16_t motor_power_kW_tenths;
    int16_t motor_power_pct;
    int16_t motor_voltage_V;
    int16_t dc_bus_voltage_V;
    int16_t heatsink_temp_C;
    int16_t igbt_temp_C;
    int16_t motor_temp_C;
    int16_t output_freq_hz_tenths;
    int32_t energy_kWh_thousandths;
    int16_t power_factor_tenths;
    int16_t process_value1;
    int16_t process_value2;
} av_internal_t;

static av_internal_t av;

static int16_t av_scale_raw(int16_t raw, int16_t raw_min, int16_t raw_max, int16_t eng_min, int16_t eng_max)
{
    if (raw_max == raw_min) return eng_min;
    int32_t val = (int32_t)(raw - raw_min) * (eng_max - eng_min) / (raw_max - raw_min) + eng_min;
    return (int16_t)val;
}

void actual_values_init(actual_values_state_t *state)
{
    state->initialized = 1;
    av.motor_speed_rpm = 0;
    av.motor_speed_pct = 0;
    av.motor_torque_cNm = 0;
    av.motor_torque_pct = 0;
    av.motor_current_A_tenths = 0;
    av.motor_current_pct = 0;
    av.motor_power_kW_tenths = 0;
    av.motor_power_pct = 0;
    av.motor_voltage_V = 0;
    av.dc_bus_voltage_V = 0;
    av.heatsink_temp_C = 0;
    av.igbt_temp_C = 0;
    av.motor_temp_C = 0;
    av.output_freq_hz_tenths = 0;
    av.energy_kWh_thousandths = 0;
    av.power_factor_tenths = 0;
    av.process_value1 = 0;
    av.process_value2 = 0;
}

void actual_values_update(actual_values_state_t *state)
{
    if (!state->initialized) return;
    (void)state;
}

void actval_update_all(actual_values_state_t *state)
{
    (void)state;

    static int16_t raw_ai1, raw_ai2, raw_ai3;
    static int16_t raw_current_u, raw_current_v, raw_current_w;
    static int16_t raw_dc_voltage, raw_encoder_speed;
    static int16_t raw_temp1, raw_temp2;

    av.motor_speed_rpm = av_scale_raw(raw_encoder_speed, 0, 20000, 0, 3000);
    av.motor_speed_pct = av_scale_raw(raw_encoder_speed, 0, 20000, 0, 1000);

    int16_t avg_current = (int16_t)(((int32_t)raw_current_u + raw_current_v + raw_current_w) / 3);
    int32_t scaled_current = (int32_t)avg_current * 1000 / 666;
    av.motor_current_A_tenths = (int16_t)scaled_current;
    av.motor_current_pct = av_scale_raw(avg_current, 0, 20000, 0, 1000);

    av.motor_voltage_V = av_scale_raw(avg_current, 0, 20000, 0, 400);

    av.dc_bus_voltage_V = av_scale_raw(raw_dc_voltage, 0, 20000, 0, 800);

    int32_t power = (int32_t)av.motor_voltage_V * av.motor_current_A_tenths;
    av.motor_power_kW_tenths = (int16_t)((power * 1732) / 100000);
    av.motor_power_pct = av_scale_raw((int16_t)(power / 10), 0, 40000, 0, 1000);

    av.motor_torque_cNm = (int16_t)((int32_t)av.motor_power_kW_tenths * 9550 / (av.motor_speed_rpm > 0 ? av.motor_speed_rpm : 1));
    av.motor_torque_pct = av_scale_raw(av.motor_torque_cNm, 0, 1000, 0, 1000);

    av.heatsink_temp_C = av_scale_raw(raw_temp1, 0, 5000, 0, 150);
    av.igbt_temp_C = av_scale_raw(raw_temp2, 0, 5000, 0, 150);

    av.output_freq_hz_tenths = (int16_t)((int32_t)av.motor_speed_rpm * 10 / 30);

    static int32_t energy_accum_mWs = 0;
    energy_accum_mWs += (int32_t)av.motor_power_kW_tenths * 100;
    av.energy_kWh_thousandths = energy_accum_mWs / 3600;

    if (av.motor_voltage_V > 0 && av.motor_current_A_tenths > 0) {
        int32_t apparent = (int32_t)av.motor_voltage_V * av.motor_current_A_tenths;
        int32_t active = av.motor_power_kW_tenths * 100;
        av.power_factor_tenths = (int16_t)((active * 1000) / (apparent > 0 ? apparent : 1));
    }

    av.process_value1 = av_scale_raw(raw_ai1, 0, 20000, 0, 1000);
    av.process_value2 = av_scale_raw(raw_ai2, 0, 20000, 0, 1000);

    (void)raw_ai3;
}

int16_t actual_values_get_speed(void)       { return av.motor_speed_rpm; }
int16_t actual_values_get_torque(void)      { return av.motor_torque_cNm; }
int16_t actual_values_get_current(void)     { return av.motor_current_A_tenths; }
int16_t actual_values_get_voltage(void)     { return av.motor_voltage_V; }
int16_t actual_values_get_dc_voltage(void)  { return av.dc_bus_voltage_V; }
int16_t actual_values_get_power(void)       { return av.motor_power_kW_tenths; }
int32_t actual_values_get_energy(void)      { return av.energy_kWh_thousandths; }
int16_t actual_values_get_heatsink_temp(void) { return av.heatsink_temp_C; }
int16_t actual_values_get_motor_temp(void)   { return av.motor_temp_C; }
int16_t actual_values_get_freq(void)         { return av.output_freq_hz_tenths; }
