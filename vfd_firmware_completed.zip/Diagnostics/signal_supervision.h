#ifndef DIAGNOSTICS_SIGNAL_SUPERVISION_H
#define DIAGNOSTICS_SIGNAL_SUPERVISION_H

/* Signal supervision (grp 32) */

#include <stdint.h>

#define SS_MAX_SIGNALS 8

typedef struct {
    uint8_t initialized;
    int16_t raw_value[SS_MAX_SIGNALS];
    int16_t scaled_value[SS_MAX_SIGNALS];
    int16_t min_limit[SS_MAX_SIGNALS];
    int16_t max_limit[SS_MAX_SIGNALS];
    int16_t under_range_threshold;
    int16_t over_range_threshold;
    uint8_t signal_type[SS_MAX_SIGNALS];
    uint8_t fault_active[SS_MAX_SIGNALS];
    uint8_t warning_active[SS_MAX_SIGNALS];
    uint8_t enabled[SS_MAX_SIGNALS];
    uint8_t open_circuit[SS_MAX_SIGNALS];
    uint32_t fault_delay_accum[SS_MAX_SIGNALS];
    uint16_t fault_delay_ms;
} signal_supervision_state_t;

void signal_supervision_init(signal_supervision_state_t *state);
void signal_supervision_update(signal_supervision_state_t *state);
void supervision_check(signal_supervision_state_t *state);

#endif /* DIAGNOSTICS_SIGNAL_SUPERVISION_H */
