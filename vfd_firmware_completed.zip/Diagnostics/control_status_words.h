#ifndef DIAGNOSTICS_CONTROL_STATUS_WORDS_H
#define DIAGNOSTICS_CONTROL_STATUS_WORDS_H

/* Control and status words (grp 06) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    uint16_t control_word;
    uint16_t status_word;
    uint8_t  cw_start;
    uint8_t  cw_stop;
    uint8_t  cw_reverse;
    uint8_t  cw_fault_reset;
    uint8_t  sw_ready;
    uint8_t  sw_running;
    uint8_t  sw_faulted;
    uint8_t  sw_warning;
    uint8_t  sw_at_setpoint;
    uint8_t  sw_off2_active;
    uint8_t  sw_off3_active;
    uint8_t  drive_running;
    uint8_t  drive_fault;
    uint8_t  drive_warning;
} control_status_words_state_t;

void control_status_words_init(control_status_words_state_t *state);
void control_status_words_update(control_status_words_state_t *state);
void ctrlstatus_update(control_status_words_state_t *state);

#endif /* DIAGNOSTICS_CONTROL_STATUS_WORDS_H */
