#ifndef DIAGNOSTICS_WARNINGS_FAULTS_H
#define DIAGNOSTICS_WARNINGS_FAULTS_H

/* Warnings and faults tracking (grp 04) */

#include <stdint.h>

#define WF_MAX_SOURCES 32

typedef struct {
    uint8_t initialized;
    uint16_t warning_word_1;
    uint16_t warning_word_2;
    uint16_t fault_word_1;
    uint16_t fault_word_2;
    uint16_t active_warnings;
    uint16_t active_faults;
    uint16_t warning_sources[WF_MAX_SOURCES];
    uint16_t fault_sources[WF_MAX_SOURCES];
    uint8_t  warning_count;
    uint8_t  fault_count;
    uint8_t  warning_active_any;
    uint8_t  fault_active_any;
} warnings_faults_state_t;

void warnings_faults_init(warnings_faults_state_t *state);
void warnings_faults_update(warnings_faults_state_t *state);
void warnfault_update(warnings_faults_state_t *state);

#endif /* DIAGNOSTICS_WARNINGS_FAULTS_H */
