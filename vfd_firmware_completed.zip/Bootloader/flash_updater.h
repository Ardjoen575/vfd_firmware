#ifndef BOOTLOADER_FLASH_UPDATER_H
#define BOOTLOADER_FLASH_UPDATER_H

#include <stdint.h>

#define APP_FLASH_START  0x08020000UL
#define APP_FLASH_END    0x080FFFFFUL
#define APP_FLASH_SIZE   (APP_FLASH_END - APP_FLASH_START + 1)
#define FLASH_SECTOR_SIZE 0x00040000UL
#define FLASH_PAGE_SIZE   0x00008000UL
#define FLASH_WORD_SIZE   4U

#define FLASH_KEY1       0x45670123UL
#define FLASH_KEY2       0xCDEF89ABUL
#define FLASH_CR_STRT    (1UL << 16)
#define FLASH_CR_SER     (1UL << 1)
#define FLASH_CR_SNB_Pos 3U
#define FLASH_CR_PG      (1UL << 0)
#define FLASH_CR_LOCK    (1UL << 31)
#define FLASH_SR_BSY     (1UL << 16)
#define FLASH_SR_PGSERR  (1UL << 7)
#define FLASH_SR_PGPERR  (1UL << 6)
#define FLASH_SR_WRPERR  (1UL << 4)
#define FLASH_SR_EOP     (1UL << 0)

#define FLASH_R_BASE      0x40023C00UL
#define FLASH_KEYR        (*(volatile uint32_t *)(FLASH_R_BASE + 0x04UL))
#define FLASH_OPTKEYR     (*(volatile uint32_t *)(FLASH_R_BASE + 0x08UL))
#define FLASH_SR          (*(volatile uint32_t *)(FLASH_R_BASE + 0x0CUL))
#define FLASH_CR          (*(volatile uint32_t *)(FLASH_R_BASE + 0x10UL))
#define FLASH_OPTCR       (*(volatile uint32_t *)(FLASH_R_BASE + 0x14UL))

typedef struct {
    uint8_t  initialized;
    uint32_t app_start_addr;
    uint32_t current_addr;
    uint32_t bytes_written;
    uint32_t bytes_total;
    uint8_t  write_complete;
    uint8_t  write_error;
    uint32_t error_code;
} flash_updater_state_t;

void flash_updater_init(flash_updater_state_t *state);
void flash_updater_update(flash_updater_state_t *state);
uint8_t flash_erase_app(void);
uint8_t flash_write_app(const uint8_t *data, uint32_t length);
uint8_t flash_verify_app(const uint8_t *data, uint32_t length);

#endif
