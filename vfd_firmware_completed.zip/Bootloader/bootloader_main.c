#include "crc_check.h"
#include "flash_updater.h"
#include <stdint.h>
#include <string.h>

#define DOWNLOAD_AREA_BASE  0x08010000UL
#define DOWNLOAD_AREA_SIZE  0x00010000UL
#define UPDATE_FLAG_ADDR    0x0800FFC0UL
#define UPDATE_FLAG_MAGIC   0x55AA5AA5UL
#define FW_HEADER_MAGIC     0x56464446UL
#define FW_HEADER_SIZE      64U

typedef struct {
    uint32_t magic;
    uint32_t version;
    uint32_t fw_size;
    uint32_t fw_crc;
    uint32_t target_addr;
    uint8_t  reserved[44];
} fw_header_t;

typedef struct {
    uint8_t initialized;
    uint8_t update_pending;
    uint8_t fw_valid;
    uint8_t flash_result;
    uint32_t fw_version;
    uint32_t fw_size;
} bootloader_state_t;

static bootloader_state_t bl_state;

static uint8_t bootloader_check_update_flag(void)
{
    uint32_t flag_value;

    flag_value = *((volatile uint32_t *)UPDATE_FLAG_ADDR);

    return (flag_value == UPDATE_FLAG_MAGIC) ? 1 : 0;
}

static uint8_t bootloader_validate_header(fw_header_t *header)
{
    if (header->magic != FW_HEADER_MAGIC) {
        return 0;
    }

    if (header->fw_size == 0 || header->fw_size > APP_FLASH_SIZE) {
        return 0;
    }

    if (header->target_addr != APP_FLASH_START) {
        return 0;
    }

    return 1;
}

static uint8_t bootloader_validate_firmware(const uint8_t *fw_data, fw_header_t *header)
{
    uint8_t result;

    result = crc_verify(fw_data + FW_HEADER_SIZE,
                        header->fw_size,
                        header->fw_crc);

    return result;
}

static void bootloader_clear_update_flag(void)
{
    *((volatile uint32_t *)UPDATE_FLAG_ADDR) = 0;
}

void bootloader_run(void)
{
    fw_header_t fw_header;
    const uint8_t *download_area;
    uint8_t result;

    if (!bootloader_check_update_flag()) {
        return;
    }

    download_area = (const uint8_t *)DOWNLOAD_AREA_BASE;

    memcpy(&fw_header, download_area, FW_HEADER_SIZE);

    if (!bootloader_validate_header(&fw_header)) {
        bootloader_clear_update_flag();
        return;
    }

    if (!bootloader_validate_firmware(download_area, &fw_header)) {
        bootloader_clear_update_flag();
        return;
    }

    result = flash_erase_app();
    if (!result) {
        bootloader_clear_update_flag();
        return;
    }

    result = flash_write_app(download_area + FW_HEADER_SIZE, fw_header.fw_size);
    if (!result) {
        bootloader_clear_update_flag();
        return;
    }

    result = flash_verify_app(download_area + FW_HEADER_SIZE, fw_header.fw_size);
    if (result) {
        bootloader_clear_update_flag();
        bl_state.fw_valid = 1;
        bl_state.fw_version = fw_header.version;
    }
}

void bootloader_init(void)
{
    memset(&bl_state, 0, sizeof(bl_state));
    bl_state.initialized = 1;
}
