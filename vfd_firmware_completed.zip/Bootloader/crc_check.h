#ifndef BOOTLOADER_CRC_CHECK_H
#define BOOTLOADER_CRC_CHECK_H

#include <stdint.h>

#define CRC32_POLYNOMIAL  0x04C11DB7UL
#define CRC32_INIT_VALUE  0xFFFFFFFFUL

typedef struct {
    uint8_t  initialized;
    uint32_t computed_crc;
    uint32_t stored_crc;
    uint8_t  crc_valid;
} crc_check_state_t;

void crc_check_init(crc_check_state_t *state);
void crc_check_update(crc_check_state_t *state);
uint32_t crc32_compute(const uint8_t *data, uint32_t length);
uint8_t crc_verify(const uint8_t *data, uint32_t length, uint32_t expected_crc);

#endif
