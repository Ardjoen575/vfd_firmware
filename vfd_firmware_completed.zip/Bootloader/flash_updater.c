#include "flash_updater.h"
#include "crc_check.h"

static uint8_t flash_wait_ready(void)
{
    while (FLASH_SR & FLASH_SR_BSY) {
    }
    return 1;
}

static void flash_unlock(void)
{
    if (FLASH_CR & FLASH_CR_LOCK) {
        FLASH_KEYR = FLASH_KEY1;
        FLASH_KEYR = FLASH_KEY2;
        __asm__ volatile ("dsb");
        __asm__ volatile ("isb");
    }
}

static void flash_lock(void)
{
    FLASH_CR |= FLASH_CR_LOCK;
}

uint8_t flash_erase_app(void)
{
    uint32_t sector;
    uint32_t start_sector;
    uint32_t end_sector;

    start_sector = (APP_FLASH_START - 0x08000000UL) / FLASH_SECTOR_SIZE;
    end_sector   = (APP_FLASH_END   - 0x08000000UL) / FLASH_SECTOR_SIZE;

    flash_unlock();

    for (sector = start_sector; sector <= end_sector; sector++) {
        flash_wait_ready();

        FLASH_CR &= ~(0x0FUL << FLASH_CR_SNB_Pos);
        FLASH_CR |= (sector << FLASH_CR_SNB_Pos);
        FLASH_CR |= FLASH_CR_SER;

        __asm__ volatile ("dsb");
        __asm__ volatile ("isb");

        FLASH_CR |= FLASH_CR_STRT;

        __asm__ volatile ("dsb");
        __asm__ volatile ("isb");

        flash_wait_ready();

        if (FLASH_SR & (FLASH_SR_PGSERR | FLASH_SR_PGPERR | FLASH_SR_WRPERR)) {
            FLASH_SR |= (FLASH_SR_PGSERR | FLASH_SR_PGPERR | FLASH_SR_WRPERR);
            FLASH_CR &= ~FLASH_CR_SER;
            flash_lock();
            return 0;
        }

        FLASH_CR &= ~FLASH_CR_SER;
    }

    flash_lock();
    return 1;
}

uint8_t flash_write_app(const uint8_t *data, uint32_t length)
{
    uint32_t i;
    uint32_t word;
    volatile uint32_t *flash_ptr;

    if (data == 0 || length == 0) {
        return 0;
    }

    if (length % FLASH_WORD_SIZE != 0) {
        return 0;
    }

    flash_unlock();

    FLASH_CR |= FLASH_CR_PG;

    flash_ptr = (volatile uint32_t *)APP_FLASH_START;

    for (i = 0; i < length; i += FLASH_WORD_SIZE) {
        word = *((const uint32_t *)(data + i));

        flash_wait_ready();

        if (FLASH_SR & (FLASH_SR_PGPERR | FLASH_SR_WRPERR)) {
            FLASH_SR |= (FLASH_SR_PGPERR | FLASH_SR_WRPERR);
            FLASH_CR &= ~FLASH_CR_PG;
            flash_lock();
            return 0;
        }

        *flash_ptr = word;

        __asm__ volatile ("dsb");
        __asm__ volatile ("isb");

        flash_ptr++;
    }

    flash_wait_ready();

    FLASH_CR &= ~FLASH_CR_PG;

    flash_lock();

    if (FLASH_SR & FLASH_SR_PGSERR) {
        FLASH_SR |= FLASH_SR_PGSERR;
        return 0;
    }

    return 1;
}

uint8_t flash_verify_app(const uint8_t *data, uint32_t length)
{
    uint32_t i;
    const uint8_t *flash_ptr;

    if (data == 0 || length == 0) {
        return 0;
    }

    flash_ptr = (const uint8_t *)APP_FLASH_START;

    for (i = 0; i < length; i++) {
        if (data[i] != flash_ptr[i]) {
            return 0;
        }
    }

    return 1;
}

void flash_updater_init(flash_updater_state_t *state)
{
    if (state == 0) return;

    state->initialized   = 1;
    state->app_start_addr = APP_FLASH_START;
    state->current_addr  = APP_FLASH_START;
    state->bytes_written = 0;
    state->bytes_total   = 0;
    state->write_complete = 0;
    state->write_error   = 0;
    state->error_code    = 0;
}

void flash_updater_update(flash_updater_state_t *state)
{
    (void)state;
}
