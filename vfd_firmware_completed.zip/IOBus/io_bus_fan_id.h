#ifndef IOBUS_IO_BUS_FAN_ID_H
#define IOBUS_IO_BUS_FAN_ID_H

#include <stdint.h>

#define FAN_ID_MAX_UNITS        4U
#define FAN_TYPE_UNKNOWN        0U
#define FAN_TYPE_AXIAL_80MM     1U
#define FAN_TYPE_AXIAL_120MM    2U
#define FAN_TYPE_CENTRIFUGAL    3U
#define FAN_TYPE_INTERNAL       4U
#define FAN_TYPE_PCB            5U

typedef enum {
    FAN_SPEED_OFF             = 0,
    FAN_SPEED_LOW             = 1,
    FAN_SPEED_MEDIUM          = 2,
    FAN_SPEED_HIGH            = 3,
    FAN_SPEED_AUTO            = 4,
    FAN_SPEED_FAULT           = 5,
} fan_speed_t;

typedef struct {
    uint8_t     installed;
    uint8_t     online;
    uint8_t     fan_type;
    uint16_t    nominal_speed_rpm;
    uint16_t    current_speed_rpm;
    uint8_t     speed_command;
    uint8_t     duty_cycle_percent;
    uint16_t    power_watts;
    uint32_t    run_hours;
    uint32_t    start_count;
    uint8_t     fault;
    uint16_t    fault_code;
} fan_unit_t;

typedef struct {
    uint8_t    initialized;
    uint8_t    auto_detect;
    uint8_t    fan_count;
    uint8_t    detected_count;
    uint8_t    identification_done;
    uint32_t   detection_time_ms;
    fan_unit_t fans[FAN_ID_MAX_UNITS];
} io_bus_fan_id_state_t;

void io_bus_fan_id_init(io_bus_fan_id_state_t *state);
void io_bus_fan_id_update(io_bus_fan_id_state_t *state);
uint8_t io_bus_fan_identify(io_bus_fan_id_state_t *state);

#endif
