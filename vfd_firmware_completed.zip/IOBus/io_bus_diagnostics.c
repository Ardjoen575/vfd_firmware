#include "io_bus_diagnostics.h"
#include <string.h>

static void iobus_diag_add_event(io_bus_diagnostics_state_t *state,
                                  io_bus_diag_event_t event,
                                  uint8_t slot, uint16_t data)
{
    io_bus_diag_entry_t *entry;

    if (state->event_count >= IOBUS_DIAG_MAX_EVENTS) {
        state->event_head = (state->event_head + 1) % IOBUS_DIAG_MAX_EVENTS;
    } else {
        state->event_count++;
        state->event_head = (state->event_head == 0)
                            ? (IOBUS_DIAG_MAX_EVENTS - 1)
                            : (state->event_head - 1);
    }

    entry = &state->event_log[state->event_head];
    entry->timestamp   = state->total_events;
    entry->event       = event;
    entry->module_slot = slot;
    entry->data        = data;

    state->total_events++;
}

void io_bus_diag_update(io_bus_diagnostics_state_t *state)
{
    uint8_t bus_fault = 0;

    if (state == 0) return;

    if (state->bus_error_count > 0) {
        bus_fault = 1;
    }

    state->bus_healthy = bus_fault ? 0 : 1;

    if (bus_fault && !state->fault_active) {
        state->fault_active = 1;
        iobus_diag_add_event(state, IOBUS_DIAG_EVENT_BUS_OFFLINE, 0, 0);
    } else if (!bus_fault && state->fault_active) {
        state->fault_active = 0;
        iobus_diag_add_event(state, IOBUS_DIAG_EVENT_BUS_RECOVER, 0, 0);
    }

    if (state->comm_error_count > 0) {
        iobus_diag_add_event(state, IOBUS_DIAG_EVENT_COMM_ERROR,
                              0, (uint16_t)state->comm_error_count);
    }

    state->active_modules = 0;
    state->modules_with_errors = 0;

    state->diag_buffer[0] = state->bus_healthy;
    state->diag_buffer[1] = state->fault_active;
    state->diag_buffer[2] = (uint8_t)(state->bus_error_count >> 8);
    state->diag_buffer[3] = (uint8_t)(state->bus_error_count & 0xFF);
    state->diag_buffer[4] = (uint8_t)(state->comm_error_count >> 8);
    state->diag_buffer[5] = (uint8_t)(state->comm_error_count & 0xFF);
}

void io_bus_diagnostics_init(io_bus_diagnostics_state_t *state)
{
    if (state == 0) return;

    memset(state, 0, sizeof(io_bus_diagnostics_state_t));
    state->initialized      = 1;
    state->bus_healthy      = 1;
    state->fault_active     = 0;
    state->event_count      = 0;
    state->event_head       = 0;
    state->total_events     = 0;
    state->bus_error_count  = 0;
    state->comm_error_count = 0;
}

void io_bus_diagnostics_update(io_bus_diagnostics_state_t *state)
{
    if (state == 0 || !state->initialized) return;

    io_bus_diag_update(state);
}
