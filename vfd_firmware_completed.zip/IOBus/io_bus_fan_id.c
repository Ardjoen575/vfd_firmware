#include "io_bus_fan_id.h"
#include <string.h>

uint8_t io_bus_fan_identify(io_bus_fan_id_state_t *state)
{
    uint8_t i;
    uint8_t found = 0;

    if (state == 0 || !state->auto_detect) return 0;

    state->detected_count = 0;
    state->fan_count = 0;

    for (i = 0; i < FAN_ID_MAX_UNITS; i++) {
        fan_unit_t *fan = &state->fans[i];
        uint8_t detected = 0;

        if (fan->installed && fan->online) {
            detected = 1;
        }

        if (detected) {
            fan->online = 1;
            fan->fault = 0;
            fan->fault_code = 0;

            if (fan->fan_type == FAN_TYPE_UNKNOWN) {
                if (fan->nominal_speed_rpm > 5000) {
                    fan->fan_type = FAN_TYPE_PCB;
                } else if (fan->nominal_speed_rpm > 3000) {
                    fan->fan_type = FAN_TYPE_AXIAL_80MM;
                } else if (fan->nominal_speed_rpm > 1500) {
                    fan->fan_type = FAN_TYPE_AXIAL_120MM;
                } else if (fan->power_watts > 50) {
                    fan->fan_type = FAN_TYPE_CENTRIFUGAL;
                } else {
                    fan->fan_type = FAN_TYPE_INTERNAL;
                }
            }

            state->fan_count++;
            found = 1;
        } else {
            fan->online = 0;
            fan->current_speed_rpm = 0;
            fan->duty_cycle_percent = 0;
        }
    }

    state->detected_count = found;
    state->identification_done = 1;

    return found;
}

void io_bus_fan_id_init(io_bus_fan_id_state_t *state)
{
    uint8_t i;

    if (state == 0) return;

    memset(state, 0, sizeof(io_bus_fan_id_state_t));
    state->initialized = 1;
    state->auto_detect = 1;
    state->fan_count = 0;
    state->detected_count = 0;
    state->identification_done = 0;

    for (i = 0; i < FAN_ID_MAX_UNITS; i++) {
        state->fans[i].installed = 0;
        state->fans[i].online = 0;
    }
}

void io_bus_fan_id_update(io_bus_fan_id_state_t *state)
{
    uint8_t i;

    if (state == 0 || !state->initialized) return;

    state->detection_time_ms++;

    for (i = 0; i < FAN_ID_MAX_UNITS; i++) {
        if (state->fans[i].online) {
            state->fans[i].run_hours++;
            if (state->fans[i].current_speed_rpm <
                (state->fans[i].nominal_speed_rpm / 2)) {
                state->fans[i].fault = 1;
                state->fans[i].fault_code = 0x6100 + i;
            }
        }
    }
}
