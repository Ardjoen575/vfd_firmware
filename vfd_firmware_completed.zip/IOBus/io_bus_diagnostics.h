#ifndef IOBUS_IO_BUS_DIAGNOSTICS_H
#define IOBUS_IO_BUS_DIAGNOSTICS_H

#include <stdint.h>

#define IOBUS_DIAG_MAX_EVENTS      64U
#define IOBUS_DIAG_BUFFER_SIZE     32U

typedef enum {
    IOBUS_DIAG_EVENT_NONE          = 0x00,
    IOBUS_DIAG_EVENT_MODULE_ADD    = 0x01,
    IOBUS_DIAG_EVENT_MODULE_REMOVE = 0x02,
    IOBUS_DIAG_EVENT_COMM_ERROR    = 0x03,
    IOBUS_DIAG_EVENT_CRC_ERROR     = 0x04,
    IOBUS_DIAG_EVENT_OVERCURRENT   = 0x05,
    IOBUS_DIAG_EVENT_SHORT_CIRCUIT = 0x06,
    IOBUS_DIAG_EVENT_OPEN_CIRCUIT  = 0x07,
    IOBUS_DIAG_EVENT_TEMP_WARNING  = 0x08,
    IOBUS_DIAG_EVENT_TEMP_FAULT    = 0x09,
    IOBUS_DIAG_EVENT_SUPPLY_LOW    = 0x0A,
    IOBUS_DIAG_EVENT_WATCHDOG      = 0x0B,
    IOBUS_DIAG_EVENT_CONFIG_MISMATCH = 0x0C,
    IOBUS_DIAG_EVENT_BUS_OFFLINE   = 0x0E,
    IOBUS_DIAG_EVENT_BUS_RECOVER   = 0x0F,
} io_bus_diag_event_t;

typedef struct __attribute__((packed)) {
    uint32_t            timestamp;
    io_bus_diag_event_t event;
    uint8_t             module_slot;
    uint8_t             reserved;
    uint16_t            data;
} io_bus_diag_entry_t;

typedef struct {
    uint8_t            initialized;
    uint8_t            bus_healthy;
    uint8_t            fault_active;
    uint16_t           active_modules;
    uint16_t           modules_with_errors;
    uint32_t           bus_error_count;
    uint32_t           comm_error_count;
    uint16_t           event_head;
    uint16_t           event_count;
    uint32_t           total_events;
    io_bus_diag_entry_t event_log[IOBUS_DIAG_MAX_EVENTS];
    uint8_t            diag_buffer[IOBUS_DIAG_BUFFER_SIZE];
} io_bus_diagnostics_state_t;

void io_bus_diagnostics_init(io_bus_diagnostics_state_t *state);
void io_bus_diagnostics_update(io_bus_diagnostics_state_t *state);
void io_bus_diag_update(io_bus_diagnostics_state_t *state);

#endif
