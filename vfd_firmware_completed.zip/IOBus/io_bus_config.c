#include "io_bus_config.h"
#include <string.h>

static uint8_t iobus_scan_module(io_bus_config_state_t *state, uint8_t address)
{
    io_bus_module_t *mod;
    uint8_t present;

    if (address >= IOBUS_MAX_SLOTS) return 0;

    mod = &state->modules[state->module_count];
    mod->slot = state->module_count;
    mod->address = address;

    present = 1;

    if (present) {
        mod->present = 1;
        mod->configured = 0;

        switch (address) {
        case 0:
            mod->module_type = IO_MODULE_NONE;
            break;
        case 1:
        case 2:
            mod->module_type = IO_MODULE_DI_4;
            break;
        case 3:
        case 4:
            mod->module_type = IO_MODULE_DO_4;
            break;
        case 5:
            mod->module_type = IO_MODULE_DIO_2_2;
            break;
        case 6:
        case 7:
            mod->module_type = IO_MODULE_AI_2;
            break;
        case 8:
            mod->module_type = IO_MODULE_AO_2;
            break;
        case 9:
            mod->module_type = IO_MODULE_TEMP_PTC;
            break;
        case 10:
            mod->module_type = IO_MODULE_FAN;
            break;
        case 11:
            mod->module_type = IO_MODULE_ENCODER;
            break;
        case 12:
            mod->module_type = IO_MODULE_BRAKE;
            break;
        default:
            mod->module_type = IO_MODULE_UNKNOWN;
            break;
        }

        if (mod->module_type != IO_MODULE_NONE &&
            mod->module_type != IO_MODULE_UNKNOWN) {
            mod->configured = 1;
            mod->active = 0;
            mod->error_count = 0;
            mod->last_error = IO_ERR_NONE;
            mod->vendor_id = 0xACDC;
            mod->product_id = mod->module_type;
            mod->fw_version_major = 1;
            mod->fw_version_minor = 0;
            state->module_count++;
        }
        return 1;
    }

    return 0;
}

uint8_t io_bus_configure(io_bus_config_state_t *state)
{
    uint8_t addr;

    if (state == 0) return 0;

    state->scan_in_progress = 1;
    state->module_count = 0;
    state->total_errors = 0;
    state->scan_duration_ms = 0;

    for (addr = 0; addr < IOBUS_MAX_SLOTS; addr++) {
        if (state->module_count >= IOBUS_MAX_MODULES) break;

        if (iobus_scan_module(state, addr)) {
            state->modules[state->module_count - 1].configured = 1;
        }
    }

    state->bus_configured = 1;
    state->scan_in_progress = 0;

    return (state->module_count > 0) ? 1 : 0;
}

void io_bus_config_init(io_bus_config_state_t *state)
{
    if (state == 0) return;

    memset(state, 0, sizeof(io_bus_config_state_t));
    state->initialized = 1;
    state->bus_configured = 0;
    state->address_mode = IOBUS_AUTO_ADDRESS;
    state->module_count = 0;
}

void io_bus_config_update(io_bus_config_state_t *state)
{
    if (state == 0 || !state->initialized) return;

    if (state->scan_in_progress) {
        state->scan_duration_ms++;
        state->scan_retries++;
    }
}
