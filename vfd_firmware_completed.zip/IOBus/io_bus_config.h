#ifndef IOBUS_IO_BUS_CONFIG_H
#define IOBUS_IO_BUS_CONFIG_H

#include <stdint.h>

#define IOBUS_MAX_MODULES         16U
#define IOBUS_MAX_SLOTS           16U
#define IOBUS_MODULE_ID_SIZE      32U
#define IOBUS_SCAN_RETRIES         3U
#define IOBUS_AUTO_ADDRESS        1U
#define IOBUS_MANUAL_ADDRESS      0U

typedef enum {
    IO_MODULE_NONE         = 0x00,
    IO_MODULE_DI_4         = 0x01,
    IO_MODULE_DI_8         = 0x02,
    IO_MODULE_DO_4         = 0x03,
    IO_MODULE_DO_8         = 0x04,
    IO_MODULE_DIO_2_2      = 0x05,
    IO_MODULE_AI_2         = 0x06,
    IO_MODULE_AI_4         = 0x07,
    IO_MODULE_AO_2         = 0x08,
    IO_MODULE_AO_4         = 0x09,
    IO_MODULE_TEMP_PT100   = 0x0A,
    IO_MODULE_TEMP_PTC     = 0x0B,
    IO_MODULE_ENCODER      = 0x0C,
    IO_MODULE_FAN          = 0x0D,
    IO_MODULE_BRAKE        = 0x0E,
    IO_MODULE_RESOLVER     = 0x0F,
    IO_MODULE_UNKNOWN      = 0xFF,
} io_module_type_t;

typedef enum {
    IO_ERR_NONE            = 0,
    IO_ERR_TIMEOUT         = 1,
    IO_ERR_CRC             = 2,
    IO_ERR_NACK            = 3,
    IO_ERR_MISSING         = 4,
    IO_ERR_MISMATCH        = 5,
    IO_ERR_DUPLICATE_ADDR  = 6,
    IO_ERR_OVERCURRENT     = 7,
    IO_ERR_CONFIG          = 8,
} io_bus_error_t;

typedef struct {
    uint8_t         slot;
    uint8_t         address;
    io_module_type_t module_type;
    uint8_t         configured;
    uint8_t         present;
    uint8_t         active;
    uint8_t         error_count;
    io_bus_error_t  last_error;
    uint8_t         module_id[IOBUS_MODULE_ID_SIZE];
    uint16_t        vendor_id;
    uint16_t        product_id;
    uint8_t         fw_version_major;
    uint8_t         fw_version_minor;
    uint32_t        io_data[8];
} io_bus_module_t;

typedef struct {
    uint8_t         initialized;
    uint8_t         bus_configured;
    uint8_t         address_mode;
    uint8_t         module_count;
    uint8_t         scan_in_progress;
    uint8_t         scan_retries;
    uint16_t        total_errors;
    uint32_t        scan_duration_ms;
    io_bus_module_t modules[IOBUS_MAX_MODULES];
} io_bus_config_state_t;

void io_bus_config_init(io_bus_config_state_t *state);
void io_bus_config_update(io_bus_config_state_t *state);
uint8_t io_bus_configure(io_bus_config_state_t *state);

#endif
