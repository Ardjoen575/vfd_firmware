#ifndef IOBUS_IO_BUS_SERVICE_H
#define IOBUS_IO_BUS_SERVICE_H

#include <stdint.h>

#define IOBUS_SERVICE_CYCLE_MS     1U
#define IOBUS_INPUT_OFFSET         0U
#define IOBUS_OUTPUT_OFFSET      128U
#define IOBUS_DIAG_OFFSET        256U
#define IOBUS_MAX_DATA_BYTES     512U
#define IOBUS_TICK_TIMEOUT        10U

typedef enum {
    IOBUS_SERVICE_IDLE       = 0,
    IOBUS_SERVICE_SCANNING   = 1,
    IOBUS_SERVICE_EXCHANGING = 2,
    IOBUS_SERVICE_ERROR      = 3,
} io_bus_service_state_t;

typedef struct {
    uint8_t                initialized;
    io_bus_service_state_t state;
    uint32_t               tick_count;
    uint8_t                exchange_active;
    uint8_t                refresh_pending;
    uint32_t               last_exchange_tick;
    uint32_t               exchange_errors;
    uint32_t               exchange_timeout_ms;
    uint8_t                input_buffer[IOBUS_MAX_DATA_BYTES];
    uint8_t                output_buffer[IOBUS_MAX_DATA_BYTES];
    uint8_t                diag_buffer[IOBUS_MAX_DATA_BYTES];
    uint16_t               input_size;
    uint16_t               output_size;
    uint16_t               diag_size;
} io_bus_service_state_t;

void io_bus_service_init(io_bus_service_state_t *state);
void io_bus_service_update(io_bus_service_state_t *state);
uint8_t io_bus_service_tick(io_bus_service_state_t *state);

#endif
