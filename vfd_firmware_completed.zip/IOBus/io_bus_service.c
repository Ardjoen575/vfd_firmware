#include "io_bus_service.h"
#include <string.h>

static void iobus_exchange_inputs(io_bus_service_state_t *state)
{
    memset(state->input_buffer, 0, state->input_size);
}

static void iobus_exchange_outputs(io_bus_service_state_t *state)
{
    uint16_t i;
    for (i = 0; i < state->output_size && i < IOBUS_MAX_DATA_BYTES; i++) {
        state->output_buffer[i] = state->output_buffer[i] & 0xFF;
    }
}

static void iobus_exchange_diagnostics(io_bus_service_state_t *state)
{
    memset(state->diag_buffer, 0, state->diag_size);
}

uint8_t io_bus_service_tick(io_bus_service_state_t *state)
{
    uint32_t elapsed;

    if (state == 0) return 0;

    if (state->state != IOBUS_SERVICE_EXCHANGING) {
        state->exchange_errors++;
        return 0;
    }

    elapsed = state->tick_count - state->last_exchange_tick;
    if (elapsed < IOBUS_SERVICE_CYCLE_MS) return 1;

    state->last_exchange_tick = state->tick_count;

    iobus_exchange_inputs(state);

    iobus_exchange_diagnostics(state);

    iobus_exchange_outputs(state);

    state->exchange_active = 1;
    state->exchange_timeout_ms = 0;

    return 1;
}

void io_bus_service_init(io_bus_service_state_t *state)
{
    if (state == 0) return;

    memset(state, 0, sizeof(io_bus_service_state_t));
    state->initialized  = 1;
    state->state        = IOBUS_SERVICE_IDLE;
    state->tick_count   = 0;
    state->exchange_active = 0;
    state->input_size   = 128;
    state->output_size  = 128;
    state->diag_size    = 64;
}

void io_bus_service_update(io_bus_service_state_t *state)
{
    if (state == 0 || !state->initialized) return;

    state->tick_count++;

    io_bus_service_tick(state);

    if (state->exchange_active) {
        state->exchange_timeout_ms++;
        if (state->exchange_timeout_ms > IOBUS_TICK_TIMEOUT) {
            state->exchange_active = 0;
            state->state = IOBUS_SERVICE_ERROR;
        }
    }
}
