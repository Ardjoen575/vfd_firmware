#include "operating_modes.h"
#include <string.h>

operating_mode_t operating_mode_select(operating_modes_state_t *state,
                                         operating_mode_t mode)
{
    if (state == 0) return OPMODE_NONE;

    if (state->drive_state == OP_STATE_FAULTED) {
        return state->active_mode;
    }

    if (state->drive_state == OP_STATE_RUNNING && !state->mode_change_allowed) {
        state->requested_mode = mode;
        state->mode_change_pending = 1;
        return state->active_mode;
    }

    switch (mode) {

    case OPMODE_SPEED:
        state->active_mode = OPMODE_SPEED;
        state->torque_ref_nm = 0;
        state->frequency_ref_hz = 0;
        state->dc_voltage_ref_v = 0;
        break;

    case OPMODE_TORQUE:
        state->active_mode = OPMODE_TORQUE;
        state->speed_ref_rpm = 0;
        state->frequency_ref_hz = 0;
        state->dc_voltage_ref_v = 0;
        break;

    case OPMODE_FREQUENCY:
        state->active_mode = OPMODE_FREQUENCY;
        state->speed_ref_rpm = 0;
        state->torque_ref_nm = 0;
        state->dc_voltage_ref_v = 0;
        break;

    case OPMODE_DC_VOLTAGE:
        state->active_mode = OPMODE_DC_VOLTAGE;
        state->speed_ref_rpm = 0;
        state->torque_ref_nm = 0;
        state->frequency_ref_hz = 0;
        break;

    case OPMODE_PID:
        state->active_mode = OPMODE_PID;
        if (state->pid_set2_active) {
            state->pid_output = 0;
        } else {
            state->pid_set1_active = 1;
        }
        break;

    case OPMODE_SPECIAL:
        state->active_mode = OPMODE_SPECIAL;
        state->special_cmd = 0;
        break;

    case OPMODE_SCALAR:
        state->active_mode = OPMODE_SCALAR;
        break;

    case OPMODE_VECTOR:
        state->active_mode = OPMODE_VECTOR;
        break;

    default:
        break;
    }

    state->requested_mode = state->active_mode;
    state->mode_change_pending = 0;
    state->last_mode_change_tick = 0;

    return state->active_mode;
}

operating_mode_t operating_mode_get_current(operating_modes_state_t *state)
{
    if (state == 0) return OPMODE_NONE;
    return state->active_mode;
}

void operating_modes_init(operating_modes_state_t *state)
{
    if (state == 0) return;

    memset(state, 0, sizeof(operating_modes_state_t));
    state->initialized       = 1;
    state->active_mode       = OPMODE_SPEED;
    state->requested_mode    = OPMODE_SPEED;
    state->drive_state       = OP_STATE_STOPPED;
    state->mode_change_pending = 0;
    state->mode_change_allowed = 1;
    state->pid_set1_active   = 0;
    state->pid_set2_active   = 0;
}

void operating_modes_update(operating_modes_state_t *state)
{
    if (state == 0 || !state->initialized) return;

    if (state->mode_change_pending) {
        if (state->drive_state != OP_STATE_RUNNING ||
            state->mode_change_allowed) {
            operating_mode_select(state, state->requested_mode);
        }
    }

    state->last_mode_change_tick++;
}
