#ifndef CONTROLLOCATIONS_CONTROL_LOCATION_H
#define CONTROLLOCATIONS_CONTROL_LOCATION_H

#include <stdint.h>

typedef enum {
    CTRL_LOC_NONE       = 0,
    CTRL_LOC_LOCAL      = 1,
    CTRL_LOC_EXT1       = 2,
    CTRL_LOC_EXT2       = 3,
    CTRL_LOC_FIELDBUS   = 4,
    CTRL_LOC_EMBEDDED   = 5,
    CTRL_LOC_DDC        = 6,
    CTRL_LOC_AUTO       = 7,
} ctrl_location_t;

typedef enum {
    CTRL_HANDOFF_NONE   = 0,
    CTRL_HANDOFF_LOCAL  = 1,
    CTRL_HANDOFF_EXT1   = 2,
    CTRL_HANDOFF_EXT2   = 3,
} ctrl_handoff_mode_t;

typedef struct {
    uint8_t             initialized;
    ctrl_location_t     active_location;
    ctrl_location_t     pending_location;
    ctrl_location_t     startup_location;
    ctrl_handoff_mode_t handoff_mode;
    uint8_t             location_change_pending;
    uint8_t             force_local;
    uint8_t             ext1_active;
    uint8_t             ext2_active;
    uint8_t             fieldbus_active;
    uint8_t             embedded_active;
    uint8_t             local_lost;
    uint8_t             ext1_lost;
    uint8_t             ext2_lost;
    uint8_t             fieldbus_lost;
    uint32_t            ext1_timeout_ms;
    uint32_t            ext2_timeout_ms;
    uint32_t            fieldbus_timeout_ms;
} control_location_state_t;

void control_location_init(control_location_state_t *state);
void control_location_update(control_location_state_t *state);
ctrl_location_t ctrl_location_select(control_location_state_t *state,
                                       ctrl_location_t requested);
ctrl_location_t ctrl_location_get_active(control_location_state_t *state);
void ctrl_location_force_local(control_location_state_t *state, uint8_t force);

#endif
