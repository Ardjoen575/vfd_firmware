#include "control_location.h"
#include <string.h>

ctrl_location_t ctrl_location_select(control_location_state_t *state,
                                       ctrl_location_t requested)
{
    if (state == 0) return CTRL_LOC_NONE;

    if (state->force_local) {
        state->active_location = CTRL_LOC_LOCAL;
        return CTRL_LOC_LOCAL;
    }

    switch (requested) {
    case CTRL_LOC_LOCAL:
        if (!state->local_lost) {
            state->active_location = CTRL_LOC_LOCAL;
        }
        break;

    case CTRL_LOC_EXT1:
        if (state->ext1_active && !state->ext1_lost) {
            state->active_location = CTRL_LOC_EXT1;
        } else if (state->ext1_lost && state->handoff_mode == CTRL_HANDOFF_EXT2) {
            if (state->ext2_active && !state->ext2_lost) {
                state->active_location = CTRL_LOC_EXT2;
            } else {
                state->active_location = CTRL_LOC_LOCAL;
            }
        }
        break;

    case CTRL_LOC_EXT2:
        if (state->ext2_active && !state->ext2_lost) {
            state->active_location = CTRL_LOC_EXT2;
        } else if (state->ext2_lost && state->handoff_mode == CTRL_HANDOFF_EXT1) {
            if (state->ext1_active && !state->ext1_lost) {
                state->active_location = CTRL_LOC_EXT1;
            } else {
                state->active_location = CTRL_LOC_LOCAL;
            }
        }
        break;

    case CTRL_LOC_FIELDBUS:
        if (state->fieldbus_active && !state->fieldbus_lost) {
            state->active_location = CTRL_LOC_FIELDBUS;
        } else if (state->fieldbus_lost) {
            if (state->handoff_mode == CTRL_HANDOFF_LOCAL) {
                state->active_location = CTRL_LOC_LOCAL;
            }
        }
        break;

    case CTRL_LOC_EMBEDDED:
        if (state->embedded_active) {
            state->active_location = CTRL_LOC_EMBEDDED;
        }
        break;

    case CTRL_LOC_AUTO:
        if (state->fieldbus_active && !state->fieldbus_lost) {
            state->active_location = CTRL_LOC_FIELDBUS;
        } else if (state->ext1_active && !state->ext1_lost) {
            state->active_location = CTRL_LOC_EXT1;
        } else if (state->ext2_active && !state->ext2_lost) {
            state->active_location = CTRL_LOC_EXT2;
        } else {
            state->active_location = CTRL_LOC_LOCAL;
        }
        break;

    default:
        state->active_location = CTRL_LOC_LOCAL;
        break;
    }

    state->location_change_pending = 1;

    return state->active_location;
}

ctrl_location_t ctrl_location_get_active(control_location_state_t *state)
{
    if (state == 0) return CTRL_LOC_NONE;
    return state->active_location;
}

void ctrl_location_force_local(control_location_state_t *state, uint8_t force)
{
    if (state == 0) return;

    state->force_local = force;

    if (force) {
        state->active_location = CTRL_LOC_LOCAL;
        state->location_change_pending = 1;
    }
}

void control_location_init(control_location_state_t *state)
{
    if (state == 0) return;

    memset(state, 0, sizeof(control_location_state_t));
    state->initialized       = 1;
    state->active_location   = CTRL_LOC_LOCAL;
    state->startup_location  = CTRL_LOC_LOCAL;
    state->handoff_mode      = CTRL_HANDOFF_LOCAL;
    state->force_local       = 0;
    state->ext1_active       = 0;
    state->ext2_active       = 0;
    state->fieldbus_active   = 0;
    state->embedded_active   = 0;
    state->ext1_timeout_ms   = 500;
    state->ext2_timeout_ms   = 500;
    state->fieldbus_timeout_ms = 1000;
}

void control_location_update(control_location_state_t *state)
{
    if (state == 0 || !state->initialized) return;

    if (state->location_change_pending) {
        state->location_change_pending = 0;
    }
}
