#ifndef CONTROLLOCATIONS_OPERATING_MODES_H
#define CONTROLLOCATIONS_OPERATING_MODES_H

#include <stdint.h>

typedef enum {
    OPMODE_SPEED        = 0,
    OPMODE_TORQUE       = 1,
    OPMODE_FREQUENCY    = 2,
    OPMODE_DC_VOLTAGE   = 3,
    OPMODE_PID          = 4,
    OPMODE_SPECIAL      = 5,
    OPMODE_SCALAR       = 6,
    OPMODE_VECTOR       = 7,
    OPMODE_NONE         = 0xFF,
} operating_mode_t;

typedef enum {
    OP_STATE_INACTIVE   = 0,
    OP_STATE_STOPPED    = 1,
    OP_STATE_RUNNING    = 2,
    OP_STATE_FAULTED    = 3,
    OP_STATE_RAMPING    = 4,
    OP_STATE_HOLDING    = 5,
} op_state_t;

typedef struct {
    uint8_t          initialized;
    operating_mode_t active_mode;
    operating_mode_t requested_mode;
    op_state_t       drive_state;
    uint8_t          mode_change_pending;
    uint8_t          mode_change_allowed;
    uint8_t          pid_set1_active;
    uint8_t          pid_set2_active;
    int32_t          speed_ref_rpm;
    int32_t          torque_ref_nm;
    int32_t          frequency_ref_hz;
    int32_t          dc_voltage_ref_v;
    int32_t          pid_setpoint;
    int32_t          pid_feedback;
    int32_t          pid_output;
    int32_t          special_cmd;
    uint32_t         last_mode_change_tick;
} operating_modes_state_t;

void operating_modes_init(operating_modes_state_t *state);
void operating_modes_update(operating_modes_state_t *state);
operating_mode_t operating_mode_select(operating_modes_state_t *state,
                                         operating_mode_t mode);
operating_mode_t operating_mode_get_current(operating_modes_state_t *state);

#endif
