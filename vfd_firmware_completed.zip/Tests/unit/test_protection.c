#include <assert.h>
#include <string.h>
#include <stdio.h>
#include <stdint.h>

static int tests_passed = 0;
static int tests_failed = 0;

#define CHECK(cond) do { \
    if (!(cond)) { \
        printf("  FAIL: %s:%d: %s\n", __FILE__, __LINE__, #cond); \
        tests_failed++; \
    } else { \
        tests_passed++; \
    } \
} while (0)

/* --------------------------------------------------------------------------
 * Protection data structures (mirrors protection.c internals)
 * -------------------------------------------------------------------------- */
#define PROT_FAULT_HISTORY_DEPTH 16

typedef enum {
    PROT_FAULT_OVERCURRENT   = 0x0001,
    PROT_FAULT_OVERVOLTAGE   = 0x0002,
    PROT_FAULT_UNDERVOLTAGE  = 0x0004,
    PROT_FAULT_OVERTEMP      = 0x0008,
    PROT_FAULT_OVERLOAD      = 0x0010,
    PROT_FAULT_EARTH         = 0x0020,
    PROT_FAULT_SHORT_CIRCUIT = 0x0040,
    PROT_FAULT_PHASE_LOSS    = 0x0080,
    PROT_FAULT_THERMAL       = 0x0100,
    PROT_FAULT_COM_LOSS      = 0x0200,
    PROT_FAULT_ENCODER       = 0x0400,
    PROT_FAULT_STO           = 0x0800,
    PROT_FAULT_EMERG_STOP    = 0x1000,
    PROT_FAULT_USER_LOAD     = 0x2000,
    PROT_FAULT_CABLE_THERM   = 0x4000,
    PROT_FAULT_HARDWARE      = 0x8000,
} prot_fault_code_t;

typedef struct {
    uint32_t timestamp;
    uint16_t fault_code;
    uint16_t fault_data;
} prot_fault_entry_t;

typedef struct {
    prot_fault_entry_t history[PROT_FAULT_HISTORY_DEPTH];
    uint8_t write_index;
    uint8_t count;
    uint32_t sys_tick_ms;
    uint8_t initialized;
} prot_state_t;

/* --------------------------------------------------------------------------
 * Motor thermal model state
 * -------------------------------------------------------------------------- */
#define MOTOR_TC_HEATING_MS    120000
#define MOTOR_TC_COOLING_MS    240000

typedef struct {
    uint16_t motor_nom_current_mA;
    uint8_t  fault_limit_pct;
    uint8_t  warning_limit_pct;
    uint32_t thermal_level;
    uint32_t current_sq_accum;
    uint8_t  fault_active;
    uint8_t  warning_active;
    uint32_t last_update_ms;
} mtp_internal_t;

/* --------------------------------------------------------------------------
 * Motor overload trip curve state
 * -------------------------------------------------------------------------- */
#define OL_CLASS_5_TRIP   5000
#define OL_CLASS_10_TRIP  10000
#define OL_CLASS_20_TRIP  20000
#define OL_CLASS_30_TRIP  30000

typedef struct {
    uint16_t motor_rated_current_mA;
    uint8_t  trip_class;
    uint16_t overload_level_mA;
    uint32_t integration_accum;
    uint32_t trip_threshold;
    uint8_t  trip_active;
    uint8_t  warning_active;
    uint32_t last_current_mA;
} olp_internal_t;

/* --------------------------------------------------------------------------
 * Auto fault reset state
 * -------------------------------------------------------------------------- */
#define AFR_MAX_RETRIES      3
#define AFR_RESET_DELAY_MS   5000
#define AFR_RETRY_WINDOW_MS  60000

typedef struct {
    uint8_t  enabled;
    uint8_t  max_retries;
    uint32_t reset_delay_ms;
    uint32_t retry_window_ms;
    uint8_t  retry_count;
    uint32_t timer_ms;
    uint32_t window_timer_ms;
    uint8_t  in_reset_sequence;
    uint8_t  reset_pending;
    uint16_t last_fault_word;
    uint8_t  initialized;
} afr_state_t;

/* --------------------------------------------------------------------------
 * Protection: fault detection
 * -------------------------------------------------------------------------- */
static uint16_t prot_fault_detect(uint16_t current_raw, uint16_t voltage_raw,
                                   uint16_t temp_raw, uint16_t overload,
                                   uint16_t sto_status, uint16_t em_stop,
                                   uint16_t encoder_stat, uint16_t com_status,
                                   uint8_t motor_thermal_pct, uint8_t cable_thermal_pct,
                                   uint8_t user_load_ok)
{
    uint16_t fault_word = 0;

    if (current_raw > 20000)             fault_word |= PROT_FAULT_OVERCURRENT;
    if (voltage_raw > 24000)             fault_word |= PROT_FAULT_OVERVOLTAGE;
    if (voltage_raw < 8000)              fault_word |= PROT_FAULT_UNDERVOLTAGE;
    if (temp_raw > 1500)                 fault_word |= PROT_FAULT_OVERTEMP;
    if (overload > 1200)                 fault_word |= PROT_FAULT_OVERLOAD;
    if (current_raw > 35000)             fault_word |= PROT_FAULT_SHORT_CIRCUIT;
    if (motor_thermal_pct >= 100)        fault_word |= PROT_FAULT_THERMAL;
    if (cable_thermal_pct >= 100)        fault_word |= PROT_FAULT_CABLE_THERM;
    if (com_status == 0)                 fault_word |= PROT_FAULT_COM_LOSS;
    if (encoder_stat != 0)               fault_word |= PROT_FAULT_ENCODER;
    if (sto_status != 0)                 fault_word |= PROT_FAULT_STO;
    if (em_stop != 0)                    fault_word |= PROT_FAULT_EMERG_STOP;
    if (user_load_ok == 0)               fault_word |= PROT_FAULT_USER_LOAD;

    return fault_word;
}

/* --------------------------------------------------------------------------
 * Protection: fault history
 * -------------------------------------------------------------------------- */
static void prot_push_history(prot_state_t *p, uint16_t fault_code)
{
    uint8_t idx = p->write_index;
    p->history[idx].timestamp = p->sys_tick_ms;
    p->history[idx].fault_code = fault_code;
    p->history[idx].fault_data = 0;
    p->write_index = (uint8_t)((idx + 1) & (PROT_FAULT_HISTORY_DEPTH - 1));
    if (p->count < PROT_FAULT_HISTORY_DEPTH) {
        p->count++;
    }
}

static const prot_fault_entry_t *prot_fault_history(prot_state_t *p, uint8_t index)
{
    if (index >= p->count) return NULL;
    uint8_t actual = (uint8_t)((p->write_index - p->count + index) & (PROT_FAULT_HISTORY_DEPTH - 1));
    return &p->history[actual];
}

/* --------------------------------------------------------------------------
 * Protection: init
 * -------------------------------------------------------------------------- */
static void prot_init(prot_state_t *p)
{
    (void)p;
    /* Stub - not used in these tests */
}

/* --------------------------------------------------------------------------
 * Motor thermal model step
 * -------------------------------------------------------------------------- */
static void motor_thermal_model_step(mtp_internal_t *mtp)
{
    uint32_t heating_tc = MOTOR_TC_HEATING_MS;
    uint32_t cooling_tc = MOTOR_TC_COOLING_MS;
    uint32_t nom_sq = (uint32_t)mtp->motor_nom_current_mA * mtp->motor_nom_current_mA;

    uint32_t current_sq = mtp->current_sq_accum;
    uint32_t rise_target;
    if (current_sq > 0 && nom_sq > 0) {
        rise_target = (current_sq * 1000) / nom_sq;
    } else {
        rise_target = 0;
    }

    uint32_t prev_level = mtp->thermal_level;
    if (rise_target > prev_level) {
        uint32_t diff = rise_target - prev_level;
        uint32_t delta = (diff * 10) / heating_tc;
        if (delta < 1) delta = 1;
        mtp->thermal_level += delta;
        if (mtp->thermal_level > rise_target) mtp->thermal_level = rise_target;
    } else {
        uint32_t diff = prev_level - rise_target;
        uint32_t delta = (diff * 10) / cooling_tc;
        if (delta < 1) delta = 1;
        if (delta > mtp->thermal_level) {
            mtp->thermal_level = 0;
        } else {
            mtp->thermal_level -= delta;
        }
    }

    uint8_t thermal_pct = (uint8_t)(mtp->thermal_level / 10);
    mtp->fault_active = (thermal_pct >= mtp->fault_limit_pct) ? 1 : 0;
    mtp->warning_active = (thermal_pct >= mtp->warning_limit_pct && thermal_pct < mtp->fault_limit_pct) ? 1 : 0;
}

/* --------------------------------------------------------------------------
 * Motor overload check
 * -------------------------------------------------------------------------- */
static void motor_overload_check(olp_internal_t *olp)
{
    switch (olp->trip_class) {
        case 5:  olp->trip_threshold = OL_CLASS_5_TRIP;  break;
        case 10: olp->trip_threshold = OL_CLASS_10_TRIP; break;
        case 20: olp->trip_threshold = OL_CLASS_20_TRIP; break;
        case 30: olp->trip_threshold = OL_CLASS_30_TRIP; break;
        default: olp->trip_threshold = OL_CLASS_10_TRIP; break;
    }

    uint32_t rated = olp->motor_rated_current_mA;
    uint32_t current = olp->last_current_mA;

    if (current <= rated) {
        if (olp->integration_accum > 0) {
            uint32_t decay = rated * 10;
            if (decay > olp->integration_accum) {
                olp->integration_accum = 0;
            } else {
                olp->integration_accum -= decay;
            }
        }
    } else {
        uint32_t overload_sq = (current - rated) * (current - rated);
        uint32_t rated_sq = rated * rated;
        if (rated_sq > 0) {
            uint32_t inc = (overload_sq * 100) / rated_sq;
            olp->integration_accum += inc;
        }
    }

    if (olp->integration_accum >= olp->trip_threshold) {
        olp->trip_active = 1;
    }

    if (olp->integration_accum >= (olp->trip_threshold * 8 / 10)) {
        olp->warning_active = 1;
    } else {
        olp->warning_active = 0;
    }
}

/* --------------------------------------------------------------------------
 * Auto fault reset attempt
 * -------------------------------------------------------------------------- */
static uint8_t auto_reset_attempt(afr_state_t *afr, uint16_t current_fault)
{
    afr->last_fault_word = current_fault;

    if (!afr->enabled) {
        afr->reset_pending = 0;
        return 0;
    }

    if (current_fault != 0 && !afr->in_reset_sequence) {
        afr->in_reset_sequence = 1;
        afr->timer_ms = 0;
        afr->reset_pending = 0;
    }

    if (afr->in_reset_sequence) {
        if (current_fault == 0) {
            afr->in_reset_sequence = 0;
            afr->timer_ms = 0;
            afr->reset_pending = 0;
            return 0;
        }

        if (afr->retry_count >= afr->max_retries) {
            afr->in_reset_sequence = 0;
            afr->timer_ms = 0;
            afr->reset_pending = 0;
            return 0;
        }

        afr->timer_ms++;
        if (afr->timer_ms >= afr->reset_delay_ms) {
            afr->reset_pending = 1;
            afr->timer_ms = 0;
        }
    }

    return afr->reset_pending;
}

static void auto_reset_confirm_executed(afr_state_t *afr)
{
    if (afr->reset_pending) {
        afr->retry_count++;
        afr->reset_pending = 0;
        afr->window_timer_ms = 0;
    }
}

static void auto_reset_window_tick(afr_state_t *afr)
{
    if (afr->retry_count > 0) {
        afr->window_timer_ms++;
        if (afr->window_timer_ms >= afr->retry_window_ms) {
            afr->retry_count = 0;
            afr->window_timer_ms = 0;
        }
    }
}

/* --------------------------------------------------------------------------
 * Helpers
 * -------------------------------------------------------------------------- */
static prot_state_t prot;
static mtp_internal_t mtp;
static olp_internal_t olp;
static afr_state_t afr;

static void setup(void)
{
    memset(&prot, 0, sizeof(prot));
    prot.initialized = 1;
    memset(&mtp, 0, sizeof(mtp));
    mtp.motor_nom_current_mA = 10000;
    mtp.fault_limit_pct = 100;
    mtp.warning_limit_pct = 95;
    memset(&olp, 0, sizeof(olp));
    olp.motor_rated_current_mA = 10000;
    olp.trip_class = 10;
    olp.trip_threshold = OL_CLASS_10_TRIP;
    memset(&afr, 0, sizeof(afr));
    afr.initialized = 1;
    afr.enabled = 1;
    afr.max_retries = AFR_MAX_RETRIES;
    afr.reset_delay_ms = AFR_RESET_DELAY_MS;
    afr.retry_window_ms = AFR_RETRY_WINDOW_MS;
}

/* --------------------------------------------------------------------------
 * Tests: fault detection
 * -------------------------------------------------------------------------- */
void test_fault_detect_no_faults(void)
{
    uint16_t fw = prot_fault_detect(10000, 15000, 500, 500,
                                     0, 0, 0, 1, 50, 50, 1);
    CHECK(fw == 0);
}

void test_fault_detect_overcurrent(void)
{
    uint16_t fw = prot_fault_detect(21000, 15000, 500, 500,
                                     0, 0, 0, 1, 50, 50, 1);
    CHECK(fw & PROT_FAULT_OVERCURRENT);
}

void test_fault_detect_overvoltage(void)
{
    uint16_t fw = prot_fault_detect(10000, 25000, 500, 500,
                                     0, 0, 0, 1, 50, 50, 1);
    CHECK(fw & PROT_FAULT_OVERVOLTAGE);
}

void test_fault_detect_undervoltage(void)
{
    uint16_t fw = prot_fault_detect(10000, 7000, 500, 500,
                                     0, 0, 0, 1, 50, 50, 1);
    CHECK(fw & PROT_FAULT_UNDERVOLTAGE);
}

void test_fault_detect_overtemp(void)
{
    uint16_t fw = prot_fault_detect(10000, 15000, 1600, 500,
                                     0, 0, 0, 1, 50, 50, 1);
    CHECK(fw & PROT_FAULT_OVERTEMP);
}

void test_fault_detect_short_circuit(void)
{
    uint16_t fw = prot_fault_detect(36000, 15000, 500, 500,
                                     0, 0, 0, 1, 50, 50, 1);
    CHECK(fw & PROT_FAULT_SHORT_CIRCUIT);
}

void test_fault_detect_thermal(void)
{
    uint16_t fw = prot_fault_detect(10000, 15000, 500, 500,
                                     0, 0, 0, 1, 100, 50, 1);
    CHECK(fw & PROT_FAULT_THERMAL);
}

void test_fault_detect_cable_thermal(void)
{
    uint16_t fw = prot_fault_detect(10000, 15000, 500, 500,
                                     0, 0, 0, 1, 50, 100, 1);
    CHECK(fw & PROT_FAULT_CABLE_THERM);
}

void test_fault_detect_com_loss(void)
{
    uint16_t fw = prot_fault_detect(10000, 15000, 500, 500,
                                     0, 0, 0, 0, 50, 50, 1);
    CHECK(fw & PROT_FAULT_COM_LOSS);
}

void test_fault_detect_encoder(void)
{
    uint16_t fw = prot_fault_detect(10000, 15000, 500, 500,
                                     0, 0, 0x01, 1, 50, 50, 1);
    CHECK(fw & PROT_FAULT_ENCODER);
}

void test_fault_detect_sto(void)
{
    uint16_t fw = prot_fault_detect(10000, 15000, 500, 500,
                                     1, 0, 0, 1, 50, 50, 1);
    CHECK(fw & PROT_FAULT_STO);
}

void test_fault_detect_emerg_stop(void)
{
    uint16_t fw = prot_fault_detect(10000, 15000, 500, 500,
                                     0, 1, 0, 1, 50, 50, 1);
    CHECK(fw & PROT_FAULT_EMERG_STOP);
}

void test_fault_detect_user_load(void)
{
    uint16_t fw = prot_fault_detect(10000, 15000, 500, 500,
                                     0, 0, 0, 1, 50, 50, 0);
    CHECK(fw & PROT_FAULT_USER_LOAD);
}

void test_fault_detect_multiple(void)
{
    uint16_t fw = prot_fault_detect(25000, 25000, 1600, 500,
                                     0, 0, 0, 0, 50, 50, 1);
    CHECK(fw & PROT_FAULT_OVERCURRENT);
    CHECK(fw & PROT_FAULT_OVERVOLTAGE);
    CHECK(fw & PROT_FAULT_OVERTEMP);
    CHECK(fw & PROT_FAULT_COM_LOSS);
}

void test_fault_detect_threshold_boundary(void)
{
    uint16_t fw_ok = prot_fault_detect(20000, 15000, 500, 500,
                                        0, 0, 0, 1, 50, 50, 1);
    CHECK(!(fw_ok & PROT_FAULT_OVERCURRENT));

    uint16_t fw_bad = prot_fault_detect(20001, 15000, 500, 500,
                                         0, 0, 0, 1, 50, 50, 1);
    CHECK(fw_bad & PROT_FAULT_OVERCURRENT);
}

/* --------------------------------------------------------------------------
 * Tests: fault history
 * -------------------------------------------------------------------------- */
void test_fault_history_empty(void)
{
    setup();
    CHECK(prot.count == 0);
    CHECK(prot_fault_history(&prot, 0) == NULL);
}

void test_fault_history_single_entry(void)
{
    setup();
    prot.sys_tick_ms = 1000;
    prot_push_history(&prot, PROT_FAULT_OVERCURRENT);
    CHECK(prot.count == 1);
    const prot_fault_entry_t *e = prot_fault_history(&prot, 0);
    CHECK(e != NULL);
    CHECK(e->fault_code == PROT_FAULT_OVERCURRENT);
    CHECK(e->timestamp == 1000);
}

void test_fault_history_multiple_entries(void)
{
    setup();
    prot.sys_tick_ms = 100;
    prot_push_history(&prot, PROT_FAULT_OVERCURRENT);
    prot.sys_tick_ms = 200;
    prot_push_history(&prot, PROT_FAULT_OVERTEMP);
    prot.sys_tick_ms = 300;
    prot_push_history(&prot, PROT_FAULT_STO);

    CHECK(prot.count == 3);

    const prot_fault_entry_t *e0 = prot_fault_history(&prot, 0);
    const prot_fault_entry_t *e1 = prot_fault_history(&prot, 1);
    const prot_fault_entry_t *e2 = prot_fault_history(&prot, 2);

    CHECK(e0->fault_code == PROT_FAULT_OVERCURRENT);
    CHECK(e1->fault_code == PROT_FAULT_OVERTEMP);
    CHECK(e2->fault_code == PROT_FAULT_STO);
}

void test_fault_history_wraparound(void)
{
    setup();
    for (int i = 0; i < 20; i++) {
        prot.sys_tick_ms = (uint32_t)(i * 10);
        prot_push_history(&prot, (uint16_t)(i + 1));
    }
    CHECK(prot.count == PROT_FAULT_HISTORY_DEPTH);

    const prot_fault_entry_t *first = prot_fault_history(&prot, 0);
    CHECK(first != NULL);
    CHECK(first->fault_code == 5);
}

void test_fault_history_out_of_range(void)
{
    setup();
    prot_push_history(&prot, PROT_FAULT_OVERCURRENT);
    CHECK(prot_fault_history(&prot, 1) == NULL);
    CHECK(prot_fault_history(&prot, 5) == NULL);
}

/* --------------------------------------------------------------------------
 * Tests: motor thermal model
 * -------------------------------------------------------------------------- */
void test_thermal_init(void)
{
    setup();
    CHECK(mtp.motor_nom_current_mA == 10000);
    CHECK(mtp.fault_limit_pct == 100);
    CHECK(mtp.warning_limit_pct == 95);
    CHECK(mtp.thermal_level == 0);
    CHECK(mtp.fault_active == 0);
    CHECK(mtp.warning_active == 0);
}

void test_thermal_heating_at_rated(void)
{
    setup();
    mtp.current_sq_accum = 10000u * 10000u;

    for (int i = 0; i < 500; i++) {
        motor_thermal_model_step(&mtp);
    }
    uint8_t pct = (uint8_t)(mtp.thermal_level / 10);
    CHECK(pct > 0);
}

void test_thermal_cooling(void)
{
    setup();
    mtp.thermal_level = 800;
    mtp.current_sq_accum = 0;

    motor_thermal_model_step(&mtp);
    CHECK(mtp.thermal_level < 800);
}

void test_thermal_fault_set(void)
{
    setup();
    mtp.thermal_level = 1010;
    mtp.fault_limit_pct = 100;
    mtp.current_sq_accum = 5000u * 5000u;

    motor_thermal_model_step(&mtp);
    CHECK(mtp.fault_active == 1);
}

void test_thermal_fault_not_set_below_limit(void)
{
    setup();
    mtp.thermal_level = 900;
    mtp.fault_limit_pct = 100;
    mtp.current_sq_accum = 5000u * 5000u;

    motor_thermal_model_step(&mtp);
    CHECK(mtp.fault_active == 0);
}

void test_thermal_warning_set(void)
{
    setup();
    mtp.thermal_level = 960;
    mtp.fault_limit_pct = 100;
    mtp.warning_limit_pct = 95;
    mtp.current_sq_accum = 5000u * 5000u;

    motor_thermal_model_step(&mtp);
    CHECK(mtp.warning_active == 1);
    CHECK(mtp.fault_active == 0);
}

void test_thermal_reset(void)
{
    setup();
    mtp.thermal_level = 1500;
    mtp.fault_active = 1;
    mtp.warning_active = 1;

    mtp.thermal_level = 0;
    mtp.fault_active = 0;
    mtp.warning_active = 0;

    CHECK(mtp.thermal_level == 0);
    CHECK(mtp.fault_active == 0);
    CHECK(mtp.warning_active == 0);
}

void test_thermal_heating_rate(void)
{
    setup();
    mtp.current_sq_accum = 20000u * 20000u;

    motor_thermal_model_step(&mtp);
    uint32_t level1 = mtp.thermal_level;
    motor_thermal_model_step(&mtp);
    uint32_t level2 = mtp.thermal_level;
    CHECK(level2 > level1);
}

/* --------------------------------------------------------------------------
 * Tests: motor overload trip curves
 * -------------------------------------------------------------------------- */
void test_overload_init(void)
{
    setup();
    CHECK(olp.motor_rated_current_mA == 10000);
    CHECK(olp.trip_class == 10);
    CHECK(olp.trip_threshold == OL_CLASS_10_TRIP);
    CHECK(olp.trip_active == 0);
    CHECK(olp.integration_accum == 0);
}

void test_overload_no_trip_at_rated(void)
{
    setup();
    olp.last_current_mA = 10000;
    for (int i = 0; i < 500; i++) {
        motor_overload_check(&olp);
    }
    CHECK(olp.trip_active == 0);
}

void test_overload_trip_after_high_current(void)
{
    setup();
    olp.motor_rated_current_mA = 10000;
    olp.trip_class = 10;
    olp.last_current_mA = 20000;

    for (int i = 0; i < 3000; i++) {
        motor_overload_check(&olp);
        if (olp.trip_active) break;
    }
    CHECK(olp.trip_active == 1);
}

void test_overload_trip_class_5(void)
{
    setup();
    olp.motor_rated_current_mA = 10000;
    olp.trip_class = 5;
    olp.last_current_mA = 20000;

    motor_overload_check(&olp);
    CHECK(olp.trip_threshold == OL_CLASS_5_TRIP);
}

void test_overload_trip_class_30(void)
{
    setup();
    olp.motor_rated_current_mA = 10000;
    olp.trip_class = 30;
    olp.last_current_mA = 20000;

    motor_overload_check(&olp);
    CHECK(olp.trip_threshold == OL_CLASS_30_TRIP);
}

void test_overload_decay_below_rated(void)
{
    setup();
    olp.last_current_mA = 20000;
    for (int i = 0; i < 100; i++) {
        motor_overload_check(&olp);
    }
    uint32_t accum_before = olp.integration_accum;
    CHECK(accum_before > 0);

    olp.last_current_mA = 5000;
    for (int i = 0; i < 200; i++) {
        motor_overload_check(&olp);
    }
    CHECK(olp.integration_accum < accum_before);
}

void test_overload_reset(void)
{
    setup();
    olp.last_current_mA = 30000;
    for (int i = 0; i < 2000; i++) {
        motor_overload_check(&olp);
        if (olp.trip_active) break;
    }
    CHECK(olp.trip_active == 1);

    olp.integration_accum = 0;
    olp.trip_active = 0;
    olp.warning_active = 0;
    CHECK(olp.trip_active == 0);
}

void test_overload_warning_before_trip(void)
{
    setup();
    olp.motor_rated_current_mA = 10000;
    olp.trip_class = 10;
    olp.last_current_mA = 20000;

    for (int i = 0; i < 5000; i++) {
        motor_overload_check(&olp);
        if (olp.warning_active) break;
    }
    CHECK(olp.warning_active == 1);
}

void test_overload_trip_class_default(void)
{
    setup();
    olp.trip_class = 99;
    motor_overload_check(&olp);
    CHECK(olp.trip_threshold == OL_CLASS_10_TRIP);
}

/* --------------------------------------------------------------------------
 * Tests: auto reset logic
 * -------------------------------------------------------------------------- */
void test_auto_reset_init(void)
{
    setup();
    CHECK(afr.enabled == 1);
    CHECK(afr.max_retries == AFR_MAX_RETRIES);
    CHECK(afr.reset_delay_ms == AFR_RESET_DELAY_MS);
    CHECK(afr.retry_window_ms == AFR_RETRY_WINDOW_MS);
    CHECK(afr.retry_count == 0);
    CHECK(afr.in_reset_sequence == 0);
    CHECK(afr.reset_pending == 0);
}

void test_auto_reset_disabled(void)
{
    setup();
    afr.enabled = 0;

    uint8_t pending = auto_reset_attempt(&afr, PROT_FAULT_OVERCURRENT);
    CHECK(pending == 0);
    CHECK(afr.in_reset_sequence == 0);
}

void test_auto_reset_sequence_starts(void)
{
    setup();
    uint8_t p = auto_reset_attempt(&afr, PROT_FAULT_OVERCURRENT);
    CHECK(p == 0);
    CHECK(afr.in_reset_sequence == 1);
}

void test_auto_reset_no_action_on_clear(void)
{
    setup();
    auto_reset_attempt(&afr, PROT_FAULT_OVERCURRENT);
    uint8_t p = auto_reset_attempt(&afr, 0);
    CHECK(p == 0);
    CHECK(afr.in_reset_sequence == 0);
}

void test_auto_reset_pending_after_delay(void)
{
    setup();
    auto_reset_attempt(&afr, PROT_FAULT_OVERCURRENT);

    for (uint32_t i = 0; i < AFR_RESET_DELAY_MS; i++) {
        auto_reset_attempt(&afr, PROT_FAULT_OVERCURRENT);
    }
    CHECK(afr.reset_pending == 1);
}

void test_auto_reset_max_retries(void)
{
    setup();
    for (int r = 0; r < AFR_MAX_RETRIES; r++) {
        uint16_t fault = PROT_FAULT_OVERCURRENT;
        uint8_t pending = 0;
        while (!pending) {
            pending = auto_reset_attempt(&afr, fault);
        }
        CHECK(pending == 1);
        auto_reset_confirm_executed(&afr);
        afr.in_reset_sequence = 0;
        afr.timer_ms = 0;
        afr.reset_pending = 0;
    }

    uint8_t p = auto_reset_attempt(&afr, PROT_FAULT_OVERCURRENT);
    CHECK(p == 0);
    CHECK(afr.retry_count == AFR_MAX_RETRIES);

    for (uint32_t i = 0; i < AFR_RESET_DELAY_MS + 1; i++) {
        p = auto_reset_attempt(&afr, PROT_FAULT_OVERCURRENT);
    }
    CHECK(p == 0);
}

void test_auto_reset_retry_window_expires(void)
{
    setup();
    auto_reset_attempt(&afr, PROT_FAULT_OVERCURRENT);
    for (uint32_t i = 0; i < AFR_RESET_DELAY_MS + 1; i++) {
        auto_reset_attempt(&afr, PROT_FAULT_OVERCURRENT);
    }
    auto_reset_confirm_executed(&afr);
    afr.in_reset_sequence = 0;
    afr.timer_ms = 0;
    afr.reset_pending = 0;

    CHECK(afr.retry_count == 1);

    for (uint32_t i = 0; i < AFR_RETRY_WINDOW_MS + 1; i++) {
        auto_reset_window_tick(&afr);
    }
    CHECK(afr.retry_count == 0);
}

void test_auto_reset_confirm_executed(void)
{
    setup();
    auto_reset_attempt(&afr, PROT_FAULT_OVERCURRENT);
    for (uint32_t i = 0; i < AFR_RESET_DELAY_MS; i++) {
        auto_reset_attempt(&afr, PROT_FAULT_OVERCURRENT);
    }
    CHECK(afr.reset_pending == 1);

    auto_reset_confirm_executed(&afr);
    CHECK(afr.reset_pending == 0);
    CHECK(afr.retry_count == 1);
    CHECK(afr.window_timer_ms == 0);
}

void test_auto_reset_disable_clears_state(void)
{
    setup();
    auto_reset_attempt(&afr, PROT_FAULT_OVERCURRENT);
    for (uint32_t i = 0; i < AFR_RESET_DELAY_MS; i++) {
        auto_reset_attempt(&afr, PROT_FAULT_OVERCURRENT);
    }

    afr.enabled = 0;
    auto_reset_attempt(&afr, PROT_FAULT_OVERCURRENT);
    CHECK(afr.reset_pending == 0);
}

/* --------------------------------------------------------------------------
 * Tests: fault latching
 * -------------------------------------------------------------------------- */
void test_fault_latch_persists(void)
{
    setup();
    uint16_t fw_initial = prot_fault_detect(21000, 15000, 500, 500,
                                             0, 0, 0, 1, 50, 50, 1);
    CHECK(fw_initial & PROT_FAULT_OVERCURRENT);

    uint16_t fw_after = prot_fault_detect(10000, 15000, 500, 500,
                                           0, 0, 0, 1, 50, 50, 1);
    CHECK(fw_after == 0);
}

void test_fault_detect_thermal_edge(void)
{
    uint16_t fw_ok = prot_fault_detect(10000, 15000, 500, 500,
                                        0, 0, 0, 1, 99, 50, 1);
    CHECK(!(fw_ok & PROT_FAULT_THERMAL));

    uint16_t fw_fault = prot_fault_detect(10000, 15000, 500, 500,
                                           0, 0, 0, 1, 100, 50, 1);
    CHECK(fw_fault & PROT_FAULT_THERMAL);
}

/* --------------------------------------------------------------------------
 * Test runner
 * -------------------------------------------------------------------------- */
int main(void)
{
    printf("=== Protection Unit Tests ===\n");

    test_fault_detect_no_faults();
    test_fault_detect_overcurrent();
    test_fault_detect_overvoltage();
    test_fault_detect_undervoltage();
    test_fault_detect_overtemp();
    test_fault_detect_short_circuit();
    test_fault_detect_thermal();
    test_fault_detect_cable_thermal();
    test_fault_detect_com_loss();
    test_fault_detect_encoder();
    test_fault_detect_sto();
    test_fault_detect_emerg_stop();
    test_fault_detect_user_load();
    test_fault_detect_multiple();
    test_fault_detect_threshold_boundary();
    test_fault_history_empty();
    test_fault_history_single_entry();
    test_fault_history_multiple_entries();
    test_fault_history_wraparound();
    test_fault_history_out_of_range();
    test_thermal_init();
    test_thermal_heating_at_rated();
    test_thermal_cooling();
    test_thermal_fault_set();
    test_thermal_fault_not_set_below_limit();
    test_thermal_warning_set();
    test_thermal_reset();
    test_thermal_heating_rate();
    test_overload_init();
    test_overload_no_trip_at_rated();
    test_overload_trip_after_high_current();
    test_overload_trip_class_5();
    test_overload_trip_class_30();
    test_overload_decay_below_rated();
    test_overload_reset();
    test_overload_warning_before_trip();
    test_overload_trip_class_default();
    test_auto_reset_init();
    test_auto_reset_disabled();
    test_auto_reset_sequence_starts();
    test_auto_reset_no_action_on_clear();
    test_auto_reset_pending_after_delay();
    test_auto_reset_max_retries();
    test_auto_reset_retry_window_expires();
    test_auto_reset_confirm_executed();
    test_auto_reset_disable_clears_state();
    test_fault_latch_persists();
    test_fault_detect_thermal_edge();

    int total_checks = tests_passed + tests_failed;
    printf("\nResults: %d/%d checks passed, %d failed\n",
           tests_passed, total_checks, tests_failed);
    return tests_failed > 0 ? 1 : 0;
}
