#include <assert.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <stdint.h>

static int tests_passed = 0;
static int tests_failed = 0;

#define CHECK(cond) do { \
    if (!(cond)) { \
        printf("  FAIL: %s:%d: %s\n", __FILE__, __LINE__, #cond); \
        tests_failed++; \
    } else { \
        tests_passed++; \
    } \
} while (0)

/* --------------------------------------------------------------------------
 * PID controller data structures
 * -------------------------------------------------------------------------- */
typedef enum {
    PID_DIR_DIRECT  = 0,
    PID_DIR_REVERSE = 1,
} pid_direction_t;

typedef struct {
    float kp;
    float ki;
    float kd;
    float ts;
    float setpoint;
    float prev_setpoint;
    float setpoint_rate_limit;
    float max_output;
    float min_output;
    float max_integral;
    float min_integral;
    float integral;
    float prev_error;
    float prev_measurement;
    float output;
    float derivative_filter_coeff;
    float filtered_derivative;
    pid_direction_t direction;
    uint8_t initialized;
    uint8_t integral_hold;
    uint8_t derivative_on_measurement;
} pid_controller_t;

/* --------------------------------------------------------------------------
 * PID init
 * -------------------------------------------------------------------------- */
static void pid_init(pid_controller_t *pid)
{
    memset(pid, 0, sizeof(*pid));
    pid->kp = 1.0f;
    pid->ki = 0.5f;
    pid->kd = 0.1f;
    pid->ts = 0.001f;
    pid->max_output = 100.0f;
    pid->min_output = -100.0f;
    pid->max_integral = 100.0f;
    pid->min_integral = -100.0f;
    pid->direction = PID_DIR_DIRECT;
    pid->derivative_on_measurement = 1;
    pid->derivative_filter_coeff = 0.1f;
    pid->integral_hold = 0;
    pid->initialized = 1;
}

/* --------------------------------------------------------------------------
 * PID compute (standard parallel form with anti-windup and D-on-PV)
 * -------------------------------------------------------------------------- */
static float pid_compute(pid_controller_t *pid, float setpoint, float measurement)
{
    float error = setpoint - measurement;

    float p_term = pid->kp * error;

    float i_term = pid->integral;
    if (!pid->integral_hold) {
        i_term += pid->ki * pid->ts * error;
    }

    float d_term;
    if (pid->derivative_on_measurement) {
        d_term = -pid->kd * (measurement - pid->prev_measurement) / pid->ts;
        d_term = pid->filtered_derivative * (1.0f - pid->derivative_filter_coeff)
                 + d_term * pid->derivative_filter_coeff;
        pid->filtered_derivative = d_term;
    } else {
        d_term = pid->kd * (error - pid->prev_error) / pid->ts;
    }

    float output = p_term + i_term + d_term;

    if (output > pid->max_output) {
        output = pid->max_output;
        if (error > 0.0f && pid->ki > 0.0f) {
            i_term = pid->max_output - p_term - d_term;
            if (i_term > pid->max_integral) i_term = pid->max_integral;
            if (i_term < pid->min_integral) i_term = pid->min_integral;
        }
    } else if (output < pid->min_output) {
        output = pid->min_output;
        if (error < 0.0f && pid->ki > 0.0f) {
            i_term = pid->min_output - p_term - d_term;
            if (i_term > pid->max_integral) i_term = pid->max_integral;
            if (i_term < pid->min_integral) i_term = pid->min_integral;
        }
    }

    if (i_term > pid->max_integral) i_term = pid->max_integral;
    if (i_term < pid->min_integral) i_term = pid->min_integral;

    pid->integral = i_term;
    pid->prev_error = error;
    pid->prev_measurement = measurement;
    pid->output = output;

    return output;
}

/* --------------------------------------------------------------------------
 * PID reset
 * -------------------------------------------------------------------------- */
static void pid_reset(pid_controller_t *pid)
{
    pid->integral = 0.0f;
    pid->prev_error = 0.0f;
    pid->prev_measurement = 0.0f;
    pid->output = 0.0f;
    pid->filtered_derivative = 0.0f;
}

/* --------------------------------------------------------------------------
 * Setup / teardown
 * -------------------------------------------------------------------------- */
static pid_controller_t pid;

static void setup(void)
{
    pid_init(&pid);
}

/* --------------------------------------------------------------------------
 * Tests: initialization
 * -------------------------------------------------------------------------- */
void test_pid_init(void)
{
    setup();
    CHECK(pid.initialized == 1);
    CHECK(pid.kp == 1.0f);
    CHECK(pid.ki == 0.5f);
    CHECK(pid.kd == 0.1f);
    CHECK(pid.ts == 0.001f);
    CHECK(pid.max_output == 100.0f);
    CHECK(pid.min_output == -100.0f);
    CHECK(pid.max_integral == 100.0f);
    CHECK(pid.min_integral == -100.0f);
    CHECK(pid.integral == 0.0f);
    CHECK(pid.output == 0.0f);
    CHECK(pid.direction == PID_DIR_DIRECT);
    CHECK(pid.derivative_on_measurement == 1);
    CHECK(pid.integral_hold == 0);
}

/* --------------------------------------------------------------------------
 * Tests: proportional term
 * -------------------------------------------------------------------------- */
void test_p_only_positive_error(void)
{
    setup();
    pid.ki = 0.0f;
    pid.kd = 0.0f;

    float out = pid_compute(&pid, 50.0f, 0.0f);
    CHECK(fabsf(out - 50.0f) < 0.01f);
    CHECK(fabsf(pid.integral) < 0.001f);
}

void test_p_only_negative_error(void)
{
    setup();
    pid.ki = 0.0f;
    pid.kd = 0.0f;

    float out = pid_compute(&pid, -30.0f, 0.0f);
    CHECK(fabsf(out - (-30.0f)) < 0.01f);
}

void test_p_only_zero_error(void)
{
    setup();
    pid.ki = 0.0f;
    pid.kd = 0.0f;
    float out = pid_compute(&pid, 10.0f, 10.0f);
    CHECK(fabsf(out) < 0.001f);
}

void test_p_only_with_gain(void)
{
    setup();
    pid.kp = 2.5f;
    pid.ki = 0.0f;
    pid.kd = 0.0f;

    float out = pid_compute(&pid, 10.0f, 0.0f);
    CHECK(fabsf(out - 25.0f) < 0.01f);
}

/* --------------------------------------------------------------------------
 * Tests: integral term
 * -------------------------------------------------------------------------- */
void test_i_only_integration(void)
{
    setup();
    pid.kp = 0.0f;
    pid.ki = 1.0f;
    pid.kd = 0.0f;
    pid.ts = 0.1f;

    float out = pid_compute(&pid, 10.0f, 0.0f);
    CHECK(fabsf(out - 1.0f) < 0.01f);

    out = pid_compute(&pid, 10.0f, 0.0f);
    CHECK(fabsf(out - 2.0f) < 0.01f);

    out = pid_compute(&pid, 10.0f, 0.0f);
    CHECK(fabsf(out - 3.0f) < 0.01f);
}

void test_i_only_zero_ki(void)
{
    setup();
    pid.kp = 0.0f;
    pid.ki = 0.0f;
    pid.kd = 0.0f;

    float out = pid_compute(&pid, 50.0f, 0.0f);
    CHECK(fabsf(out) < 0.001f);
}

void test_i_only_integral_hold(void)
{
    setup();
    pid.kp = 0.0f;
    pid.ki = 1.0f;
    pid.kd = 0.0f;
    pid.ts = 0.1f;

    pid_compute(&pid, 10.0f, 0.0f);
    float after_first = pid.integral;

    pid.integral_hold = 1;
    pid_compute(&pid, 10.0f, 0.0f);
    CHECK(fabsf(pid.integral - after_first) < 0.001f);

    pid.integral_hold = 0;
    pid_compute(&pid, 10.0f, 0.0f);
    CHECK(pid.integral > after_first);
}

void test_i_only_reset(void)
{
    setup();
    pid.kp = 0.0f;
    pid.ki = 1.0f;
    pid.kd = 0.0f;

    pid_compute(&pid, 10.0f, 0.0f);
    pid_compute(&pid, 10.0f, 0.0f);
    CHECK(pid.integral > 0.0f);

    pid_reset(&pid);
    CHECK(pid.integral == 0.0f);
    CHECK(pid.output == 0.0f);
}

/* --------------------------------------------------------------------------
 * Tests: derivative term
 * -------------------------------------------------------------------------- */
void test_d_only_decreasing_error(void)
{
    setup();
    pid.kp = 0.0f;
    pid.ki = 0.0f;
    pid.kd = 1.0f;
    pid.ts = 0.1f;
    pid.derivative_on_measurement = 0;
    pid.derivative_filter_coeff = 1.0f;

    float out = pid_compute(&pid, 10.0f, 0.0f);
    CHECK(fabsf(out - 100.0f) < 0.1f);

    out = pid_compute(&pid, 20.0f, 0.0f);
    CHECK(fabsf(out - 100.0f) < 0.1f);
}

void test_d_on_measurement(void)
{
    setup();
    pid.kp = 0.0f;
    pid.ki = 0.0f;
    pid.kd = 1.0f;
    pid.ts = 0.1f;
    pid.derivative_on_measurement = 1;
    pid.derivative_filter_coeff = 1.0f;

    float out = pid_compute(&pid, 10.0f, 0.0f);
    CHECK(fabsf(out) < 0.01f);

    out = pid_compute(&pid, 10.0f, 5.0f);
    CHECK(out < 0.0f);
}

void test_d_filtering(void)
{
    setup();
    pid.kp = 0.0f;
    pid.ki = 0.0f;
    pid.kd = 1.0f;
    pid.ts = 0.1f;
    pid.derivative_on_measurement = 1;
    pid.derivative_filter_coeff = 0.3f;

    pid_compute(&pid, 10.0f, 0.0f);
    float out1 = pid_compute(&pid, 10.0f, 5.0f);
    float out2 = pid_compute(&pid, 10.0f, 5.0f);
    CHECK(fabsf(out2) < fabsf(out1));
}

/* --------------------------------------------------------------------------
 * Tests: anti-windup
 * -------------------------------------------------------------------------- */
void test_anti_windup_positive_saturation(void)
{
    setup();
    pid.kp = 1.0f;
    pid.ki = 1.0f;
    pid.kd = 0.0f;
    pid.ts = 0.1f;
    pid.max_output = 10.0f;
    pid.max_integral = 10.0f;

    for (int i = 0; i < 100; i++) {
        pid_compute(&pid, 100.0f, 0.0f);
    }

    CHECK(pid.integral <= pid.max_integral);
    CHECK(pid.output == pid.max_output);
}

void test_anti_windup_negative_saturation(void)
{
    setup();
    pid.kp = 1.0f;
    pid.ki = 1.0f;
    pid.kd = 0.0f;
    pid.ts = 0.1f;
    pid.min_output = -10.0f;
    pid.min_integral = -10.0f;

    for (int i = 0; i < 100; i++) {
        pid_compute(&pid, -100.0f, 0.0f);
    }

    CHECK(pid.integral >= pid.min_integral);
    CHECK(pid.output == pid.min_output);
}

void test_anti_windup_recovery(void)
{
    setup();
    pid.kp = 1.0f;
    pid.ki = 1.0f;
    pid.kd = 0.0f;
    pid.ts = 0.1f;
    pid.max_output = 10.0f;
    pid.max_integral = 10.0f;

    for (int i = 0; i < 50; i++) {
        pid_compute(&pid, 100.0f, 0.0f);
    }
    CHECK(pid.output == pid.max_output);

    pid_compute(&pid, -10.0f, 0.0f);
    CHECK(pid.output < pid.max_output);
}

void test_anti_windup_no_ki(void)
{
    setup();
    pid.kp = 10.0f;
    pid.ki = 0.0f;
    pid.kd = 0.0f;
    pid.max_output = 5.0f;

    float out = pid_compute(&pid, 10.0f, 0.0f);
    CHECK(out == pid.max_output);
    CHECK(pid.integral == 0.0f);
}

/* --------------------------------------------------------------------------
 * Tests: output clamping
 * -------------------------------------------------------------------------- */
void test_output_clamp_max(void)
{
    setup();
    pid.kp = 1000.0f;
    pid.ki = 0.0f;
    pid.kd = 0.0f;
    pid.max_output = 50.0f;

    float out = pid_compute(&pid, 100.0f, 0.0f);
    CHECK(out == 50.0f);
}

void test_output_clamp_min(void)
{
    setup();
    pid.kp = 1000.0f;
    pid.ki = 0.0f;
    pid.kd = 0.0f;
    pid.min_output = -50.0f;

    float out = pid_compute(&pid, -100.0f, 0.0f);
    CHECK(out == -50.0f);
}

void test_output_clamp_symmetric(void)
{
    setup();
    pid.kp = 10.0f;
    pid.ki = 0.0f;
    pid.kd = 0.0f;
    pid.max_output = 80.0f;
    pid.min_output = -80.0f;

    float out_pos = pid_compute(&pid, 100.0f, 0.0f);
    CHECK(out_pos == 80.0f);
    pid_reset(&pid);

    float out_neg = pid_compute(&pid, -100.0f, 0.0f);
    CHECK(out_neg == -80.0f);
}

void test_output_clamp_within_bounds(void)
{
    setup();
    pid.kp = 1.0f;
    pid.ki = 0.0f;
    pid.kd = 0.0f;
    pid.max_output = 100.0f;
    pid.min_output = -100.0f;

    float out = pid_compute(&pid, 25.0f, 0.0f);
    CHECK(out == 25.0f);
}

/* --------------------------------------------------------------------------
 * Tests: setpoint changes
 * -------------------------------------------------------------------------- */
void test_setpoint_step_up(void)
{
    setup();
    pid.kp = 1.0f;
    pid.ki = 0.5f;
    pid.kd = 0.1f;
    pid.ts = 0.01f;

    pid_compute(&pid, 0.0f, 0.0f);
    float out1 = pid_compute(&pid, 10.0f, 0.0f);
    CHECK(out1 > 0.0f);
}

void test_setpoint_step_down(void)
{
    setup();
    pid.kp = 1.0f;
    pid.ki = 0.5f;
    pid.kd = 0.1f;

    for (int i = 0; i < 20; i++) {
        pid_compute(&pid, 10.0f, 10.0f);
    }

    float out = pid_compute(&pid, 5.0f, 10.0f);
    CHECK(out < 0.0f);
}

void test_setpoint_zero_crossover(void)
{
    setup();
    pid.kp = 1.0f;
    pid.ki = 0.5f;
    pid.kd = 0.0f;

    pid_compute(&pid, 10.0f, 0.0f);
    pid_compute(&pid, 10.0f, 0.0f);
    float out = pid_compute(&pid, -10.0f, 0.0f);
    CHECK(out < 0.0f);
}

void test_setpoint_tracking(void)
{
    setup();
    pid.kp = 1.0f;
    pid.ki = 5.0f;
    pid.kd = 0.0f;
    pid.ts = 0.001f;

    float measurement = 0.0f;
    for (int i = 0; i < 3000; i++) {
        float out = pid_compute(&pid, 1.0f, measurement);
        measurement += out * pid.ts * 0.5f;
    }

    CHECK(fabsf(measurement - 1.0f) < 0.1f);
}

/* --------------------------------------------------------------------------
 * Tests: PID + I + D complete response
 * -------------------------------------------------------------------------- */
void test_pid_full_response(void)
{
    setup();
    pid.kp = 2.0f;
    pid.ki = 0.5f;
    pid.kd = 0.05f;
    pid.ts = 0.01f;
    pid.derivative_on_measurement = 0;
    pid.derivative_filter_coeff = 1.0f;

    float sp = 10.0f;
    float pv = 0.0f;
    float prev_pv = 0.0f;

    for (int i = 0; i < 100; i++) {
        float out_i = pid_compute(&pid, sp, pv);
        pv += out_i * 0.01f;
        prev_pv = pv;
        (void)prev_pv;
    }

    CHECK(fabsf(pv - sp) < 2.0f);
}

void test_pid_steady_state(void)
{
    setup();
    pid.kp = 2.0f;
    pid.ki = 10.0f;
    pid.kd = 0.0f;
    pid.ts = 0.001f;
    pid.max_output = 500.0f;
    pid.min_output = -500.0f;
    pid.max_integral = 500.0f;
    pid.min_integral = -500.0f;

    float measurement = 0.0f;
    for (int i = 0; i < 10000; i++) {
        float out = pid_compute(&pid, 5.0f, measurement);
        measurement += out * pid.ts * 0.2f;
        if (fabsf(measurement - 5.0f) < 0.1f && i > 1000) break;
    }

    CHECK(fabsf(measurement - 5.0f) < 0.1f);
}

/* --------------------------------------------------------------------------
 * Test runner
 * -------------------------------------------------------------------------- */
int main(void)
{
    printf("=== PID Controller Unit Tests ===\n");

    test_pid_init();
    test_p_only_positive_error();
    test_p_only_negative_error();
    test_p_only_zero_error();
    test_p_only_with_gain();
    test_i_only_integration();
    test_i_only_zero_ki();
    test_i_only_integral_hold();
    test_i_only_reset();
    test_d_only_decreasing_error();
    test_d_on_measurement();
    test_d_filtering();
    test_anti_windup_positive_saturation();
    test_anti_windup_negative_saturation();
    test_anti_windup_recovery();
    test_anti_windup_no_ki();
    test_output_clamp_max();
    test_output_clamp_min();
    test_output_clamp_symmetric();
    test_output_clamp_within_bounds();
    test_setpoint_step_up();
    test_setpoint_step_down();
    test_setpoint_zero_crossover();
    test_setpoint_tracking();
    test_pid_full_response();
    test_pid_steady_state();

    int total_checks = tests_passed + tests_failed;
    printf("\nResults: %d/%d checks passed, %d failed\n",
           tests_passed, total_checks, tests_failed);
    return tests_failed > 0 ? 1 : 0;
}
