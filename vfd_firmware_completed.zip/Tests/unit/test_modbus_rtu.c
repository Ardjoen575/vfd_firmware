#include <assert.h>
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

static int tests_passed = 0;
static int tests_failed = 0;

#define CHECK(cond) do { \
    if (!(cond)) { \
        printf("  FAIL: %s:%d: %s\n", __FILE__, __LINE__, #cond); \
        tests_failed++; \
    } else { \
        tests_passed++; \
    } \
} while (0)

/* --------------------------------------------------------------------------
 * CRC-16 (Modbus) reference implementation
 * -------------------------------------------------------------------------- */
static uint16_t modbus_crc16(const uint8_t *buf, int len)
{
    uint16_t crc = 0xFFFF;
    for (int i = 0; i < len; i++) {
        crc ^= (uint16_t)buf[i];
        for (int j = 0; j < 8; j++) {
            if (crc & 0x0001) {
                crc = (crc >> 1) ^ 0xA001;
            } else {
                crc >>= 1;
            }
        }
    }
    return crc;
}

static int modbus_crc_check(const uint8_t *frame, int frame_len)
{
    if (frame_len < 4) return 0;
    uint16_t computed = modbus_crc16(frame, frame_len - 2);
    uint16_t received  = (uint16_t)frame[frame_len - 1] << 8 | frame[frame_len - 2];
    return computed == received;
}

static void modbus_append_crc(uint8_t *frame, int data_len)
{
    uint16_t crc = modbus_crc16(frame, data_len);
    frame[data_len]     = (uint8_t)(crc & 0xFF);
    frame[data_len + 1] = (uint8_t)(crc >> 8);
}

/* --------------------------------------------------------------------------
 * Modbus function codes
 * -------------------------------------------------------------------------- */
#define MB_FC_READ_COILS              0x01
#define MB_FC_READ_DISCRETE_INPUTS    0x02
#define MB_FC_READ_HOLDING_REGISTERS  0x03
#define MB_FC_READ_INPUT_REGISTERS    0x04
#define MB_FC_WRITE_SINGLE_COIL       0x05
#define MB_FC_WRITE_SINGLE_REGISTER   0x06
#define MB_FC_WRITE_MULTIPLE_COILS    0x0F
#define MB_FC_WRITE_MULTIPLE_REGISTERS 0x10

/* --------------------------------------------------------------------------
 * Modbus exception codes
 * -------------------------------------------------------------------------- */
#define MB_EX_ILLEGAL_FUNCTION       0x01
#define MB_EX_ILLEGAL_DATA_ADDRESS   0x02
#define MB_EX_ILLEGAL_DATA_VALUE     0x03
#define MB_EX_SLAVE_DEVICE_FAILURE   0x04

/* --------------------------------------------------------------------------
 * Modbus register file (virtual device)
 * -------------------------------------------------------------------------- */
#define NUM_COILS              256
#define NUM_DISCRETE_INPUTS    256
#define NUM_HOLDING_REGISTERS  512
#define NUM_INPUT_REGISTERS    256

static uint8_t  coil_bits[NUM_COILS / 8];
static uint8_t  discrete_bits[NUM_DISCRETE_INPUTS / 8];
static uint16_t holding_regs[NUM_HOLDING_REGISTERS];
static uint16_t input_regs[NUM_INPUT_REGISTERS];

static void mb_regfile_reset(void)
{
    memset(coil_bits, 0, sizeof(coil_bits));
    memset(discrete_bits, 0, sizeof(discrete_bits));
    memset(holding_regs, 0, sizeof(holding_regs));
    memset(input_regs, 0, sizeof(input_regs));

    for (int i = 0; i < NUM_INPUT_REGISTERS; i++) {
        input_regs[i] = (uint16_t)(i * 10);
    }
}

static void mb_set_coil(int addr, int val)
{
    if (addr < 0 || addr >= NUM_COILS) return;
    int byte_idx = addr / 8;
    int bit_idx  = addr % 8;
    if (val) coil_bits[byte_idx] |= (1 << bit_idx);
    else     coil_bits[byte_idx] &= ~(1 << bit_idx);
}

static int mb_get_coil(int addr)
{
    if (addr < 0 || addr >= NUM_COILS) return 0;
    int byte_idx = addr / 8;
    int bit_idx  = addr % 8;
    return (coil_bits[byte_idx] >> bit_idx) & 1;
}

static int mb_get_discrete(int addr)
{
    if (addr < 0 || addr >= NUM_DISCRETE_INPUTS) return 0;
    int byte_idx = addr / 8;
    int bit_idx  = addr % 8;
    return (discrete_bits[byte_idx] >> bit_idx) & 1;
}

static void mb_set_discrete(int addr, int val)
{
    if (addr < 0 || addr >= NUM_DISCRETE_INPUTS) return;
    int byte_idx = addr / 8;
    int bit_idx  = addr % 8;
    if (val) discrete_bits[byte_idx] |= (1 << bit_idx);
    else     discrete_bits[byte_idx] &= ~(1 << bit_idx);
}

/* --------------------------------------------------------------------------
 * Response builder
 * -------------------------------------------------------------------------- */
static uint8_t resp_buf[256];
static int resp_len = 0;

static void mb_build_exception(uint8_t slave, uint8_t func, uint8_t ex_code)
{
    resp_buf[0] = slave;
    resp_buf[1] = func | 0x80;
    resp_buf[2] = ex_code;
    resp_len = 3;
    modbus_append_crc(resp_buf, resp_len);
    resp_len += 2;
}

/* --------------------------------------------------------------------------
 * Request handler (simulates modbus_handle_request)
 * -------------------------------------------------------------------------- */
static void mb_handle_request(const uint8_t *frame, int frame_len)
{
    resp_len = 0;
    if (frame_len < 4) return;

    uint8_t slave = frame[0];
    uint8_t func  = frame[1];

    if (!modbus_crc_check(frame, frame_len)) {
        return;
    }

    int data_len = frame_len - 4;

    switch (func) {
    case MB_FC_READ_COILS: {
        if (data_len < 4) { mb_build_exception(slave, func, MB_EX_ILLEGAL_DATA_ADDRESS); return; }
        uint16_t start_addr = (uint16_t)(frame[2] << 8) | frame[3];
        uint16_t quantity   = (uint16_t)(frame[4] << 8) | frame[5];
        if (quantity < 1 || quantity > 2000) { mb_build_exception(slave, func, MB_EX_ILLEGAL_DATA_VALUE); return; }
        if (start_addr + quantity > NUM_COILS) { mb_build_exception(slave, func, MB_EX_ILLEGAL_DATA_ADDRESS); return; }
        int byte_count = (quantity + 7) / 8;
        resp_buf[0] = slave;
        resp_buf[1] = func;
        resp_buf[2] = (uint8_t)byte_count;
        for (int i = 0; i < byte_count; i++) {
            uint8_t b = 0;
            for (int j = 0; j < 8; j++) {
                int bit_idx = i * 8 + j;
                if (bit_idx >= (int)quantity) break;
                if (mb_get_coil(start_addr + bit_idx)) b |= (1 << j);
            }
            resp_buf[3 + i] = b;
        }
        resp_len = 3 + byte_count;
        modbus_append_crc(resp_buf, resp_len);
        resp_len += 2;
        break;
    }
    case MB_FC_READ_DISCRETE_INPUTS: {
        if (data_len < 4) { mb_build_exception(slave, func, MB_EX_ILLEGAL_DATA_ADDRESS); return; }
        uint16_t start_addr = (uint16_t)(frame[2] << 8) | frame[3];
        uint16_t quantity   = (uint16_t)(frame[4] << 8) | frame[5];
        if (quantity < 1 || quantity > 2000) { mb_build_exception(slave, func, MB_EX_ILLEGAL_DATA_VALUE); return; }
        if (start_addr + quantity > NUM_DISCRETE_INPUTS) { mb_build_exception(slave, func, MB_EX_ILLEGAL_DATA_ADDRESS); return; }
        int byte_count = (quantity + 7) / 8;
        resp_buf[0] = slave;
        resp_buf[1] = func;
        resp_buf[2] = (uint8_t)byte_count;
        for (int i = 0; i < byte_count; i++) {
            uint8_t b = 0;
            for (int j = 0; j < 8; j++) {
                int bit_idx = i * 8 + j;
                if (bit_idx >= (int)quantity) break;
                if (mb_get_discrete(start_addr + bit_idx)) b |= (1 << j);
            }
            resp_buf[3 + i] = b;
        }
        resp_len = 3 + byte_count;
        modbus_append_crc(resp_buf, resp_len);
        resp_len += 2;
        break;
    }
    case MB_FC_READ_HOLDING_REGISTERS: {
        if (data_len < 4) { mb_build_exception(slave, func, MB_EX_ILLEGAL_DATA_ADDRESS); return; }
        uint16_t start_addr = (uint16_t)(frame[2] << 8) | frame[3];
        uint16_t quantity   = (uint16_t)(frame[4] << 8) | frame[5];
        if (quantity < 1 || quantity > 125) { mb_build_exception(slave, func, MB_EX_ILLEGAL_DATA_VALUE); return; }
        if (start_addr + quantity > NUM_HOLDING_REGISTERS) { mb_build_exception(slave, func, MB_EX_ILLEGAL_DATA_ADDRESS); return; }
        int byte_count = quantity * 2;
        resp_buf[0] = slave;
        resp_buf[1] = func;
        resp_buf[2] = (uint8_t)byte_count;
        for (int i = 0; i < (int)quantity; i++) {
            resp_buf[3 + i * 2]     = (uint8_t)(holding_regs[start_addr + i] >> 8);
            resp_buf[3 + i * 2 + 1] = (uint8_t)(holding_regs[start_addr + i] & 0xFF);
        }
        resp_len = 3 + byte_count;
        modbus_append_crc(resp_buf, resp_len);
        resp_len += 2;
        break;
    }
    case MB_FC_READ_INPUT_REGISTERS: {
        if (data_len < 4) { mb_build_exception(slave, func, MB_EX_ILLEGAL_DATA_ADDRESS); return; }
        uint16_t start_addr = (uint16_t)(frame[2] << 8) | frame[3];
        uint16_t quantity   = (uint16_t)(frame[4] << 8) | frame[5];
        if (quantity < 1 || quantity > 125) { mb_build_exception(slave, func, MB_EX_ILLEGAL_DATA_VALUE); return; }
        if (start_addr + quantity > NUM_INPUT_REGISTERS) { mb_build_exception(slave, func, MB_EX_ILLEGAL_DATA_ADDRESS); return; }
        int byte_count = quantity * 2;
        resp_buf[0] = slave;
        resp_buf[1] = func;
        resp_buf[2] = (uint8_t)byte_count;
        for (int i = 0; i < (int)quantity; i++) {
            resp_buf[3 + i * 2]     = (uint8_t)(input_regs[start_addr + i] >> 8);
            resp_buf[3 + i * 2 + 1] = (uint8_t)(input_regs[start_addr + i] & 0xFF);
        }
        resp_len = 3 + byte_count;
        modbus_append_crc(resp_buf, resp_len);
        resp_len += 2;
        break;
    }
    case MB_FC_WRITE_SINGLE_COIL: {
        if (data_len < 4) { mb_build_exception(slave, func, MB_EX_ILLEGAL_DATA_ADDRESS); return; }
        uint16_t addr   = (uint16_t)(frame[2] << 8) | frame[3];
        uint16_t val    = (uint16_t)(frame[4] << 8) | frame[5];
        if (addr >= NUM_COILS) { mb_build_exception(slave, func, MB_EX_ILLEGAL_DATA_ADDRESS); return; }
        if (val != 0x0000 && val != 0xFF00) { mb_build_exception(slave, func, MB_EX_ILLEGAL_DATA_VALUE); return; }
        mb_set_coil(addr, val == 0xFF00 ? 1 : 0);
        memcpy(resp_buf, frame, frame_len);
        resp_len = frame_len;
        break;
    }
    case MB_FC_WRITE_SINGLE_REGISTER: {
        if (data_len < 4) { mb_build_exception(slave, func, MB_EX_ILLEGAL_DATA_ADDRESS); return; }
        uint16_t addr   = (uint16_t)(frame[2] << 8) | frame[3];
        uint16_t val    = (uint16_t)(frame[4] << 8) | frame[5];
        if (addr >= NUM_HOLDING_REGISTERS) { mb_build_exception(slave, func, MB_EX_ILLEGAL_DATA_ADDRESS); return; }
        holding_regs[addr] = val;
        memcpy(resp_buf, frame, frame_len);
        resp_len = frame_len;
        break;
    }
    case MB_FC_WRITE_MULTIPLE_COILS: {
        if (data_len < 5) { mb_build_exception(slave, func, MB_EX_ILLEGAL_DATA_ADDRESS); return; }
        uint16_t start_addr = (uint16_t)(frame[2] << 8) | frame[3];
        uint16_t quantity   = (uint16_t)(frame[4] << 8) | frame[5];
        uint8_t  byte_count = frame[6];
        if (quantity < 1 || quantity > 1968) { mb_build_exception(slave, func, MB_EX_ILLEGAL_DATA_VALUE); return; }
        if (start_addr + quantity > NUM_COILS) { mb_build_exception(slave, func, MB_EX_ILLEGAL_DATA_ADDRESS); return; }
        if (byte_count != ((quantity + 7) / 8)) { mb_build_exception(slave, func, MB_EX_ILLEGAL_DATA_VALUE); return; }
        for (int i = 0; i < (int)quantity; i++) {
            int b = frame[7 + i / 8];
            mb_set_coil(start_addr + i, (b >> (i % 8)) & 1);
        }
        resp_buf[0] = slave;
        resp_buf[1] = func;
        resp_buf[2] = (uint8_t)(start_addr >> 8);
        resp_buf[3] = (uint8_t)(start_addr & 0xFF);
        resp_buf[4] = (uint8_t)(quantity >> 8);
        resp_buf[5] = (uint8_t)(quantity & 0xFF);
        resp_len = 6;
        modbus_append_crc(resp_buf, resp_len);
        resp_len += 2;
        break;
    }
    case MB_FC_WRITE_MULTIPLE_REGISTERS: {
        if (data_len < 5) { mb_build_exception(slave, func, MB_EX_ILLEGAL_DATA_ADDRESS); return; }
        uint16_t start_addr = (uint16_t)(frame[2] << 8) | frame[3];
        uint16_t quantity   = (uint16_t)(frame[4] << 8) | frame[5];
        uint8_t  byte_count = frame[6];
        if (quantity < 1 || quantity > 123) { mb_build_exception(slave, func, MB_EX_ILLEGAL_DATA_VALUE); return; }
        if (start_addr + quantity > NUM_HOLDING_REGISTERS) { mb_build_exception(slave, func, MB_EX_ILLEGAL_DATA_ADDRESS); return; }
        if (byte_count != quantity * 2) { mb_build_exception(slave, func, MB_EX_ILLEGAL_DATA_VALUE); return; }
        for (int i = 0; i < (int)quantity; i++) {
            holding_regs[start_addr + i] = (uint16_t)(frame[7 + i * 2] << 8) | frame[7 + i * 2 + 1];
        }
        resp_buf[0] = slave;
        resp_buf[1] = func;
        resp_buf[2] = (uint8_t)(start_addr >> 8);
        resp_buf[3] = (uint8_t)(start_addr & 0xFF);
        resp_buf[4] = (uint8_t)(quantity >> 8);
        resp_buf[5] = (uint8_t)(quantity & 0xFF);
        resp_len = 6;
        modbus_append_crc(resp_buf, resp_len);
        resp_len += 2;
        break;
    }
    default:
        mb_build_exception(slave, func, MB_EX_ILLEGAL_FUNCTION);
        break;
    }
}

/* --------------------------------------------------------------------------
 * Test helpers
 * -------------------------------------------------------------------------- */
static void setup(void)
{
    mb_regfile_reset();
    memset(resp_buf, 0, sizeof(resp_buf));
    resp_len = 0;
}

/* --------------------------------------------------------------------------
 * Tests: CRC calculation
 * -------------------------------------------------------------------------- */
void test_crc_zero_length(void)
{
    uint8_t buf[] = { 0x01 };
    uint16_t crc = modbus_crc16(buf, 1);
    CHECK(crc != 0xFFFF);
}

void test_crc_known_vector(void)
{
    uint8_t buf[] = { 0x01, 0x03, 0x00, 0x00, 0x00, 0x01 };
    uint16_t crc = modbus_crc16(buf, 6);
    uint16_t expected = 0x0A84;
    CHECK(crc == expected);
}

void test_crc_check_valid(void)
{
    uint8_t buf[] = { 0x01, 0x03, 0x00, 0x00, 0x00, 0x01, 0x84, 0x0A };
    CHECK(modbus_crc_check(buf, 8));
}

void test_crc_check_invalid(void)
{
    uint8_t buf[] = { 0x01, 0x03, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00 };
    CHECK(!modbus_crc_check(buf, 8));
}

void test_crc_append_and_check(void)
{
    uint8_t buf[8] = { 0x01, 0x04, 0x00, 0x10, 0x00, 0x02, 0x00, 0x00 };
    modbus_append_crc(buf, 6);
    CHECK(modbus_crc_check(buf, 8));
}

void test_crc_different_data(void)
{
    uint8_t a[8] = { 0x01, 0x01, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00 };
    uint8_t b[8] = { 0x01, 0x01, 0x00, 0x10, 0x00, 0x10, 0x00, 0x00 };
    modbus_append_crc(a, 6);
    modbus_append_crc(b, 6);

    CHECK(a[6] != b[6] || a[7] != b[7]);
}

/* --------------------------------------------------------------------------
 * Tests: Function code dispatch
 * -------------------------------------------------------------------------- */
void test_fc_read_coils(void)
{
    setup();
    mb_set_coil(0, 1);
    mb_set_coil(3, 1);
    mb_set_coil(7, 1);

    uint8_t req[8] = { 0x01, 0x01, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00 };
    modbus_append_crc(req, 6);

    mb_handle_request(req, 8);
    CHECK(resp_len > 0);
    CHECK(resp_buf[0] == 0x01);
    CHECK(resp_buf[1] == 0x01);
    CHECK(resp_buf[2] == 0x01);
    CHECK(resp_buf[3] == 0x89);
}

void test_fc_read_discrete_inputs(void)
{
    setup();
    mb_set_discrete(5, 1);
    mb_set_discrete(6, 1);

    uint8_t req[8] = { 0x01, 0x02, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00 };
    modbus_append_crc(req, 6);

    mb_handle_request(req, 8);
    CHECK(resp_len > 0);
    CHECK(resp_buf[0] == 0x01);
    CHECK(resp_buf[1] == 0x02);
    CHECK(resp_buf[2] == 0x02);
}

void test_fc_read_holding_registers(void)
{
    setup();
    holding_regs[0] = 0x1234;
    holding_regs[1] = 0x5678;

    uint8_t req[8] = { 0x01, 0x03, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00 };
    modbus_append_crc(req, 6);

    mb_handle_request(req, 8);
    CHECK(resp_len > 0);
    CHECK(resp_buf[0] == 0x01);
    CHECK(resp_buf[1] == 0x03);
    CHECK(resp_buf[2] == 0x04);
    CHECK(resp_buf[3] == 0x12);
    CHECK(resp_buf[4] == 0x34);
    CHECK(resp_buf[5] == 0x56);
    CHECK(resp_buf[6] == 0x78);
}

void test_fc_read_input_registers(void)
{
    setup();

    uint8_t req[8] = { 0x01, 0x04, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00 };
    modbus_append_crc(req, 6);

    mb_handle_request(req, 8);
    CHECK(resp_len > 0);
    CHECK(resp_buf[0] == 0x01);
    CHECK(resp_buf[1] == 0x04);
    CHECK(resp_buf[2] == 0x02);
    CHECK(resp_buf[3] == 0x00);
    CHECK(resp_buf[4] == 0x00);
}

void test_fc_write_single_coil_on(void)
{
    setup();
    uint8_t req[8] = { 0x01, 0x05, 0x00, 0x0A, 0xFF, 0x00, 0x00, 0x00 };
    modbus_append_crc(req, 6);

    mb_handle_request(req, 8);
    CHECK(resp_len > 0);
    CHECK(mb_get_coil(10) == 1);
}

void test_fc_write_single_coil_off(void)
{
    setup();
    mb_set_coil(10, 1);

    uint8_t req[8] = { 0x01, 0x05, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x00 };
    modbus_append_crc(req, 6);

    mb_handle_request(req, 8);
    CHECK(resp_len > 0);
    CHECK(mb_get_coil(10) == 0);
}

void test_fc_write_single_register(void)
{
    setup();
    uint8_t req[8] = { 0x01, 0x06, 0x00, 0x05, 0xAB, 0xCD, 0x00, 0x00 };
    modbus_append_crc(req, 6);

    mb_handle_request(req, 8);
    CHECK(resp_len > 0);
    CHECK(holding_regs[5] == 0xABCD);
}

void test_fc_write_multiple_coils(void)
{
    setup();
    uint8_t req[11] = { 0x01, 0x0F, 0x00, 0x00, 0x00, 0x0A, 0x02, 0xCD, 0x01, 0x00, 0x00 };
    modbus_append_crc(req, 9);

    mb_handle_request(req, 11);
    CHECK(resp_len > 0);
    CHECK(mb_get_coil(0) == 1);
    CHECK(mb_get_coil(1) == 0);
    CHECK(mb_get_coil(2) == 1);
    CHECK(mb_get_coil(3) == 1);
    CHECK(mb_get_coil(7) == 1);
    CHECK(mb_get_coil(8) == 1);
}

void test_fc_write_multiple_registers(void)
{
    setup();
    uint8_t req[13] = {
        0x01, 0x10, 0x00, 0x02, 0x00, 0x02, 0x04,
        0x11, 0x22, 0x33, 0x44, 0x00, 0x00
    };
    modbus_append_crc(req, 11);

    mb_handle_request(req, 13);
    CHECK(resp_len > 0);
    CHECK(holding_regs[2] == 0x1122);
    CHECK(holding_regs[3] == 0x3344);
}

/* --------------------------------------------------------------------------
 * Tests: Exception handling
 * -------------------------------------------------------------------------- */
void test_exception_illegal_function(void)
{
    setup();
    uint8_t req[8] = { 0x01, 0x7F, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00 };
    modbus_append_crc(req, 6);

    mb_handle_request(req, 8);
    CHECK(resp_len > 0);
    CHECK(resp_buf[1] == (0x7F | 0x80));
    CHECK(resp_buf[2] == MB_EX_ILLEGAL_FUNCTION);
}

void test_exception_illegal_data_address_coil(void)
{
    setup();
    uint8_t req[8] = { 0x01, 0x01, 0x01, 0x00, 0x00, 0x01, 0x00, 0x00 };
    modbus_append_crc(req, 6);

    mb_handle_request(req, 8);
    CHECK(resp_len > 0);
    CHECK(resp_buf[1] == (0x01 | 0x80));
    CHECK(resp_buf[2] == MB_EX_ILLEGAL_DATA_ADDRESS);
}

void test_exception_illegal_data_value_write_coil(void)
{
    setup();
    uint8_t req[8] = { 0x01, 0x05, 0x00, 0x00, 0xAA, 0x55, 0x00, 0x00 };
    modbus_append_crc(req, 6);

    mb_handle_request(req, 8);
    CHECK(resp_len > 0);
    CHECK(resp_buf[1] == (0x05 | 0x80));
    CHECK(resp_buf[2] == MB_EX_ILLEGAL_DATA_VALUE);
}

void test_exception_read_coils_zero_quantity(void)
{
    setup();
    uint8_t req[8] = { 0x01, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
    modbus_append_crc(req, 6);

    mb_handle_request(req, 8);
    CHECK(resp_len > 0);
    CHECK(resp_buf[1] == (0x01 | 0x80));
}

void test_bad_crc_no_response(void)
{
    setup();
    uint8_t req[8] = { 0x01, 0x03, 0x00, 0x00, 0x00, 0x01, 0xFF, 0xFF };

    resp_len = 0;
    mb_handle_request(req, 8);
    CHECK(resp_len == 0);
}

/* --------------------------------------------------------------------------
 * Tests: Frame parsing edge cases
 * -------------------------------------------------------------------------- */
void test_frame_too_short(void)
{
    setup();
    uint8_t req[3] = { 0x01, 0x03, 0x00 };

    resp_len = 0;
    mb_handle_request(req, 3);
    CHECK(resp_len == 0);
}

void test_coil_read_range_boundary(void)
{
    setup();
    uint8_t req[8] = { 0x01, 0x01, 0x00, 0xFE, 0x00, 0x02, 0x00, 0x00 };
    modbus_append_crc(req, 6);

    mb_handle_request(req, 8);
    CHECK(resp_len > 0);
    CHECK(resp_buf[1] == 0x01);
}

void test_register_read_large_range(void)
{
    setup();
    uint8_t req[8] = { 0x01, 0x03, 0x00, 0x00, 0x00, 0x7D, 0x00, 0x00 };
    modbus_append_crc(req, 6);

    mb_handle_request(req, 8);
    CHECK(resp_len > 0);
    CHECK(resp_buf[1] == 0x03);
    CHECK(resp_buf[2] == 0xFA);
}

void test_read_coils_single_bit(void)
{
    setup();
    mb_set_coil(5, 1);
    uint8_t req[8] = { 0x01, 0x01, 0x00, 0x05, 0x00, 0x01, 0x00, 0x00 };
    modbus_append_crc(req, 6);

    mb_handle_request(req, 8);
    CHECK(resp_len > 0);
    CHECK(resp_buf[1] == 0x01);
    CHECK(resp_buf[2] == 0x01);
    CHECK((resp_buf[3] & 0x01) == 0x01);
}

void test_write_multiple_registers_zero(void)
{
    setup();
    holding_regs[10] = 0xAAAA;
    uint8_t req[9] = { 0x01, 0x10, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x00, 0x00 };
    modbus_append_crc(req, 7);

    mb_handle_request(req, 9);
    CHECK(resp_len > 0);
    CHECK(resp_buf[1] == (0x10 | 0x80));
    CHECK(holding_regs[10] == 0xAAAA);
}

void test_coil_write_invalid_value(void)
{
    setup();
    uint8_t req[8] = { 0x01, 0x05, 0x00, 0x00, 0x55, 0x55, 0x00, 0x00 };
    modbus_append_crc(req, 6);

    mb_handle_request(req, 8);
    CHECK(resp_len > 0);
    CHECK(resp_buf[1] == (0x05 | 0x80));
    CHECK(mb_get_coil(0) == 0);
}

/* --------------------------------------------------------------------------
 * Test runner
 * -------------------------------------------------------------------------- */
int main(void)
{
    printf("=== Modbus RTU Unit Tests ===\n");

    test_crc_zero_length();
    test_crc_known_vector();
    test_crc_check_valid();
    test_crc_check_invalid();
    test_crc_append_and_check();
    test_crc_different_data();
    test_fc_read_coils();
    test_fc_read_discrete_inputs();
    test_fc_read_holding_registers();
    test_fc_read_input_registers();
    test_fc_write_single_coil_on();
    test_fc_write_single_coil_off();
    test_fc_write_single_register();
    test_fc_write_multiple_coils();
    test_fc_write_multiple_registers();
    test_exception_illegal_function();
    test_exception_illegal_data_address_coil();
    test_exception_illegal_data_value_write_coil();
    test_exception_read_coils_zero_quantity();
    test_bad_crc_no_response();
    test_frame_too_short();
    test_coil_read_range_boundary();
    test_register_read_large_range();
    test_read_coils_single_bit();
    test_write_multiple_registers_zero();
    test_coil_write_invalid_value();

    int total_checks = tests_passed + tests_failed;
    printf("\nResults: %d/%d checks passed, %d failed\n",
           tests_passed, total_checks, tests_failed);
    return tests_failed > 0 ? 1 : 0;
}
