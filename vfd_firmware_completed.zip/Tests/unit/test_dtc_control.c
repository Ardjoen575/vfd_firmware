#include <assert.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdint.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif

static int tests_passed = 0;
static int tests_failed = 0;

#define CHECK(cond) do { \
    if (!(cond)) { \
        printf("  FAIL: %s:%d: %s\n", __FILE__, __LINE__, #cond); \
        tests_failed++; \
    } else { \
        tests_passed++; \
    } \
} while (0)

#define CHECK_FLOAT_EQ(a, b, eps) do { \
    float _a = (a); \
    float _b = (b); \
    if (fabsf(_a - _b) > (eps)) { \
        printf("  FAIL: %s:%d: %s == %s  (got %.6f, expected %.6f)\n", __FILE__, __LINE__, #a, #b, _a, _b); \
        tests_failed++; \
    } else { \
        tests_passed++; \
    } \
} while (0)

/* --------------------------------------------------------------------------
 * DTC state and function implementations (inline copy from dtc_control.c)
 * -------------------------------------------------------------------------- */
typedef struct {
    uint8_t initialized;
    float flux_alpha;
    float flux_beta;
    float flux_magnitude;
    float flux_ref;
    float torque_estimated;
    float torque_ref;
    float v_alpha;
    float v_beta;
    float v_dc;
    float i_alpha;
    float i_beta;
    float u_alpha;
    float u_beta;
    float rs;
    float ls;
    float ts;
    float flux_hyst;
    float torque_hyst;
    float flux_hyst_band;
    float torque_hyst_band;
    int sector;
    int switching_state;
    float maximum_flux;
    float rated_torque;
} dtc_control_state_t;

static const float SQRT3_DIV_2  = 0.8660254037844386f;

static const int SWITCHING_TABLE[4][6] = {
    { 5, 6, 2, 1, 4, 5 },
    { 4, 5, 1, 0, 6, 1 },
    { 6, 1, 3, 2, 1, 0 },
    { 1, 0, 4, 3, 0, 0 },
};

static const float VDC_ALPHA[7] = { 0.0f, 0.6667f, 0.3333f, -0.3333f, -0.6667f, -0.3333f, 0.3333f };
static const float VDC_BETA[7]  = { 0.0f, 0.0f, SQRT3_DIV_2, SQRT3_DIV_2, 0.0f, -SQRT3_DIV_2, -SQRT3_DIV_2 };

static void dtc_control_init(dtc_control_state_t *state)
{
    memset(state, 0, sizeof(*state));
    state->initialized = 1;
    state->flux_ref = 1.0f;
    state->torque_ref = 0.0f;
    state->flux_hyst_band = 0.01f;
    state->torque_hyst_band = 0.01f;
    state->rs = 1.0f;
    state->ls = 0.01f;
    state->ts = 0.0001f;
    state->v_dc = 540.0f;
    state->maximum_flux = 1.5f;
    state->rated_torque = 10.0f;
    state->sector = 0;
}

static int find_sector(float f_alpha, float f_beta)
{
    float angle = atan2f(f_beta, f_alpha);
    if (angle < 0.0f) angle += 2.0f * M_PI;
    int sec = (int)(angle / (M_PI / 3.0f));
    if (sec >= 6) sec = 0;
    return sec;
}

static void dtc_flux_estimate(dtc_control_state_t *state)
{
    float u_alpha = state->v_dc * VDC_ALPHA[state->switching_state];
    float u_beta  = state->v_dc * VDC_BETA[state->switching_state];
    float r_drop_alpha = state->rs * state->i_alpha;
    float r_drop_beta  = state->rs * state->i_beta;
    state->flux_alpha += (u_alpha - r_drop_alpha) * state->ts;
    state->flux_beta  += (u_beta  - r_drop_beta)  * state->ts;
    float f_mag_sq = state->flux_alpha * state->flux_alpha + state->flux_beta * state->flux_beta;
    state->flux_magnitude = sqrtf(f_mag_sq > 0.0f ? f_mag_sq : 0.0f);
    float Ls_f = state->ls;
    if (Ls_f < 0.00001f) Ls_f = 0.00001f;
    state->torque_estimated = 1.5f * 1.0f * (
        state->flux_alpha * state->i_beta - state->flux_beta * state->i_alpha
    );
    state->sector = find_sector(state->flux_alpha, state->flux_beta);
}

static void dtc_compute_torque_step(dtc_control_state_t *state)
{
    float flux_err = state->flux_ref - state->flux_magnitude;
    float torque_err = state->torque_ref - state->torque_estimated;
    int flux_idx = (flux_err > state->flux_hyst_band) ? 0 : 1;
    flux_idx = (flux_err < -state->flux_hyst_band) ? 2 : flux_idx;
    int torque_idx = (torque_err > state->torque_hyst_band) ? 0 : 1;
    int table_row;
    if (flux_idx == 0 && torque_idx == 0) table_row = 0;
    else if (flux_idx == 0 && torque_idx == 1) table_row = 1;
    else if (flux_idx == 1 && torque_idx == 0) table_row = 2;
    else table_row = 3;
    state->switching_state = SWITCHING_TABLE[table_row][state->sector];
    state->u_alpha = state->v_dc * VDC_ALPHA[state->switching_state];
    state->u_beta  = state->v_dc * VDC_BETA[state->switching_state];
}

static void dtc_control_update(dtc_control_state_t *state)
{
    if (!state->initialized) return;
    dtc_flux_estimate(state);
    dtc_compute_torque_step(state);

    float f_mag = state->flux_magnitude;
    float t_est = state->torque_estimated;
    if (f_mag > 2.0f * state->maximum_flux) {
        state->flux_alpha *= 0.5f;
        state->flux_beta  *= 0.5f;
    }
    if (t_est > 3.0f * state->rated_torque) {
        state->torque_ref = state->rated_torque;
    }
}

static dtc_control_state_t st;

static void test_dtc_init_defaults(void)
{
    dtc_control_init(&st);
    CHECK(st.initialized == 1);
    CHECK(st.flux_ref == 1.0f);
    CHECK(st.torque_ref == 0.0f);
    CHECK(st.flux_hyst_band == 0.01f);
    CHECK(st.torque_hyst_band == 0.01f);
    CHECK(st.rs == 1.0f);
    CHECK(st.ls == 0.01f);
    CHECK(st.ts == 0.0001f);
    CHECK_FLOAT_EQ(st.v_dc, 540.0f, 0.01f);
    CHECK_FLOAT_EQ(st.maximum_flux, 1.5f, 0.01f);
    CHECK_FLOAT_EQ(st.rated_torque, 10.0f, 0.01f);
    CHECK(st.sector == 0);
    CHECK(st.switching_state == 0);
    CHECK_FLOAT_EQ(st.flux_alpha, 0.0f, 0.001f);
    CHECK_FLOAT_EQ(st.flux_beta, 0.0f, 0.001f);
    CHECK_FLOAT_EQ(st.flux_magnitude, 0.0f, 0.001f);
}

static void test_dtc_flux_estimate_no_currents(void)
{
    dtc_control_init(&st);
    st.flux_alpha = 0.5f;
    st.flux_beta = 0.0f;
    st.i_alpha = 0.0f;
    st.i_beta = 0.0f;
    st.switching_state = 1;

    dtc_flux_estimate(&st);

    CHECK(st.flux_magnitude > 0.49f);
    CHECK(st.torque_estimated == 0.0f);
    CHECK(st.sector >= 0 && st.sector < 6);
    CHECK(st.sector == 0);
}

static void test_dtc_flux_estimate_with_currents(void)
{
    dtc_control_init(&st);
    st.flux_alpha = 0.8f;
    st.flux_beta = 0.3f;
    st.i_alpha = 5.0f;
    st.i_beta = 3.0f;
    st.switching_state = 2;

    dtc_flux_estimate(&st);

    CHECK(st.flux_magnitude > 0.0f);
    CHECK(st.flux_magnitude < 2.0f);
    CHECK(st.torque_estimated > 0.0f);
    CHECK(st.sector >= 0 && st.sector < 6);
}

static void test_dtc_flux_estimate_zero_inputs(void)
{
    dtc_control_init(&st);
    st.flux_alpha = 0.0f;
    st.flux_beta = 0.0f;
    st.i_alpha = 0.0f;
    st.i_beta = 0.0f;
    st.switching_state = 0;

    dtc_flux_estimate(&st);

    CHECK(st.flux_magnitude == 0.0f);
    CHECK_FLOAT_EQ(st.torque_estimated, 0.0f, 0.001f);
}

static void test_dtc_switching_table_flux_hi_torque_hi(void)
{
    dtc_control_init(&st);
    st.flux_magnitude = 0.9f;
    st.flux_ref = 1.0f;
    st.torque_ref = 5.0f;
    st.torque_estimated = 0.0f;

    st.sector = 0;
    dtc_compute_torque_step(&st);
    CHECK(st.switching_state == 5);
    st.sector = 1;
    dtc_compute_torque_step(&st);
    CHECK(st.switching_state == 6);
    st.sector = 2;
    dtc_compute_torque_step(&st);
    CHECK(st.switching_state == 2);
    st.sector = 3;
    dtc_compute_torque_step(&st);
    CHECK(st.switching_state == 1);
}

static void test_dtc_switching_table_flux_lo_torque_hi(void)
{
    dtc_control_init(&st);
    st.flux_magnitude = 1.1f;
    st.flux_ref = 1.0f;
    st.torque_ref = 5.0f;
    st.torque_estimated = 0.0f;

    st.sector = 0;
    dtc_compute_torque_step(&st);
    CHECK(st.switching_state == 1);
    st.sector = 1;
    dtc_compute_torque_step(&st);
    CHECK(st.switching_state == 0);
    st.sector = 2;
    dtc_compute_torque_step(&st);
    CHECK(st.switching_state == 4);
    st.sector = 3;
    dtc_compute_torque_step(&st);
    CHECK(st.switching_state == 3);
}

static void test_dtc_switching_table_flux_lo_torque_lo(void)
{
    dtc_control_init(&st);
    st.flux_magnitude = 1.15f;
    st.flux_ref = 1.0f;
    st.torque_ref = 1.0f;
    st.torque_estimated = 5.0f;

    st.sector = 0;
    dtc_compute_torque_step(&st);
    CHECK(st.switching_state == 1);
    st.sector = 1;
    dtc_compute_torque_step(&st);
    CHECK(st.switching_state == 0);
    st.sector = 2;
    dtc_compute_torque_step(&st);
    CHECK(st.switching_state == 4);
    st.sector = 3;
    dtc_compute_torque_step(&st);
    CHECK(st.switching_state == 3);
}

static void test_dtc_hysteresis_flux_in_band(void)
{
    dtc_control_init(&st);
    st.flux_magnitude = 1.005f;
    st.flux_ref = 1.0f;
    st.torque_ref = 5.0f;
    st.torque_estimated = 0.0f;
    st.sector = 0;

    dtc_compute_torque_step(&st);
    CHECK(st.switching_state == 6);
}

static void test_dtc_hysteresis_torque_in_band(void)
{
    dtc_control_init(&st);
    st.flux_magnitude = 0.9f;
    st.flux_ref = 1.0f;
    st.torque_ref = 5.0f;
    st.torque_estimated = 4.995f;
    st.sector = 0;

    dtc_compute_torque_step(&st);
    CHECK(st.switching_state == 4);
}

static void test_dtc_control_update_initialized(void)
{
    dtc_control_init(&st);
    st.flux_alpha = 0.5f;
    st.flux_beta = 0.2f;
    st.i_alpha = 2.0f;
    st.i_beta = 1.0f;
    st.switching_state = 1;

    dtc_control_update(&st);

    CHECK(st.switching_state >= 0 && st.switching_state <= 6);
    CHECK(st.flux_magnitude > 0.0f);
}

static void test_dtc_control_update_not_initialized(void)
{
    memset(&st, 0, sizeof(st));
    dtc_control_update(&st);
    CHECK(st.flux_magnitude == 0.0f);
}

static void test_dtc_flux_clamping(void)
{
    dtc_control_init(&st);
    st.flux_alpha = 5.0f;
    st.flux_beta = 5.0f;
    st.i_alpha = 0.0f;
    st.i_beta = 0.0f;
    st.switching_state = 0;

    dtc_control_update(&st);

    CHECK(st.flux_alpha < 5.0f);
    CHECK(st.flux_beta < 5.0f);
}

static void test_dtc_torque_clamping(void)
{
    dtc_control_init(&st);
    st.torque_ref = 100.0f;
    st.flux_alpha = 0.8f;
    st.flux_beta = 0.2f;
    st.i_alpha = 40.0f;
    st.i_beta = 40.0f;
    st.switching_state = 1;

    dtc_control_update(&st);
    CHECK(st.torque_ref <= st.rated_torque);
}

static void test_dtc_sector_all_possible(void)
{
    dtc_control_init(&st);

    float angles[6] = {
        0.0f, M_PI / 6.0f,
        M_PI / 3.0f + 0.001f, M_PI / 2.0f,
        2.0f * M_PI / 3.0f + 0.001f, M_PI - 0.001f
    };
    int expected[6] = { 0, 0, 1, 1, 2, 2 };

    for (int i = 0; i < 6; i++) {
        st.flux_alpha = cosf(angles[i]);
        st.flux_beta = sinf(angles[i]);
        st.i_alpha = 0.0f;
        st.i_beta = 0.0f;
        st.switching_state = 0;
        dtc_flux_estimate(&st);
        CHECK(st.sector == expected[i]);
    }
}

static void test_dtc_torque_estimate_linear(void)
{
    dtc_control_init(&st);
    st.flux_alpha = 1.0f;
    st.flux_beta = 0.0f;
    st.i_alpha = 0.0f;
    st.i_beta = 2.0f;
    st.switching_state = 0;

    dtc_flux_estimate(&st);

    float expected_torque = 1.5f * 1.0f * (1.0f * 2.0f - 0.0f * 0.0f);
    CHECK_FLOAT_EQ(st.torque_estimated, expected_torque, 0.01f);
}

static void test_dtc_torque_estimate_full_flux(void)
{
    dtc_control_init(&st);
    st.flux_alpha = 0.7071f;
    st.flux_beta = 0.7071f;
    st.i_alpha = -0.5f;
    st.i_beta = 1.5f;
    st.switching_state = 0;

    dtc_flux_estimate(&st);

    float expected_torque = 1.5f * 1.0f * (
        st.flux_alpha * st.i_beta - st.flux_beta * st.i_alpha
    );
    CHECK_FLOAT_EQ(st.torque_estimated, expected_torque, 0.01f);
    CHECK(st.flux_magnitude > 0.9f && st.flux_magnitude < 1.1f);
}

static void test_dtc_sector_transition(void)
{
    dtc_control_init(&st);

    float test_angles[] = { 0.0f, 0.524f, 1.571f, 2.618f, 3.665f, 4.712f };
    int expected_sectors[] = { 0, 0, 1, 2, 3, 4 };

    for (int i = 0; i < 6; i++) {
        st.flux_alpha = cosf(test_angles[i]);
        st.flux_beta = sinf(test_angles[i]);
        st.i_alpha = 0.0f;
        st.i_beta = 0.0f;
        st.switching_state = 0;
        dtc_flux_estimate(&st);
        CHECK(st.sector == expected_sectors[i]);
    }
}

int main(void)
{
    printf("=== DTC Control Unit Tests ===\n");

    test_dtc_init_defaults();
    test_dtc_flux_estimate_no_currents();
    test_dtc_flux_estimate_with_currents();
    test_dtc_flux_estimate_zero_inputs();
    test_dtc_switching_table_flux_hi_torque_hi();
    test_dtc_switching_table_flux_lo_torque_hi();
    test_dtc_switching_table_flux_lo_torque_lo();
    test_dtc_hysteresis_flux_in_band();
    test_dtc_hysteresis_torque_in_band();
    test_dtc_control_update_initialized();
    test_dtc_control_update_not_initialized();
    test_dtc_flux_clamping();
    test_dtc_torque_clamping();
    test_dtc_sector_all_possible();
    test_dtc_torque_estimate_linear();
    test_dtc_torque_estimate_full_flux();
    test_dtc_sector_transition();

    printf("\nResults: %d/%d checks passed, %d failed\n",
           tests_passed, tests_passed + tests_failed, tests_failed);
    return tests_failed > 0 ? 1 : 0;
}
