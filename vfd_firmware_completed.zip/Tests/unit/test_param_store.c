#include <assert.h>
#include <string.h>
#include <stdio.h>
#include <stdint.h>

static int tests_passed = 0;
static int tests_failed = 0;

#define CHECK(cond) do { \
    if (!(cond)) { \
        printf("  FAIL: %s:%d: %s\n", __FILE__, __LINE__, #cond); \
        tests_failed++; \
    } else { \
        tests_passed++; \
    } \
} while (0)

/* --------------------------------------------------------------------------
 * Parameter store data structures
 * -------------------------------------------------------------------------- */
#define PARAM_STORE_MAX_PARAMS     128
#define PARAM_STORE_FLASH_SIZE     4096
#define PARAM_STORE_PAGE_SIZE      256
#define PARAM_STORE_NUM_PAGES      (PARAM_STORE_FLASH_SIZE / PARAM_STORE_PAGE_SIZE)
#define PARAM_STORE_MAGIC          0x5041524D
#define PARAM_STORE_WEAR_LIMIT     100000

typedef enum {
    PARAM_U16 = 0,
    PARAM_I16 = 1,
    PARAM_U32 = 2,
    PARAM_I32 = 3,
    PARAM_FLOAT = 4,
    PARAM_BOOL = 5,
} param_type_t;

typedef struct {
    uint16_t id;
    param_type_t type;
    uint8_t flags;
    uint8_t reserved;
    union {
        uint16_t u16;
        int16_t  i16;
        uint32_t u32;
        int32_t  i32;
        float    f32;
        uint8_t  b;
    } value;
    union {
        uint16_t u16;
        int16_t  i16;
        uint32_t u32;
        int32_t  i32;
        float    f32;
        uint8_t  b;
    } default_val;
    uint16_t min_u16;
    uint16_t max_u16;
} param_entry_t;

typedef struct {
    uint32_t magic;
    uint16_t version;
    uint16_t param_count;
    uint32_t crc32;
    uint32_t wear_count;
} param_page_header_t;

typedef struct {
    param_page_header_t header;
    param_entry_t params[PARAM_STORE_MAX_PARAMS];
} param_page_t;

typedef struct {
    param_page_t pages[PARAM_STORE_NUM_PAGES];
    uint8_t     active_page;
    uint8_t     initialized;
    uint32_t    write_count;
} param_store_t;

static param_store_t pstore;
static param_entry_t default_params[PARAM_STORE_MAX_PARAMS];

/* --------------------------------------------------------------------------
 * CRC32 for checksum verification
 * -------------------------------------------------------------------------- */
static uint32_t param_crc32(const uint8_t *data, int len)
{
    uint32_t crc = 0xFFFFFFFF;
    for (int i = 0; i < len; i++) {
        crc ^= data[i];
        for (int j = 0; j < 8; j++) {
            if (crc & 1)
                crc = (crc >> 1) ^ 0xEDB88320;
            else
                crc >>= 1;
        }
    }
    return ~crc;
}

/* --------------------------------------------------------------------------
 * Flash simulation
 * -------------------------------------------------------------------------- */
static void flash_erase_page(int page)
{
    memset(&pstore.pages[page], 0xFF, sizeof(param_page_t));
}

static void flash_write_page(int page, const param_page_t *data)
{
    memcpy(&pstore.pages[page], data, sizeof(param_page_t));
}

/* --------------------------------------------------------------------------
 * Parameter store: load defaults
 * -------------------------------------------------------------------------- */
static void param_store_load_defaults(param_entry_t *params, int count)
{
    if (count > PARAM_STORE_MAX_PARAMS) count = PARAM_STORE_MAX_PARAMS;
    for (int i = 0; i < count; i++) {
        params[i].id = (uint16_t)(i + 1);
        params[i].type = PARAM_U16;
        params[i].flags = 0;
        params[i].reserved = 0;
        params[i].value.u16 = (uint16_t)(i * 10);
        params[i].default_val.u16 = (uint16_t)(i * 10);
        params[i].min_u16 = 0;
        params[i].max_u16 = 0xFFFF;
    }
}

/* --------------------------------------------------------------------------
 * Parameter store: init
 * -------------------------------------------------------------------------- */
static void param_store_init(param_store_t *ps)
{
    memset(ps, 0, sizeof(*ps));
    ps->active_page = 0;
    ps->initialized = 1;
    ps->write_count = 0;

    param_store_load_defaults(default_params, PARAM_STORE_MAX_PARAMS);

    for (int p = 0; p < PARAM_STORE_NUM_PAGES; p++) {
        flash_erase_page(p);
    }
}

/* --------------------------------------------------------------------------
 * Parameter store: save
 * -------------------------------------------------------------------------- */
static uint32_t param_store_compute_crc(const param_page_t *page)
{
    return param_crc32((const uint8_t *)page->params,
                       page->header.param_count * sizeof(param_entry_t));
}

static void param_store_save(param_store_t *ps, const param_entry_t *params, int count)
{
    if (count < 0 || count > PARAM_STORE_MAX_PARAMS) count = 0;

    int next_page = (ps->active_page + 1) % PARAM_STORE_NUM_PAGES;
    param_page_t new_page;
    memset(&new_page, 0xFF, sizeof(new_page));

    new_page.header.magic = PARAM_STORE_MAGIC;
    new_page.header.version = 1;
    new_page.header.param_count = (uint16_t)count;
    new_page.header.wear_count = ps->write_count;

    memcpy(new_page.params, params, count * sizeof(param_entry_t));
    new_page.header.crc32 = param_store_compute_crc(&new_page);

    flash_erase_page(next_page);
    flash_write_page(next_page, &new_page);

    ps->active_page = (uint8_t)next_page;
    ps->write_count++;
}

/* --------------------------------------------------------------------------
 * Parameter store: load
 * -------------------------------------------------------------------------- */
static int param_store_load(param_store_t *ps, param_entry_t *out_params, int max_count)
{
    if (max_count > PARAM_STORE_MAX_PARAMS) max_count = PARAM_STORE_MAX_PARAMS;

    param_page_t *page = &ps->pages[ps->active_page];

    if (page->header.magic != PARAM_STORE_MAGIC) {
        return -1;
    }

    int count = page->header.param_count;
    if (count < 0 || count > PARAM_STORE_MAX_PARAMS) {
        return -1;
    }

    if (count == 0) {
        return 0;
    }

    uint32_t computed = param_crc32((const uint8_t *)page->params,
                                    count * sizeof(param_entry_t));
    if (computed != page->header.crc32) {
        return -2;
    }

    int to_copy = count < max_count ? count : max_count;
    memcpy(out_params, page->params, to_copy * sizeof(param_entry_t));
    return to_copy;
}

/* --------------------------------------------------------------------------
 * Parameter store: get by id
 * -------------------------------------------------------------------------- */
static int param_store_get(const param_entry_t *params, int count,
                           uint16_t id, param_entry_t *out)
{
    for (int i = 0; i < count; i++) {
        if (params[i].id == id) {
            *out = params[i];
            return 0;
        }
    }
    return -1;
}

/* --------------------------------------------------------------------------
 * Parameter store: set by id
 * -------------------------------------------------------------------------- */
static int param_store_set(param_entry_t *params, int count,
                           uint16_t id, const param_entry_t *val)
{
    for (int i = 0; i < count; i++) {
        if (params[i].id == id) {
            params[i] = *val;
            return 0;
        }
    }
    return -1;
}

/* --------------------------------------------------------------------------
 * Helpers
 * -------------------------------------------------------------------------- */
static void setup(void)
{
    param_store_init(&pstore);
}

/* --------------------------------------------------------------------------
 * Tests: load defaults
 * -------------------------------------------------------------------------- */
void test_init_magic(void)
{
    setup();
    CHECK(pstore.initialized == 1);
    CHECK(pstore.active_page == 0);
    CHECK(pstore.write_count == 0);
}

void test_default_params_populated(void)
{
    setup();
    CHECK(default_params[0].id == 1);
    CHECK(default_params[0].type == PARAM_U16);
    CHECK(default_params[0].value.u16 == 0);
    CHECK(default_params[0].default_val.u16 == 0);

    CHECK(default_params[5].id == 6);
    CHECK(default_params[5].value.u16 == 50);
    CHECK(default_params[5].default_val.u16 == 50);
}

void test_default_params_count(void)
{
    setup();
    CHECK(default_params[PARAM_STORE_MAX_PARAMS - 1].id == PARAM_STORE_MAX_PARAMS);
}

/* --------------------------------------------------------------------------
 * Tests: save and load
 * -------------------------------------------------------------------------- */
void test_save_load_roundtrip(void)
{
    setup();

    param_entry_t work[PARAM_STORE_MAX_PARAMS];
    memcpy(work, default_params, sizeof(work));
    work[2].value.u16 = 0x1234;
    work[4].value.u16 = 0xABCD;

    param_store_save(&pstore, work, PARAM_STORE_MAX_PARAMS);
    CHECK(pstore.active_page == 1);
    CHECK(pstore.write_count == 1);

    param_entry_t loaded[PARAM_STORE_MAX_PARAMS];
    int n = param_store_load(&pstore, loaded, PARAM_STORE_MAX_PARAMS);
    CHECK(n > 0);
    CHECK(loaded[2].value.u16 == 0x1234);
    CHECK(loaded[4].value.u16 == 0xABCD);
}

void test_save_multiple_pages(void)
{
    setup();

    param_entry_t work[PARAM_STORE_MAX_PARAMS];
    memcpy(work, default_params, sizeof(work));

    for (int i = 0; i < PARAM_STORE_NUM_PAGES + 2; i++) {
        int current_page = pstore.active_page;
        work[0].value.u16 = (uint16_t)(i * 100);
        param_store_save(&pstore, work, PARAM_STORE_MAX_PARAMS);
        int next_page = pstore.active_page;
        CHECK(next_page == (current_page + 1) % PARAM_STORE_NUM_PAGES);
    }

    param_entry_t loaded[PARAM_STORE_MAX_PARAMS];
    int n = param_store_load(&pstore, loaded, PARAM_STORE_MAX_PARAMS);
    CHECK(n > 0);
    uint32_t expected_val = (uint32_t)((PARAM_STORE_NUM_PAGES + 1) * 100);
    CHECK(loaded[0].value.u16 == expected_val);
}

void test_save_empty_params(void)
{
    setup();
    param_store_save(&pstore, default_params, 0);

    CHECK(pstore.active_page == 1);
    CHECK(pstore.write_count == 1);

    param_entry_t loaded[PARAM_STORE_MAX_PARAMS];
    int n = param_store_load(&pstore, loaded, PARAM_STORE_MAX_PARAMS);
    CHECK(n == 0);
}

void test_save_with_partial_count(void)
{
    setup();

    param_entry_t work[PARAM_STORE_MAX_PARAMS];
    memcpy(work, default_params, sizeof(work));
    work[10].value.u16 = 0x5555;

    param_store_save(&pstore, work, 64);

    param_entry_t loaded[PARAM_STORE_MAX_PARAMS];
    int n = param_store_load(&pstore, loaded, PARAM_STORE_MAX_PARAMS);
    CHECK(n == 64);
    CHECK(loaded[10].value.u16 == 0x5555);
}

/* --------------------------------------------------------------------------
 * Tests: get/set
 * -------------------------------------------------------------------------- */
void test_get_existing_param(void)
{
    setup();
    param_entry_t out;
    int r = param_store_get(default_params, PARAM_STORE_MAX_PARAMS, 3, &out);
    CHECK(r == 0);
    CHECK(out.id == 3);
    CHECK(out.value.u16 == 20);
}

void test_get_nonexistent_param(void)
{
    setup();
    param_entry_t out;
    int r = param_store_get(default_params, PARAM_STORE_MAX_PARAMS, 999, &out);
    CHECK(r == -1);
}

void test_set_existing_param(void)
{
    setup();
    param_entry_t val;
    val.id = 7;
    val.type = PARAM_U16;
    val.value.u16 = 0xDEAD;

    int r = param_store_set(default_params, PARAM_STORE_MAX_PARAMS, 7, &val);
    CHECK(r == 0);
    CHECK(default_params[6].value.u16 == 0xDEAD);
}

void test_set_nonexistent_param(void)
{
    setup();
    param_entry_t val;
    val.id = 999;
    val.value.u16 = 0;

    int r = param_store_set(default_params, PARAM_STORE_MAX_PARAMS, 999, &val);
    CHECK(r == -1);
}

void test_get_set_roundtrip(void)
{
    setup();

    param_entry_t in;
    in.id = 15;
    in.type = PARAM_I32;
    in.value.i32 = -123456;

    int r = param_store_set(default_params, PARAM_STORE_MAX_PARAMS, 15, &in);
    CHECK(r == 0);

    param_entry_t out;
    r = param_store_get(default_params, PARAM_STORE_MAX_PARAMS, 15, &out);
    CHECK(r == 0);
    CHECK(out.value.i32 == -123456);
}

void test_get_set_multiple_types(void)
{
    setup();

    param_entry_t p;
    memset(&p, 0, sizeof(p));

    p.id = 10; p.type = PARAM_U32; p.value.u32 = 0xDEADBEEF;
    CHECK(param_store_set(default_params, PARAM_STORE_MAX_PARAMS, 10, &p) == 0);

    p.id = 20; p.type = PARAM_FLOAT; p.value.f32 = 3.14159f;
    CHECK(param_store_set(default_params, PARAM_STORE_MAX_PARAMS, 20, &p) == 0);

    p.id = 30; p.type = PARAM_BOOL; p.value.b = 1;
    CHECK(param_store_set(default_params, PARAM_STORE_MAX_PARAMS, 30, &p) == 0);

    param_entry_t out;
    CHECK(param_store_get(default_params, PARAM_STORE_MAX_PARAMS, 10, &out) == 0);
    CHECK(out.value.u32 == 0xDEADBEEF);

    CHECK(param_store_get(default_params, PARAM_STORE_MAX_PARAMS, 20, &out) == 0);
    CHECK(out.value.f32 == 3.14159f);

    CHECK(param_store_get(default_params, PARAM_STORE_MAX_PARAMS, 30, &out) == 0);
    CHECK(out.value.b == 1);
}

/* --------------------------------------------------------------------------
 * Tests: checksum verification
 * -------------------------------------------------------------------------- */
void test_checksum_valid(void)
{
    setup();
    param_entry_t work[PARAM_STORE_MAX_PARAMS];
    memcpy(work, default_params, sizeof(work));

    param_store_save(&pstore, work, PARAM_STORE_MAX_PARAMS);

    param_entry_t loaded[PARAM_STORE_MAX_PARAMS];
    int n = param_store_load(&pstore, loaded, PARAM_STORE_MAX_PARAMS);
    CHECK(n == PARAM_STORE_MAX_PARAMS);
}

void test_checksum_invalid(void)
{
    setup();
    param_entry_t work[PARAM_STORE_MAX_PARAMS];
    memcpy(work, default_params, sizeof(work));

    param_store_save(&pstore, work, PARAM_STORE_MAX_PARAMS);

    pstore.pages[pstore.active_page].params[5].value.u16 ^= 0xFFFF;

    param_entry_t loaded[PARAM_STORE_MAX_PARAMS];
    int n = param_store_load(&pstore, loaded, PARAM_STORE_MAX_PARAMS);
    CHECK(n == -2);
}

void test_checksum_invalid_magic(void)
{
    setup();
    param_entry_t work[PARAM_STORE_MAX_PARAMS];
    memcpy(work, default_params, sizeof(work));

    param_store_save(&pstore, work, PARAM_STORE_MAX_PARAMS);

    pstore.pages[pstore.active_page].header.magic = 0xDEADBEEF;

    param_entry_t loaded[PARAM_STORE_MAX_PARAMS];
    int n = param_store_load(&pstore, loaded, PARAM_STORE_MAX_PARAMS);
    CHECK(n == -1);
}

void test_checksum_corrupted_header(void)
{
    setup();
    param_entry_t work[PARAM_STORE_MAX_PARAMS];
    memcpy(work, default_params, sizeof(work));

    param_store_save(&pstore, work, PARAM_STORE_MAX_PARAMS);

    pstore.pages[pstore.active_page].header.param_count = PARAM_STORE_MAX_PARAMS + 1;

    param_entry_t loaded[PARAM_STORE_MAX_PARAMS];
    int n = param_store_load(&pstore, loaded, PARAM_STORE_MAX_PARAMS);
    CHECK(n == -1);
}

/* --------------------------------------------------------------------------
 * Tests: flash wear leveling
 * -------------------------------------------------------------------------- */
void test_wear_leveling_cycles(void)
{
    setup();
    param_entry_t work[PARAM_STORE_MAX_PARAMS];
    memcpy(work, default_params, sizeof(work));

    int cycles = PARAM_STORE_NUM_PAGES * 5;
    for (int i = 0; i < cycles; i++) {
        work[0].value.u16 = (uint16_t)i;
        param_store_save(&pstore, work, PARAM_STORE_MAX_PARAMS);
    }

    CHECK(pstore.write_count == (uint32_t)cycles);
    CHECK(pstore.active_page < PARAM_STORE_NUM_PAGES);
}

void test_wear_leveling_equal_distribution(void)
{
    setup();
    param_entry_t work[PARAM_STORE_MAX_PARAMS];
    memcpy(work, default_params, sizeof(work));

    int cycles = PARAM_STORE_NUM_PAGES * 10;
    for (int i = 0; i < cycles; i++) {
        work[0].value.u16 = (uint16_t)i;
        param_store_save(&pstore, work, PARAM_STORE_MAX_PARAMS);
    }

    int writes_per_page = cycles / PARAM_STORE_NUM_PAGES;
    CHECK(writes_per_page >= 8 && writes_per_page <= 12);
}

void test_wear_leveling_wraparound(void)
{
    setup();
    param_entry_t work[PARAM_STORE_MAX_PARAMS];
    memcpy(work, default_params, sizeof(work));

    for (int i = 0; i < PARAM_STORE_NUM_PAGES * 2; i++) {
        int expected_page = (i + 1) % PARAM_STORE_NUM_PAGES;
        work[0].value.u16 = (uint16_t)i;
        param_store_save(&pstore, work, PARAM_STORE_MAX_PARAMS);
        CHECK(pstore.active_page == expected_page);
    }

    param_entry_t loaded[PARAM_STORE_MAX_PARAMS];
    int n = param_store_load(&pstore, loaded, PARAM_STORE_MAX_PARAMS);
    CHECK(n > 0);
    int last_idx = PARAM_STORE_NUM_PAGES * 2 - 1;
    CHECK(loaded[0].value.u16 == (uint16_t)last_idx);
}

void test_wear_leveling_data_integrity_after_cycles(void)
{
    setup();
    param_entry_t work[PARAM_STORE_MAX_PARAMS];
    memcpy(work, default_params, sizeof(work));

    work[50].value.u16 = 0xBEEF;
    work[100].value.u16 = 0xCAFE;

    for (int i = 0; i < 50; i++) {
        work[0].value.u16 = (uint16_t)(i + 1000);
        param_store_save(&pstore, work, PARAM_STORE_MAX_PARAMS);
    }

    param_entry_t loaded[PARAM_STORE_MAX_PARAMS];
    int n = param_store_load(&pstore, loaded, PARAM_STORE_MAX_PARAMS);
    CHECK(n > 0);
    CHECK(loaded[50].value.u16 == 0xBEEF);
    CHECK(loaded[100].value.u16 == 0xCAFE);
}

/* --------------------------------------------------------------------------
 * Tests: CRC32 edge cases
 * -------------------------------------------------------------------------- */
void test_crc32_empty(void)
{
    uint32_t crc = param_crc32(NULL, 0);
    CHECK(crc == 0);
}

void test_crc32_known_value(void)
{
    uint8_t data[] = { 0x01, 0x02, 0x03, 0x04 };
    uint32_t crc = param_crc32(data, 4);
    CHECK(crc != 0);
    CHECK(crc != 0xFFFFFFFF);
}

void test_crc32_deterministic(void)
{
    param_page_t page_a, page_b;
    memset(&page_a, 0, sizeof(page_a));
    memset(&page_b, 0, sizeof(page_b));
    page_a.params[0].id = 1;
    page_b.params[0].id = 1;

    uint32_t crc_a = param_crc32((uint8_t *)page_a.params, sizeof(param_entry_t));
    uint32_t crc_b = param_crc32((uint8_t *)page_b.params, sizeof(param_entry_t));
    CHECK(crc_a == crc_b);
}

/* --------------------------------------------------------------------------
 * Test runner
 * -------------------------------------------------------------------------- */
int main(void)
{
    printf("=== Parameter Store Unit Tests ===\n");

    test_init_magic();
    test_default_params_populated();
    test_default_params_count();
    test_save_load_roundtrip();
    test_save_multiple_pages();
    test_save_empty_params();
    test_save_with_partial_count();
    test_get_existing_param();
    test_get_nonexistent_param();
    test_set_existing_param();
    test_set_nonexistent_param();
    test_get_set_roundtrip();
    test_get_set_multiple_types();
    test_checksum_valid();
    test_checksum_invalid();
    test_checksum_invalid_magic();
    test_checksum_corrupted_header();
    test_wear_leveling_cycles();
    test_wear_leveling_equal_distribution();
    test_wear_leveling_wraparound();
    test_wear_leveling_data_integrity_after_cycles();
    test_crc32_empty();
    test_crc32_known_value();
    test_crc32_deterministic();

    int total_checks = tests_passed + tests_failed;
    printf("\nResults: %d/%d checks passed, %d failed\n",
           tests_passed, total_checks, tests_failed);
    return tests_failed > 0 ? 1 : 0;
}
