#include <assert.h>
#include <string.h>
#include <stdio.h>
#include <stdint.h>

static int tests_passed = 0;
static int tests_failed = 0;

#define CHECK(cond) do { \
    if (!(cond)) { \
        printf("  FAIL: %s:%d: %s\n", __FILE__, __LINE__, #cond); \
        tests_failed++; \
    } else { \
        tests_passed++; \
    } \
} while (0)

/* --------------------------------------------------------------------------
 * State machine constants
 * -------------------------------------------------------------------------- */
#define START_CMD_OFF     0u
#define START_CMD_RUNNING 1u
#define START_CMD_RAMPING 2u

#define DIR_FORWARD  1u
#define DIR_REVERSE  2u

#define READY_BIT        0x0001u
#define RUNNING_BIT      0x0002u
#define FAULT_BIT        0x0008u
#define RAMPING_BIT      0x0010u
#define DIRECTION_BIT    0x0020u

#define START_SEQ_IDLE       0u
#define START_SEQ_INTERLOCK  1u
#define START_SEQ_DELAY      2u
#define START_SEQ_MAGNETIZE  3u
#define START_SEQ_RUNNING    4u

/* --------------------------------------------------------------------------
 * Protection fault codes
 * -------------------------------------------------------------------------- */
typedef enum {
    PROT_FAULT_OVERCURRENT   = 0x0001,
    PROT_FAULT_OVERVOLTAGE   = 0x0002,
    PROT_FAULT_UNDERVOLTAGE  = 0x0004,
    PROT_FAULT_OVERTEMP      = 0x0008,
    PROT_FAULT_OVERLOAD      = 0x0010,
    PROT_FAULT_EARTH         = 0x0020,
    PROT_FAULT_SHORT_CIRCUIT = 0x0040,
    PROT_FAULT_PHASE_LOSS    = 0x0080,
    PROT_FAULT_THERMAL       = 0x0100,
    PROT_FAULT_COM_LOSS      = 0x0200,
    PROT_FAULT_ENCODER       = 0x0400,
    PROT_FAULT_STO           = 0x0800,
    PROT_FAULT_EMERG_STOP    = 0x1000,
    PROT_FAULT_USER_LOAD     = 0x2000,
    PROT_FAULT_CABLE_THERM   = 0x4000,
    PROT_FAULT_HARDWARE      = 0x8000,
} prot_fault_code_t;

/* --------------------------------------------------------------------------
 * Start/stop/direction state
 * -------------------------------------------------------------------------- */
typedef struct {
    uint8_t initialized;
    uint16_t cmd_word;
    uint16_t state_word;
    uint8_t running;
    uint8_t direction;
    uint8_t start_request;
    uint8_t stop_request;
    uint8_t interlock_ok;
    uint8_t emergency_stop_active;
    uint8_t coast_stop_active;
    uint8_t ramp_stop_active;
    uint8_t start_seq_step;
    float start_delay_timer;
    float start_delay_threshold;
    float ramp_down_rate;
    uint8_t ready;
    uint8_t faulted;
} start_stop_direction_state_t;

/* --------------------------------------------------------------------------
 * Start/stop mode state
 * -------------------------------------------------------------------------- */
#define START_MODE_AUTO    0u
#define START_MODE_MANUAL  1u
#define TRIGGER_LEVEL      0u
#define TRIGGER_EDGE       1u
#define STOP_MODE_COAST    0u
#define STOP_MODE_RAMP     1u

typedef struct {
    uint8_t initialized;
    uint8_t start_mode;
    uint8_t trigger_type;
    uint8_t stop_mode;
    uint8_t level_active;
    uint8_t edge_latched;
    uint8_t edge_prev;
    uint8_t edge_detect_enable;
    uint8_t start_cmd_input;
    uint8_t stop_cmd_input;
} start_stop_mode_state_t;

/* --------------------------------------------------------------------------
 * Fault history state
 * -------------------------------------------------------------------------- */
#define PROT_FAULT_HISTORY_DEPTH 16

typedef struct {
    uint32_t timestamp;
    uint16_t fault_code;
    uint16_t fault_data;
} prot_fault_entry_t;

typedef struct {
    prot_fault_entry_t history[PROT_FAULT_HISTORY_DEPTH];
    uint8_t write_index;
    uint8_t count;
    uint32_t sys_tick_ms;
} prot_internal_t;

/* --------------------------------------------------------------------------
 * State machine: start command
 * -------------------------------------------------------------------------- */
static void start_cmd(start_stop_direction_state_t *state)
{
    if (state->faulted) {
        state->start_request = 0;
        state->start_seq_step = START_SEQ_IDLE;
        return;
    }

    if (!state->interlock_ok) {
        state->start_request = 0;
        state->start_seq_step = START_SEQ_IDLE;
        return;
    }

    switch (state->start_seq_step) {
    case START_SEQ_IDLE:
        state->state_word |= RAMPING_BIT;
        state->state_word &= ~READY_BIT;
        state->start_seq_step = START_SEQ_INTERLOCK;
        state->start_delay_timer = 0.0f;
        break;

    case START_SEQ_INTERLOCK:
        if (state->interlock_ok) {
            state->start_seq_step = START_SEQ_DELAY;
            state->start_delay_timer = 0.0f;
        } else {
            state->start_seq_step = START_SEQ_IDLE;
            state->start_request = 0;
            state->state_word |= READY_BIT;
        }
        break;

    case START_SEQ_DELAY:
        state->start_delay_timer += 0.001f;
        if (state->start_delay_timer >= state->start_delay_threshold) {
            state->start_seq_step = START_SEQ_MAGNETIZE;
            state->start_delay_timer = 0.0f;
        }
        break;

    case START_SEQ_MAGNETIZE:
        state->start_delay_timer += 0.001f;
        if (state->start_delay_timer >= 0.5f) {
            state->start_seq_step = START_SEQ_RUNNING;
            state->running = 1;
            state->start_request = 0;
            state->state_word |= RUNNING_BIT;
            state->state_word &= ~(RAMPING_BIT | READY_BIT);
            if (state->direction == DIR_REVERSE) {
                state->state_word |= DIRECTION_BIT;
            } else {
                state->state_word &= ~DIRECTION_BIT;
            }
        }
        break;

    case START_SEQ_RUNNING:
        state->start_request = 0;
        break;

    default:
        state->start_seq_step = START_SEQ_IDLE;
        break;
    }
}

/* --------------------------------------------------------------------------
 * State machine: stop command
 * -------------------------------------------------------------------------- */
static void stop_cmd(start_stop_direction_state_t *state)
{
    if (state->emergency_stop_active || state->coast_stop_active) {
        state->running = 0;
        state->start_seq_step = START_SEQ_IDLE;
        state->start_request = 0;
        state->stop_request = 0;
        state->ramp_stop_active = 0;
        state->state_word = READY_BIT;
        state->ramp_down_rate = 400.0f;
        return;
    }

    if (state->ramp_stop_active) {
        state->running = 0;
        state->start_seq_step = START_SEQ_IDLE;
        state->start_request = 0;
        state->stop_request = 0;
        state->ramp_stop_active = 0;
        state->state_word = READY_BIT;
        return;
    }

    state->running = 0;
    state->start_seq_step = START_SEQ_IDLE;
    state->start_request = 0;
    state->stop_request = 0;
    state->state_word = READY_BIT;
    state->state_word &= ~RUNNING_BIT;
}

/* --------------------------------------------------------------------------
 * State machine: init
 * -------------------------------------------------------------------------- */
static void state_machine_init(start_stop_direction_state_t *st)
{
    memset(st, 0, sizeof(*st));
    st->initialized = 1;
    st->cmd_word = 0;
    st->state_word = READY_BIT;
    st->running = 0;
    st->direction = DIR_FORWARD;
    st->start_request = 0;
    st->stop_request = 0;
    st->interlock_ok = 1;
    st->emergency_stop_active = 0;
    st->coast_stop_active = 0;
    st->ramp_stop_active = 0;
    st->start_seq_step = START_SEQ_IDLE;
    st->start_delay_timer = 0.0f;
    st->start_delay_threshold = 0.5f;
    st->ramp_down_rate = 10.0f;
    st->ready = 1;
    st->faulted = 0;
}

/* --------------------------------------------------------------------------
 * State machine: update (main loop entry)
 * -------------------------------------------------------------------------- */
static void state_machine_update(start_stop_direction_state_t *st)
{
    if (st->emergency_stop_active) {
        st->faulted = 1;
        st->start_request = 0;
        st->stop_request = 1;
        stop_cmd(st);
        return;
    }

    if (st->start_request && !st->running && !st->faulted) {
        start_cmd(st);
    }

    if (st->stop_request && st->running) {
        stop_cmd(st);
    }
}

/* --------------------------------------------------------------------------
 * State machine: propagate fault
 * -------------------------------------------------------------------------- */
static void state_machine_set_fault(start_stop_direction_state_t *st, int fault)
{
    st->faulted = fault;
    st->state_word |= FAULT_BIT;
    st->state_word &= ~(RUNNING_BIT | READY_BIT);
    st->running = 0;
    st->start_request = 0;
}

/* --------------------------------------------------------------------------
 * State machine: reset fault
 * -------------------------------------------------------------------------- */
static void state_machine_reset_fault(start_stop_direction_state_t *st)
{
    st->faulted = 0;
    st->state_word &= ~FAULT_BIT;
    st->state_word |= READY_BIT;
    st->start_seq_step = START_SEQ_IDLE;
    st->start_delay_timer = 0.0f;
}

/* --------------------------------------------------------------------------
 * State machine: startstop mode configure
 * -------------------------------------------------------------------------- */
static void startstop_mode_configure(start_stop_mode_state_t *st)
{
    st->edge_detect_enable = 0;
    st->level_active = 0;

    if (st->trigger_type == TRIGGER_LEVEL) {
        st->level_active = 1;
    } else if (st->trigger_type == TRIGGER_EDGE) {
        if (st->start_cmd_input && !st->edge_prev) {
            st->edge_latched = 1;
            st->edge_detect_enable = 1;
        } else if (!st->start_cmd_input && st->edge_prev) {
            st->edge_detect_enable = 0;
        }
        st->edge_prev = st->start_cmd_input;
    }

    if (st->start_mode == START_MODE_AUTO) {
        st->edge_detect_enable = 1;
        st->level_active = 1;
    }

    if (st->stop_cmd_input && st->start_mode == START_MODE_AUTO) {
        st->level_active = 0;
        st->edge_latched = 0;
    }
}

/* --------------------------------------------------------------------------
 * Fault detection (simplified for state machine tests)
 * -------------------------------------------------------------------------- */
static uint16_t prot_fault_detect(uint16_t current_raw, uint16_t voltage_raw,
                                   uint16_t temp_raw, uint16_t sto_status,
                                   uint16_t em_stop, uint16_t encoder_stat,
                                   uint16_t com_status)
{
    uint16_t fault_word = 0;
    if (current_raw > 20000)    fault_word |= PROT_FAULT_OVERCURRENT;
    if (voltage_raw > 24000)    fault_word |= PROT_FAULT_OVERVOLTAGE;
    if (voltage_raw < 8000)     fault_word |= PROT_FAULT_UNDERVOLTAGE;
    if (temp_raw > 1500)        fault_word |= PROT_FAULT_OVERTEMP;
    if (current_raw > 35000)    fault_word |= PROT_FAULT_SHORT_CIRCUIT;
    if (com_status == 0)        fault_word |= PROT_FAULT_COM_LOSS;
    if (encoder_stat != 0)      fault_word |= PROT_FAULT_ENCODER;
    if (sto_status != 0)        fault_word |= PROT_FAULT_STO;
    if (em_stop != 0)           fault_word |= PROT_FAULT_EMERG_STOP;
    return fault_word;
}

/* --------------------------------------------------------------------------
 * Helpers
 * -------------------------------------------------------------------------- */
static start_stop_direction_state_t sm;
static start_stop_mode_state_t mode;
static prot_internal_t prot_hist;

#define TICK_MS 1

static void setup(void)
{
    state_machine_init(&sm);
    memset(&mode, 0, sizeof(mode));
    mode.initialized = 1;
    mode.start_mode = START_MODE_AUTO;
    mode.trigger_type = TRIGGER_LEVEL;
    mode.stop_mode = STOP_MODE_RAMP;
    memset(&prot_hist, 0, sizeof(prot_hist));
}

static void tick_ms(start_stop_direction_state_t *st, int ms)
{
    for (int i = 0; i < ms; i++) {
        state_machine_update(st);
    }
}

/* --------------------------------------------------------------------------
 * Tests: NOT_READY to READY transition
 * -------------------------------------------------------------------------- */
void test_init_is_ready(void)
{
    setup();
    CHECK(sm.initialized == 1);
    CHECK(sm.state_word & READY_BIT);
    CHECK(!(sm.state_word & RUNNING_BIT));
    CHECK(!(sm.state_word & FAULT_BIT));
    CHECK(sm.ready == 1);
    CHECK(sm.faulted == 0);
    CHECK(sm.running == 0);
}

/* --------------------------------------------------------------------------
 * Tests: READY to RUNNING transition
 * -------------------------------------------------------------------------- */
void test_ready_to_running_full_sequence(void)
{
    setup();
    CHECK(sm.state_word & READY_BIT);

    sm.start_request = 1;

    tick_ms(&sm, 1);
    CHECK(sm.start_seq_step == START_SEQ_INTERLOCK);
    CHECK(sm.state_word & RAMPING_BIT);
    CHECK(!(sm.state_word & READY_BIT));

    tick_ms(&sm, 1);
    CHECK(sm.start_seq_step == START_SEQ_DELAY);

    while (sm.start_seq_step == START_SEQ_DELAY) {
        tick_ms(&sm, 10);
    }
    CHECK(sm.start_seq_step == START_SEQ_MAGNETIZE);

    while (sm.start_seq_step == START_SEQ_MAGNETIZE) {
        tick_ms(&sm, 10);
    }
    CHECK(sm.start_seq_step == START_SEQ_RUNNING);
    CHECK(sm.running == 1);
    CHECK(sm.state_word & RUNNING_BIT);
    CHECK(!(sm.state_word & READY_BIT));
}

void test_ready_to_running_status_word(void)
{
    setup();
    sm.start_request = 1;

    while (sm.start_seq_step != START_SEQ_RUNNING && sm.running == 0) {
        tick_ms(&sm, 10);
    }

    CHECK(sm.running == 1);
    CHECK(sm.state_word & RUNNING_BIT);
    CHECK(!(sm.state_word & RAMPING_BIT));
}

void test_ready_to_running_with_forward_direction(void)
{
    setup();
    sm.direction = DIR_FORWARD;
    sm.start_request = 1;

    while (sm.start_seq_step != START_SEQ_RUNNING && sm.running == 0) {
        tick_ms(&sm, 10);
    }

    CHECK(!(sm.state_word & DIRECTION_BIT));
}

void test_ready_to_running_with_reverse_direction(void)
{
    setup();
    sm.direction = DIR_REVERSE;
    sm.start_request = 1;

    while (sm.start_seq_step != START_SEQ_RUNNING && sm.running == 0) {
        tick_ms(&sm, 10);
    }

    CHECK(sm.state_word & DIRECTION_BIT);
}

/* --------------------------------------------------------------------------
 * Tests: RUNNING to READY transition (normal stop)
 * -------------------------------------------------------------------------- */
void test_running_to_ready_normal_stop(void)
{
    setup();
    sm.start_request = 1;
    while (sm.start_seq_step != START_SEQ_RUNNING && sm.running == 0) {
        tick_ms(&sm, 10);
    }
    CHECK(sm.running == 1);

    sm.stop_request = 1;
    tick_ms(&sm, 1);
    CHECK(sm.running == 0);
    CHECK(sm.state_word & READY_BIT);
    CHECK(!(sm.state_word & RUNNING_BIT));
}

void test_running_to_ready_ramp_stop(void)
{
    setup();
    sm.start_request = 1;
    while (sm.start_seq_step != START_SEQ_RUNNING && sm.running == 0) {
        tick_ms(&sm, 10);
    }
    CHECK(sm.running == 1);

    sm.ramp_stop_active = 1;
    sm.stop_request = 1;
    tick_ms(&sm, 1);

    CHECK(sm.running == 0);
    CHECK(sm.state_word & READY_BIT);
    CHECK(sm.ramp_stop_active == 0);
}

void test_running_to_ready_coast_stop(void)
{
    setup();
    sm.start_request = 1;
    while (sm.start_seq_step != START_SEQ_RUNNING && sm.running == 0) {
        tick_ms(&sm, 10);
    }
    CHECK(sm.running == 1);

    sm.coast_stop_active = 1;
    sm.stop_request = 1;
    tick_ms(&sm, 1);

    CHECK(sm.running == 0);
    CHECK(sm.state_word & READY_BIT);
    CHECK(sm.ramp_down_rate == 400.0f);
}

/* --------------------------------------------------------------------------
 * Tests: FAULT transition
 * -------------------------------------------------------------------------- */
void test_running_to_fault_overcurrent(void)
{
    setup();
    sm.start_request = 1;
    while (sm.start_seq_step != START_SEQ_RUNNING && sm.running == 0) {
        tick_ms(&sm, 10);
    }
    CHECK(sm.running == 1);

    state_machine_set_fault(&sm, 1);
    CHECK(sm.faulted == 1);
    CHECK(sm.running == 0);
    CHECK(sm.state_word & FAULT_BIT);
    CHECK(!(sm.state_word & RUNNING_BIT));
    CHECK(!(sm.state_word & READY_BIT));
}

void test_ready_to_fault_direct(void)
{
    setup();
    CHECK(sm.state_word & READY_BIT);

    state_machine_set_fault(&sm, 1);
    CHECK(sm.faulted == 1);
    CHECK(sm.state_word & FAULT_BIT);
    CHECK(!(sm.state_word & READY_BIT));
}

void test_fault_blocks_start(void)
{
    setup();
    state_machine_set_fault(&sm, 1);
    CHECK(sm.faulted == 1);

    sm.start_request = 1;
    tick_ms(&sm, 10);
    CHECK(sm.running == 0);
    CHECK(sm.start_seq_step == START_SEQ_IDLE);
}

void test_fault_detection_in_running(void)
{
    setup();
    sm.start_request = 1;
    while (sm.start_seq_step != START_SEQ_RUNNING && sm.running == 0) {
        tick_ms(&sm, 10);
    }
    CHECK(sm.running == 1);

    uint16_t fw = prot_fault_detect(25000, 15000, 500, 0, 0, 0, 1);
    if (fw != 0) {
        state_machine_set_fault(&sm, 1);
        CHECK(sm.faulted == 1);
        CHECK(sm.state_word & FAULT_BIT);
    }
    CHECK(fw != 0);
}

void test_fault_latches_until_reset(void)
{
    setup();
    state_machine_set_fault(&sm, 1);
    CHECK(sm.faulted == 1);

    sm.start_request = 1;
    tick_ms(&sm, 20);
    CHECK(sm.running == 0);

    state_machine_reset_fault(&sm);
    CHECK(sm.faulted == 0);
    CHECK(sm.state_word & READY_BIT);
    CHECK(!(sm.state_word & FAULT_BIT));
}

/* --------------------------------------------------------------------------
 * Tests: emergency stop flow
 * -------------------------------------------------------------------------- */
void test_emergency_stop_from_running(void)
{
    setup();
    sm.start_request = 1;
    while (sm.start_seq_step != START_SEQ_RUNNING && sm.running == 0) {
        tick_ms(&sm, 10);
    }
    CHECK(sm.running == 1);

    sm.emergency_stop_active = 1;

    tick_ms(&sm, 1);
    CHECK(sm.faulted == 1);
    CHECK(sm.running == 0);
    CHECK(sm.state_word & READY_BIT);
    CHECK(!(sm.state_word & RUNNING_BIT));
}

void test_emergency_stop_from_ramping(void)
{
    setup();
    sm.start_request = 1;
    tick_ms(&sm, 1);
    CHECK(sm.start_seq_step == START_SEQ_INTERLOCK);

    sm.emergency_stop_active = 1;
    tick_ms(&sm, 1);
    CHECK(sm.faulted == 1);
    CHECK(sm.running == 0);
}

void test_emergency_stop_from_idle(void)
{
    setup();
    CHECK(sm.state_word & READY_BIT);

    sm.emergency_stop_active = 1;
    tick_ms(&sm, 1);
    CHECK(sm.faulted == 1);
    CHECK(sm.state_word & READY_BIT);
}

void test_emergency_stop_response_speed_coast(void)
{
    setup();
    sm.start_request = 1;
    while (sm.start_seq_step != START_SEQ_RUNNING && sm.running == 0) {
        tick_ms(&sm, 10);
    }
    CHECK(sm.running == 1);

    sm.emergency_stop_active = 1;
    sm.coast_stop_active = 1;

    tick_ms(&sm, 1);
    CHECK(sm.ramp_down_rate == 400.0f);
}

/* --------------------------------------------------------------------------
 * Tests: fault reset sequence
 * -------------------------------------------------------------------------- */
void test_fault_reset_full_cycle(void)
{
    setup();

    CHECK(sm.state_word & READY_BIT);

    sm.start_request = 1;
    while (sm.start_seq_step != START_SEQ_RUNNING && sm.running == 0) {
        tick_ms(&sm, 10);
    }
    CHECK(sm.running == 1);

    state_machine_set_fault(&sm, 1);
    CHECK(sm.faulted == 1);
    CHECK(sm.state_word & FAULT_BIT);

    state_machine_reset_fault(&sm);
    CHECK(sm.faulted == 0);
    CHECK(sm.state_word & READY_BIT);

    sm.start_request = 1;
    while (sm.start_seq_step != START_SEQ_RUNNING && sm.running == 0) {
        tick_ms(&sm, 10);
    }
    CHECK(sm.running == 1);
}

void test_fault_reset_preserves_direction(void)
{
    setup();
    sm.direction = DIR_REVERSE;

    sm.start_request = 1;
    while (sm.start_seq_step != START_SEQ_RUNNING && sm.running == 0) {
        tick_ms(&sm, 10);
    }

    state_machine_set_fault(&sm, 1);
    state_machine_reset_fault(&sm);

    CHECK(sm.direction == DIR_REVERSE);
}

void test_fault_reset_requires_explicit_reset(void)
{
    setup();
    sm.start_request = 1;
    while (sm.start_seq_step != START_SEQ_RUNNING && sm.running == 0) {
        tick_ms(&sm, 10);
    }
    state_machine_set_fault(&sm, 1);
    CHECK(sm.faulted == 1);

    sm.start_request = 1;
    tick_ms(&sm, 20);
    CHECK(sm.running == 0);

    state_machine_reset_fault(&sm);
    sm.start_request = 1;
    while (sm.start_seq_step != START_SEQ_RUNNING && sm.running == 0) {
        tick_ms(&sm, 10);
    }
    CHECK(sm.running == 1);
}

void test_fault_reset_only_from_faulted(void)
{
    setup();
    CHECK(sm.state_word & READY_BIT);
    state_machine_reset_fault(&sm);
    CHECK(sm.state_word & READY_BIT);
    CHECK(sm.faulted == 0);
}

/* --------------------------------------------------------------------------
 * Tests: interlock prevents start
 * -------------------------------------------------------------------------- */
void test_interlock_blocks_start(void)
{
    setup();
    sm.interlock_ok = 0;
    sm.start_request = 1;

    tick_ms(&sm, 10);
    CHECK(sm.running == 0);
    CHECK(sm.start_seq_step == START_SEQ_IDLE);
}

void test_interlock_clear_allows_start(void)
{
    setup();
    sm.interlock_ok = 0;
    sm.start_request = 1;
    tick_ms(&sm, 1);
    CHECK(sm.running == 0);

    sm.interlock_ok = 1;
    sm.start_request = 1;

    tick_ms(&sm, 1);
    CHECK(sm.start_seq_step == START_SEQ_INTERLOCK);
}

/* --------------------------------------------------------------------------
 * Tests: start/stop mode integration
 * -------------------------------------------------------------------------- */
void test_mode_level_trigger_active(void)
{
    setup();
    mode.trigger_type = TRIGGER_LEVEL;
    mode.start_cmd_input = 1;

    startstop_mode_configure(&mode);
    CHECK(mode.level_active == 1);
}

void test_mode_edge_trigger_rising(void)
{
    setup();
    mode.trigger_type = TRIGGER_EDGE;
    mode.edge_prev = 0;
    mode.start_cmd_input = 1;

    startstop_mode_configure(&mode);
    CHECK(mode.edge_latched == 1);
    CHECK(mode.edge_detect_enable == 1);
}

void test_mode_auto_overrides(void)
{
    setup();
    mode.start_mode = START_MODE_AUTO;
    mode.trigger_type = TRIGGER_EDGE;

    startstop_mode_configure(&mode);
    CHECK(mode.edge_detect_enable == 1);
    CHECK(mode.level_active == 1);
}

void test_mode_stop_cmd_in_auto(void)
{
    setup();
    mode.start_mode = START_MODE_AUTO;
    mode.level_active = 1;
    mode.edge_latched = 1;
    mode.stop_cmd_input = 1;

    startstop_mode_configure(&mode);
    CHECK(mode.level_active == 0);
    CHECK(mode.edge_latched == 0);
}

void test_integrated_mode_and_state_machine(void)
{
    setup();
    mode.start_mode = START_MODE_AUTO;
    mode.trigger_type = TRIGGER_LEVEL;

    startstop_mode_configure(&mode);
    CHECK(mode.level_active == 1);

    if (mode.level_active) {
        sm.start_request = 1;
    }
    while (sm.start_seq_step != START_SEQ_RUNNING && sm.running == 0) {
        tick_ms(&sm, 10);
    }
    CHECK(sm.running == 1);

    mode.stop_cmd_input = 1;
    startstop_mode_configure(&mode);
    CHECK(mode.level_active == 0);

    if (mode.level_active == 0) {
        sm.stop_request = 1;
        tick_ms(&sm, 1);
    }
    CHECK(sm.running == 0);
}

/* --------------------------------------------------------------------------
 * Tests: multiple fault types during running
 * -------------------------------------------------------------------------- */
void test_fault_multi_type_during_running(void)
{
    setup();
    sm.start_request = 1;
    while (sm.start_seq_step != START_SEQ_RUNNING && sm.running == 0) {
        tick_ms(&sm, 10);
    }
    CHECK(sm.running == 1);

    uint16_t fw1 = prot_fault_detect(21000, 15000, 500, 0, 0, 0, 1);
    if (fw1) state_machine_set_fault(&sm, 1);
    CHECK(sm.faulted == 1);
    state_machine_reset_fault(&sm);

    sm.start_request = 1;
    while (sm.start_seq_step != START_SEQ_RUNNING && sm.running == 0) {
        tick_ms(&sm, 10);
    }
    CHECK(sm.running == 1);

    uint16_t fw2 = prot_fault_detect(10000, 25000, 500, 0, 0, 0, 1);
    if (fw2) state_machine_set_fault(&sm, 1);
    CHECK(sm.faulted == 1);

    uint16_t expected = PROT_FAULT_OVERVOLTAGE;
    CHECK(fw2 == expected);
}

/* --------------------------------------------------------------------------
 * Test runner
 * -------------------------------------------------------------------------- */
int main(void)
{
    printf("=== State Machine Flow Integration Tests ===\n");

    test_init_is_ready();
    test_ready_to_running_full_sequence();
    test_ready_to_running_status_word();
    test_ready_to_running_with_forward_direction();
    test_ready_to_running_with_reverse_direction();
    test_running_to_ready_normal_stop();
    test_running_to_ready_ramp_stop();
    test_running_to_ready_coast_stop();
    test_running_to_fault_overcurrent();
    test_ready_to_fault_direct();
    test_fault_blocks_start();
    test_fault_detection_in_running();
    test_fault_latches_until_reset();
    test_emergency_stop_from_running();
    test_emergency_stop_from_ramping();
    test_emergency_stop_from_idle();
    test_emergency_stop_response_speed_coast();
    test_fault_reset_full_cycle();
    test_fault_reset_preserves_direction();
    test_fault_reset_requires_explicit_reset();
    test_fault_reset_only_from_faulted();
    test_interlock_blocks_start();
    test_interlock_clear_allows_start();
    test_mode_level_trigger_active();
    test_mode_edge_trigger_rising();
    test_mode_auto_overrides();
    test_mode_stop_cmd_in_auto();
    test_integrated_mode_and_state_machine();
    test_fault_multi_type_during_running();

    int total_checks = tests_passed + tests_failed;
    printf("\nResults: %d/%d checks passed, %d failed\n",
           tests_passed, total_checks, tests_failed);
    return tests_failed > 0 ? 1 : 0;
}
