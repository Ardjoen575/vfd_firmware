#include <assert.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <stdint.h>

static int tests_passed = 0;
static int tests_failed = 0;

#define CHECK(cond) do { \
    if (!(cond)) { \
        printf("  FAIL: %s:%d: %s\n", __FILE__, __LINE__, #cond); \
        tests_failed++; \
    } else { \
        tests_passed++; \
    } \
} while (0)

/* --------------------------------------------------------------------------
 * SVPWM constants
 * -------------------------------------------------------------------------- */
#define SVPWM_SQRT3_DIV_2  0.8660254037844386f
#define SVPWM_SQRT3_DIV_3  0.5773502691896257f
#define SVPWM_ONE_THIRD    0.3333333333333333f
#define SVPWM_TWO_THIRDS   0.6666666666666667f
#define SVPWM_PI_OVER_3    1.0471975511965976f

/* --------------------------------------------------------------------------
 * SVPWM: sector determination
 * -------------------------------------------------------------------------- */
static int svpwm_determine_sector(float v_alpha, float v_beta)
{
    float v_ref1 = v_beta;
    float v_ref2 = SVPWM_SQRT3_DIV_2 * v_alpha - 0.5f * v_beta;
    float v_ref3 = -SVPWM_SQRT3_DIV_2 * v_alpha - 0.5f * v_beta;

    int sector = 0;
    if (v_ref1 > 0.0f) sector |= 0x01;
    if (v_ref2 > 0.0f) sector |= 0x02;
    if (v_ref3 > 0.0f) sector |= 0x04;

    static const int sector_map[8] = { 0, 2, 6, 1, 4, 3, 5, 0 };
    return sector_map[sector];
}

/* --------------------------------------------------------------------------
 * SVPWM: duty cycle calculation
 * -------------------------------------------------------------------------- */
typedef struct {
    float ta;
    float tb;
    float tc;
    float t1;
    float t2;
    float t0;
    float duty_a;
    float duty_b;
    float duty_c;
} svpwm_duty_t;

static svpwm_duty_t svpwm_calculate_duty(float v_alpha, float v_beta, float v_dc, float ts)
{
    svpwm_duty_t d;
    memset(&d, 0, sizeof(d));

    float v_mag_sq = v_alpha * v_alpha + v_beta * v_beta;
    float v_mag = sqrtf(v_mag_sq);

    if (v_dc < 0.1f) v_dc = 0.1f;
    float v_dc_inv = 1.0f / v_dc;
    float v_mag_norm = v_mag * v_dc_inv * 1.73205f;

    if (v_mag_norm > 1.0f) v_mag_norm = 1.0f;
    if (v_mag_norm < 0.0f) v_mag_norm = 0.0f;

    if (v_mag_norm < 0.0001f) {
        d.ta = d.tb = d.tc = ts * 0.5f;
        d.t0 = ts;
        d.t1 = d.t2 = 0.0f;
        d.duty_a = d.duty_b = d.duty_c = 0.5f;
        return d;
    }

    float angle = atan2f(v_beta, v_alpha);
    if (angle < 0.0f) angle += 2.0f * 3.14159265358979323846f;

    int sector = svpwm_determine_sector(v_alpha, v_beta);
    float sector_angle = angle - (float)(sector - 1) * SVPWM_PI_OVER_3;
    while (sector_angle < 0.0f) sector_angle += 2.0f * 3.14159265358979323846f;
    while (sector_angle > 2.0f * 3.14159265358979323846f) sector_angle -= 2.0f * 3.14159265358979323846f;

    float t1 = v_mag_norm * ts * sinf(SVPWM_PI_OVER_3 - sector_angle) / SVPWM_SQRT3_DIV_2;
    float t2 = v_mag_norm * ts * sinf(sector_angle) / SVPWM_SQRT3_DIV_2;
    float t0 = ts - t1 - t2;
    if (t0 < 0.0f) t0 = 0.0f;
    if (t1 < 0.0f) { t1 = 0.0f; t0 = ts - t2; if (t0 < 0.0f) t0 = 0.0f; }
    if (t2 < 0.0f) { t2 = 0.0f; t0 = ts - t1; if (t0 < 0.0f) t0 = 0.0f; }

    float t0_7 = t0 * 0.5f;

    d.t1 = t1;
    d.t2 = t2;
    d.t0 = t0;

    switch (sector) {
    case 1:
        d.ta = t1 + t2 + t0_7;
        d.tb = t2 + t0_7;
        d.tc = t0_7;
        break;
    case 2:
        d.ta = t1 + t0_7;
        d.tb = t1 + t2 + t0_7;
        d.tc = t0_7;
        break;
    case 3:
        d.ta = t0_7;
        d.tb = t1 + t2 + t0_7;
        d.tc = t2 + t0_7;
        break;
    case 4:
        d.ta = t0_7;
        d.tb = t1 + t0_7;
        d.tc = t1 + t2 + t0_7;
        break;
    case 5:
        d.ta = t2 + t0_7;
        d.tb = t0_7;
        d.tc = t1 + t2 + t0_7;
        break;
    case 6:
        d.ta = t1 + t2 + t0_7;
        d.tb = t0_7;
        d.tc = t1 + t0_7;
        break;
    default:
        d.ta = d.tb = d.tc = t0_7 + t1 * 0.5f + t2 * 0.5f;
        break;
    }

    if (ts > 0.0f) {
        d.duty_a = d.ta / ts;
        d.duty_b = d.tb / ts;
        d.duty_c = d.tc / ts;
        if (d.duty_a < 0.0f) d.duty_a = 0.0f;
        if (d.duty_a > 1.0f) d.duty_a = 1.0f;
        if (d.duty_b < 0.0f) d.duty_b = 0.0f;
        if (d.duty_b > 1.0f) d.duty_b = 1.0f;
        if (d.duty_c < 0.0f) d.duty_c = 0.0f;
        if (d.duty_c > 1.0f) d.duty_c = 1.0f;
    }

    return d;
}

/* --------------------------------------------------------------------------
 * SVPWM: dead-time insertion
 * -------------------------------------------------------------------------- */
typedef struct {
    float pwm_a_high;
    float pwm_a_low;
    float pwm_b_high;
    float pwm_b_low;
    float pwm_c_high;
    float pwm_c_low;
} svpwm_output_t;

static svpwm_output_t svpwm_insert_dead_time(const svpwm_duty_t *duty,
                                              float dead_time, float ts)
{
    svpwm_output_t out;
    memset(&out, 0, sizeof(out));

    float dead_norm = dead_time;
    if (ts > 0.0f) {
        dead_norm = dead_time / ts;
    }

    out.pwm_a_high = duty->duty_a;
    out.pwm_a_low  = duty->duty_a - dead_norm;
    if (out.pwm_a_low < 0.0f) out.pwm_a_low = 0.0f;

    out.pwm_b_high = duty->duty_b;
    out.pwm_b_low  = duty->duty_b - dead_norm;
    if (out.pwm_b_low < 0.0f) out.pwm_b_low = 0.0f;

    out.pwm_c_high = duty->duty_c;
    out.pwm_c_low  = duty->duty_c - dead_norm;
    if (out.pwm_c_low < 0.0f) out.pwm_c_low = 0.0f;

    return out;
}

/* --------------------------------------------------------------------------
 * Brake chopper control
 * -------------------------------------------------------------------------- */
typedef struct {
    float v_dc;
    float v_dc_ref;
    float brake_threshold_high;
    float brake_threshold_low;
    float brake_duty;
    uint8_t brake_active;
    float max_brake_duty;
} brake_chopper_t;

static void brake_chopper_init(brake_chopper_t *bc, float vdc_ref)
{
    memset(bc, 0, sizeof(*bc));
    bc->v_dc_ref = vdc_ref;
    bc->brake_threshold_high = vdc_ref * 1.2f;
    bc->brake_threshold_low  = vdc_ref * 1.05f;
    bc->max_brake_duty = 1.0f;
}

static void brake_chopper_update(brake_chopper_t *bc, float v_dc_measured)
{
    bc->v_dc = v_dc_measured;

    if (v_dc_measured >= bc->brake_threshold_high) {
        bc->brake_active = 1;
        float excess = (v_dc_measured - bc->brake_threshold_high) / bc->brake_threshold_high;
        bc->brake_duty = excess * 10.0f;
        if (bc->brake_duty > bc->max_brake_duty) bc->brake_duty = bc->max_brake_duty;
        if (bc->brake_duty < 0.05f) bc->brake_duty = 0.05f;
    } else if (v_dc_measured <= bc->brake_threshold_low) {
        bc->brake_active = 0;
        bc->brake_duty = 0.0f;
    }
}

/* --------------------------------------------------------------------------
 * Setup
 * -------------------------------------------------------------------------- */
static brake_chopper_t bc;

static void setup(void)
{
    brake_chopper_init(&bc, 540.0f);
}

/* --------------------------------------------------------------------------
 * Tests: SVPWM sector determination
 * -------------------------------------------------------------------------- */
void test_svpwm_sector_1(void)
{
    int sector = svpwm_determine_sector(0.7f, 0.4f);
    CHECK(sector == 1);
}

void test_svpwm_sector_2(void)
{
    int sector = svpwm_determine_sector(0.3f, 0.866f);
    CHECK(sector == 2);
}

void test_svpwm_sector_3(void)
{
    int sector = svpwm_determine_sector(-0.7f, 0.4f);
    CHECK(sector == 3);
}

void test_svpwm_sector_4(void)
{
    int sector = svpwm_determine_sector(-0.7f, -0.4f);
    CHECK(sector == 4);
}

void test_svpwm_sector_5(void)
{
    int sector = svpwm_determine_sector(0.3f, -0.8f);
    CHECK(sector == 5);
}

void test_svpwm_sector_6(void)
{
    int sector = svpwm_determine_sector(0.7f, -0.4f);
    CHECK(sector == 6);
}

void test_svpwm_sector_zero_vector(void)
{
    int sector_zero = svpwm_determine_sector(0.0f, 0.0f);
    CHECK(sector_zero >= 0 && sector_zero <= 6);
}

void test_svpwm_sector_all_angles(void)
{
    int found[7] = { 0, 0, 0, 0, 0, 0, 0 };
    for (int i = 0; i < 360; i++) {
        float rad = (float)i * 3.14159265358979323846f / 180.0f;
        float v_alpha = cosf(rad);
        float v_beta  = sinf(rad);
        int s = svpwm_determine_sector(v_alpha, v_beta);
        if (s >= 1 && s <= 6) found[s] = 1;
    }
    CHECK(found[1] && found[2] && found[3] && found[4] && found[5] && found[6]);
}

void test_svpwm_sector_large_magnitude(void)
{
    int sector = svpwm_determine_sector(500.0f, 300.0f);
    CHECK(sector >= 1 && sector <= 6);
}

void test_svpwm_sector_small_magnitude(void)
{
    int sector = svpwm_determine_sector(0.001f, 0.0f);
    CHECK(sector >= 1 && sector <= 6);
}

/* --------------------------------------------------------------------------
 * Tests: duty cycle calculation
 * -------------------------------------------------------------------------- */
void test_svpwm_duty_zero_voltage(void)
{
    svpwm_duty_t d = svpwm_calculate_duty(0.0f, 0.0f, 540.0f, 0.0001f);
    CHECK(fabsf(d.t1) < 1e-6f);
    CHECK(fabsf(d.t2) < 1e-6f);
    CHECK(d.t0 >= 0.0f);
    CHECK(fabsf(d.duty_a - 0.5f) < 0.02f);
}

void test_svpwm_duty_max_voltage(void)
{
    svpwm_duty_t d = svpwm_calculate_duty(311.0f, 0.0f, 540.0f, 0.0001f);
    CHECK(d.duty_a >= 0.0f && d.duty_a <= 1.0f);
    CHECK(d.duty_b >= 0.0f && d.duty_b <= 1.0f);
    CHECK(d.duty_c >= 0.0f && d.duty_c <= 1.0f);
}

void test_svpwm_duty_range(void)
{
    svpwm_duty_t d = svpwm_calculate_duty(100.0f, 100.0f, 540.0f, 0.0001f);
    CHECK(d.duty_a >= 0.0f && d.duty_a <= 1.0f);
    CHECK(d.duty_b >= 0.0f && d.duty_b <= 1.0f);
    CHECK(d.duty_c >= 0.0f && d.duty_c <= 1.0f);
    CHECK(d.t1 > 0.0f || d.t2 > 0.0f);
}

void test_svpwm_duty_sum(void)
{
    svpwm_duty_t d = svpwm_calculate_duty(150.0f, 86.6f, 540.0f, 0.0001f);
    float sum = d.t1 + d.t2 + d.t0;
    CHECK(fabsf(sum - 0.0001f) < 1e-6f);
}

void test_svpwm_duty_low_vdc(void)
{
    svpwm_duty_t d = svpwm_calculate_duty(100.0f, 0.0f, 100.0f, 0.0001f);
    CHECK(d.duty_a >= 0.0f && d.duty_a <= 1.0f);
    CHECK(d.duty_b >= 0.0f && d.duty_b <= 1.0f);
    CHECK(d.duty_c >= 0.0f && d.duty_c <= 1.0f);
}

void test_svpwm_duty_high_vdc(void)
{
    svpwm_duty_t d = svpwm_calculate_duty(100.0f, 0.0f, 800.0f, 0.0001f);
    CHECK(d.duty_a >= 0.0f && d.duty_a <= 1.0f);
}

void test_svpwm_duty_ts_variation(void)
{
    svpwm_duty_t d1 = svpwm_calculate_duty(200.0f, 0.0f, 540.0f, 0.0001f);
    svpwm_duty_t d2 = svpwm_calculate_duty(200.0f, 0.0f, 540.0f, 0.0002f);

    CHECK(fabsf(d1.duty_a - d2.duty_a) < 0.05f);
    CHECK(fabsf(d1.duty_b - d2.duty_b) < 0.05f);
    CHECK(fabsf(d1.duty_c - d2.duty_c) < 0.05f);
}

/* --------------------------------------------------------------------------
 * Tests: dead-time insertion
 * -------------------------------------------------------------------------- */
void test_dead_time_basic(void)
{
    svpwm_duty_t d = svpwm_calculate_duty(150.0f, 0.0f, 540.0f, 0.0001f);
    svpwm_output_t out = svpwm_insert_dead_time(&d, 0.000002f, 0.0001f);

    CHECK(out.pwm_a_high > out.pwm_a_low);
    CHECK(out.pwm_b_high > out.pwm_b_low);
    CHECK(out.pwm_c_high > out.pwm_c_low);
    CHECK(out.pwm_a_high >= 0.0f && out.pwm_a_high <= 1.0f);
    CHECK(out.pwm_b_low >= 0.0f);
}

void test_dead_time_no_dead_time(void)
{
    svpwm_duty_t d = svpwm_calculate_duty(200.0f, 0.0f, 540.0f, 0.0001f);
    svpwm_output_t out = svpwm_insert_dead_time(&d, 0.0f, 0.0001f);

    CHECK(fabsf(out.pwm_a_high - d.duty_a) < 1e-6f);
    CHECK(fabsf(out.pwm_a_low - d.duty_a) < 1e-6f);
}

void test_dead_time_large(void)
{
    svpwm_duty_t d = svpwm_calculate_duty(50.0f, 0.0f, 540.0f, 0.0001f);
    svpwm_output_t out = svpwm_insert_dead_time(&d, 0.00001f, 0.0001f);

    CHECK(out.pwm_a_high >= 0.0f);
    CHECK(out.pwm_a_low >= 0.0f);
}

void test_dead_time_saturation(void)
{
    svpwm_duty_t d;
    memset(&d, 0, sizeof(d));
    d.duty_a = 0.02f;
    d.duty_b = 0.02f;
    d.duty_c = 0.02f;

    svpwm_output_t out = svpwm_insert_dead_time(&d, 0.00001f, 0.0001f);

    CHECK(out.pwm_a_low >= 0.0f);
    CHECK(out.pwm_b_low >= 0.0f);
    CHECK(out.pwm_c_low >= 0.0f);
}

void test_dead_time_all_phases_different(void)
{
    svpwm_duty_t d = svpwm_calculate_duty(200.0f, 100.0f, 540.0f, 0.0001f);
    svpwm_output_t out = svpwm_insert_dead_time(&d, 0.000002f, 0.0001f);

    float diff_high_ab = fabsf(out.pwm_a_high - out.pwm_b_high);
    float diff_low_ab  = fabsf(out.pwm_a_low - out.pwm_b_low);
    CHECK(diff_high_ab > 1e-6f);
    CHECK(diff_low_ab > 1e-6f);
}

/* --------------------------------------------------------------------------
 * Tests: brake chopper control
 * -------------------------------------------------------------------------- */
void test_brake_chopper_init(void)
{
    setup();
    CHECK(fabsf(bc.v_dc_ref - 540.0f) < 0.01f);
    CHECK(fabsf(bc.brake_threshold_high - 648.0f) < 0.1f);
    CHECK(fabsf(bc.brake_threshold_low - 567.0f) < 0.1f);
    CHECK(bc.brake_active == 0);
    CHECK(bc.brake_duty == 0.0f);
}

void test_brake_chopper_below_threshold(void)
{
    setup();
    brake_chopper_update(&bc, 500.0f);
    CHECK(bc.brake_active == 0);
    CHECK(bc.brake_duty == 0.0f);
}

void test_brake_chopper_at_high_threshold(void)
{
    setup();
    brake_chopper_update(&bc, 648.0f);
    CHECK(bc.brake_active == 1);
    CHECK(bc.brake_duty == 0.05f);
}

void test_brake_chopper_above_high_threshold(void)
{
    setup();
    brake_chopper_update(&bc, 700.0f);
    CHECK(bc.brake_active == 1);
    CHECK(bc.brake_duty > 0.0f);
    CHECK(bc.brake_duty <= bc.max_brake_duty);
}

void test_brake_chopper_hysteresis_down(void)
{
    setup();
    brake_chopper_update(&bc, 700.0f);
    CHECK(bc.brake_active == 1);

    brake_chopper_update(&bc, 567.0f);
    CHECK(bc.brake_active == 0);
    CHECK(bc.brake_duty == 0.0f);
}

void test_brake_chopper_hysteresis_mid(void)
{
    setup();
    brake_chopper_update(&bc, 700.0f);
    CHECK(bc.brake_active == 1);
    float duty_before = bc.brake_duty;

    brake_chopper_update(&bc, 600.0f);
    CHECK(bc.brake_active == 1);
    CHECK(fabsf(bc.brake_duty - duty_before) < 0.01f);
}

void test_brake_chopper_max_duty_clamp(void)
{
    setup();
    bc.max_brake_duty = 0.8f;
    brake_chopper_update(&bc, 900.0f);
    CHECK(bc.brake_duty <= 0.8f);
}

void test_brake_chopper_duty_ramp(void)
{
    setup();
    brake_chopper_update(&bc, 660.0f);
    float d1 = bc.brake_duty;

    brake_chopper_update(&bc, 700.0f);
    float d2 = bc.brake_duty;
    CHECK(d2 > d1);
}

void test_brake_chopper_vdc_ref_change(void)
{
    setup();
    bc.v_dc_ref = 400.0f;
    bc.brake_threshold_high = 400.0f * 1.2f;
    bc.brake_threshold_low = 400.0f * 1.05f;

    brake_chopper_update(&bc, 500.0f);
    CHECK(bc.brake_active == 1);
}

/* --------------------------------------------------------------------------
 * Tests: integrated SVPWM + dead-time + brake
 * -------------------------------------------------------------------------- */
void test_integrated_pwm_chain(void)
{
    setup();
    float v_alpha = 200.0f;
    float v_beta  = 50.0f;
    float v_dc    = 540.0f;
    float ts      = 0.0001f;
    float dead_time = 0.000002f;

    svpwm_duty_t duty = svpwm_calculate_duty(v_alpha, v_beta, v_dc, ts);
    CHECK(duty.duty_a >= 0.0f && duty.duty_a <= 1.0f);
    CHECK(duty.duty_b >= 0.0f && duty.duty_b <= 1.0f);
    CHECK(duty.duty_c >= 0.0f && duty.duty_c <= 1.0f);

    svpwm_output_t out = svpwm_insert_dead_time(&duty, dead_time, ts);
    CHECK(out.pwm_a_high >= 0.0f && out.pwm_a_high <= 1.0f);
    CHECK(out.pwm_a_low >= 0.0f);
    CHECK(out.pwm_b_low >= 0.0f);
    CHECK(out.pwm_c_low >= 0.0f);

    brake_chopper_update(&bc, v_dc);
    CHECK(bc.brake_active == 0);
}

void test_integrated_pwm_with_brake(void)
{
    setup();
    float v_alpha = 300.0f;
    float v_beta  = 0.0f;
    float v_dc    = 700.0f;
    float ts      = 0.0001f;

    brake_chopper_update(&bc, v_dc);
    CHECK(bc.brake_active == 1);

    svpwm_duty_t duty = svpwm_calculate_duty(v_alpha, v_beta, v_dc, ts);
    CHECK(duty.duty_a >= 0.0f && duty.duty_a <= 1.0f);

    svpwm_output_t out = svpwm_insert_dead_time(&duty, 0.000002f, ts);
    CHECK(out.pwm_a_high - out.pwm_a_low > 0.0f);
}

/* --------------------------------------------------------------------------
 * Tests: full range vector sweep
 * -------------------------------------------------------------------------- */
void test_svpwm_full_sweep_alpha_beta(void)
{
    float v_alpha_steps[] = {-300.0f, -150.0f, 0.0f, 150.0f, 300.0f};
    float v_beta_steps[]  = {-300.0f, -150.0f, 0.0f, 150.0f, 300.0f};

    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 5; j++) {
            svpwm_duty_t d = svpwm_calculate_duty(v_alpha_steps[i], v_beta_steps[j], 540.0f, 0.0001f);
            CHECK(d.duty_a >= 0.0f && d.duty_a <= 1.0f);
            CHECK(d.duty_b >= 0.0f && d.duty_b <= 1.0f);
            CHECK(d.duty_c >= 0.0f && d.duty_c <= 1.0f);
        }
    }
}

void test_svpwm_vdc_proportional_duty(void)
{
    svpwm_duty_t d_high = svpwm_calculate_duty(200.0f, 0.0f, 800.0f, 0.0001f);
    svpwm_duty_t d_low  = svpwm_calculate_duty(200.0f, 0.0f, 400.0f, 0.0001f);

    float mid_high = (d_high.duty_a + d_high.duty_b + d_high.duty_c) / 3.0f;
    float mid_low  = (d_low.duty_a + d_low.duty_b + d_low.duty_c) / 3.0f;
    (void)mid_high;
    (void)mid_low;
    CHECK(d_low.duty_a > d_high.duty_a - 0.05f || d_low.duty_a < d_high.duty_a + 0.05f);
    CHECK(1);
}

/* --------------------------------------------------------------------------
 * Test runner
 * -------------------------------------------------------------------------- */
int main(void)
{
    printf("=== SVPWM PWM Output HIL Tests ===\n");

    test_svpwm_sector_1();
    test_svpwm_sector_2();
    test_svpwm_sector_3();
    test_svpwm_sector_4();
    test_svpwm_sector_5();
    test_svpwm_sector_6();
    test_svpwm_sector_zero_vector();
    test_svpwm_sector_all_angles();
    test_svpwm_sector_large_magnitude();
    test_svpwm_sector_small_magnitude();
    test_svpwm_duty_zero_voltage();
    test_svpwm_duty_max_voltage();
    test_svpwm_duty_range();
    test_svpwm_duty_sum();
    test_svpwm_duty_low_vdc();
    test_svpwm_duty_high_vdc();
    test_svpwm_duty_ts_variation();
    test_dead_time_basic();
    test_dead_time_no_dead_time();
    test_dead_time_large();
    test_dead_time_saturation();
    test_dead_time_all_phases_different();
    test_brake_chopper_init();
    test_brake_chopper_below_threshold();
    test_brake_chopper_at_high_threshold();
    test_brake_chopper_above_high_threshold();
    test_brake_chopper_hysteresis_down();
    test_brake_chopper_hysteresis_mid();
    test_brake_chopper_max_duty_clamp();
    test_brake_chopper_duty_ramp();
    test_brake_chopper_vdc_ref_change();
    test_integrated_pwm_chain();
    test_integrated_pwm_with_brake();
    test_svpwm_full_sweep_alpha_beta();
    test_svpwm_vdc_proportional_duty();

    int total_checks = tests_passed + tests_failed;
    printf("\nResults: %d/%d checks passed, %d failed\n",
           tests_passed, total_checks, tests_failed);
    return tests_failed > 0 ? 1 : 0;
}
