#ifndef DCVOLTAGECONTROL_OVERVOLTAGE_CONTROL_H
#define DCVOLTAGECONTROL_OVERVOLTAGE_CONTROL_H

/* DC bus overvoltage control */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    uint8_t active;
    float dc_voltage;
    float ov_threshold;
    float ov_reference;
    float ov_max_voltage;
    float freq_boost;
    float freq_boost_rate;
    float freq_boost_max;
    float freq_boost_integral;
    float kp;
    float ki;
    float controller_output;
    float freq_ref_base;
    float freq_ref_modified;
    uint8_t overvoltage_detected;
} overvoltage_control_state_t;

void overvoltage_control_init(overvoltage_control_state_t *state);
void overvoltage_control_update(overvoltage_control_state_t *state);
void overvoltage_regulate(overvoltage_control_state_t *state);

#endif /* DCVOLTAGECONTROL_OVERVOLTAGE_CONTROL_H */
