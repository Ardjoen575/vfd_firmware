#include "overvoltage_control.h"
#include <math.h>

#define FMAX(a, b) ((a) > (b) ? (a) : (b))
#define FMIN(a, b) ((a) < (b) ? (a) : (b))
#define FABS(x) ((x) < 0.0f ? -(x) : (x))

static float clampf(float val, float lo, float hi)
{
    if (val > hi) return hi;
    if (val < lo) return lo;
    return val;
}

void overvoltage_control_init(overvoltage_control_state_t *state)
{
    state->initialized = 1;
    state->active = 1;
    state->dc_voltage = 540.0f;
    state->ov_threshold = 780.0f;
    state->ov_reference = 760.0f;
    state->ov_max_voltage = 850.0f;
    state->freq_boost = 0.0f;
    state->freq_boost_rate = 50.0f;
    state->freq_boost_max = 10.0f;
    state->freq_boost_integral = 0.0f;
    state->kp = 0.5f;
    state->ki = 5.0f;
    state->controller_output = 0.0f;
    state->freq_ref_base = 0.0f;
    state->freq_ref_modified = 0.0f;
    state->overvoltage_detected = 0;
}

void overvoltage_control_update(overvoltage_control_state_t *state)
{
    overvoltage_regulate(state);
}

void overvoltage_regulate(overvoltage_control_state_t *state)
{
    float error;
    float prop;
    float dt = 0.001f;

    if (!state->active) {
        state->freq_boost = 0.0f;
        state->freq_boost_integral = 0.0f;
        state->controller_output = 0.0f;
        state->freq_ref_modified = state->freq_ref_base;
        state->overvoltage_detected = 0;
        return;
    }

    if (state->dc_voltage > state->ov_threshold) {
        state->overvoltage_detected = 1;

        error = state->dc_voltage - state->ov_reference;

        prop = state->kp * error;
        state->freq_boost_integral += state->ki * error * dt;
        state->freq_boost_integral = clampf(state->freq_boost_integral, 0.0f, state->freq_boost_max);

        state->controller_output = prop + state->freq_boost_integral;
        state->freq_boost = clampf(state->controller_output, 0.0f, state->freq_boost_max);

        state->freq_ref_modified = state->freq_ref_base + state->freq_boost;
    } else {
        if (state->overvoltage_detected) {
            state->freq_boost_integral -= state->freq_boost_rate * dt * 0.1f;
            state->freq_boost_integral = FMAX(state->freq_boost_integral, 0.0f);
            state->freq_boost = state->freq_boost_integral;
            state->freq_ref_modified = state->freq_ref_base + state->freq_boost;

            if (state->freq_boost_integral <= 0.0f) {
                state->overvoltage_detected = 0;
                state->freq_boost = 0.0f;
                state->freq_boost_integral = 0.0f;
                state->controller_output = 0.0f;
                state->freq_ref_modified = state->freq_ref_base;
            }
        } else {
            state->freq_ref_modified = state->freq_ref_base;
        }
    }
}
