#ifndef DCVOLTAGECONTROL_UNDERVOLTAGE_CONTROL_H
#define DCVOLTAGECONTROL_UNDERVOLTAGE_CONTROL_H

/* Power loss ride-through */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    uint8_t active;
    uint8_t kinetic_buffering_active;
    float dc_voltage;
    float dc_voltage_nominal;
    float uv_threshold;
    float uv_min_voltage;
    float uv_reference;
    float freq_ref;
    float freq_decay_rate;
    float freq_min;
    float speed_at_start;
    float dc_minimum;
    float kinetic_energy;
    float inertia_kgm2;
    float kp;
    float ki;
    float integral;
    float integral_min;
    float integral_max;
    float controller_output;
    uint8_t power_loss_detected;
    float ride_through_timer;
    float ride_through_timeout;
} undervoltage_control_state_t;

void undervoltage_control_init(undervoltage_control_state_t *state);
void undervoltage_control_update(undervoltage_control_state_t *state);
void undervoltage_ridethrough(undervoltage_control_state_t *state);

#endif /* DCVOLTAGECONTROL_UNDERVOLTAGE_CONTROL_H */
