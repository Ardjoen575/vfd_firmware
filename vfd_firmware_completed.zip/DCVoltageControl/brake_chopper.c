#include "brake_chopper.h"

#define FMAX(a, b) ((a) > (b) ? (a) : (b))
#define FMIN(a, b) ((a) < (b) ? (a) : (b))

void brake_chopper_init(brake_chopper_state_t *state)
{
    state->initialized = 1;
    state->dc_voltage = 540.0f;
    state->dc_voltage_nominal = 540.0f;
    state->chopper_on_voltage = 780.0f;
    state->chopper_off_voltage = 750.0f;
    state->hysteresis = 10.0f;
    state->chopper_duty = 0.0f;
    state->chopper_duty_max = 0.95f;
    state->pwm_period = 0.001f;
    state->pwm_counter = 0.0f;
    state->chopper_enabled = 1;
    state->igbt_state = 0;
    state->resistance = 10.0f;
    state->power_rating = 5000.0f;
    state->power_dissipated = 0.0f;
}

void brake_chopper_update(brake_chopper_state_t *state)
{
    chopper_pwm_update(state);
}

void chopper_pwm_update(brake_chopper_state_t *state)
{
    float v_diff;
    float p_max;
    float duty_calc;

    if (!state->chopper_enabled) {
        state->igbt_state = 0;
        state->chopper_duty = 0.0f;
        state->power_dissipated = 0.0f;
        return;
    }

    v_diff = state->dc_voltage - state->chopper_on_voltage;

    if (state->dc_voltage > state->chopper_on_voltage) {
        p_max = (state->dc_voltage * state->dc_voltage) / state->resistance;

        if (p_max > 1e-6f) {
            duty_calc = v_diff / (state->chopper_on_voltage - state->chopper_off_voltage);
            if (duty_calc > 1.0f) duty_calc = 1.0f;
            if (duty_calc < 0.05f) duty_calc = 0.05f;
        } else {
            duty_calc = 0.05f;
        }

        state->chopper_duty = FMIN(duty_calc, state->chopper_duty_max);

        state->pwm_counter += 0.001f;
        if (state->pwm_counter >= state->pwm_period) {
            state->pwm_counter -= state->pwm_period;
        }

        if (state->pwm_counter < state->chopper_duty * state->pwm_period) {
            state->igbt_state = 1;
        } else {
            state->igbt_state = 0;
        }

        state->power_dissipated = (state->dc_voltage * state->dc_voltage)
                                / state->resistance * state->chopper_duty;
    } else if (state->dc_voltage < state->chopper_off_voltage) {
        state->chopper_duty = 0.0f;
        state->igbt_state = 0;
        state->power_dissipated = 0.0f;
        state->pwm_counter = 0.0f;
    } else {
        if (state->pwm_counter < state->chopper_duty * state->pwm_period) {
            state->igbt_state = 1;
        } else {
            state->igbt_state = 0;
        }
    }
}
