#ifndef DCVOLTAGECONTROL_DC_VOLTAGE_MODE_H
#define DCVOLTAGECONTROL_DC_VOLTAGE_MODE_H

/* DC voltage control mode */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    uint8_t active;
    float dc_ref;
    float dc_fb;
    float pi_kp;
    float pi_ki;
    float pi_integral;
    float pi_integral_min;
    float pi_integral_max;
    float active_current_ref;
    float reactive_current_ref;
    float active_current_limit;
    float output;
    uint8_t active_front_end_present;
} dc_voltage_mode_state_t;

void dc_voltage_mode_init(dc_voltage_mode_state_t *state);
void dc_voltage_mode_update(dc_voltage_mode_state_t *state);
void dcvolt_mode_step(dc_voltage_mode_state_t *state);

#endif /* DCVOLTAGECONTROL_DC_VOLTAGE_MODE_H */
