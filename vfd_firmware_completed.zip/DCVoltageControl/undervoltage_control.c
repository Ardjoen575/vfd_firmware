#include "undervoltage_control.h"
#include <math.h>

#define FMAX(a, b) ((a) > (b) ? (a) : (b))
#define FMIN(a, b) ((a) < (b) ? (a) : (b))
#define FABS(x) ((x) < 0.0f ? -(x) : (x))

static float clampf(float val, float lo, float hi)
{
    if (val > hi) return hi;
    if (val < lo) return lo;
    return val;
}

void undervoltage_control_init(undervoltage_control_state_t *state)
{
    state->initialized = 1;
    state->active = 1;
    state->kinetic_buffering_active = 0;
    state->dc_voltage = 540.0f;
    state->dc_voltage_nominal = 540.0f;
    state->uv_threshold = 400.0f;
    state->uv_min_voltage = 350.0f;
    state->uv_reference = 420.0f;
    state->freq_ref = 50.0f;
    state->freq_decay_rate = 20.0f;
    state->freq_min = 5.0f;
    state->speed_at_start = 0.0f;
    state->dc_minimum = 540.0f;
    state->kinetic_energy = 0.0f;
    state->inertia_kgm2 = 0.1f;
    state->kp = 2.0f;
    state->ki = 20.0f;
    state->integral = 0.0f;
    state->integral_min = -20.0f;
    state->integral_max = 0.0f;
    state->controller_output = 0.0f;
    state->power_loss_detected = 0;
    state->ride_through_timer = 0.0f;
    state->ride_through_timeout = 2.0f;
}

void undervoltage_control_update(undervoltage_control_state_t *state)
{
    undervoltage_ridethrough(state);
}

void undervoltage_ridethrough(undervoltage_control_state_t *state)
{
    float error;
    float prop;
    float dt = 0.001f;

    if (!state->active) {
        state->kinetic_buffering_active = 0;
        state->power_loss_detected = 0;
        state->integral = 0.0f;
        state->controller_output = 0.0f;
        state->ride_through_timer = 0.0f;
        return;
    }

    if (state->dc_voltage < state->uv_threshold) {
        if (!state->power_loss_detected) {
            state->power_loss_detected = 1;
            state->speed_at_start = state->freq_ref;
            state->dc_minimum = state->dc_voltage;
            state->kinetic_energy = 0.5f * state->inertia_kgm2
                                 * (state->freq_ref * 2.0f * 3.14159265358979323846f / 60.0f)
                                 * (state->freq_ref * 2.0f * 3.14159265358979323846f / 60.0f);
        }

        state->kinetic_buffering_active = 1;

        error = state->uv_reference - state->dc_voltage;

        state->integral += state->ki * error * dt;
        state->integral = clampf(state->integral, state->integral_min, 0.0f);

        prop = state->kp * error;
        state->controller_output = prop + state->integral;

        state->freq_ref = state->speed_at_start + state->controller_output;
        state->freq_ref = FMAX(state->freq_ref, state->freq_min);

        state->ride_through_timer += dt;

        if (state->dc_voltage < state->dc_minimum) {
            state->dc_minimum = state->dc_voltage;
        }

        if (state->dc_voltage < state->uv_min_voltage ||
            state->ride_through_timer > state->ride_through_timeout) {
            state->kinetic_buffering_active = 0;
            state->freq_ref = 0.0f;
            state->controller_output = 0.0f;
            state->integral = 0.0f;
        }
    } else {
        if (state->power_loss_detected) {
            state->power_loss_detected = 0;
            state->kinetic_buffering_active = 0;
            state->integral = 0.0f;
            state->controller_output = 0.0f;
            state->ride_through_timer = 0.0f;
        }
    }
}
