#include "voltage_trip_limits.h"

void voltage_trip_limits_init(voltage_trip_limits_state_t *state)
{
    state->initialized = 1;
    state->dc_voltage = 540.0f;
    state->overvolt_trip_level = 840.0f;
    state->undervolt_trip_level = 320.0f;
    state->overvolt_warning_level = 800.0f;
    state->undervolt_warning_level = 380.0f;
    state->trip_delay_time = 0.5f;
    state->ov_timer = 0.0f;
    state->uv_timer = 0.0f;
    state->ov_fault_issued = 0;
    state->uv_fault_issued = 0;
    state->ov_warning_issued = 0;
    state->uv_warning_issued = 0;
    state->trip_enabled = 1;
    state->dt = 0.001f;
}

void voltage_trip_limits_update(voltage_trip_limits_state_t *state)
{
    voltage_check_trip(state);
}

void voltage_check_trip(voltage_trip_limits_state_t *state)
{
    if (!state->trip_enabled) {
        state->ov_timer = 0.0f;
        state->uv_timer = 0.0f;
        state->ov_fault_issued = 0;
        state->uv_fault_issued = 0;
        state->ov_warning_issued = 0;
        state->uv_warning_issued = 0;
        return;
    }

    if (state->dc_voltage >= state->overvolt_warning_level &&
        !state->ov_fault_issued) {
        state->ov_warning_issued = 1;
    } else if (state->dc_voltage < state->overvolt_warning_level) {
        state->ov_warning_issued = 0;
    }

    if (state->dc_voltage >= state->overvolt_trip_level) {
        state->ov_timer += state->dt;
        if (state->ov_timer >= state->trip_delay_time && !state->ov_fault_issued) {
            state->ov_fault_issued = 1;
        }
    } else {
        if (state->dc_voltage < state->overvolt_trip_level - 20.0f) {
            state->ov_timer = 0.0f;
        }
    }

    if (state->dc_voltage <= state->undervolt_warning_level &&
        state->dc_voltage > state->undervolt_trip_level &&
        !state->uv_fault_issued) {
        state->uv_warning_issued = 1;
    } else if (state->dc_voltage > state->undervolt_warning_level + 20.0f) {
        state->uv_warning_issued = 0;
    }

    if (state->dc_voltage <= state->undervolt_trip_level &&
        state->dc_voltage > 0.0f) {
        state->uv_timer += state->dt;
        if (state->uv_timer >= state->trip_delay_time && !state->uv_fault_issued) {
            state->uv_fault_issued = 1;
        }
    } else {
        if (state->dc_voltage > state->undervolt_trip_level + 20.0f) {
            state->uv_timer = 0.0f;
        }
    }
}
