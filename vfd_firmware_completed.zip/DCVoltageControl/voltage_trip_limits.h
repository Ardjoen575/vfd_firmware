#ifndef DCVOLTAGECONTROL_VOLTAGE_TRIP_LIMITS_H
#define DCVOLTAGECONTROL_VOLTAGE_TRIP_LIMITS_H

/* Voltage control and trip limits */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    float dc_voltage;
    float overvolt_trip_level;
    float undervolt_trip_level;
    float overvolt_warning_level;
    float undervolt_warning_level;
    float trip_delay_time;
    float ov_timer;
    float uv_timer;
    uint8_t ov_fault_issued;
    uint8_t uv_fault_issued;
    uint8_t ov_warning_issued;
    uint8_t uv_warning_issued;
    uint8_t trip_enabled;
    float dt;
} voltage_trip_limits_state_t;

void voltage_trip_limits_init(voltage_trip_limits_state_t *state);
void voltage_trip_limits_update(voltage_trip_limits_state_t *state);
void voltage_check_trip(voltage_trip_limits_state_t *state);

#endif /* DCVOLTAGECONTROL_VOLTAGE_TRIP_LIMITS_H */
