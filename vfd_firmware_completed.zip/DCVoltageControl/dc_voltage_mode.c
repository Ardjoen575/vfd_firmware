#include "dc_voltage_mode.h"
#include <math.h>

#define FMAX(a, b) ((a) > (b) ? (a) : (b))
#define FMIN(a, b) ((a) < (b) ? (a) : (b))

static float clampf(float val, float lo, float hi)
{
    if (val > hi) return hi;
    if (val < lo) return lo;
    return val;
}

void dc_voltage_mode_init(dc_voltage_mode_state_t *state)
{
    state->initialized = 1;
    state->active = 0;
    state->dc_ref = 700.0f;
    state->dc_fb = 540.0f;
    state->pi_kp = 2.0f;
    state->pi_ki = 10.0f;
    state->pi_integral = 0.0f;
    state->pi_integral_min = -100.0f;
    state->pi_integral_max = 100.0f;
    state->active_current_ref = 0.0f;
    state->reactive_current_ref = 0.0f;
    state->active_current_limit = 100.0f;
    state->output = 0.0f;
    state->active_front_end_present = 0;
}

void dc_voltage_mode_update(dc_voltage_mode_state_t *state)
{
    dcvolt_mode_step(state);
}

void dcvolt_mode_step(dc_voltage_mode_state_t *state)
{
    float error;
    float prop;
    float p_error;
    float i_error;

    if (!state->active || !state->active_front_end_present) {
        state->output = 0.0f;
        state->pi_integral = 0.0f;
        state->active_current_ref = 0.0f;
        return;
    }

    error = state->dc_ref - state->dc_fb;

    prop = state->pi_kp * error;
    state->pi_integral += state->pi_ki * error * 0.001f;
    state->pi_integral = clampf(state->pi_integral, state->pi_integral_min, state->pi_integral_max);

    state->output = prop + state->pi_integral;

    state->active_current_ref = clampf(state->output, -state->active_current_limit, state->active_current_limit);

    p_error = state->dc_ref - state->dc_fb;
    i_error = state->pi_integral;
    (void)p_error;
    (void)i_error;
}
