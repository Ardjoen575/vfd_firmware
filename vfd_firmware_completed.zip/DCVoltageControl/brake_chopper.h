#ifndef DCVOLTAGECONTROL_BRAKE_CHOPPER_H
#define DCVOLTAGECONTROL_BRAKE_CHOPPER_H

/* Brake chopper control (grp 43) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    float dc_voltage;
    float dc_voltage_nominal;
    float chopper_on_voltage;
    float chopper_off_voltage;
    float hysteresis;
    float chopper_duty;
    float chopper_duty_max;
    float pwm_period;
    float pwm_counter;
    uint8_t chopper_enabled;
    uint8_t igbt_state;
    float resistance;
    float power_rating;
    float power_dissipated;
} brake_chopper_state_t;

void brake_chopper_init(brake_chopper_state_t *state);
void brake_chopper_update(brake_chopper_state_t *state);
void chopper_pwm_update(brake_chopper_state_t *state);

#endif /* DCVOLTAGECONTROL_BRAKE_CHOPPER_H */
