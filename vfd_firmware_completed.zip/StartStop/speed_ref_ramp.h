#ifndef STARTSTOP_SPEED_REF_RAMP_H
#define STARTSTOP_SPEED_REF_RAMP_H

/* Speed reference ramp (grp 23) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    float ramp_input;
    float ramp_output;
    float ramp_output_last;
    float accel_rate;
    float decel_rate;
    float shape_time_acc;
    float shape_time_dec;
    float shape_accel_jerk;
    float shape_decel_jerk;
    float dt;
    float shape_phase_acc;
    float shape_phase_dec;
    float ramp_increment;
    uint8_t ramp_hold;
    uint8_t ramp_zero;
    uint8_t shaping_active;
} speed_ref_ramp_state_t;

void speed_ref_ramp_init(speed_ref_ramp_state_t *state);
void speed_ref_ramp_update(speed_ref_ramp_state_t *state);
void speed_ref_ramp_step(speed_ref_ramp_state_t *state);

#endif /* STARTSTOP_SPEED_REF_RAMP_H */
