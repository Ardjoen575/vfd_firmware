#include "speed_ref_ramp.h"
#include <math.h>

#define FABS(x) ((x) < 0.0f ? -(x) : (x))
#define FSIGN(x) ((x) >= 0.0f ? 1.0f : -1.0f)

static float ramp_s_curve(float t, float T)
{
    float ratio;
    if (T <= 1e-9f) return 1.0f;
    ratio = t / T;
    if (ratio >= 1.0f) return 1.0f;
    return ratio * ratio * (3.0f - 2.0f * ratio);
}

void speed_ref_ramp_init(speed_ref_ramp_state_t *state)
{
    state->initialized = 1;
    state->ramp_input = 0.0f;
    state->ramp_output = 0.0f;
    state->ramp_output_last = 0.0f;
    state->accel_rate = 3.0f;
    state->decel_rate = 3.0f;
    state->shape_time_acc = 0.0f;
    state->shape_time_dec = 0.0f;
    state->shape_accel_jerk = 0.0f;
    state->shape_decel_jerk = 0.0f;
    state->dt = 0.001f;
    state->shape_phase_acc = 0.0f;
    state->shape_phase_dec = 0.0f;
    state->ramp_increment = 0.0f;
    state->ramp_hold = 0;
    state->ramp_zero = 0;
    state->shaping_active = 0;
}

void speed_ref_ramp_update(speed_ref_ramp_state_t *state)
{
    speed_ref_ramp_step(state);
}

void speed_ref_ramp_step(speed_ref_ramp_state_t *state)
{
    float max_step;
    float shape_factor;
    float diff;
    float output;

    if (state->ramp_zero) {
        state->ramp_output = 0.0f;
        state->ramp_output_last = 0.0f;
        state->shape_phase_acc = 0.0f;
        state->shape_phase_dec = 0.0f;
        return;
    }

    if (state->ramp_hold) {
        state->ramp_input = state->ramp_output;
    }

    diff = state->ramp_input - state->ramp_output;

    if (FABS(diff) < 1e-6f) {
        state->ramp_output = state->ramp_input;
        state->shape_phase_acc = 0.0f;
        state->shape_phase_dec = 0.0f;
        return;
    }

    if (diff > 0.0f) {
        max_step = state->accel_rate * state->dt;

        if (state->shape_time_acc > 0.001f && FABS(diff) < state->accel_rate * state->shape_time_acc) {
            state->shape_phase_acc += state->dt;
            shape_factor = ramp_s_curve(state->shape_phase_acc, state->shape_time_acc);
            max_step *= shape_factor;
            state->shaping_active = 1;
        } else {
            state->shape_phase_acc = 0.0f;
            state->shaping_active = 0;
        }
    } else {
        max_step = state->decel_rate * state->dt;

        if (state->shape_time_dec > 0.001f && FABS(diff) < state->decel_rate * state->shape_time_dec) {
            state->shape_phase_dec += state->dt;
            shape_factor = ramp_s_curve(state->shape_phase_dec, state->shape_time_dec);
            max_step *= shape_factor;
            state->shaping_active = 1;
        } else {
            state->shape_phase_dec = 0.0f;
            state->shaping_active = 0;
        }
    }

    if (max_step > FABS(diff)) {
        output = state->ramp_input;
    } else if (diff > 0.0f) {
        output = state->ramp_output + max_step;
    } else {
        output = state->ramp_output - max_step;
    }

    state->ramp_output_last = state->ramp_output;
    state->ramp_output = output;
}
