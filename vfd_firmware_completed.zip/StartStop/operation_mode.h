#ifndef STARTSTOP_OPERATION_MODE_H
#define STARTSTOP_OPERATION_MODE_H

/* Operation mode select (grp 19) */

#include <stdint.h>

#define OPMODE_SPEED   0u
#define OPMODE_TORQUE  1u
#define OPMODE_FREQ    2u

typedef struct {
    uint8_t initialized;
    uint8_t op_mode;
    uint8_t requested_mode;
    uint8_t mode_change_in_progress;
    uint8_t prev_op_mode;
    float transition_timer;
    float transition_time;
    float speed_ref;
    float torque_ref;
    float freq_ref;
} operation_mode_state_t;

void operation_mode_init(operation_mode_state_t *state);
void operation_mode_update(operation_mode_state_t *state);
void opmode_apply(operation_mode_state_t *state);

#endif /* STARTSTOP_OPERATION_MODE_H */
