#ifndef STARTSTOP_START_STOP_MODE_H
#define STARTSTOP_START_STOP_MODE_H

/* Start/stop mode configuration (grp 21) */

#include <stdint.h>

#define START_MODE_AUTO    0u
#define START_MODE_MANUAL  1u

#define TRIGGER_LEVEL      0u
#define TRIGGER_EDGE       1u

#define STOP_MODE_COAST    0u
#define STOP_MODE_RAMP     1u

typedef struct {
    uint8_t initialized;
    uint8_t start_mode;
    uint8_t trigger_type;
    uint8_t stop_mode;
    uint8_t level_active;
    uint8_t edge_latched;
    uint8_t edge_prev;
    uint8_t edge_detect_enable;
    uint8_t start_cmd_input;
    uint8_t stop_cmd_input;
} start_stop_mode_state_t;

void start_stop_mode_init(start_stop_mode_state_t *state);
void start_stop_mode_update(start_stop_mode_state_t *state);
void startstop_mode_configure(start_stop_mode_state_t *state);

#endif /* STARTSTOP_START_STOP_MODE_H */
