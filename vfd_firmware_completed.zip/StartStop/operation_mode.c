#include "operation_mode.h"

#define TRANSITION_TIME_DEFAULT 0.1f

void operation_mode_init(operation_mode_state_t *state)
{
    state->initialized = 1;
    state->op_mode = OPMODE_SPEED;
    state->requested_mode = OPMODE_SPEED;
    state->mode_change_in_progress = 0;
    state->prev_op_mode = OPMODE_SPEED;
    state->transition_timer = 0.0f;
    state->transition_time = TRANSITION_TIME_DEFAULT;
    state->speed_ref = 0.0f;
    state->torque_ref = 0.0f;
    state->freq_ref = 0.0f;
}

void operation_mode_update(operation_mode_state_t *state)
{
    opmode_apply(state);
}

void opmode_apply(operation_mode_state_t *state)
{
    if (state->requested_mode != state->op_mode) {
        if (!state->mode_change_in_progress) {
            state->mode_change_in_progress = 1;
            state->prev_op_mode = state->op_mode;
            state->transition_timer = 0.0f;
        }

        state->transition_timer += 0.001f;

        if (state->transition_timer >= state->transition_time) {
            state->op_mode = state->requested_mode;
            state->mode_change_in_progress = 0;
            state->transition_timer = 0.0f;
        }
    } else {
        state->mode_change_in_progress = 0;
        state->transition_timer = 0.0f;
    }

    switch (state->op_mode) {
    case OPMODE_SPEED:
        break;
    case OPMODE_TORQUE:
        break;
    case OPMODE_FREQ:
        break;
    default:
        state->op_mode = OPMODE_SPEED;
        break;
    }
}
