#include "start_stop_direction.h"

#define START_DELAY_DEFAULT 0.1f
#define READY_BIT        0x0001u
#define RUNNING_BIT      0x0002u
#define FAULT_BIT        0x0008u
#define RAMPING_BIT      0x0010u
#define DIRECTION_BIT    0x0020u

#define START_SEQ_IDLE       0u
#define START_SEQ_INTERLOCK  1u
#define START_SEQ_DELAY      2u
#define START_SEQ_MAGNETIZE  3u
#define START_SEQ_RUNNING    4u

void start_stop_direction_init(start_stop_direction_state_t *state)
{
    state->initialized = 1;
    state->cmd_word = 0;
    state->state_word = READY_BIT;
    state->running = 0;
    state->direction = DIR_FORWARD;
    state->start_request = 0;
    state->stop_request = 0;
    state->interlock_ok = 1;
    state->emergency_stop_active = 0;
    state->coast_stop_active = 0;
    state->ramp_stop_active = 0;
    state->start_seq_step = START_SEQ_IDLE;
    state->start_delay_timer = 0.0f;
    state->start_delay_threshold = 0.5f;
    state->ramp_down_rate = 10.0f;
    state->ready = 1;
    state->faulted = 0;
}

void start_stop_direction_update(start_stop_direction_state_t *state)
{
    if (state->start_request && !state->running && !state->faulted) {
        start_cmd(state);
    }

    if (state->stop_request && state->running) {
        stop_cmd(state);
    }
}

void start_cmd(start_stop_direction_state_t *state)
{
    if (state->faulted) {
        state->start_request = 0;
        state->start_seq_step = START_SEQ_IDLE;
        return;
    }

    if (!state->interlock_ok) {
        state->start_request = 0;
        state->start_seq_step = START_SEQ_IDLE;
        return;
    }

    switch (state->start_seq_step) {
    case START_SEQ_IDLE:
        state->state_word |= RAMPING_BIT;
        state->state_word &= ~READY_BIT;
        state->start_seq_step = START_SEQ_INTERLOCK;
        state->start_delay_timer = 0.0f;
        break;

    case START_SEQ_INTERLOCK:
        if (state->interlock_ok) {
            state->start_seq_step = START_SEQ_DELAY;
            state->start_delay_timer = 0.0f;
        } else {
            state->start_seq_step = START_SEQ_IDLE;
            state->start_request = 0;
            state->state_word |= READY_BIT;
        }
        break;

    case START_SEQ_DELAY:
        state->start_delay_timer += 0.001f;
        if (state->start_delay_timer >= state->start_delay_threshold) {
            state->start_seq_step = START_SEQ_MAGNETIZE;
            state->start_delay_timer = 0.0f;
        }
        break;

    case START_SEQ_MAGNETIZE:
        state->start_delay_timer += 0.001f;
        if (state->start_delay_timer >= 0.5f) {
            state->start_seq_step = START_SEQ_RUNNING;
            state->running = 1;
            state->start_request = 0;
            state->state_word |= RUNNING_BIT;
            state->state_word &= ~(RAMPING_BIT | READY_BIT);
            if (state->direction == DIR_REVERSE) {
                state->state_word |= DIRECTION_BIT;
            } else {
                state->state_word &= ~DIRECTION_BIT;
            }
        }
        break;

    case START_SEQ_RUNNING:
        state->start_request = 0;
        break;

    default:
        state->start_seq_step = START_SEQ_IDLE;
        break;
    }
}

void stop_cmd(start_stop_direction_state_t *state)
{
    if (state->emergency_stop_active || state->coast_stop_active) {
        state->running = 0;
        state->start_seq_step = START_SEQ_IDLE;
        state->start_request = 0;
        state->stop_request = 0;
        state->ramp_stop_active = 0;
        state->state_word = READY_BIT;
        state->ramp_down_rate = 400.0f;
        return;
    }

    if (state->ramp_stop_active) {
        state->running = 0;
        state->start_seq_step = START_SEQ_IDLE;
        state->start_request = 0;
        state->stop_request = 0;
        state->ramp_stop_active = 0;
        state->state_word = READY_BIT;
        return;
    }

    state->running = 0;
    state->start_seq_step = START_SEQ_IDLE;
    state->start_request = 0;
    state->stop_request = 0;
    state->state_word = READY_BIT;
    state->state_word &= ~RUNNING_BIT;
}
