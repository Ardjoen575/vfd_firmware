#include "start_stop_mode.h"

void start_stop_mode_init(start_stop_mode_state_t *state)
{
    state->initialized = 1;
    state->start_mode = START_MODE_AUTO;
    state->trigger_type = TRIGGER_LEVEL;
    state->stop_mode = STOP_MODE_RAMP;
    state->level_active = 0;
    state->edge_latched = 0;
    state->edge_prev = 0;
    state->edge_detect_enable = 0;
    state->start_cmd_input = 0;
    state->stop_cmd_input = 0;
}

void start_stop_mode_update(start_stop_mode_state_t *state)
{
    startstop_mode_configure(state);
}

void startstop_mode_configure(start_stop_mode_state_t *state)
{
    state->edge_detect_enable = 0;
    state->level_active = 0;

    if (state->trigger_type == TRIGGER_LEVEL) {
        state->level_active = 1;
    } else if (state->trigger_type == TRIGGER_EDGE) {
        if (state->start_cmd_input && !state->edge_prev) {
            state->edge_latched = 1;
            state->edge_detect_enable = 1;
        } else if (!state->start_cmd_input && state->edge_prev) {
            state->edge_detect_enable = 0;
        }
        state->edge_prev = state->start_cmd_input;
    }

    if (state->start_mode == START_MODE_AUTO) {
        state->edge_detect_enable = 1;
        state->level_active = 1;
    }

    if (state->stop_cmd_input && state->start_mode == START_MODE_AUTO) {
        state->level_active = 0;
        state->edge_latched = 0;
    }
}
