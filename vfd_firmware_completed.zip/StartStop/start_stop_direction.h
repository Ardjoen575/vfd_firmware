#ifndef STARTSTOP_START_STOP_DIRECTION_H
#define STARTSTOP_START_STOP_DIRECTION_H

/* Start/stop/direction control (grp 20) */

#include <stdint.h>

#define START_CMD_OFF     0u
#define START_CMD_RUNNING 1u
#define START_CMD_RAMPING 2u

#define DIR_FORWARD  1u
#define DIR_REVERSE  2u

typedef struct {
    uint8_t initialized;
    uint16_t cmd_word;
    uint16_t state_word;
    uint8_t running;
    uint8_t direction;
    uint8_t start_request;
    uint8_t stop_request;
    uint8_t interlock_ok;
    uint8_t emergency_stop_active;
    uint8_t coast_stop_active;
    uint8_t ramp_stop_active;
    uint8_t start_seq_step;
    float start_delay_timer;
    float start_delay_threshold;
    float ramp_down_rate;
    uint8_t ready;
    uint8_t faulted;
} start_stop_direction_state_t;

void start_stop_direction_init(start_stop_direction_state_t *state);
void start_stop_direction_update(start_stop_direction_state_t *state);
void start_cmd(start_stop_direction_state_t *state);
void stop_cmd(start_stop_direction_state_t *state);

#endif /* STARTSTOP_START_STOP_DIRECTION_H */
