#ifndef STARTSTOP_SPEED_REF_CONDITIONING_H
#define STARTSTOP_SPEED_REF_CONDITIONING_H

/* Speed reference conditioning (grp 24) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    float raw_speed;
    float conditioned_speed;
    float notch_freq;
    float notch_bw;
    float notch_b0;
    float notch_b1;
    float notch_b2;
    float notch_a1;
    float notch_a2;
    float notch_x1;
    float notch_x2;
    float notch_y1;
    float notch_y2;
    float scale_numerator;
    float scale_denominator;
    float sign_multiplier;
    int8_t invert;
} speed_ref_conditioning_state_t;

void speed_ref_conditioning_init(speed_ref_conditioning_state_t *state);
void speed_ref_conditioning_update(speed_ref_conditioning_state_t *state);
void speed_ref_condition(speed_ref_conditioning_state_t *state);

#endif /* STARTSTOP_SPEED_REF_CONDITIONING_H */
