#ifndef STARTSTOP_SPEED_REF_SELECTION_H
#define STARTSTOP_SPEED_REF_SELECTION_H

/* Speed reference selection (grp 22) */

#include <stdint.h>

#define SRC_AI1       0u
#define SRC_AI2       1u
#define SRC_FIELDBUS  2u
#define SRC_PANEL     3u
#define SRC_MOTORPOT  4u
#define SRC_PID       5u
#define SRC_FREQ_IN   6u

typedef struct {
    uint8_t initialized;
    uint8_t source;
    uint8_t source_ext1;
    uint8_t source_ext2;
    float ai1_raw;
    float ai2_raw;
    float ai1_scaled;
    float ai2_scaled;
    float fieldbus_ref;
    float panel_ref;
    float motorpot_value;
    float motorpot_step;
    float motorpot_min;
    float motorpot_max;
    float pid_output;
    float freq_input;
    float selected_ref;
    float ext1_ref;
    float ext2_ref;
} speed_ref_selection_state_t;

void speed_ref_selection_init(speed_ref_selection_state_t *state);
void speed_ref_selection_update(speed_ref_selection_state_t *state);
void speed_ref_select_source(speed_ref_selection_state_t *state);

#endif /* STARTSTOP_SPEED_REF_SELECTION_H */
