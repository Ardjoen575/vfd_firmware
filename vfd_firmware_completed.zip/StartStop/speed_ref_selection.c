#include "speed_ref_selection.h"

void speed_ref_selection_init(speed_ref_selection_state_t *state)
{
    state->initialized = 1;
    state->source = SRC_AI1;
    state->source_ext1 = SRC_AI1;
    state->source_ext2 = SRC_PANEL;
    state->ai1_raw = 0.0f;
    state->ai2_raw = 0.0f;
    state->ai1_scaled = 0.0f;
    state->ai2_scaled = 0.0f;
    state->fieldbus_ref = 0.0f;
    state->panel_ref = 0.0f;
    state->motorpot_value = 0.0f;
    state->motorpot_step = 0.01f;
    state->motorpot_min = -60.0f;
    state->motorpot_max = 60.0f;
    state->pid_output = 0.0f;
    state->freq_input = 0.0f;
    state->selected_ref = 0.0f;
    state->ext1_ref = 0.0f;
    state->ext2_ref = 0.0f;
}

void speed_ref_selection_update(speed_ref_selection_state_t *state)
{
    speed_ref_select_source(state);
}

void speed_ref_select_source(speed_ref_selection_state_t *state)
{
    float raw = 0.0f;

    state->ai1_scaled = state->ai1_raw * 60.0f;
    state->ai2_scaled = state->ai2_raw * 60.0f;

    switch (state->source) {
    case SRC_AI1:
        raw = state->ai1_scaled;
        break;
    case SRC_AI2:
        raw = state->ai2_scaled;
        break;
    case SRC_FIELDBUS:
        raw = state->fieldbus_ref;
        break;
    case SRC_PANEL:
        raw = state->panel_ref;
        break;
    case SRC_MOTORPOT:
        raw = state->motorpot_value;
        break;
    case SRC_PID:
        raw = state->pid_output;
        break;
    case SRC_FREQ_IN:
        raw = state->freq_input;
        break;
    default:
        raw = 0.0f;
        break;
    }

    state->selected_ref = raw;
    state->ext1_ref = raw;
    state->ext2_ref = raw;
}
