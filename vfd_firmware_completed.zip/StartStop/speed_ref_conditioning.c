#include "speed_ref_conditioning.h"
#include <math.h>

#define PI_F (3.14159265358979323846f)

void speed_ref_conditioning_init(speed_ref_conditioning_state_t *state)
{
    state->initialized = 1;
    state->raw_speed = 0.0f;
    state->conditioned_speed = 0.0f;
    state->notch_freq = 0.0f;
    state->notch_bw = 1.0f;
    state->notch_b0 = 1.0f;
    state->notch_b1 = 0.0f;
    state->notch_b2 = 0.0f;
    state->notch_a1 = 0.0f;
    state->notch_a2 = 0.0f;
    state->notch_x1 = 0.0f;
    state->notch_x2 = 0.0f;
    state->notch_y1 = 0.0f;
    state->notch_y2 = 0.0f;
    state->scale_numerator = 1.0f;
    state->scale_denominator = 1.0f;
    state->sign_multiplier = 1.0f;
    state->invert = 0;
}

void speed_ref_conditioning_update(speed_ref_conditioning_state_t *state)
{
    speed_ref_condition(state);
}

void speed_ref_condition(speed_ref_conditioning_state_t *state)
{
    float output;
    float x;

    x = state->raw_speed;

    if (state->notch_freq > 1.0f && state->notch_bw > 0.001f) {
        float w0 = 2.0f * PI_F * state->notch_freq * 0.001f;
        float bw = 2.0f * PI_F * state->notch_bw * 0.001f;
        float cos_w0 = cosf(w0);
        float alpha = sinf(w0) * sinhf(logf(2.0f) / 2.0f * bw * w0 / sinf(w0));

        float a0 = 1.0f + alpha;
        state->notch_b0 = 1.0f / a0;
        state->notch_b1 = (-2.0f * cos_w0) / a0;
        state->notch_b2 = 1.0f / a0;
        state->notch_a1 = (2.0f * cos_w0) / a0;
        state->notch_a2 = (alpha - 1.0f) / a0;

        output = state->notch_b0 * x + state->notch_b1 * state->notch_x1
               + state->notch_b2 * state->notch_x2
               - state->notch_a1 * state->notch_y1
               - state->notch_a2 * state->notch_y2;
    } else {
        output = x;
        state->notch_b0 = 1.0f;
        state->notch_b1 = 0.0f;
        state->notch_b2 = 0.0f;
        state->notch_a1 = 0.0f;
        state->notch_a2 = 0.0f;
    }

    state->notch_x2 = state->notch_x1;
    state->notch_x1 = x;
    state->notch_y2 = state->notch_y1;
    state->notch_y1 = output;

    if (state->scale_denominator > 1e-9f) {
        output = output * state->scale_numerator / state->scale_denominator;
    }

    if (state->invert) {
        output = -output;
    }

    output *= state->sign_multiplier;

    state->conditioned_speed = output;
}
