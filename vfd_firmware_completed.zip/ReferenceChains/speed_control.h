#ifndef REFERENCECHAINS_SPEED_CONTROL_H
#define REFERENCECHAINS_SPEED_CONTROL_H

/* Speed controller (grp 25) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    float kp;
    float ki;
    float kd;
    float integral;
    float prev_error;
    float integral_min;
    float integral_max;
    float output_min;
    float output_max;
    float droop_gain;
    float accel_comp_gain;
    float accel_comp_value;
    float speed_ref;
    float speed_fb;
    float error;
    float torque_ref_out;
    float deriv_output;
    float prop_output;
    float dt;
} speed_control_state_t;

void speed_control_init(speed_control_state_t *state);
void speed_control_update(speed_control_state_t *state);
void speed_ctrl_step(speed_control_state_t *state);
void speed_ctrl_pid(speed_control_state_t *state);

#endif /* REFERENCECHAINS_SPEED_CONTROL_H */
