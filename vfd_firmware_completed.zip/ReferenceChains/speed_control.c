#include "speed_control.h"
#include <math.h>

#define FABS(x) ((x) < 0.0f ? -(x) : (x))
#define FMAX(a, b) ((a) > (b) ? (a) : (b))
#define FMIN(a, b) ((a) < (b) ? (a) : (b))

static float clampf(float val, float lo, float hi)
{
    if (val > hi) return hi;
    if (val < lo) return lo;
    return val;
}

void speed_control_init(speed_control_state_t *state)
{
    state->initialized = 1;
    state->kp = 10.0f;
    state->ki = 100.0f;
    state->kd = 0.0f;
    state->integral = 0.0f;
    state->prev_error = 0.0f;
    state->integral_min = -150.0f;
    state->integral_max = 150.0f;
    state->output_min = -150.0f;
    state->output_max = 150.0f;
    state->droop_gain = 0.0f;
    state->accel_comp_gain = 0.0f;
    state->accel_comp_value = 0.0f;
    state->speed_ref = 0.0f;
    state->speed_fb = 0.0f;
    state->error = 0.0f;
    state->torque_ref_out = 0.0f;
    state->deriv_output = 0.0f;
    state->prop_output = 0.0f;
    state->dt = 0.001f;
}

void speed_control_update(speed_control_state_t *state)
{
    speed_ctrl_step(state);
}

void speed_ctrl_pid(speed_control_state_t *state)
{
    float output;
    float deriv;

    state->error = state->speed_ref - state->speed_fb;

    state->prop_output = state->kp * state->error;

    state->integral += state->ki * state->error * state->dt;
    state->integral = clampf(state->integral, state->integral_min, state->integral_max);

    if (state->dt > 1e-9f) {
        deriv = state->kd * (state->error - state->prev_error) / state->dt;
    } else {
        deriv = 0.0f;
    }
    state->deriv_output = deriv;
    state->prev_error = state->error;

    output = state->prop_output + state->integral + state->deriv_output;

    if (state->droop_gain > 0.0f) {
        output -= state->droop_gain * state->torque_ref_out;
    }

    if (state->accel_comp_gain > 0.0f) {
        output += state->accel_comp_gain * state->accel_comp_value;
    }

    output = clampf(output, state->output_min, state->output_max);

    state->torque_ref_out = output;
}

void speed_ctrl_step(speed_control_state_t *state)
{
    float saturation;
    float anti_windup;

    state->error = state->speed_ref - state->speed_fb;

    state->prop_output = state->kp * state->error;

    state->integral += state->ki * state->error * state->dt;
    state->integral = clampf(state->integral, state->integral_min, state->integral_max);

    saturation = state->integral;

    if (state->dt > 1e-9f) {
        state->deriv_output = state->kd * (state->error - state->prev_error) / state->dt;
    } else {
        state->deriv_output = 0.0f;
    }

    state->prev_error = state->error;

    state->torque_ref_out = state->prop_output + state->integral + state->deriv_output;

    if (state->droop_gain > 0.0f) {
        state->torque_ref_out -= state->droop_gain * state->torque_ref_out;
    }

    if (state->accel_comp_gain > 0.0f) {
        state->torque_ref_out += state->accel_comp_gain * state->accel_comp_value;
    }

    if (state->torque_ref_out > state->output_max) {
        state->torque_ref_out = state->output_max;
        anti_windup = state->torque_ref_out - saturation;
        state->integral = clampf(state->integral, anti_windup, state->integral_max);
    } else if (state->torque_ref_out < state->output_min) {
        state->torque_ref_out = state->output_min;
        anti_windup = state->torque_ref_out - saturation;
        state->integral = clampf(state->integral, state->integral_min, anti_windup);
    }
}
