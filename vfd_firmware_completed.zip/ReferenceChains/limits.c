#include "limits.h"
#include <math.h>

#define FABS(x) ((x) < 0.0f ? -(x) : (x))
#define FMAX(a, b) ((a) > (b) ? (a) : (b))
#define FMIN(a, b) ((a) < (b) ? (a) : (b))

void limits_init(limits_state_t *state)
{
    state->initialized = 1;
    state->torque_ref = 0.0f;
    state->torque_min = -150.0f;
    state->torque_max = 150.0f;
    state->torque_clamped = 0.0f;
    state->current_ref = 0.0f;
    state->current_min = 0.0f;
    state->current_max = 100.0f;
    state->current_clamped = 0.0f;
    state->speed_ref = 0.0f;
    state->speed_min = 0.0f;
    state->speed_max = 60.0f;
    state->speed_max_abs = 60.0f;
    state->power_limit = 200.0f;
    state->power_actual = 0.0f;
    state->torque_limit_scaling = 1.0f;
}

void limits_update(limits_state_t *state)
{
    limits_clamp(state);
}

void limits_clamp(limits_state_t *state)
{
    float tq_abs_max;
    float tq_min_scaled;
    float tq_max_scaled;

    if (state->power_limit > 0.0f && state->speed_fb > 0.1f) {
        tq_abs_max = (state->power_limit * 9550.0f) / state->speed_fb;
        tq_abs_max = FMIN(tq_abs_max, FABS(state->torque_max));
    } else {
        tq_abs_max = FABS(state->torque_max);
    }

    tq_max_scaled = FMIN(tq_abs_max, state->torque_max) * state->torque_limit_scaling;
    tq_min_scaled = FMAX(-tq_abs_max, state->torque_min) * state->torque_limit_scaling;

    if (state->torque_ref > tq_max_scaled) {
        state->torque_clamped = tq_max_scaled;
    } else if (state->torque_ref < tq_min_scaled) {
        state->torque_clamped = tq_min_scaled;
    } else {
        state->torque_clamped = state->torque_ref;
    }

    if (state->current_ref > state->current_max) {
        state->current_clamped = state->current_max;
    } else if (state->current_ref < state->current_min) {
        state->current_clamped = state->current_min;
    } else {
        state->current_clamped = state->current_ref;
    }

    state->speed_max_abs = FABS(state->speed_max);
}
