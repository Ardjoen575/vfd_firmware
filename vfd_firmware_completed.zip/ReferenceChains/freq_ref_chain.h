#ifndef REFERENCECHAINS_FREQ_REF_CHAIN_H
#define REFERENCECHAINS_FREQ_REF_CHAIN_H

/* Frequency reference chain (grp 28) */

#include <stdint.h>

#define CRITICAL_SPEEDS_COUNT 3

typedef struct {
    uint8_t initialized;
    uint8_t direction;
    float freq_ref;
    float raw_ref;
    float min_freq;
    float max_freq;
    float critical_speeds[CRITICAL_SPEEDS_COUNT];
    float critical_hysteresis;
    float speed_fb;
    float freq_ref_before_critical;
    uint8_t critical_active;
} freq_ref_chain_state_t;

void freq_ref_chain_init(freq_ref_chain_state_t *state);
void freq_ref_chain_update(freq_ref_chain_state_t *state);
void freq_ref_compute(freq_ref_chain_state_t *state);

#endif /* REFERENCECHAINS_FREQ_REF_CHAIN_H */
