#include "torque_ref_chain.h"
#include <math.h>

#define FABS(x) ((x) < 0.0f ? -(x) : (x))
#define FMAX(a, b) ((a) > (b) ? (a) : (b))
#define FMIN(a, b) ((a) < (b) ? (a) : (b))

static float clampf(float val, float lo, float hi)
{
    if (val > hi) return hi;
    if (val < lo) return lo;
    return val;
}

void torque_ref_chain_init(torque_ref_chain_state_t *state)
{
    state->initialized = 1;
    state->torque_ref_in = 0.0f;
    state->torque_ref_out = 0.0f;
    state->torque_max = 150.0f;
    state->torque_min = -150.0f;
    state->filter_tc = 0.002f;
    state->filter_output = 0.0f;
    state->add_torque = 0.0f;
    state->torque_scale = 1.0f;
    state->motoring_limit = 150.0f;
    state->generating_limit = -150.0f;
}

void torque_ref_chain_update(torque_ref_chain_state_t *state)
{
    torque_ref_compute(state);
}

void torque_ref_compute(torque_ref_chain_state_t *state)
{
    float alpha;
    float raw_torque;
    float filtered;
    float limit;

    raw_torque = state->torque_ref_in * state->torque_scale + state->add_torque;

    if (state->filter_tc > 1e-9f) {
        alpha = 0.001f / (state->filter_tc + 0.001f);
    } else {
        alpha = 1.0f;
    }
    filtered = alpha * raw_torque + (1.0f - alpha) * state->filter_output;
    state->filter_output = filtered;

    if (state->speed_fb >= 0.0f) {
        limit = state->motoring_limit;
    } else {
        limit = -state->generating_limit;
    }

    if (raw_torque >= 0.0f) {
        filtered = clampf(filtered, 0.0f, FMIN(state->torque_max, limit));
    } else {
        filtered = clampf(filtered, FMAX(state->torque_min, limit), 0.0f);
    }

    filtered = clampf(filtered, state->torque_min, state->torque_max);

    state->torque_ref_out = filtered;
}
