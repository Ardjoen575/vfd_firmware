#ifndef REFERENCECHAINS_TORQUE_REF_CHAIN_H
#define REFERENCECHAINS_TORQUE_REF_CHAIN_H

/* Torque reference chain (grp 26) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    float torque_ref_in;
    float torque_ref_out;
    float torque_max;
    float torque_min;
    float filter_tc;
    float filter_output;
    float add_torque;
    float torque_scale;
    float speed_fb;
    float motoring_limit;
    float generating_limit;
} torque_ref_chain_state_t;

void torque_ref_chain_init(torque_ref_chain_state_t *state);
void torque_ref_chain_update(torque_ref_chain_state_t *state);
void torque_ref_compute(torque_ref_chain_state_t *state);

#endif /* REFERENCECHAINS_TORQUE_REF_CHAIN_H */
