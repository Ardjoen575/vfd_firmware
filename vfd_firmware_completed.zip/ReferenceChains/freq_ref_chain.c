#include "freq_ref_chain.h"
#include <math.h>

#define FABS(x) ((x) < 0.0f ? -(x) : (x))

void freq_ref_chain_init(freq_ref_chain_state_t *state)
{
    state->initialized = 1;
    state->direction = 1;
    state->freq_ref = 0.0f;
    state->raw_ref = 0.0f;
    state->min_freq = 0.0f;
    state->max_freq = 60.0f;
    state->critical_speeds[0] = 0.0f;
    state->critical_speeds[1] = 0.0f;
    state->critical_speeds[2] = 0.0f;
    state->critical_hysteresis = 1.0f;
    state->speed_fb = 0.0f;
    state->freq_ref_before_critical = 0.0f;
    state->critical_active = 0;
}

void freq_ref_chain_update(freq_ref_chain_state_t *state)
{
    freq_ref_compute(state);
}

void freq_ref_compute(freq_ref_chain_state_t *state)
{
    float working_ref = state->raw_ref;
    float abs_ref = FABS(working_ref);
    float abs_speed = FABS(state->speed_fb);
    int i;
    int in_critical_band = 0;
    float low, high;

    for (i = 0; i < CRITICAL_SPEEDS_COUNT; i++) {
        if (state->critical_speeds[i] <= 0.1f) continue;

        low = state->critical_speeds[i] - state->critical_hysteresis;
        high = state->critical_speeds[i] + state->critical_hysteresis;

        if (abs_ref > low && abs_ref < high) {
            in_critical_band = 1;
            if (!state->critical_active) {
                state->freq_ref_before_critical = working_ref;
                state->critical_active = 1;
            }

            if (abs_speed > state->critical_speeds[i]) {
                working_ref = (working_ref > 0.0f ? 1.0f : -1.0f) * high;
            } else {
                working_ref = (working_ref > 0.0f ? 1.0f : -1.0f) * low;
            }
            break;
        }
    }

    if (!in_critical_band) {
        state->critical_active = 0;
    }

    if (working_ref > state->max_freq) {
        working_ref = state->max_freq;
    } else if (working_ref < -state->max_freq) {
        working_ref = -state->max_freq;
    }

    if (FABS(working_ref) < state->min_freq && working_ref != 0.0f) {
        working_ref = (working_ref > 0.0f) ? state->min_freq : -state->min_freq;
    }

    state->freq_ref = working_ref;
}
