#include "voltage_ref_chain.h"
#include <math.h>

#define FABS(x) ((x) < 0.0f ? -(x) : (x))
#define FMIN(a, b) ((a) < (b) ? (a) : (b))
#define SQRT2 (1.41421356237f)
#define SQRT3 (1.73205080757f)

static float clampf_max(float val, float hi)
{
    if (val > hi) return hi;
    return val;
}

void voltage_ref_chain_init(voltage_ref_chain_state_t *state)
{
    state->initialized = 1;
    state->vd_ref = 0.0f;
    state->vq_ref = 0.0f;
    state->vdc_nominal = 540.0f;
    state->vdc_actual = 540.0f;
    state->mod_index = 0.0f;
    state->mod_index_max = 0.95f;
    state->mod_index_out = 0.0f;
    state->flux_ref = 1.0f;
    state->torque_ref = 0.0f;
    state->rs_comp = 0.0f;
    state->ls_sigma = 0.01f;
    state->frequency = 0.0f;
    state->voltage_mag = 0.0f;
    state->overmodulation_enabled = 0;
}

void voltage_ref_chain_update(voltage_ref_chain_state_t *state)
{
    voltage_ref_compute(state);
}

void voltage_ref_compute(voltage_ref_chain_state_t *state)
{
    float vdc_comp_ratio;
    float mod_max;
    float mod_norm;
    float vd, vq;

    if (state->vdc_actual > 10.0f) {
        vdc_comp_ratio = state->vdc_nominal / state->vdc_actual;
    } else {
        vdc_comp_ratio = 1.0f;
    }

    vd = state->vd_ref * vdc_comp_ratio;
    vq = state->vq_ref * vdc_comp_ratio;

    state->voltage_mag = sqrtf(vd * vd + vq * vq);

    mod_max = state->overmodulation_enabled ? 1.05f : state->mod_index_max;

    if (state->vdc_actual > 10.0f) {
        state->mod_index = (SQRT2 * state->voltage_mag) / (state->vdc_actual / SQRT3);
    } else {
        state->mod_index = 0.0f;
    }

    if (state->mod_index > mod_max) {
        mod_norm = mod_max / state->mod_index;
        vd *= mod_norm;
        vq *= mod_norm;
        state->mod_index_out = mod_max;
    } else {
        state->mod_index_out = state->mod_index;
    }

    state->vd_ref = vd;
    state->vq_ref = vq;
}
