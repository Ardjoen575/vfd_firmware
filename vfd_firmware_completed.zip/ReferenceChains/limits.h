#ifndef REFERENCECHAINS_LIMITS_H
#define REFERENCECHAINS_LIMITS_H

/* Torque/current/speed limits (grp 30) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    float torque_ref;
    float torque_min;
    float torque_max;
    float torque_clamped;
    float current_ref;
    float current_min;
    float current_max;
    float current_clamped;
    float speed_ref;
    float speed_fb;
    float speed_min;
    float speed_max;
    float speed_max_abs;
    float power_limit;
    float power_actual;
    float torque_limit_scaling;
} limits_state_t;

void limits_init(limits_state_t *state);
void limits_update(limits_state_t *state);
void limits_clamp(limits_state_t *state);

#endif /* REFERENCECHAINS_LIMITS_H */
