#ifndef REFERENCECHAINS_VOLTAGE_REF_CHAIN_H
#define REFERENCECHAINS_VOLTAGE_REF_CHAIN_H

/* Voltage reference chain (grp 29) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    float vd_ref;
    float vq_ref;
    float vdc_nominal;
    float vdc_actual;
    float mod_index;
    float mod_index_max;
    float mod_index_out;
    float flux_ref;
    float torque_ref;
    float rs_comp;
    float ls_sigma;
    float frequency;
    float voltage_mag;
    uint8_t overmodulation_enabled;
} voltage_ref_chain_state_t;

void voltage_ref_chain_init(voltage_ref_chain_state_t *state);
void voltage_ref_chain_update(voltage_ref_chain_state_t *state);
void voltage_ref_compute(voltage_ref_chain_state_t *state);

#endif /* REFERENCECHAINS_VOLTAGE_REF_CHAIN_H */
