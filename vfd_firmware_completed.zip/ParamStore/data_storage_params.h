#ifndef PARAMSTORE_DATA_STORAGE_PARAMS_H
#define PARAMSTORE_DATA_STORAGE_PARAMS_H

#include <stdint.h>

#define DATA_STORE_MAX_SLOTS     16U
#define DATA_STORE_SLOT_SIZE    128U
#define DATA_STORE_MAX_SIZE    2048U
#define DATA_STORE_FLASH_BASE   0x0800E000UL
#define DATA_STORE_MAGIC        0x44534154UL

typedef struct __attribute__((packed)) {
    uint32_t magic;
    uint16_t slot_count;
    uint16_t checksum;
    uint32_t write_counter;
} data_store_header_t;

typedef struct __attribute__((packed)) {
    uint16_t slot_id;
    uint16_t data_length;
    uint8_t  data[DATA_STORE_SLOT_SIZE - 4];
} data_store_slot_t;

typedef struct {
    uint8_t            initialized;
    uint8_t            storage_ready;
    uint8_t            write_pending;
    uint16_t           slot_count;
    uint32_t           write_counter;
    data_store_slot_t  slots[DATA_STORE_MAX_SLOTS];
    uint8_t            raw_buffer[DATA_STORE_MAX_SIZE];
} data_storage_params_state_t;

void data_storage_params_init(data_storage_params_state_t *state);
void data_storage_params_update(data_storage_params_state_t *state);
uint8_t data_store_read(data_storage_params_state_t *state,
                         uint16_t slot_id, uint8_t *buffer, uint16_t *length);
uint8_t data_store_write(data_storage_params_state_t *state,
                          uint16_t slot_id, const uint8_t *data, uint16_t length);

#endif
