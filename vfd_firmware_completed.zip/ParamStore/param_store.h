#ifndef PARAMSTORE_PARAM_STORE_H
#define PARAMSTORE_PARAM_STORE_H

#include <stdint.h>

#define PARAM_MAX_COUNT            2048U
#define PARAM_STORE_FLASH_BASE    0x0800C000UL
#define PARAM_STORE_PAGE_SIZE      0x00008000UL
#define PARAM_STORE_PAGE_COUNT         4U
#define PARAM_STORE_ENTRY_SIZE       128U
#define PARAM_STORE_MAGIC         0x50524D53UL
#define PARAM_STORE_VERSION              1U
#define PARAM_WEAR_LEVEL_MAX      100000U

typedef struct __attribute__((packed)) {
    uint32_t magic;
    uint32_t version;
    uint16_t param_count;
    uint16_t checksum;
    uint32_t write_count;
    uint32_t timestamp;
} param_store_header_t;

typedef struct __attribute__((packed)) {
    uint16_t param_id;
    uint8_t  data_type;
    uint8_t  flags;
    int32_t  value;
    int32_t  min_val;
    int32_t  max_val;
    int32_t  default_val;
    uint32_t write_count;
} param_entry_t;

typedef struct {
    uint8_t              initialized;
    uint8_t              store_ready;
    uint8_t              save_pending;
    uint8_t              load_complete;
    uint16_t             param_count;
    uint16_t             active_page;
    uint32_t             total_writes;
    uint32_t             page_write_counts[PARAM_STORE_PAGE_COUNT];
    uint32_t             next_write_time;
    param_entry_t        params[PARAM_MAX_COUNT];
    param_store_header_t active_header;
} param_store_state_t;

void param_store_init(param_store_state_t *state);
void param_store_update(param_store_state_t *state);
uint8_t param_load_all(param_store_state_t *state);
uint8_t param_save_all(param_store_state_t *state);
int32_t param_get(param_store_state_t *state, uint16_t param_id);
uint8_t param_set(param_store_state_t *state, uint16_t param_id, int32_t value);

#endif
