#include "param_store.h"
#include <string.h>

#define FLASH_R_BASE       0x40023C00UL
#define FLASH_KEYR         (*(volatile uint32_t *)(FLASH_R_BASE + 0x04UL))
#define FLASH_SR           (*(volatile uint32_t *)(FLASH_R_BASE + 0x0CUL))
#define FLASH_CR           (*(volatile uint32_t *)(FLASH_R_BASE + 0x10UL))
#define FLASH_KEY1         0x45670123UL
#define FLASH_KEY2         0xCDEF89ABUL
#define FLASH_CR_STRT      (1UL << 16)
#define FLASH_CR_SER       (1UL << 1)
#define FLASH_CR_PG        (1UL << 0)
#define FLASH_CR_LOCK      (1UL << 31)
#define FLASH_SR_BSY       (1UL << 16)
#define FLASH_CR_SNB_Pos   3U

static void flash_lock_internal(void)
{
    FLASH_CR |= FLASH_CR_LOCK;
}

static void flash_unlock_internal(void)
{
    if (FLASH_CR & FLASH_CR_LOCK) {
        FLASH_KEYR = FLASH_KEY1;
        FLASH_KEYR = FLASH_KEY2;
        __asm__ volatile ("dsb");
        __asm__ volatile ("isb");
    }
}

static void flash_wait_ready_internal(void)
{
    while (FLASH_SR & FLASH_SR_BSY) {
    }
}

static uint8_t flash_erase_sector_internal(uint32_t sector)
{
    flash_unlock_internal();
    flash_wait_ready_internal();

    FLASH_CR &= ~(0x0FUL << FLASH_CR_SNB_Pos);
    FLASH_CR |= (sector << FLASH_CR_SNB_Pos);
    FLASH_CR |= FLASH_CR_SER;

    __asm__ volatile ("dsb");
    __asm__ volatile ("isb");

    FLASH_CR |= FLASH_CR_STRT;

    __asm__ volatile ("dsb");
    __asm__ volatile ("isb");

    flash_wait_ready_internal();

    FLASH_CR &= ~FLASH_CR_SER;

    flash_wait_ready_internal();
    flash_lock_internal();

    return 1;
}

static uint16_t param_store_calc_checksum(const param_entry_t *entries,
                                           uint16_t count)
{
    uint16_t sum = 0;
    uint16_t i;
    const uint8_t *p = (const uint8_t *)entries;

    for (i = 0; i < (uint16_t)(count * sizeof(param_entry_t)); i++) {
        sum = (uint16_t)(sum + p[i] + (sum >> 8));
    }

    return sum ^ 0xAAAA;
}

static uint8_t param_store_select_best_page(param_store_state_t *state)
{
    uint8_t best = 0;
    uint32_t lowest = 0xFFFFFFFFUL;
    uint8_t i;

    for (i = 0; i < PARAM_STORE_PAGE_COUNT; i++) {
        if (state->page_write_counts[i] < lowest) {
            lowest = state->page_write_counts[i];
            best = i;
        }
    }

    return best;
}

uint8_t param_load_all(param_store_state_t *state)
{
    uint32_t page_addr;
    const param_store_header_t *header;
    const param_entry_t *entries;
    uint16_t calc_checksum;
    uint8_t i;

    if (state == 0) return 0;

    state->active_page = param_store_select_best_page(state);

    page_addr = PARAM_STORE_FLASH_BASE +
                ((uint32_t)state->active_page * PARAM_STORE_PAGE_SIZE);

    header = (const param_store_header_t *)page_addr;

    if (header->magic != PARAM_STORE_MAGIC) {
        state->param_count = 0;
        state->load_complete = 1;
        state->store_ready = 1;
        return 0;
    }

    if (header->param_count > PARAM_MAX_COUNT) {
        state->load_complete = 1;
        return 0;
    }

    entries = (const param_entry_t *)(page_addr + sizeof(param_store_header_t));

    calc_checksum = param_store_calc_checksum(entries, header->param_count);

    if (calc_checksum != header->checksum) {
        state->load_complete = 1;
        return 0;
    }

    state->param_count = header->param_count;
    state->total_writes = header->write_count;
    state->active_header = *header;

    memcpy(state->params, entries,
           header->param_count * sizeof(param_entry_t));

    state->load_complete = 1;
    state->store_ready = 1;

    return 1;
}

uint8_t param_save_all(param_store_state_t *state)
{
    uint32_t page_addr;
    uint32_t sector;
    param_store_header_t header;
    uint16_t checksum;
    volatile uint32_t *flash_ptr;
    const uint32_t *src_ptr;
    uint32_t total_words;
    uint32_t i;

    if (state == 0 || state->param_count == 0) return 0;

    state->active_page = param_store_select_best_page(state);

    page_addr = PARAM_STORE_FLASH_BASE +
                ((uint32_t)state->active_page * PARAM_STORE_PAGE_SIZE);

    sector = (page_addr - 0x08000000UL) / PARAM_STORE_PAGE_SIZE;

    header.magic       = PARAM_STORE_MAGIC;
    header.version     = PARAM_STORE_VERSION;
    header.param_count = state->param_count;
    header.write_count = state->total_writes + 1;
    header.timestamp   = state->next_write_time;

    checksum = param_store_calc_checksum(state->params, state->param_count);
    header.checksum = checksum;

    if (!flash_erase_sector_internal(sector)) {
        return 0;
    }

    flash_unlock_internal();
    FLASH_CR |= FLASH_CR_PG;

    flash_ptr = (volatile uint32_t *)page_addr;

    src_ptr = (const uint32_t *)&header;
    for (i = 0; i < sizeof(header) / 4; i++) {
        flash_ptr[i] = src_ptr[i];
        flash_wait_ready_internal();
    }

    src_ptr = (const uint32_t *)state->params;
    total_words = ((uint32_t)state->param_count * sizeof(param_entry_t)) / 4U;

    for (i = 0; i < total_words; i++) {
        flash_ptr[(sizeof(header) / 4) + i] = src_ptr[i];
        flash_wait_ready_internal();
    }

    FLASH_CR &= ~FLASH_CR_PG;
    flash_lock_internal();

    state->total_writes++;
    state->page_write_counts[state->active_page]++;

    if (state->page_write_counts[state->active_page] >= PARAM_WEAR_LEVEL_MAX) {
        uint8_t min = 0;
        for (i = 0; i < PARAM_STORE_PAGE_COUNT; i++) {
            if (state->page_write_counts[i] <
                state->page_write_counts[min]) {
                min = i;
            }
        }
        state->page_write_counts[state->active_page] =
            state->page_write_counts[min];
    }

    state->active_header = header;
    state->save_pending = 0;

    return 1;
}

int32_t param_get(param_store_state_t *state, uint16_t param_id)
{
    uint16_t i;

    if (state == 0) return 0;

    for (i = 0; i < state->param_count && i < PARAM_MAX_COUNT; i++) {
        if (state->params[i].param_id == param_id) {
            return state->params[i].value;
        }
    }

    return 0;
}

uint8_t param_set(param_store_state_t *state, uint16_t param_id, int32_t value)
{
    uint16_t i;

    if (state == 0) return 0;

    for (i = 0; i < state->param_count && i < PARAM_MAX_COUNT; i++) {
        if (state->params[i].param_id == param_id) {
            if (value < state->params[i].min_val) {
                value = state->params[i].min_val;
            }
            if (value > state->params[i].max_val) {
                value = state->params[i].max_val;
            }

            state->params[i].value = value;
            state->params[i].write_count++;
            state->save_pending = 1;
            return 1;
        }
    }

    return 0;
}

void param_store_init(param_store_state_t *state)
{
    uint8_t i;

    if (state == 0) return;

    memset(state, 0, sizeof(param_store_state_t));
    state->initialized = 1;
    state->store_ready = 0;
    state->save_pending = 0;
    state->load_complete = 0;
    state->param_count = 0;
    state->total_writes = 0;

    for (i = 0; i < PARAM_STORE_PAGE_COUNT; i++) {
        state->page_write_counts[i] = 0;
    }
}

void param_store_update(param_store_state_t *state)
{
    if (state == 0 || !state->initialized) return;

    state->next_write_time++;

    if (state->save_pending) {
        param_save_all(state);
    }
}
