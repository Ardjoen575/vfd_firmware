#include "data_storage_params.h"
#include <string.h>

#define FLASH_R_BASE       0x40023C00UL
#define FLASH_KEYR         (*(volatile uint32_t *)(FLASH_R_BASE + 0x04UL))
#define FLASH_SR           (*(volatile uint32_t *)(FLASH_R_BASE + 0x0CUL))
#define FLASH_CR           (*(volatile uint32_t *)(FLASH_R_BASE + 0x10UL))
#define FLASH_KEY1         0x45670123UL
#define FLASH_KEY2         0xCDEF89ABUL
#define FLASH_CR_STRT      (1UL << 16)
#define FLASH_CR_SER       (1UL << 1)
#define FLASH_CR_PG        (1UL << 0)
#define FLASH_CR_LOCK      (1UL << 31)
#define FLASH_SR_BSY       (1UL << 16)
#define FLASH_CR_SNB_Pos   3U

static void ds_flash_unlock(void)
{
    if (FLASH_CR & FLASH_CR_LOCK) {
        FLASH_KEYR = FLASH_KEY1;
        FLASH_KEYR = FLASH_KEY2;
        __asm__ volatile ("dsb");
        __asm__ volatile ("isb");
    }
}

static void ds_flash_lock(void)
{
    FLASH_CR |= FLASH_CR_LOCK;
}

static void ds_flash_wait(void)
{
    while (FLASH_SR & FLASH_SR_BSY) {
    }
}

static uint16_t ds_calc_checksum(const uint8_t *data, uint16_t len)
{
    uint16_t crc = 0xFFFF;
    uint16_t i, j;

    for (i = 0; i < len; i++) {
        crc ^= (uint16_t)data[i];
        for (j = 0; j < 8; j++) {
            if (crc & 0x0001) {
                crc = (uint16_t)((crc >> 1) ^ 0xA001);
            } else {
                crc = (uint16_t)(crc >> 1);
            }
        }
    }

    return crc;
}

uint8_t data_store_read(data_storage_params_state_t *state,
                         uint16_t slot_id, uint8_t *buffer, uint16_t *length)
{
    const data_store_header_t *header;
    const data_store_slot_t *slot;
    const uint8_t *flash_base;
    uint16_t i;

    if (state == 0 || buffer == 0 || length == 0) return 0;

    header = (const data_store_header_t *)DATA_STORE_FLASH_BASE;

    if (header->magic != DATA_STORE_MAGIC) {
        return 0;
    }

    if (header->slot_count > DATA_STORE_MAX_SLOTS) {
        return 0;
    }

    flash_base = (const uint8_t *)(DATA_STORE_FLASH_BASE +
                                    sizeof(data_store_header_t));

    slot = (const data_store_slot_t *)flash_base;

    for (i = 0; i < header->slot_count; i++) {
        if (slot->slot_id == slot_id) {
            uint16_t len = slot->data_length;
            if (len > *length) {
                len = *length;
            }
            memcpy(buffer, slot->data, len);
            *length = len;
            return 1;
        }
        slot++;
    }

    return 0;
}

uint8_t data_store_write(data_storage_params_state_t *state,
                          uint16_t slot_id, const uint8_t *data, uint16_t length)
{
    volatile uint32_t *flash_ptr;
    uint32_t sector;
    data_store_header_t header;
    data_store_slot_t slot;
    const uint32_t *src;
    uint32_t word_count;
    uint32_t i;

    if (state == 0 || data == 0 || length == 0) return 0;
    if (length > (DATA_STORE_SLOT_SIZE - 4)) return 0;

    sector = (DATA_STORE_FLASH_BASE - 0x08000000UL) / 0x00008000UL;

    ds_flash_unlock();
    ds_flash_wait();

    FLASH_CR &= ~(0x0FUL << FLASH_CR_SNB_Pos);
    FLASH_CR |= (sector << FLASH_CR_SNB_Pos);
    FLASH_CR |= FLASH_CR_SER;
    __asm__ volatile ("dsb");
    __asm__ volatile ("isb");
    FLASH_CR |= FLASH_CR_STRT;
    __asm__ volatile ("dsb");
    __asm__ volatile ("isb");
    ds_flash_wait();
    FLASH_CR &= ~FLASH_CR_SER;
    ds_flash_wait();

    FLASH_CR |= FLASH_CR_PG;

    header.magic       = DATA_STORE_MAGIC;
    header.slot_count  = state->slot_count + 1;
    header.write_counter = state->write_counter + 1;

    slot.slot_id    = slot_id;
    slot.data_length = length;
    memcpy(slot.data, data, length);

    header.checksum = ds_calc_checksum(
        (const uint8_t *)&slot, sizeof(data_store_slot_t));

    flash_ptr = (volatile uint32_t *)DATA_STORE_FLASH_BASE;

    src = (const uint32_t *)&header;
    for (i = 0; i < sizeof(header) / 4; i++) {
        flash_ptr[i] = src[i];
        ds_flash_wait();
    }

    src = (const uint32_t *)&slot;
    word_count = (sizeof(data_store_slot_t) + 3) / 4;
    for (i = 0; i < word_count; i++) {
        flash_ptr[(sizeof(header) / 4) + i] = src[i];
        ds_flash_wait();
    }

    FLASH_CR &= ~FLASH_CR_PG;
    ds_flash_lock();

    state->slot_count++;
    state->write_counter++;

    return 1;
}

void data_storage_params_init(data_storage_params_state_t *state)
{
    if (state == 0) return;

    memset(state, 0, sizeof(data_storage_params_state_t));
    state->initialized    = 1;
    state->storage_ready  = 0;
    state->write_pending  = 0;
    state->slot_count     = 0;
    state->write_counter  = 0;
}

void data_storage_params_update(data_storage_params_state_t *state)
{
    const data_store_header_t *header;

    if (state == 0 || !state->initialized) return;

    header = (const data_store_header_t *)DATA_STORE_FLASH_BASE;

    if (header->magic == DATA_STORE_MAGIC && !state->storage_ready) {
        state->slot_count    = header->slot_count;
        state->write_counter = header->write_counter;
        state->storage_ready = 1;
    }
}
