#include "pwm_driver.h"
#include <stdint.h>

typedef struct {
    volatile uint32_t CR1;
    volatile uint32_t CR2;
    volatile uint32_t SMCR;
    volatile uint32_t DIER;
    volatile uint32_t SR;
    volatile uint32_t EGR;
    volatile uint32_t CCMR1;
    volatile uint32_t CCMR2;
    volatile uint32_t CCER;
    volatile uint32_t CNT;
    volatile uint32_t PSC;
    volatile uint32_t ARR;
    volatile uint32_t RCR;
    volatile uint32_t CCR1;
    volatile uint32_t CCR2;
    volatile uint32_t CCR3;
    volatile uint32_t CCR4;
    volatile uint32_t BDTR;
    volatile uint32_t DCR;
    volatile uint32_t DMAR;
} tim_advanced_t;

#define TIM1_BASE ((tim_advanced_t *)0x40010000UL)
#define TIM1      (TIM1_BASE)

/*
 * Fixed-point math macros. Q15 format for trig values (range -1..+1).
 */
static inline int32_t mul_q15(int32_t a, int32_t b)
{
    return (a * b) >> 15;
}

static inline int32_t mul_q16(int32_t a, int32_t b)
{
    return (int64_t)(a) * (int64_t)(b) >> 16;
}

/*
 * Clarke transform: a,b,c -> alpha, beta
 *   v_alpha = (v_a - 0.5 * v_b - 0.5 * v_c) * 2/3
 *           = (2*v_a - v_b - v_c) / 3
 *   v_beta  = (sqrt(3)/2 * v_b - sqrt(3)/2 * v_c) * 2/3
 *           = (v_b - v_c) / sqrt(3)
 */
static void clarke_transform(int32_t va, int32_t vb, int32_t vc,
                             int32_t *v_alpha, int32_t *v_beta)
{
    *v_alpha = (2 * va - vb - vc) / 3;
    *v_beta  = (vb - vc) * 37837 / 65536;
}

/*
 * Park transform: alpha, beta -> d, q (rotating frame).
 *   v_d =  v_alpha * cos(theta) + v_beta * sin(theta)
 *   v_q = -v_alpha * sin(theta) + v_beta * cos(theta)
 */
static void park_transform(int32_t v_alpha, int32_t v_beta,
                           int32_t cos_theta, int32_t sin_theta,
                           int32_t *v_d, int32_t *v_q)
{
    *v_d = mul_q15(v_alpha, cos_theta) + mul_q15(v_beta, sin_theta);
    *v_q = -mul_q15(v_alpha, sin_theta) + mul_q15(v_beta, cos_theta);
}

/*
 * Inverse Park: d, q -> alpha, beta
 *   v_alpha = v_d * cos(theta) - v_q * sin(theta)
 *   v_beta  = v_d * sin(theta) + v_q * cos(theta)
 */
static void inv_park_transform(int32_t v_d, int32_t v_q,
                               int32_t cos_theta, int32_t sin_theta,
                               int32_t *v_alpha, int32_t *v_beta)
{
    *v_alpha =  mul_q15(v_d, cos_theta) - mul_q15(v_q, sin_theta);
    *v_beta  =  mul_q15(v_d, sin_theta) + mul_q15(v_q, cos_theta);
}

/*
 * Space vector PWM sector determination and duty cycle calculation.
 *
 * Inputs:
 *   v_alpha, v_beta:  alpha-beta voltages (Q15, range -32768..32767)
 *   vdc:              DC bus voltage in mV
 *
 * Outputs:
 *   ta, tb, tc:       compare values for TIM1 CCR1, CCR2, CCR3 (0..PWM_PERIOD)
 *
 * Sectors:
 *   Sector 1: 0..60   -> ta = t0/2, tb = t0/2 + t1, tc = t0/2 + t1 + t2
 *   Sector 2: 60..120 -> tb = t0/2, ta = t0/2 + t1, tc = t0/2 + t1 + t2
 *   Sector 3: 120..180-> tb = t0/2, tc = t0/2 + t1, ta = t0/2 + t1 + t2
 *   Sector 4: 180..240-> tc = t0/2, tb = t0/2 + t1, ta = t0/2 + t1 + t2
 *   Sector 5: 240..300-> tc = t0/2, ta = t0/2 + t1, tb = t0/2 + t1 + t2
 *   Sector 6: 300..360-> ta = t0/2, tc = t0/2 + t1, tb = t0/2 + t1 + t2
 *
 * This uses center-aligned PWM:
 *   ta_on = (PWM_PERIOD - (ta_end - ta_start)) / 2
 *         = (PWM_PERIOD - t_phase) / 2
 * The CCRx values set the compare point. For center-aligned mode 1 (CMS=01),
 *   OCxREF = 1 when CNT > CCRx (counting up) AND CNT < (ARR - CCRx) (counting down)
 *
 * We compute the time as fraction of PWM_PERIOD:
 *   t1 = sqrt(3) * Ts * Vref * sin(60 - theta) / Vdc
 *   t2 = sqrt(3) * Ts * Vref * sin(theta) / Vdc
 *   t0 = Ts - t1 - t2
 *
 * Where Ts = PWM_PERIOD (in timer ticks).
 * Vref = modulation_index * Vdc / ONE_Q16
 */

static void svpwm_sector_and_duty(pwm_driver_state_t *state)
{
    int32_t va = state->v_alpha;
    int32_t vb = state->v_beta;
    uint32_t vdc_mv_adc = (uint32_t)(state->dc_bus_mv > 0 ? state->dc_bus_mv : 1);

    /*
     * Determine sector based on angle of voltage vector.
     * Sector is determined by sign of vb and (sqrt(3)*va - vb) etc.
     *
     * References:
     *   v_ref1 = vb
     *   v_ref2 = sqrt(3)/2 * va - 1/2 * vb
     *   v_ref3 = -sqrt(3)/2 * va - 1/2 * vb
     */

    int32_t v_ref1 =  vb;
    int32_t v_ref2 =  mul_q15(va, 56756) - (vb >> 1);  /* sqrt(3)/2 in Q15 = 56756 */
    int32_t v_ref3 = -mul_q15(va, 56756) - (vb >> 1);

    uint8_t sector = 0;

    if (v_ref1 > 0) {
        sector |= 1;
    }
    if (v_ref2 > 0) {
        sector |= 2;
    }
    if (v_ref3 > 0) {
        sector |= 4;
    }

    /*
     * Map to sector 1..6:
     *   v_ref1>0 v_ref2>0 v_ref3>0 -> sector
     *     1        0        1     -> 1
     *     1        1        0     -> 2
     *     0        1        0     -> 3
     *     0        1        1     -> 4
     *     0        0        1     -> 5
     *     1        0        1     -> (duplicate, use 1)
     *     1        0        0     -> (error)
     *     0        0        0     -> 5 (use 5)
     *     1        1        1     -> 2 (use 2)
     */
    switch (sector) {
        case 5: sector = 1; break;   /* 101 */
        case 6: sector = 2; break;   /* 110 */
        case 2: sector = 3; break;   /* 010 */
        case 3: sector = 4; break;   /* 011 */
        case 4: sector = 5; break;   /* 100 */
        case 0: sector = 5; break;   /* 000 */
        case 7: sector = 2; break;   /* 111 */
        case 1: sector = 1; break;   /* 001 */
        default: sector = 1; break;
    }

    state->sector = sector;

    /*
     * Compute t1, t2, t0 based on sector, Vdc, and modulation index.
     *
     * The voltage magnitude is determined by the modulation index:
     *   |V| = mod_index * Vdc
     * Where mod_index is in Q16 (ONE_Q16 = 1.0).
     *
     * t1 = sqrt(3) * Ts * |V| * sin(pi/3 - theta_sector) / Vdc
     * t2 = sqrt(3) * Ts * |V| * sin(theta_sector) / Vdc
     *
     * Since |V|/Vdc = mod_index / ONE_Q16, and sqrt(3) in Q15 = 56756:
     *
     * t1 = 56756 * Ts * sin(pi/3 - theta) / 32768 * mod_index / ONE_Q16
     * t2 = 56756 * Ts * sin(theta) / 32768 * mod_index / ONE_Q16
     *
     * Precompute k = sqrt(3) * Ts * mod_index in Q16:
     *   k = 56756 * Ts * mod_index >> 31  (Q16 * Q16 >> 16 = Q16, but 56756 is Q15 so >> 31 total)
     */

    uint32_t Ts = state->period;

    /*
     * Simplified version for fixed-point implementation:
     * Compute t1, t2 directly from v_alpha, v_beta.
     *
     * In sector 1:
     *   t1 = Ts * (va - vb/sqrt(3)) * (3/(2*Vdc)) ...  complex
     *
     * Simpler approach: use the reference vector components directly.
     *
     * For any sector, map alpha-beta into the sector's coordinate system
     * using precomputed transformation. Given the DSP-oriented format,
     * we compute t1 and t2 from:
     *
     *   X = va
     *   Y = (va + sqrt(3)*vb) / 2
     *   Z = (va - sqrt(3)*vb) / 2
     *
     * Then for each sector:
     *   sector 1: t1 = Z, t2 = Y
     *   sector 2: t1 = Y, t2 = -X
     *   sector 3: t1 = -Z, t2 = X
     *   sector 4: t1 = -X, t2 = Z
     *   sector 5: t1 = X, t2 = -Y
     *   sector 6: t1 = -Y, t2 = -Z
     *
     * Scale by Ts/Vdc:
     *   duty_scale = Ts * ONE_Q16 / Vdc_ref
     *   Where Vdc_ref is the DC bus in the same units as modulation index.
     *
     * Since v_alpha/v_beta are in Q15 and dc_bus_mv is in mV,
     * we normalize everything:
     *
     * v_alpha_norm = v_alpha (Q15, range +/-32767 representing full-scale voltage)
     * v_beta_norm = v_beta (Q15)
     *
     * The maximum sine-wave peak amplitude without overmodulation is Vdc/sqrt(3).
     * The SVPWM maximum amplitude is Vdc (vector length of inscribed circle in hexagon).
     * For linear modulation: |V_ref| <= Vdc
     *
     * We work with the raw alpha-beta values scaled by the modulation factor.
     * The final compare values are:
     */

    int32_t va_scaled = mul_q15(va, (int32_t)(state->modulation_index >> 1));
    int32_t vb_scaled = mul_q15(vb, (int32_t)(state->modulation_index >> 1));

    int32_t X =  va_scaled;
    int32_t Y = (va_scaled + mul_q15(vb_scaled, 56756)) >> 1;
    int32_t Z = (va_scaled - mul_q15(vb_scaled, 56756)) >> 1;

    int32_t t1, t2;

    switch (sector) {
        case 1: t1 = Z; t2 = Y; break;
        case 2: t1 = Y; t2 = -X; break;
        case 3: t1 = -Z; t2 = X; break;
        case 4: t1 = -X; t2 = Z; break;
        case 5: t1 = X; t2 = -Y; break;
        case 6: t1 = -Y; t2 = -Z; break;
        default: t1 = 0; t2 = 0; break;
    }

    /*
     * Map Q15 t1, t2 to timer ticks.
     * The range of t1,t2 is 0..32767 corresponding to 0..Ts.
     * So: duty_ticks = (t * Ts) / 32768
     *               = (t * Ts) >> 15
     */
    state->t1 = (t1 > 0) ? (uint32_t)(((int64_t)t1 * (int64_t)Ts) >> 15) : 0;
    state->t2 = (t2 > 0) ? (uint32_t)(((int64_t)t2 * (int64_t)Ts) >> 15) : 0;

    uint32_t t1_t2 = state->t1 + state->t2;

    /* Clamp — if t1+t2 > period, saturate (overmodulation) */
    if (t1_t2 > Ts) {
        uint64_t scale = ((uint64_t)Ts << 16) / (uint64_t)t1_t2;
        state->t1 = (uint32_t)((state->t1 * scale) >> 16);
        state->t2 = (uint32_t)((state->t2 * scale) >> 16);
        state->t0 = 0;
    } else {
        state->t0 = Ts - t1_t2;
    }

    /*
     * Compute compare values for center-aligned PWM.
     *
     * For center-aligned mode:
     *   ta_on = (t1 + t2 + t0/2)  — or equivalently:
     *   ta = t0/2 + t1 + t2
     *   tb = t0/2 + t1
     *   tc = t0/2
     *
     * But the mapping depends on sector. We compute three compare values
     * (T_on_a, T_on_b, T_on_c) and then assign them to physical CCRx registers
     * based on the sector.
     */

    uint32_t half_t0 = state->t0 >> 1;

    switch (sector) {
        case 1: /* 0-60 */
            state->ta = half_t0 + state->t1 + state->t2;
            state->tb = half_t0 + state->t1;
            state->tc = half_t0;
            break;
        case 2: /* 60-120 */
            state->ta = half_t0 + state->t1;
            state->tb = half_t0 + state->t1 + state->t2;
            state->tc = half_t0;
            break;
        case 3: /* 120-180 */
            state->ta = half_t0;
            state->tb = half_t0 + state->t1 + state->t2;
            state->tc = half_t0 + state->t1;
            break;
        case 4: /* 180-240 */
            state->ta = half_t0;
            state->tb = half_t0 + state->t1;
            state->tc = half_t0 + state->t1 + state->t2;
            break;
        case 5: /* 240-300 */
            state->ta = half_t0 + state->t1;
            state->tb = half_t0;
            state->tc = half_t0 + state->t1 + state->t2;
            break;
        case 6: /* 300-360 */
            state->ta = half_t0 + state->t1 + state->t2;
            state->tb = half_t0;
            state->tc = half_t0 + state->t1;
            break;
        default:
            state->ta = state->tb = state->tc = Ts >> 1;
            break;
    }

    /* Clamp compare values */
    if (state->ta > Ts) state->ta = Ts;
    if (state->tb > Ts) state->tb = Ts;
    if (state->tc > Ts) state->tc = Ts;
}

void pwm_driver_init(pwm_driver_state_t *state)
{
    state->initialized = 1;
    state->period = PWM_PERIOD;
    state->deadband = PWM_DEADBAND;

    state->duty_a = 0;
    state->duty_b = 0;
    state->duty_c = 0;

    state->v_alpha = 0;
    state->v_beta = 0;
    state->modulation_index = 0;

    state->dc_bus_mv = 0;
    state->t0 = state->period >> 1;
    state->t1 = 0;
    state->t2 = 0;
    state->ta = state->period >> 1;
    state->tb = state->period >> 1;
    state->tc = state->period >> 1;
    state->sector = 1;

    state->chopper_duty = 0;
    state->brake_active = 0;

    /*
     * Initialize TIM1 CCRs to 50% (zero voltage vector).
     * Dead-time and polarity are configured in hrtim_bsp_init().
     */
    TIM1->CCR1 = (uint32_t)(state->period >> 1);
    TIM1->CCR2 = (uint32_t)(state->period >> 1);
    TIM1->CCR3 = (uint32_t)(state->period >> 1);
    TIM1->CCR4 = 0;

    /*
     * Main output enable.
     */
    TIM1->BDTR |= (1UL << 15); /* MOE */
}

void pwm_driver_update(pwm_driver_state_t *state)
{
    /*
     * Write duty cycles to TIM1 compare registers.
     * The shadow registers are updated at the next update event
     * (center of PWM cycle for center-aligned mode).
     */
    TIM1->CCR1 = state->ta;
    TIM1->CCR2 = state->tb;
    TIM1->CCR3 = state->tc;
}

void pwm_svm_update(pwm_driver_state_t *state)
{
    /*
     * Run the SVPWM calculation with current alpha-beta reference
     * and DC bus voltage, then update the hardware registers.
     */

    svpwm_sector_and_duty(state);

    TIM1->CCR1 = state->ta;
    TIM1->CCR2 = state->tb;
    TIM1->CCR3 = state->tc;
}

void pwm_chopper_update(pwm_driver_state_t *state)
{
    int32_t vbus = state->dc_bus_mv;

    if (vbus > DC_BUS_BRAKE_ON_MV) {
        state->brake_active = 1;
    } else if (vbus < DC_BUS_BRAKE_OFF_MV) {
        state->brake_active = 0;
    }

    if (state->brake_active) {
        /*
         * Brake chopper duty cycle proportional to overvoltage.
         * 0% at brake_on threshold, 100% at overvoltage threshold.
         */
        int32_t range = DC_BUS_OVERVOLTAGE_MV - DC_BUS_BRAKE_ON_MV;
        int32_t excess = vbus - DC_BUS_BRAKE_ON_MV;

        if (range <= 0) range = 1;

        int32_t duty_q16 = (excess << 16) / range;
        if (duty_q16 > ONE_Q16) duty_q16 = ONE_Q16;
        if (duty_q16 < 0) duty_q16 = 0;

        state->chopper_duty = (uint32_t)((duty_q16 * state->period) >> 16);

        /*
         * Clamp chopper duty to avoid shoot-through:
         * max duty = period - deadband_ticks (safety margin).
         */
        if (state->chopper_duty > (state->period - state->deadband)) {
            state->chopper_duty = state->period - state->deadband;
        }
    } else {
        state->chopper_duty = 0;
    }

    /*
     * TIM1 CH4 is the brake chopper output (PE14).
     * CCR4 = 0 means 100% off (PWM mode 2: OCxREF=1 when CNT>CCR, so CCR4=0 -> always off).
     * CCR4 > 0 applies duty cycle.
     */
    TIM1->CCR4 = state->chopper_duty;
}
