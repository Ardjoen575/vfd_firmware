#ifndef DRIVERS_ADC_DRIVER_H
#define DRIVERS_ADC_DRIVER_H

/* Current, DC bus, analog input sampling */

#include <stdint.h>
#include <stddef.h>

#define ADC_NUM_CHANNELS      8
#define ADC_NUM_INJECTED      3
#define ADC_CAL_SAMPLES      512
#define ADC_VREF_MV           3300
#define ADC_RESOLUTION        4096
#define ADC_MIDPOINT          (ADC_RESOLUTION / 2)

typedef struct {
    uint8_t initialized;

    volatile uint16_t *dma_buffer;
    volatile uint16_t *inj_buffer;

    uint16_t raw_buffer[ADC_NUM_CHANNELS * 2];
    uint16_t raw_injected[ADC_NUM_INJECTED * 2];

    uint16_t adc_values[ADC_NUM_CHANNELS];
    uint16_t injected_values[ADC_NUM_INJECTED];

    int32_t offset[ADC_NUM_CHANNELS];
    int32_t offset_inj[ADC_NUM_INJECTED];
    int32_t gain[ADC_NUM_CHANNELS];

    int32_t current_u;
    int32_t current_v;
    int32_t current_w;
    int32_t dc_bus_mv;
    int32_t heatsink_temp_adc;
    int32_t analog_in1;
    int32_t analog_in2;
    int32_t pot_adc;

    uint32_t cal_index;
    int32_t cal_accum[ADC_NUM_CHANNELS];

    uint8_t calibration_done;
} adc_driver_state_t;

void adc_driver_init(adc_driver_state_t *state);
void adc_driver_update(adc_driver_state_t *state);
void adc_sample_all(adc_driver_state_t *state);
void adc_calibrate(adc_driver_state_t *state);

#endif /* DRIVERS_ADC_DRIVER_H */
