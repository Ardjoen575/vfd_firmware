#ifndef DRIVERS_PWM_DRIVER_H
#define DRIVERS_PWM_DRIVER_H

/* HRTIM SVPWM + braking chopper PWM */

#include <stdint.h>

#define PWM_PERIOD_MAX        2625    /* TIM1 half-period (168M / (16k*2) - 1) = 5249 */
#define PWM_DEADBAND          50
#define PWM_PERIOD            (PWM_PERIOD_MAX - PWM_DEADBAND)

#define DC_BUS_NOMINAL_MV     325000  /* 325 V DC (230 VAC rectified) */
#define DC_BUS_OVERVOLTAGE_MV 400000  /* 400 V overvoltage threshold */
#define DC_BUS_BRAKE_ON_MV    380000  /* 380 V brake chopper on */
#define DC_BUS_BRAKE_OFF_MV   360000  /* 360 V brake chopper off */

#define SVPWM_SQRT3_DIV2      56756   /* sqrt(3)/2 in Q16 */
#define ONE_Q16               65536

typedef struct {
    uint8_t initialized;

    uint32_t period;
    uint32_t deadband;

    int32_t duty_a;
    int32_t duty_b;
    int32_t duty_c;

    int32_t v_alpha;
    int32_t v_beta;
    int32_t modulation_index;

    int32_t dc_bus_mv;
    uint32_t t0;
    uint32_t t1;
    uint32_t t2;
    uint32_t ta;
    uint32_t tb;
    uint32_t tc;
    uint8_t sector;

    uint32_t chopper_duty;
    uint8_t brake_active;
} pwm_driver_state_t;

void pwm_driver_init(pwm_driver_state_t *state);
void pwm_driver_update(pwm_driver_state_t *state);
void pwm_svm_update(pwm_driver_state_t *state);
void pwm_chopper_update(pwm_driver_state_t *state);

#endif /* DRIVERS_PWM_DRIVER_H */
