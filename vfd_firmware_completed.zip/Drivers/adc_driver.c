#include "adc_driver.h"
#include <stdint.h>

#define ONE_Q16               65536

typedef struct {
    volatile uint32_t SR;
    volatile uint32_t CR1;
    volatile uint32_t CR2;
    volatile uint32_t SMPR1;
    volatile uint32_t SMPR2;
    volatile uint32_t JOFR1;
    volatile uint32_t JOFR2;
    volatile uint32_t JOFR3;
    volatile uint32_t JOFR4;
    volatile uint32_t HTR;
    volatile uint32_t LTR;
    volatile uint32_t SQR1;
    volatile uint32_t SQR2;
    volatile uint32_t SQR3;
    volatile uint32_t JSQR;
    volatile uint32_t JDR1;
    volatile uint32_t JDR2;
    volatile uint32_t JDR3;
    volatile uint32_t JDR4;
    volatile uint32_t DR;
    uint32_t _pad0;
    volatile uint32_t CSR;
    volatile uint32_t CCR;
    volatile uint32_t CDR;
} adc_t;

typedef struct {
    volatile uint32_t SxCR;
    volatile uint32_t SxNDTR;
    volatile uint32_t SxPAR;
    volatile uint32_t SxM0AR;
    volatile uint32_t SxM1AR;
    volatile uint32_t SxFCR;
} dma_stream_t;

#define ADC1_BASE  ((adc_t *)0x40012000UL)
#define ADC2_BASE  ((adc_t *)0x40012100UL)
#define ADC3_BASE  ((adc_t *)0x40012200UL)
#define ADC_COM    ((adc_t *)0x40012300UL)

#define ADC1 (ADC1_BASE)
#define ADC2 (ADC2_BASE)
#define ADC3 (ADC3_BASE)
#define ADC_CO (ADC_COM)

#define DMA2_BASE   ((volatile uint32_t *)0x40026400UL)
#define DMA2_S0     ((dma_stream_t *)(0x40026400UL + 0x10UL))

#define DMA_SxCR_EN          (1UL << 0)
#define DMA_SxCR_TCIE        (1UL << 4)
#define DMA_SxCR_DIR_P2M     (0x0UL << 6)
#define DMA_SxCR_CIRC        (1UL << 8)
#define DMA_SxCR_MINC        (1UL << 10)
#define DMA_SxCR_PSIZE_16    (0x1UL << 11)
#define DMA_SxCR_MSIZE_16    (0x1UL << 13)
#define DMA_SxCR_PL_HIGH     (0x2UL << 16)
#define DMA_SxCR_CHSEL_0     (0x0UL << 25)

#define DMA_LIFCR            (*(volatile uint32_t *)(0x40026400UL + 0x08UL))
#define DMA_LIFCR_CTCIF0     (1UL << 5)
#define DMA_LIFCR_CHTIF0     (1UL << 6)

#define ADC_CR2_ADON         (1UL << 0)
#define ADC_CR2_SWSTART      (1UL << 30)
#define ADC_CR2_JSWSTART     (1UL << 22)
#define ADC_CR2_DMA          (1UL << 8)

#define ADC_CSR_ADON_MST     (1UL << 13)
#define ADC_CSR_ADON_SLV1    (1UL << 14)
#define ADC_CSR_ADON_SLV2    (1UL << 15)

static void dma_configure(adc_driver_state_t *state)
{
    dma_stream_t *s = DMA2_S0;

    s->SxCR &= ~DMA_SxCR_EN;

    s->SxCR = DMA_SxCR_CHSEL_0
            | DMA_SxCR_DIR_P2M
            | DMA_SxCR_MINC
            | DMA_SxCR_CIRC
            | DMA_SxCR_PSIZE_16
            | DMA_SxCR_MSIZE_16
            | DMA_SxCR_PL_HIGH
            | DMA_SxCR_TCIE;

    s->SxNDTR = ADC_NUM_CHANNELS * 2;   /* dual mode -> 2 words per sample */
    s->SxPAR  = (uint32_t)&ADC_CO->CDR;
    s->SxM0AR = (uint32_t)state->raw_buffer;

    s->SxCR |= DMA_SxCR_EN;
}

static void adc_calibrate_peripheral(void)
{
    /*
     * Perform ADC self-calibration.
     * ADC_CR2 must have ADON=1.
     * Set RSTCAL, wait for it to clear, then set CAL, wait for it to clear.
     */

    adc_t *adcs[3] = {ADC1, ADC2, ADC3};

    for (int i = 0; i < 3; i++) {
        adc_t *a = adcs[i];

        a->CR2 |= (1UL << 3);                /* RSTCAL */
        while (a->CR2 & (1UL << 3)) {        /* wait RSTCAL clear */
            __asm__ volatile("nop");
        }

        a->CR2 |= (1UL << 2);                /* CAL */
        while (a->CR2 & (1UL << 2)) {        /* wait CAL clear */
            __asm__ volatile("nop");
        }
    }
}

void adc_driver_init(adc_driver_state_t *state)
{
    state->initialized = 1;
    state->calibration_done = 0;

    state->dma_buffer = NULL;
    state->inj_buffer = NULL;

    for (int i = 0; i < ADC_NUM_CHANNELS; i++) {
        state->raw_buffer[i] = 0;
        state->adc_values[i] = 0;
        state->offset[i] = 0;
        state->gain[i] = ONE_Q16;
        state->cal_accum[i] = 0;
    }

    for (int i = 0; i < ADC_NUM_INJECTED; i++) {
        state->raw_injected[i] = 0;
        state->injected_values[i] = 0;
        state->offset_inj[i] = 0;
    }

    state->current_u = 0;
    state->current_v = 0;
    state->current_w = 0;
    state->dc_bus_mv = 0;
    state->heatsink_temp_adc = 0;
    state->analog_in1 = 0;
    state->analog_in2 = 0;
    state->pot_adc = 0;

    state->cal_index = 0;

    dma_configure(state);

    adc_calibrate_peripheral();

    /*
     * Enable all three ADCs (ADON bit in ADC_CSR for multi-mode).
     */
    uint32_t csr = ADC_CO->CSR;
    csr |= ADC_CSR_ADON_MST | ADC_CSR_ADON_SLV1 | ADC_CSR_ADON_SLV2;
    ADC_CO->CSR = csr;

    /*
     * Start continuous conversion on ADC1 (master).
     * In dual mode, this also drives ADC2 and ADC3.
     */
    ADC1->CR2 |= ADC_CR2_SWSTART;
}

void adc_driver_update(adc_driver_state_t *state)
{
    (void)state;

    /*
     * DMA is running in circular mode, automatically filling raw_buffer.
     * Copy the most recent DMA data into adc_values buffer atomically.
     * The DMA buffer in dual simultaneous mode contains interleaved data:
     *   raw_buffer[0] = ADC1_CH3 | (ADC2_CH2 << 16)   (dual regular data)
     * But since we read individually for each ADC, we just grab the CDR.
     * For simplicity: read injected data directly from JDR registers.
     */

    /* Read injected (current) data directly from JDR registers */
    state->injected_values[0] = (uint16_t)(ADC1->JDR1 & 0xFFFF);
    state->injected_values[1] = (uint16_t)(ADC1->JDR2 & 0xFFFF);
    state->injected_values[2] = (uint16_t)(ADC1->JDR3 & 0xFFFF);

    /*
     * Copy regular channel data from DMA buffer.
     * raw_buffer layout (dual simultaneous mode, DMA mode 1):
     *   [0] = ADC1_CDR (lower 16: ADC1, upper 16: ADC2)
     *   [1] = ADC1_CDR next conversion pair
     *   ...
     */
    for (int i = 0; i < ADC_NUM_CHANNELS; i++) {
        volatile uint32_t cdr = ADC_CO->CDR;
        /*
         * In practice with DMA running, we read from the DMA buffer.
         * But since CDR contains the latest pair, for a quick update
         * we read it synchronously. In a full implementation, you'd
         * synchronize with the DMA transfer-complete interrupt.
         */
        state->adc_values[i] = (uint16_t)(cdr & 0xFFFF);
    }

    /*
     * Compute calibrated values.
     */
    state->current_u = state->injected_values[0] - state->offset_inj[0];
    state->current_v = state->injected_values[1] - state->offset_inj[1];
    state->current_w = state->injected_values[2] - state->offset_inj[2];

    /*
     * Channel assignments:
     *   ch0: current U (injected)
     *   ch1: current V (injected)
     *   ch2: current W (injected)
     *   ch3: DC bus voltage
     *   ch4: heatsink temperature
     *   ch5: analog input 1
     *   ch6: analog input 2
     *   ch7: analog potentiometer
     */
    state->dc_bus_mv          = (int32_t)((state->adc_values[3] - state->offset[3]) * ADC_VREF_MV / ADC_RESOLUTION);
    state->heatsink_temp_adc  = (int32_t)state->adc_values[4];
    state->analog_in1         = (int32_t)state->adc_values[5];
    state->analog_in2         = (int32_t)state->adc_values[6];
    state->pot_adc            = (int32_t)state->adc_values[7];

    /*
     * Rescale DC bus: voltage divider typically divides by ~100 for 325V bus.
     * ADC input = DC_BUS / divider_ratio * VREF / resolution
     * dc_bus_mv = adc_value * VREF_mV / 4096 * divider_ratio
     *
     * With divider_ratio = 100, VREF = 3300 mV:
     *   Full scale ADC reading (4095) = 3.3V at pin = 330V bus
     *   dc_bus_mv = adc * 3300 / 4096 * 100
     *             = adc * 330000 / 4096
     */
    state->dc_bus_mv = (int32_t)((state->adc_values[3] - state->offset[3]) * 330000 / ADC_RESOLUTION);
}

void adc_sample_all(adc_driver_state_t *state)
{
    /*
     * Trigger a fresh set of injected conversions (phase currents)
     * and regular conversions (all other channels).
     *
     * In dual simultaneous mode, JSWSTART on ADC1 starts injected
     * conversion on both ADC1 and ADC2 simultaneously.
     */
    ADC1->CR2 |= ADC_CR2_JSWSTART;

    /*
     * Wait for injected sequence to complete:
     * JEOC flag in ADC1_SR (bit 2).
     */
    while (!(ADC1->SR & (1UL << 2))) {
        __asm__ volatile("nop");
    }

    /*
     * Read all injected results with offset correction.
     */
    state->injected_values[0] = (uint16_t)(ADC1->JDR1 & 0xFFFF);
    state->injected_values[1] = (uint16_t)(ADC1->JDR2 & 0xFFFF);
    state->injected_values[2] = (uint16_t)(ADC1->JDR3 & 0xFFFF);

    /*
     * Trigger regular conversions.
     */
    ADC1->CR2 |= ADC_CR2_SWSTART;

    /*
     * Wait for regular sequence to complete:
     * EOC flag cycles through all channels. We wait for the
     * end-of-sequence by polling until all channels are done.
     * Simple approach: wait for SQR count of EOC events.
     */

    for (int i = 0; i < 5; i++) {
        while (!(ADC1->SR & (1UL << 1))) {
            __asm__ volatile("nop");
        }
    }

    /*
     * Read regular conversion results from DMA buffer pointer.
     * The DMA buffer should now contain the latest conversions.
     */
    for (int i = 0; i < ADC_NUM_CHANNELS; i++) {
        state->adc_values[i] = state->raw_buffer[i] & 0xFFFF;
    }

    /*
     * Apply offset/gain correction.
     * Corrected = (raw - offset) * gain / ONE_Q16
     */
    for (int i = 0; i < ADC_NUM_CHANNELS; i++) {
        int32_t corrected = (int32_t)state->adc_values[i] - state->offset[i];
        if (state->calibration_done) {
            corrected = (corrected * state->gain[i]) >> 16;
        }
        state->adc_values[i] = (uint16_t)(corrected < 0 ? 0 : (corrected > 4095 ? 4095 : corrected));
    }

    for (int i = 0; i < ADC_NUM_INJECTED; i++) {
        int32_t corrected = (int32_t)state->injected_values[i] - state->offset_inj[i];
        state->injected_values[i] = (uint16_t)(corrected < 0 ? 0 : (corrected > 4095 ? 4095 : corrected));
    }

    state->current_u = state->injected_values[0];
    state->current_v = state->injected_values[1];
    state->current_w = state->injected_values[2];
    state->dc_bus_mv = (int32_t)(state->adc_values[3] * 330000 / ADC_RESOLUTION);
    state->heatsink_temp_adc = state->adc_values[4];
    state->analog_in1 = state->adc_values[5];
    state->analog_in2 = state->adc_values[6];
    state->pot_adc = state->adc_values[7];
}

void adc_calibrate(adc_driver_state_t *state)
{
    if (state->cal_index == 0) {
        for (int ch = 0; ch < ADC_NUM_CHANNELS; ch++) {
            state->cal_accum[ch] = 0;
        }
    }

    /*
     * Accumulate ADC samples for zero-offset measurement.
     * The external circuit should be in zero-current / zero-voltage state.
     */
    ADC1->CR2 |= ADC_CR2_SWSTART;

    for (int i = 0; i < 5; i++) {
        while (!(ADC1->SR & (1UL << 1))) {
            __asm__ volatile("nop");
        }
    }

    for (int ch = 0; ch < ADC_NUM_CHANNELS; ch++) {
        state->cal_accum[ch] += (int32_t)(ADC1->DR & 0xFFFF);
    }

    state->cal_index++;

    if (state->cal_index >= ADC_CAL_SAMPLES) {
        for (int ch = 0; ch < ADC_NUM_CHANNELS; ch++) {
            state->offset[ch] = state->cal_accum[ch] / ADC_CAL_SAMPLES;
            state->gain[ch] = ONE_Q16;
        }

        for (int i = 0; i < ADC_NUM_INJECTED; i++) {
            state->offset_inj[i] = state->offset[i];
        }

        state->calibration_done = 1;
        state->cal_index = 0;
    }
}
