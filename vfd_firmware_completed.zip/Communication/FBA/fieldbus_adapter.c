#include "fieldbus_adapter.h"
#include <string.h>

static void fba_process_data_exchange(fieldbus_adapter_state_t *state)
{
    if (!state->data_exchange_active) return;

    state->exchange_counter++;

    if (state->rx_word_count > 0 && state->rx_word_count <= FBA_MAX_DATA_WORDS) {
        state->rx_data_words[0] = (uint16_t)(state->exchange_counter & 0xFFFF);
    }
}

static void fba_update_protocol_state(fieldbus_adapter_state_t *state)
{
    switch (state->protocol_state) {
    case FBA_STATE_IDLE:
        state->protocol_state = FBA_STATE_INIT;
        break;
    case FBA_STATE_INIT:
        if (state->config_locked) {
            state->protocol_state = FBA_STATE_PREOP;
        }
        break;
    case FBA_STATE_PREOP:
        state->protocol_state = FBA_STATE_OP;
        state->data_exchange_active = 1;
        break;
    case FBA_STATE_OP:
        if (state->watchdog_counter >= state->watchdog_timeout_ms) {
            state->protocol_state = FBA_STATE_ERROR;
            state->data_exchange_active = 0;
            state->error_counter++;
        }
        break;
    case FBA_STATE_ERROR:
        if (state->error_counter < 3) {
            state->protocol_state = FBA_STATE_PREOP;
        }
        break;
    }
}

void fieldbus_adapter_init(fieldbus_adapter_state_t *state)
{
    state->initialized = 1;
    state->adapter_active = 0;
    state->protocol_type = FBA_PROTO_PROFINET;
    state->protocol_state = FBA_STATE_IDLE;
    memset(state->rx_data_words, 0, sizeof(state->rx_data_words));
    memset(state->tx_data_words, 0, sizeof(state->tx_data_words));
    state->rx_word_count = 16;
    state->tx_word_count = 16;
    state->data_exchange_active = 0;
    state->config_locked = 0;
    state->poll_counter = 0;
    state->exchange_counter = 0;
    state->error_counter = 0;
    state->watchdog_counter = 0;
    state->watchdog_timeout_ms = 1000;
    memset(state->module_id, 0, sizeof(state->module_id));
    state->module_id[0] = 0x01;
    state->module_id[1] = 0x00;
    state->firmware_version[0] = 0x01;
    state->firmware_version[1] = 0x00;
    memset(state->mac_address, 0, sizeof(state->mac_address));
}

void fieldbus_adapter_update(fieldbus_adapter_state_t *state)
{
    if (!state->initialized || !state->adapter_active) return;

    state->poll_counter++;
    state->watchdog_counter++;

    fba_update_protocol_state(state);

    if (state->protocol_state == FBA_STATE_OP) {
        state->watchdog_counter = 0;
    }
}

void fba_init(fieldbus_adapter_state_t *state)
{
    state->adapter_active = 1;
    state->protocol_state = FBA_STATE_IDLE;
    state->data_exchange_active = 0;
    state->config_locked = 0;
    state->poll_counter = 0;
    state->exchange_counter = 0;
    state->error_counter = 0;
    state->watchdog_counter = 0;
    memset(state->rx_data_words, 0, sizeof(state->rx_data_words));
    memset(state->tx_data_words, 0, sizeof(state->tx_data_words));
}

void fba_poll(fieldbus_adapter_state_t *state)
{
    if (!state->initialized || !state->adapter_active) return;

    state->poll_counter++;

    fba_update_protocol_state(state);

    if (state->protocol_state == FBA_STATE_OP && state->data_exchange_active) {
        fba_process_data_exchange(state);
        state->watchdog_counter = 0;
    }
}
