#ifndef COMMUNICATION_FBA_FBA_B_SETTINGS_H
#define COMMUNICATION_FBA_FBA_B_SETTINGS_H

#include <stdint.h>

#define FBA_B_MAX_PROFILES 4

typedef enum {
    FBA_B_PROFILE_ABB_DRIVES = 0,
    FBA_B_PROFILE_TRANSPARENT_16 = 1,
    FBA_B_PROFILE_TRANSPARENT_32 = 2,
    FBA_B_PROFILE_CUSTOM = 3
} fba_b_profile_type_t;

typedef enum {
    FBA_B_BAUD_9600 = 0,
    FBA_B_BAUD_19200 = 1,
    FBA_B_BAUD_38400 = 2,
    FBA_B_BAUD_AUTO = 3
} fba_b_baud_rate_t;

typedef struct {
    uint8_t initialized;
    uint8_t node_id;
    uint8_t slot_number;
    fba_b_baud_rate_t baud_rate;
    fba_b_profile_type_t profile_selection;
    uint16_t poll_timeout_ms;
    uint8_t data_in_words;
    uint8_t data_out_words;
    uint8_t comm_mode;
    uint8_t redundancy_enabled;
    uint16_t device_type;
    uint16_t custom_vendor_id;
    uint32_t serial_number;
    uint8_t fw_version_major;
    uint8_t fw_version_minor;
    uint8_t config_valid;
    uint8_t config_dirty;
} fba_b_settings_state_t;

void fba_b_settings_init(fba_b_settings_state_t *state);
void fba_b_settings_update(fba_b_settings_state_t *state);
void fba_b_configure(fba_b_settings_state_t *state);

#endif
