#include "fba_b_data_out.h"
#include <string.h>

static uint16_t fba_b_swap_bytes_out(uint16_t val, uint8_t swap)
{
    if (swap) {
        return (uint16_t)((val >> 8) | (val << 8));
    }
    return val;
}

static void fba_b_pack_actuals(fba_b_data_out_state_t *state)
{
    if (state->tx_word_count >= 1) {
        state->tx_words[0] = fba_b_swap_bytes_out(state->ext_status_word,
                                                    state->byte_order_swap);
    }
    if (state->tx_word_count >= 3) {
        state->tx_words[2] = fba_b_swap_bytes_out(
            (uint16_t)(state->ext_actual_speed & 0xFFFF), state->byte_order_swap);
    }
    if (state->tx_word_count >= 5) {
        state->tx_words[4] = fba_b_swap_bytes_out(
            (uint16_t)((state->ext_actual_position >> 16) & 0xFFFF),
            state->byte_order_swap);
        state->tx_words[5] = fba_b_swap_bytes_out(
            (uint16_t)(state->ext_actual_position & 0xFFFF),
            state->byte_order_swap);
    }
}

static void fba_b_apply_mapped_outputs(fba_b_data_out_state_t *state)
{
    for (uint8_t i = 0; i < state->mapping_count; i++) {
        if (!state->mapping[i].enabled) continue;
        if (state->mapping[i].word_index >= state->tx_word_count) continue;

        uint16_t param = state->mapping[i].param_group * 256 +
                         state->mapping[i].param_index;
        int32_t value = 0;

        switch (param) {
        case 0x0208: value = state->ext_status_word; break;
        case 0x0205: value = state->ext_actual_speed; break;
        case 0x0206: value = state->ext_actual_position; break;
        case 0x0209: value = state->ext_custom_actual1; break;
        case 0x020A: value = state->ext_custom_actual2; break;
        case 0x020B: value = state->ext_analog_in1; break;
        case 0x020C: value = state->ext_analog_in2; break;
        case 0x020D: value = state->ext_digital_inputs; break;
        default: continue;
        }

        state->tx_words[state->mapping[i].word_index] =
            fba_b_swap_bytes_out((uint16_t)(value & 0xFFFF), state->byte_order_swap);
    }
}

void fba_b_data_out_init(fba_b_data_out_state_t *state)
{
    state->initialized = 1;
    memset(state->tx_words, 0, sizeof(state->tx_words));
    state->tx_word_count = 8;
    memset(state->mapping, 0, sizeof(state->mapping));
    state->mapping_count = 0;
    state->ext_status_word = 0;
    state->ext_actual_speed = 0;
    state->ext_actual_position = 0;
    state->ext_custom_actual1 = 0;
    state->ext_custom_actual2 = 0;
    state->ext_analog_in1 = 0;
    state->ext_analog_in2 = 0;
    state->ext_digital_inputs = 0;
    state->data_updated = 0;
    state->update_counter = 0;
    state->byte_order_swap = 0;
}

void fba_b_data_out_update(fba_b_data_out_state_t *state)
{
    if (!state->initialized) return;

    fba_b_pack_actuals(state);
    fba_b_apply_mapped_outputs(state);
    state->data_updated = 1;
    state->update_counter++;
}

void fba_b_write_data_out(fba_b_data_out_state_t *state)
{
    if (!state->initialized) return;

    fba_b_pack_actuals(state);
    fba_b_apply_mapped_outputs(state);

    for (uint8_t i = 6; i < state->tx_word_count && i < FBA_B_DATA_OUT_WORDS; i++) {
        if (state->tx_words[i] == 0) {
            switch (i) {
            case 6:
                state->tx_words[i] = fba_b_swap_bytes_out(
                    (uint16_t)state->ext_analog_in1, state->byte_order_swap);
                break;
            case 7:
                state->tx_words[i] = fba_b_swap_bytes_out(
                    (uint16_t)state->ext_analog_in2, state->byte_order_swap);
                break;
            case 8:
                state->tx_words[i] = fba_b_swap_bytes_out(
                    (uint16_t)state->ext_digital_inputs, state->byte_order_swap);
                break;
            default: break;
            }
        }
    }

    state->data_updated = 1;
    state->update_counter++;
}
