#ifndef COMMUNICATION_FBA_FBA_A_DATA_IN_H
#define COMMUNICATION_FBA_FBA_A_DATA_IN_H

#include <stdint.h>

#define FBA_A_DATA_IN_WORDS 32

typedef struct {
    uint16_t word_index;
    uint16_t param_group;
    uint16_t param_index;
    uint8_t enabled;
} fba_a_in_mapping_entry_t;

typedef struct {
    uint8_t initialized;
    uint16_t rx_words[FBA_A_DATA_IN_WORDS];
    uint8_t rx_word_count;
    fba_a_in_mapping_entry_t mapping[FBA_A_DATA_IN_WORDS];
    uint8_t mapping_count;
    int16_t control_word;
    int32_t speed_ref;
    int32_t torque_ref;
    int32_t process_ref1;
    int32_t process_ref2;
    uint16_t profile_type;
    uint8_t data_valid;
    uint8_t new_data;
    uint32_t update_counter;
} fba_a_data_in_state_t;

void fba_a_data_in_init(fba_a_data_in_state_t *state);
void fba_a_data_in_update(fba_a_data_in_state_t *state);
void fba_a_read_data_in(fba_a_data_in_state_t *state);

#endif
