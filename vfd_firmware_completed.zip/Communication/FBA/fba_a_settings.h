#ifndef COMMUNICATION_FBA_FBA_A_SETTINGS_H
#define COMMUNICATION_FBA_FBA_A_SETTINGS_H

#include <stdint.h>

#define FBA_A_MAX_PROFILES 4

typedef enum {
    FBA_PROFILE_ABB_DRIVES = 0,
    FBA_PROFILE_TRANSPARENT_16 = 1,
    FBA_PROFILE_TRANSPARENT_32 = 2,
    FBA_PROFILE_VENDOR_SPECIFIC = 3
} fba_profile_type_t;

typedef enum {
    FBA_BAUD_9600 = 0,
    FBA_BAUD_19200 = 1,
    FBA_BAUD_38400 = 2,
    FBA_BAUD_57600 = 3,
    FBA_BAUD_115200 = 4,
    FBA_BAUD_AUTO = 5
} fba_baud_rate_t;

typedef struct {
    uint8_t initialized;
    uint8_t node_id;
    uint8_t comm_module_type;
    fba_baud_rate_t baud_rate;
    fba_profile_type_t profile_selection;
    uint16_t watchdog_time_ms;
    uint8_t data_in_words;
    uint8_t data_out_words;
    uint8_t auto_baud_detect;
    uint8_t sw_select_active;
    uint16_t vendor_id;
    uint16_t device_id;
    uint32_t device_instance;
    uint8_t ip_address[4];
    uint8_t subnet_mask[4];
    uint8_t gateway[4];
    uint8_t dhcp_enabled;
    uint8_t dhcp_status;
    uint8_t config_valid;
    uint8_t config_dirty;
} fba_a_settings_state_t;

void fba_a_settings_init(fba_a_settings_state_t *state);
void fba_a_settings_update(fba_a_settings_state_t *state);
void fba_a_configure(fba_a_settings_state_t *state);

#endif
