#include "fba_a_settings.h"
#include <string.h>

static void fba_a_apply_defaults(fba_a_settings_state_t *state)
{
    state->node_id = 1;
    state->comm_module_type = 0x01;
    state->baud_rate = FBA_BAUD_AUTO;
    state->profile_selection = FBA_PROFILE_ABB_DRIVES;
    state->watchdog_time_ms = 1000;
    state->data_in_words = 16;
    state->data_out_words = 16;
    state->auto_baud_detect = 1;
    state->sw_select_active = 0;
    state->vendor_id = 0x01AB;
    state->device_id = 0x0001;
    state->device_instance = 1;
    state->ip_address[0] = 192;
    state->ip_address[1] = 168;
    state->ip_address[2] = 1;
    state->ip_address[3] = (uint8_t)(10 + state->node_id);
    state->subnet_mask[0] = 255;
    state->subnet_mask[1] = 255;
    state->subnet_mask[2] = 255;
    state->subnet_mask[3] = 0;
    state->gateway[0] = 192;
    state->gateway[1] = 168;
    state->gateway[2] = 1;
    state->gateway[3] = 1;
    state->dhcp_enabled = 0;
    state->dhcp_status = 0;
}

static void fba_a_validate_config(fba_a_settings_state_t *state)
{
    state->config_valid = 0;

    if (state->node_id < 1 || state->node_id > 254) return;
    if (state->data_in_words > 32 || state->data_out_words > 32) return;
    if (state->watchdog_time_ms < 10 || state->watchdog_time_ms > 60000) return;
    if (state->profile_selection > FBA_PROFILE_VENDOR_SPECIFIC) return;

    state->config_valid = 1;
}

void fba_a_settings_init(fba_a_settings_state_t *state)
{
    state->initialized = 1;
    memset(state, 0, sizeof(*state));
    state->initialized = 1;

    fba_a_apply_defaults(state);
    fba_a_validate_config(state);
    state->config_dirty = 0;
}

void fba_a_settings_update(fba_a_settings_state_t *state)
{
    if (!state->initialized) return;

    if (state->config_dirty) {
        fba_a_validate_config(state);
        state->config_dirty = 0;
    }

    if (state->dhcp_enabled && !state->dhcp_status) {
        state->dhcp_status = 2;
    }
}

void fba_a_configure(fba_a_settings_state_t *state)
{
    if (!state->initialized) return;

    if (state->sw_select_active) {
        state->node_id = 0x7E;
    }

    if (state->auto_baud_detect) {
        state->baud_rate = FBA_BAUD_115200;
    }

    if (state->dhcp_enabled && state->dhcp_status == 0) {
        state->dhcp_status = 1;
        state->ip_address[0] = 0;
        state->ip_address[1] = 0;
        state->ip_address[2] = 0;
        state->ip_address[3] = 0;
    }

    fba_a_validate_config(state);

    if (state->config_valid) {
        state->config_dirty = 0;
    }
}
