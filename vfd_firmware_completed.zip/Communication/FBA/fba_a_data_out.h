#ifndef COMMUNICATION_FBA_FBA_A_DATA_OUT_H
#define COMMUNICATION_FBA_FBA_A_DATA_OUT_H

#include <stdint.h>

#define FBA_A_DATA_OUT_WORDS 32

typedef struct {
    uint16_t word_index;
    uint16_t param_group;
    uint16_t param_index;
    uint8_t enabled;
} fba_a_out_mapping_entry_t;

typedef struct {
    uint8_t initialized;
    uint16_t tx_words[FBA_A_DATA_OUT_WORDS];
    uint8_t tx_word_count;
    fba_a_out_mapping_entry_t mapping[FBA_A_DATA_OUT_WORDS];
    uint8_t mapping_count;
    uint16_t status_word;
    int32_t actual_speed;
    int32_t actual_torque;
    int32_t actual_current;
    int32_t dc_link_voltage;
    int32_t motor_temp;
    int16_t actual_power;
    int32_t actual_process1;
    int32_t actual_process2;
    uint8_t data_updated;
    uint32_t update_counter;
} fba_a_data_out_state_t;

void fba_a_data_out_init(fba_a_data_out_state_t *state);
void fba_a_data_out_update(fba_a_data_out_state_t *state);
void fba_a_write_data_out(fba_a_data_out_state_t *state);

#endif
