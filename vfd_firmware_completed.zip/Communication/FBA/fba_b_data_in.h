#ifndef COMMUNICATION_FBA_FBA_B_DATA_IN_H
#define COMMUNICATION_FBA_FBA_B_DATA_IN_H

#include <stdint.h>

#define FBA_B_DATA_IN_WORDS 32

typedef struct {
    uint16_t word_index;
    uint16_t param_group;
    uint16_t param_index;
    uint8_t byte_offset;
    uint8_t enabled;
} fba_b_in_mapping_entry_t;

typedef struct {
    uint8_t initialized;
    uint16_t rx_words[FBA_B_DATA_IN_WORDS];
    uint8_t rx_word_count;
    fba_b_in_mapping_entry_t mapping[FBA_B_DATA_IN_WORDS];
    uint8_t mapping_count;
    int16_t ext_control_word;
    int32_t ext_speed_ref;
    int32_t ext_position_ref;
    int32_t ext_custom_ref1;
    int32_t ext_custom_ref2;
    uint8_t data_valid;
    uint8_t new_data;
    uint32_t update_counter;
    uint8_t byte_order_swap;
} fba_b_data_in_state_t;

void fba_b_data_in_init(fba_b_data_in_state_t *state);
void fba_b_data_in_update(fba_b_data_in_state_t *state);
void fba_b_read_data_in(fba_b_data_in_state_t *state);

#endif
