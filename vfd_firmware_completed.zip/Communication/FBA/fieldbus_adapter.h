#ifndef COMMUNICATION_FBA_FIELDBUS_ADAPTER_H
#define COMMUNICATION_FBA_FIELDBUS_ADAPTER_H

#include <stdint.h>

#define FBA_MAX_DATA_WORDS 32
#define FBA_ADAPTER_A 0
#define FBA_ADAPTER_B 1

typedef enum {
    FBA_PROTO_PROFIBUS = 0,
    FBA_PROTO_PROFINET = 1,
    FBA_PROTO_ETHERNETIP = 2,
    FBA_PROTO_ETHERCAT = 3,
    FBA_PROTO_CANOPEN = 4
} fba_protocol_t;

typedef enum {
    FBA_STATE_IDLE = 0,
    FBA_STATE_INIT = 1,
    FBA_STATE_PREOP = 2,
    FBA_STATE_OP = 3,
    FBA_STATE_ERROR = 4
} fba_protocol_state_t;

typedef struct {
    uint8_t initialized;
    uint8_t adapter_active;
    fba_protocol_t protocol_type;
    fba_protocol_state_t protocol_state;
    uint16_t rx_data_words[FBA_MAX_DATA_WORDS];
    uint16_t tx_data_words[FBA_MAX_DATA_WORDS];
    uint8_t rx_word_count;
    uint8_t tx_word_count;
    uint8_t data_exchange_active;
    uint8_t config_locked;
    uint32_t poll_counter;
    uint32_t exchange_counter;
    uint32_t error_counter;
    uint32_t watchdog_counter;
    uint16_t watchdog_timeout_ms;
    uint8_t module_id[4];
    uint8_t firmware_version[2];
    uint8_t mac_address[6];
} fieldbus_adapter_state_t;

void fieldbus_adapter_init(fieldbus_adapter_state_t *state);
void fieldbus_adapter_update(fieldbus_adapter_state_t *state);
void fba_init(fieldbus_adapter_state_t *state);
void fba_poll(fieldbus_adapter_state_t *state);

#endif
