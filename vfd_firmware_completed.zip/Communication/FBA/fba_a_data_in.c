#include "fba_a_data_in.h"
#include <string.h>

#define FBA_A_CW_INDEX  0
#define FBA_A_REF1_INDEX 1
#define FBA_A_REF2_INDEX 2

static void fba_a_extract_abb_profile(fba_a_data_in_state_t *state)
{
    if (state->rx_word_count < 4) return;

    state->control_word = (int16_t)state->rx_words[FBA_A_CW_INDEX];
    state->speed_ref = (int32_t)((int16_t)state->rx_words[FBA_A_REF1_INDEX]);
    state->torque_ref = (int32_t)((int16_t)state->rx_words[FBA_A_REF2_INDEX]);
}

static void fba_a_extract_transparent(fba_a_data_in_state_t *state)
{
    state->control_word = (int16_t)state->rx_words[0];
    state->speed_ref = (int32_t)((int16_t)state->rx_words[2]);
    state->torque_ref = (int32_t)((int16_t)state->rx_words[3]);
}

static void fba_a_apply_mapped_refs(fba_a_data_in_state_t *state)
{
    for (uint8_t i = 0; i < state->mapping_count; i++) {
        if (!state->mapping[i].enabled) continue;
        if (state->mapping[i].word_index >= state->rx_word_count) continue;

        uint16_t raw = state->rx_words[state->mapping[i].word_index];
        uint16_t param = state->mapping[i].param_group * 256 +
                         state->mapping[i].param_index;

        switch (param) {
        case 0x0101:
            state->control_word = (int16_t)raw;
            break;
        case 0x0102:
            state->speed_ref = (int32_t)((int16_t)raw);
            break;
        case 0x0103:
            state->torque_ref = (int32_t)((int16_t)raw);
            break;
        default:
            break;
        }
    }
}

void fba_a_data_in_init(fba_a_data_in_state_t *state)
{
    state->initialized = 1;
    memset(state->rx_words, 0, sizeof(state->rx_words));
    state->rx_word_count = 16;
    memset(state->mapping, 0, sizeof(state->mapping));
    state->mapping_count = 0;
    state->control_word = 0;
    state->speed_ref = 0;
    state->torque_ref = 0;
    state->process_ref1 = 0;
    state->process_ref2 = 0;
    state->profile_type = 0;
    state->data_valid = 0;
    state->new_data = 0;
    state->update_counter = 0;
}

void fba_a_data_in_update(fba_a_data_in_state_t *state)
{
    if (!state->initialized) return;

    state->new_data = 0;

    if (state->data_valid) {
        if (state->profile_type == 0) {
            fba_a_extract_abb_profile(state);
        } else {
            fba_a_extract_transparent(state);
        }
        fba_a_apply_mapped_refs(state);
        state->new_data = 1;
        state->update_counter++;
    }
}

void fba_a_read_data_in(fba_a_data_in_state_t *state)
{
    if (!state->initialized) return;

    if (state->rx_word_count > 0) {
        state->data_valid = 1;
    } else {
        state->data_valid = 0;
    }

    if (state->data_valid) {
        if (state->profile_type == 0) {
            fba_a_extract_abb_profile(state);
        } else {
            fba_a_extract_transparent(state);
        }
        fba_a_apply_mapped_refs(state);
        state->new_data = 1;
        state->update_counter++;
    }
}
