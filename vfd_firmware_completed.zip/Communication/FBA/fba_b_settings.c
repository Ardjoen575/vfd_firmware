#include "fba_b_settings.h"
#include <string.h>

static void fba_b_apply_defaults(fba_b_settings_state_t *state)
{
    state->node_id = 2;
    state->slot_number = 1;
    state->baud_rate = FBA_B_BAUD_AUTO;
    state->profile_selection = FBA_B_PROFILE_TRANSPARENT_16;
    state->poll_timeout_ms = 500;
    state->data_in_words = 8;
    state->data_out_words = 8;
    state->comm_mode = 0;
    state->redundancy_enabled = 0;
    state->device_type = 0x0002;
    state->custom_vendor_id = 0x01AB;
    state->serial_number = 1;
    state->fw_version_major = 1;
    state->fw_version_minor = 0;
}

static void fba_b_validate_config(fba_b_settings_state_t *state)
{
    state->config_valid = 0;

    if (state->node_id < 1 || state->node_id > 126) return;
    if (state->slot_number > 4) return;
    if (state->data_in_words > 32 || state->data_out_words > 32) return;
    if (state->poll_timeout_ms < 20 || state->poll_timeout_ms > 10000) return;
    if (state->profile_selection > FBA_B_PROFILE_CUSTOM) return;

    state->config_valid = 1;
}

void fba_b_settings_init(fba_b_settings_state_t *state)
{
    state->initialized = 1;
    memset(state, 0, sizeof(*state));
    state->initialized = 1;

    fba_b_apply_defaults(state);
    fba_b_validate_config(state);
    state->config_dirty = 0;
}

void fba_b_settings_update(fba_b_settings_state_t *state)
{
    if (!state->initialized) return;

    if (state->config_dirty) {
        fba_b_validate_config(state);
        state->config_dirty = 0;
    }
}

void fba_b_configure(fba_b_settings_state_t *state)
{
    if (!state->initialized) return;

    if (state->baud_rate == FBA_B_BAUD_AUTO) {
        state->baud_rate = FBA_B_BAUD_38400;
    }

    if (state->redundancy_enabled) {
        state->comm_mode |= 0x01;
    } else {
        state->comm_mode &= ~0x01;
    }

    fba_b_validate_config(state);

    if (state->config_valid) {
        state->config_dirty = 0;
    }
}
