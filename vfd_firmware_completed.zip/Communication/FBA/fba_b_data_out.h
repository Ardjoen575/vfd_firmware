#ifndef COMMUNICATION_FBA_FBA_B_DATA_OUT_H
#define COMMUNICATION_FBA_FBA_B_DATA_OUT_H

#include <stdint.h>

#define FBA_B_DATA_OUT_WORDS 32

typedef struct {
    uint16_t word_index;
    uint16_t param_group;
    uint16_t param_index;
    uint8_t byte_offset;
    uint8_t enabled;
} fba_b_out_mapping_entry_t;

typedef struct {
    uint8_t initialized;
    uint16_t tx_words[FBA_B_DATA_OUT_WORDS];
    uint8_t tx_word_count;
    fba_b_out_mapping_entry_t mapping[FBA_B_DATA_OUT_WORDS];
    uint8_t mapping_count;
    uint16_t ext_status_word;
    int32_t ext_actual_speed;
    int32_t ext_actual_position;
    int32_t ext_custom_actual1;
    int32_t ext_custom_actual2;
    int16_t ext_analog_in1;
    int16_t ext_analog_in2;
    uint8_t ext_digital_inputs;
    uint8_t data_updated;
    uint32_t update_counter;
    uint8_t byte_order_swap;
} fba_b_data_out_state_t;

void fba_b_data_out_init(fba_b_data_out_state_t *state);
void fba_b_data_out_update(fba_b_data_out_state_t *state);
void fba_b_write_data_out(fba_b_data_out_state_t *state);

#endif
