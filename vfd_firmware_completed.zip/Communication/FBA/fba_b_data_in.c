#include "fba_b_data_in.h"
#include <string.h>

static uint16_t fba_b_swap_bytes(uint16_t val, uint8_t swap)
{
    if (swap) {
        return (uint16_t)((val >> 8) | (val << 8));
    }
    return val;
}

static void fba_b_extract_refs(fba_b_data_in_state_t *state)
{
    if (state->rx_word_count >= 1) {
        state->ext_control_word = (int16_t)fba_b_swap_bytes(
            state->rx_words[0], state->byte_order_swap);
    }
    if (state->rx_word_count >= 3) {
        state->ext_speed_ref = (int32_t)((int16_t)fba_b_swap_bytes(
            state->rx_words[2], state->byte_order_swap));
    }
    if (state->rx_word_count >= 5) {
        int32_t hi = (int16_t)fba_b_swap_bytes(
            state->rx_words[4], state->byte_order_swap);
        int32_t lo = (int16_t)fba_b_swap_bytes(
            state->rx_words[5], state->byte_order_swap);
        state->ext_position_ref = (hi << 16) | (uint16_t)lo;
    }
}

static void fba_b_apply_mapped_refs(fba_b_data_in_state_t *state)
{
    for (uint8_t i = 0; i < state->mapping_count; i++) {
        if (!state->mapping[i].enabled) continue;
        if (state->mapping[i].word_index >= state->rx_word_count) continue;

        uint16_t raw = fba_b_swap_bytes(
            state->rx_words[state->mapping[i].word_index],
            state->byte_order_swap);

        if (state->mapping[i].byte_offset == 0) {
            switch (state->mapping[i].param_group * 256 +
                    state->mapping[i].param_index) {
            case 0x0201: state->ext_control_word = (int16_t)raw; break;
            case 0x0202: state->ext_speed_ref = (int32_t)((int16_t)raw); break;
            case 0x0203: state->ext_custom_ref1 = (int32_t)((int16_t)raw); break;
            case 0x0204: state->ext_custom_ref2 = (int32_t)((int16_t)raw); break;
            default: break;
            }
        }
    }
}

void fba_b_data_in_init(fba_b_data_in_state_t *state)
{
    state->initialized = 1;
    memset(state->rx_words, 0, sizeof(state->rx_words));
    state->rx_word_count = 8;
    memset(state->mapping, 0, sizeof(state->mapping));
    state->mapping_count = 0;
    state->ext_control_word = 0;
    state->ext_speed_ref = 0;
    state->ext_position_ref = 0;
    state->ext_custom_ref1 = 0;
    state->ext_custom_ref2 = 0;
    state->data_valid = 0;
    state->new_data = 0;
    state->update_counter = 0;
    state->byte_order_swap = 0;
}

void fba_b_data_in_update(fba_b_data_in_state_t *state)
{
    if (!state->initialized) return;

    state->new_data = 0;

    if (state->data_valid) {
        fba_b_extract_refs(state);
        fba_b_apply_mapped_refs(state);
        state->new_data = 1;
        state->update_counter++;
    }
}

void fba_b_read_data_in(fba_b_data_in_state_t *state)
{
    if (!state->initialized) return;

    if (state->rx_word_count > 0) {
        state->data_valid = 1;
    } else {
        state->data_valid = 0;
    }

    if (state->data_valid) {
        fba_b_extract_refs(state);
        fba_b_apply_mapped_refs(state);
        state->new_data = 1;
        state->update_counter++;
    }
}
