#include "fba_a_data_out.h"
#include <string.h>

#define FBA_A_SW_INDEX  0
#define FBA_A_SB_INDEX  1
#define FBA_A_IB_INDEX  2
#define FBA_A_FB_INDEX  3

static void fba_a_pack_abb_profile(fba_a_data_out_state_t *state)
{
    if (state->tx_word_count < 4) return;

    state->tx_words[FBA_A_SW_INDEX] = state->status_word;
    state->tx_words[FBA_A_SB_INDEX] = (uint16_t)(state->actual_speed & 0xFFFF);
    state->tx_words[FBA_A_IB_INDEX] = (uint16_t)(state->actual_torque & 0xFFFF);
    state->tx_words[FBA_A_FB_INDEX] = (uint16_t)(state->actual_current & 0xFFFF);
}

static void fba_a_pack_transparent(fba_a_data_out_state_t *state)
{
    state->tx_words[0] = state->status_word;
    state->tx_words[1] = (uint16_t)(state->actual_speed & 0xFFFF);
    state->tx_words[2] = (uint16_t)(state->actual_torque & 0xFFFF);
    state->tx_words[3] = (uint16_t)(state->actual_current & 0xFFFF);
}

static void fba_a_apply_mapped_actuals(fba_a_data_out_state_t *state)
{
    for (uint8_t i = 0; i < state->mapping_count; i++) {
        if (!state->mapping[i].enabled) continue;
        if (state->mapping[i].word_index >= state->tx_word_count) continue;

        uint16_t param = state->mapping[i].param_group * 256 +
                         state->mapping[i].param_index;
        int32_t value = 0;

        switch (param) {
        case 0x0108: value = state->status_word; break;
        case 0x0105: value = state->actual_speed; break;
        case 0x0106: value = state->actual_torque; break;
        case 0x0104: value = state->actual_current; break;
        case 0x0107: value = state->dc_link_voltage; break;
        case 0x0109: value = state->actual_power; break;
        default: continue;
        }

        state->tx_words[state->mapping[i].word_index] = (uint16_t)(value & 0xFFFF);
    }
}

void fba_a_data_out_init(fba_a_data_out_state_t *state)
{
    state->initialized = 1;
    memset(state->tx_words, 0, sizeof(state->tx_words));
    state->tx_word_count = 16;
    memset(state->mapping, 0, sizeof(state->mapping));
    state->mapping_count = 0;
    state->status_word = 0;
    state->actual_speed = 0;
    state->actual_torque = 0;
    state->actual_current = 0;
    state->dc_link_voltage = 0;
    state->motor_temp = 0;
    state->actual_power = 0;
    state->actual_process1 = 0;
    state->actual_process2 = 0;
    state->data_updated = 0;
    state->update_counter = 0;
}

void fba_a_data_out_update(fba_a_data_out_state_t *state)
{
    if (!state->initialized) return;

    fba_a_pack_abb_profile(state);
    fba_a_apply_mapped_actuals(state);
    state->data_updated = 1;
    state->update_counter++;
}

void fba_a_write_data_out(fba_a_data_out_state_t *state)
{
    if (!state->initialized) return;

    fba_a_pack_abb_profile(state);
    fba_a_apply_mapped_actuals(state);
    state->data_updated = 1;
    state->update_counter++;

    for (uint8_t i = 4; i < state->tx_word_count && i < FBA_A_DATA_OUT_WORDS; i++) {
        if (state->tx_words[i] == 0) {
            switch (i) {
            case 4: state->tx_words[i] = (uint16_t)(state->dc_link_voltage & 0xFFFF); break;
            case 5: state->tx_words[i] = (uint16_t)(state->actual_power & 0xFFFF); break;
            case 6: state->tx_words[i] = (uint16_t)(state->motor_temp & 0xFFFF); break;
            case 7: state->tx_words[i] = (uint16_t)(state->actual_process1 & 0xFFFF); break;
            case 8: state->tx_words[i] = (uint16_t)(state->actual_process2 & 0xFFFF); break;
            default: break;
            }
        }
    }
}
