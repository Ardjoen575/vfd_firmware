#include "modbus_discrete_inputs.h"
#include <string.h>

int16_t discrete_inputs_read(modbus_discrete_inputs_state_t *state,
                             uint16_t start_addr,
                             uint16_t count,
                             uint8_t *out_buffer)
{
    if (start_addr >= state->input_count) return -1;
    if ((start_addr + count) > state->input_count) return -1;
    if (count == 0 || count > 2000) return -1;

    state->input_bits[0] = state->drive_running;
    state->input_bits[1] = state->drive_faulted;
    state->input_bits[2] = state->drive_warning;
    state->input_bits[3] = state->at_setpoint;
    state->input_bits[4] = state->remote_active;

    for (uint8_t i = 0; i < 8; i++) {
        uint8_t bit_val = (state->physical_inputs >> i) & 0x01;
        state->input_bits[16 + i] = bit_val;
    }

    state->input_bits[8] = (state->logical_status >> 0) & 0x01;
    state->input_bits[9] = (state->logical_status >> 1) & 0x01;

    for (uint16_t i = 0; i < count; i++) {
        uint16_t addr = start_addr + i;
        uint8_t byte_idx = addr / 8;
        uint8_t bit_mask = (uint8_t)(1 << (addr % 8));

        if (state->input_filter_ms > 0) {
            if (state->input_bits[byte_idx] & bit_mask) {
                if (state->filter_bits[byte_idx] & bit_mask) {
                    out_buffer[i / 8] |= (uint8_t)(1 << (i % 8));
                }
                state->filter_bits[byte_idx] |= bit_mask;
            } else {
                state->filter_bits[byte_idx] &= ~bit_mask;
            }
        } else {
            if (state->input_bits[byte_idx] & bit_mask) {
                out_buffer[i / 8] |= (uint8_t)(1 << (i % 8));
            }
        }
    }

    state->read_count++;
    state->last_address = start_addr;
    state->last_count = count;
    return (int16_t)((count + 7) / 8);
}

void modbus_discrete_inputs_init(modbus_discrete_inputs_state_t *state)
{
    state->initialized = 1;
    memset(state->input_bits, 0, MODBUS_DI_BYTES);
    state->input_count = MODBUS_DI_COUNT;
    state->read_count = 0;
    state->last_address = 0;
    state->last_count = 0;
    state->input_filter_ms = 0;
    memset(state->filter_bits, 0, MODBUS_DI_BYTES);
    state->physical_inputs = 0;
    state->logical_status = 0;
    state->drive_running = 0;
    state->drive_faulted = 0;
    state->drive_warning = 0;
    state->at_setpoint = 0;
    state->remote_active = 0;
}

void modbus_discrete_inputs_update(modbus_discrete_inputs_state_t *state)
{
    if (!state->initialized) return;

    state->input_bits[0] = state->drive_running;
    state->input_bits[1] = state->drive_faulted;
    state->input_bits[2] = state->drive_warning;
    state->input_bits[3] = state->at_setpoint;
    state->input_bits[4] = state->remote_active;

    for (uint8_t i = 0; i < 8; i++) {
        state->input_bits[16 + i] = (state->physical_inputs >> i) & 0x01;
    }
}

void modbus_discrete_read(modbus_discrete_inputs_state_t *state)
{
    uint8_t buffer[32];
    discrete_inputs_read(state, 0, state->input_count, buffer);
}
