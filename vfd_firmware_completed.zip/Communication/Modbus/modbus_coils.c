#include "modbus_coils.h"
#include <string.h>

int16_t coils_read(modbus_coils_state_t *state, uint16_t start_addr,
                   uint16_t count, uint8_t *out_buffer)
{
    if (start_addr >= state->coil_count) return -1;
    if ((start_addr + count) > state->coil_count) return -1;
    if (count == 0 || count > 2000) return -1;

    uint16_t byte_count = (count + 7) / 8;
    memset(out_buffer, 0, byte_count);

    for (uint16_t i = 0; i < count; i++) {
        uint16_t coil_addr = start_addr + i;
        uint8_t byte_idx = coil_addr / 8;
        uint8_t bit_mask = (uint8_t)(1 << (coil_addr % 8));

        if (state->force_mode_active) {
            if (state->force_values[byte_idx] & bit_mask) {
                out_buffer[i / 8] |= (uint8_t)(1 << (i % 8));
            }
        } else {
            if (state->coil_bits[byte_idx] & bit_mask) {
                out_buffer[i / 8] |= (uint8_t)(1 << (i % 8));
            }
        }
    }

    state->read_count++;
    state->last_address = start_addr;
    state->last_count = count;
    return (int16_t)byte_count;
}

int16_t coils_write(modbus_coils_state_t *state, uint16_t start_addr,
                    uint16_t count, const uint8_t *in_buffer)
{
    if (state->write_protect) return -1;
    if (start_addr >= state->coil_count) return -1;
    if ((start_addr + count) > state->coil_count) return -1;
    if (count == 0 || count > 1968) return -1;

    for (uint16_t i = 0; i < count; i++) {
        uint16_t coil_addr = start_addr + i;
        uint8_t byte_idx = coil_addr / 8;
        uint8_t bit_mask = (uint8_t)(1 << (coil_addr % 8));

        if (in_buffer[i / 8] & (1 << (i % 8))) {
            state->coil_bits[byte_idx] |= bit_mask;
        } else {
            state->coil_bits[byte_idx] &= ~bit_mask;
        }
    }

    state->write_count++;
    state->last_address = start_addr;
    state->last_count = count;
    return (int16_t)count;
}

void modbus_coils_init(modbus_coils_state_t *state)
{
    state->initialized = 1;
    memset(state->coil_bits, 0, MODBUS_COIL_BYTES);
    state->coil_count = MODBUS_COIL_COUNT;
    state->write_protect = 0;
    state->read_count = 0;
    state->write_count = 0;
    state->last_address = 0;
    state->last_count = 0;
    state->force_mode_active = 0;
    memset(state->force_values, 0, MODBUS_COIL_BYTES);
}

void modbus_coils_update(modbus_coils_state_t *state)
{
    if (!state->initialized) return;

    if (state->force_mode_active) {
        memcpy(state->coil_bits, state->force_values, MODBUS_COIL_BYTES);
    }
}

void modbus_coil_read(modbus_coils_state_t *state)
{
    uint8_t buffer[32];
    coils_read(state, 0, state->coil_count, buffer);
}

void modbus_coil_write(modbus_coils_state_t *state)
{
    uint8_t buffer[32];
    memset(buffer, 0xFF, 32);
    coils_write(state, 0, state->coil_count, buffer);
}
