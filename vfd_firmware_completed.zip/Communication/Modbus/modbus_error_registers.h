#ifndef COMMUNICATION_MODBUS_MODBUS_ERROR_REGISTERS_H
#define COMMUNICATION_MODBUS_MODBUS_ERROR_REGISTERS_H

#include <stdint.h>

#define MODBUS_ERROR_REG_BASE  400090
#define MODBUS_ERROR_REG_COUNT 11

typedef struct {
    uint8_t initialized;
    uint16_t error_registers[MODBUS_ERROR_REG_COUNT];
    uint32_t crc_error_count;
    uint32_t exception_count;
    uint32_t bus_message_count;
    uint32_t bus_comm_error_count;
    uint32_t slave_message_count;
    uint32_t slave_no_response_count;
    uint32_t slave_nak_count;
    uint32_t slave_busy_count;
    uint32_t bus_char_overrun_count;
    uint32_t last_update_tick;
    uint8_t registers_dirty;
} modbus_error_registers_state_t;

void modbus_error_registers_init(modbus_error_registers_state_t *state);
void modbus_error_registers_update(modbus_error_registers_state_t *state);
void modbus_error_reg_get(modbus_error_registers_state_t *state);

#endif
