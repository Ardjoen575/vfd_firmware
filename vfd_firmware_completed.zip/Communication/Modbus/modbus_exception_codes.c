#include "modbus_exception_codes.h"
#include <string.h>

int16_t exception_build(modbus_exception_codes_state_t *state,
                        uint8_t function_code,
                        uint8_t exception_code,
                        uint8_t *response_buffer,
                        uint16_t *response_len)
{
    if (exception_code > 0x0B) return -1;

    response_buffer[0] = 0x01;
    response_buffer[1] = function_code | 0x80;
    response_buffer[2] = exception_code;

    uint16_t crc = 0xFFFF;
    for (uint8_t i = 0; i < 3; i++) {
        crc ^= (uint16_t)response_buffer[i];
        for (uint8_t j = 0; j < 8; j++) {
            if (crc & 0x0001) {
                crc = (crc >> 1) ^ 0xA001;
            } else {
                crc >>= 1;
            }
        }
    }
    response_buffer[3] = (uint8_t)(crc & 0xFF);
    response_buffer[4] = (uint8_t)(crc >> 8);
    *response_len = 5;

    state->last_exception_code = exception_code;
    state->last_function_code = function_code;

    if (exception_code < 16) {
        state->exception_counts[exception_code]++;
    }
    state->total_exception_count++;

    state->exception_history[state->history_index] = exception_code;
    state->history_index = (state->history_index + 1) % 10;

    if (exception_code == MODBUS_EXC_SLAVE_DEVICE_BUSY) {
        state->device_busy = 1;
        state->busy_counter = state->busy_retry_ms;
    }

    return 5;
}

void modbus_exception_codes_init(modbus_exception_codes_state_t *state)
{
    state->initialized = 1;
    state->last_exception_code = 0;
    state->last_function_code = 0;
    state->last_error_address[0] = 0;
    state->last_error_address[1] = 0;
    memset(state->exception_counts, 0, sizeof(state->exception_counts));
    state->total_exception_count = 0;
    memset(state->exception_history, 0, sizeof(state->exception_history));
    state->history_index = 0;
    state->device_busy = 0;
    state->busy_retry_ms = 100;
    state->busy_counter = 0;
}

void modbus_exception_codes_update(modbus_exception_codes_state_t *state)
{
    if (!state->initialized) return;

    if (state->device_busy) {
        if (state->busy_counter > 0) {
            state->busy_counter--;
        } else {
            state->device_busy = 0;
        }
    }
}

void modbus_exception_raise(modbus_exception_codes_state_t *state)
{
    if (!state->initialized) return;

    uint8_t buf[8];
    uint16_t len = 0;
    exception_build(state, state->last_function_code,
                    MODBUS_EXC_ILLEGAL_FUNCTION, buf, &len);
}
