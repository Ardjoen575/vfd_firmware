#ifndef COMMUNICATION_MODBUS_MODBUS_COILS_H
#define COMMUNICATION_MODBUS_MODBUS_COILS_H

#include <stdint.h>

#define MODBUS_COIL_COUNT 256
#define MODBUS_COIL_BYTES (MODBUS_COIL_COUNT / 8)

typedef struct {
    uint8_t initialized;
    uint8_t coil_bits[MODBUS_COIL_BYTES];
    uint16_t coil_count;
    uint8_t write_protect;
    uint32_t read_count;
    uint32_t write_count;
    uint16_t last_address;
    uint16_t last_count;
    uint8_t force_mode_active;
    uint8_t force_values[MODBUS_COIL_BYTES];
} modbus_coils_state_t;

void modbus_coils_init(modbus_coils_state_t *state);
void modbus_coils_update(modbus_coils_state_t *state);
void modbus_coil_read(modbus_coils_state_t *state);
void modbus_coil_write(modbus_coils_state_t *state);

#endif
