#include "modbus_error_registers.h"
#include <string.h>

static void error_reg_pack(modbus_error_registers_state_t *state)
{
    state->error_registers[0] = (uint16_t)(state->crc_error_count & 0xFFFF);
    state->error_registers[1] = (uint16_t)(state->crc_error_count >> 16);
    state->error_registers[2] = (uint16_t)(state->exception_count & 0xFFFF);
    state->error_registers[3] = (uint16_t)(state->exception_count >> 16);
    state->error_registers[4] = (uint16_t)(state->bus_message_count & 0xFFFF);
    state->error_registers[5] = (uint16_t)(state->bus_comm_error_count & 0xFFFF);
    state->error_registers[6] = (uint16_t)(state->slave_message_count & 0xFFFF);
    state->error_registers[7] = (uint16_t)(state->slave_no_response_count & 0xFFFF);
    state->error_registers[8] = (uint16_t)(state->slave_nak_count & 0xFFFF);
    state->error_registers[9] = (uint16_t)(state->slave_busy_count & 0xFFFF);
    state->error_registers[10] = (uint16_t)(state->bus_char_overrun_count & 0xFFFF);

    state->registers_dirty = 0;
}

int16_t error_reg_read(modbus_error_registers_state_t *state,
                       uint16_t reg_offset,
                       uint16_t *value)
{
    if (reg_offset >= MODBUS_ERROR_REG_COUNT) return -1;

    if (state->registers_dirty) {
        error_reg_pack(state);
    }

    *value = state->error_registers[reg_offset];
    return 0;
}

int16_t error_reg_update(modbus_error_registers_state_t *state,
                         uint16_t reg_offset,
                         uint16_t value)
{
    if (reg_offset >= MODBUS_ERROR_REG_COUNT) return -1;

    state->error_registers[reg_offset] = value;

    switch (reg_offset) {
    case 0: state->crc_error_count = (state->crc_error_count & 0xFFFF0000) | value; break;
    case 1: state->crc_error_count = (state->crc_error_count & 0xFFFF) |
                                      ((uint32_t)value << 16); break;
    case 2: state->exception_count = (state->exception_count & 0xFFFF0000) | value; break;
    case 3: state->exception_count = (state->exception_count & 0xFFFF) |
                                      ((uint32_t)value << 16); break;
    case 4: state->bus_message_count = value; break;
    case 5: state->bus_comm_error_count = value; break;
    case 6: state->slave_message_count = value; break;
    case 7: state->slave_no_response_count = value; break;
    case 8: state->slave_nak_count = value; break;
    case 9: state->slave_busy_count = value; break;
    case 10: state->bus_char_overrun_count = value; break;
    default: break;
    }

    state->registers_dirty = 0;
    return 0;
}

void modbus_error_registers_init(modbus_error_registers_state_t *state)
{
    state->initialized = 1;
    memset(state->error_registers, 0, sizeof(state->error_registers));
    state->crc_error_count = 0;
    state->exception_count = 0;
    state->bus_message_count = 0;
    state->bus_comm_error_count = 0;
    state->slave_message_count = 0;
    state->slave_no_response_count = 0;
    state->slave_nak_count = 0;
    state->slave_busy_count = 0;
    state->bus_char_overrun_count = 0;
    state->last_update_tick = 0;
    state->registers_dirty = 0;
}

void modbus_error_registers_update(modbus_error_registers_state_t *state)
{
    if (!state->initialized) return;

    state->last_update_tick++;
    if (state->last_update_tick >= 1000) {
        state->last_update_tick = 0;
        state->registers_dirty = 1;
        error_reg_pack(state);
    }
}

void modbus_error_reg_get(modbus_error_registers_state_t *state)
{
    uint16_t value;
    for (uint16_t i = 0; i < MODBUS_ERROR_REG_COUNT; i++) {
        error_reg_read(state, i, &value);
    }
}
