#ifndef COMMUNICATION_MODBUS_MODBUS_FUNCTION_CODES_H
#define COMMUNICATION_MODBUS_MODBUS_FUNCTION_CODES_H

#include <stdint.h>

#define MODBUS_HOLDING_REGS 256

typedef enum {
    MODBUS_FC_RESULT_OK = 0,
    MODBUS_FC_RESULT_EXCEPTION = 1,
    MODBUS_FC_RESULT_BUSY = 2,
    MODBUS_FC_RESULT_TIMEOUT = 3
} modbus_fc_result_t;

typedef struct {
    uint8_t initialized;
    uint16_t holding_registers[MODBUS_HOLDING_REGS];
    uint16_t reg_count;
    uint8_t last_function_code;
    modbus_fc_result_t last_result;
    uint32_t fc_counters[16];
    uint16_t broadcast_count;
    uint8_t write_protect;
    uint8_t multi_write_active;
    uint16_t multi_write_addr;
    uint16_t multi_write_count;
} modbus_function_codes_state_t;

void modbus_function_codes_init(modbus_function_codes_state_t *state);
void modbus_function_codes_update(modbus_function_codes_state_t *state);
void modbus_fc_dispatch(modbus_function_codes_state_t *state);

#endif
