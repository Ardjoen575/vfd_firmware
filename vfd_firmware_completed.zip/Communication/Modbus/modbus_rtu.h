#ifndef COMMUNICATION_MODBUS_MODBUS_RTU_H
#define COMMUNICATION_MODBUS_MODBUS_RTU_H

#include <stdint.h>

#define MODBUS_RX_BUF_SIZE 256
#define MODBUS_TX_BUF_SIZE 256
#define MODBUS_MAX_FRAME_SIZE 256
#define MODBUS_BROADCAST_ADDR 0x00

typedef enum {
    MODBUS_PARITY_NONE = 0,
    MODBUS_PARITY_ODD = 1,
    MODBUS_PARITY_EVEN = 2
} modbus_parity_t;

typedef enum {
    MODBUS_STATE_IDLE = 0,
    MODBUS_STATE_RECEIVING = 1,
    MODBUS_STATE_PROCESSING = 2,
    MODBUS_STATE_TRANSMITTING = 3,
    MODBUS_STATE_ERROR = 4
} modbus_state_t;

typedef struct {
    uint8_t initialized;
    uint8_t slave_address;
    uint32_t baud_rate;
    modbus_parity_t parity;
    uint8_t stop_bits;
    uint8_t data_bits;
    modbus_state_t state;
    uint8_t rx_buffer[MODBUS_RX_BUF_SIZE];
    uint16_t rx_index;
    uint16_t rx_len;
    uint8_t tx_buffer[MODBUS_TX_BUF_SIZE];
    uint16_t tx_len;
    uint16_t tx_index;
    uint32_t t15_us;
    uint32_t t35_us;
    uint32_t timer_t15;
    uint32_t timer_t35;
    uint8_t silence_detected;
    uint32_t last_char_time_us;
    uint32_t rx_message_count;
    uint32_t tx_message_count;
    uint32_t crc_error_count;
    uint32_t overrun_count;
    uint32_t timeout_count;
} modbus_rtu_state_t;

void modbus_rtu_init(modbus_rtu_state_t *state);
void modbus_rtu_update(modbus_rtu_state_t *state);
void modbus_handle_request(modbus_rtu_state_t *state);
void modbus_register_read(modbus_rtu_state_t *state);
void modbus_register_write(modbus_rtu_state_t *state);

#endif
