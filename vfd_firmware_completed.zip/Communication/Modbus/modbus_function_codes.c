#include "modbus_function_codes.h"
#include <string.h>

static uint8_t modbus_reg_addr_valid(uint16_t addr, uint16_t count)
{
    if (addr >= MODBUS_HOLDING_REGS) return 0;
    if ((addr + count) > MODBUS_HOLDING_REGS) return 0;
    return 1;
}

static modbus_fc_result_t modbus_fc_read_holding(
    modbus_function_codes_state_t *state,
    const uint8_t *rx_frame,
    uint16_t rx_len,
    uint8_t *tx_buffer,
    uint16_t *tx_len)
{
    if (rx_len < 8) return MODBUS_FC_RESULT_EXCEPTION;

    uint16_t start_addr = (uint16_t)((rx_frame[2] << 8) | rx_frame[3]);
    uint16_t reg_count = (uint16_t)((rx_frame[4] << 8) | rx_frame[5]);

    if (reg_count < 1 || reg_count > 125) return MODBUS_FC_RESULT_EXCEPTION;
    if (!modbus_reg_addr_valid(start_addr, reg_count)) return MODBUS_FC_RESULT_EXCEPTION;

    uint8_t byte_count = (uint8_t)(reg_count * 2);
    tx_buffer[0] = rx_frame[0];
    tx_buffer[1] = rx_frame[1];
    tx_buffer[2] = byte_count;

    for (uint16_t i = 0; i < reg_count; i++) {
        uint16_t val = state->holding_registers[start_addr + i];
        tx_buffer[3 + i * 2] = (uint8_t)(val >> 8);
        tx_buffer[4 + i * 2] = (uint8_t)(val & 0xFF);
    }

    *tx_len = 3 + byte_count;
    state->last_result = MODBUS_FC_RESULT_OK;
    return MODBUS_FC_RESULT_OK;
}

static modbus_fc_result_t modbus_fc_write_single(
    modbus_function_codes_state_t *state,
    const uint8_t *rx_frame,
    uint16_t rx_len,
    uint8_t *tx_buffer,
    uint16_t *tx_len)
{
    if (rx_len < 8) return MODBUS_FC_RESULT_EXCEPTION;

    uint16_t reg_addr = (uint16_t)((rx_frame[2] << 8) | rx_frame[3]);
    uint16_t reg_value = (uint16_t)((rx_frame[4] << 8) | rx_frame[5]);

    if (!modbus_reg_addr_valid(reg_addr, 1)) return MODBUS_FC_RESULT_EXCEPTION;

    if (!state->write_protect) {
        state->holding_registers[reg_addr] = reg_value;
    }

    memcpy(tx_buffer, rx_frame, 6);
    *tx_len = 6;
    state->last_result = MODBUS_FC_RESULT_OK;
    return MODBUS_FC_RESULT_OK;
}

static modbus_fc_result_t modbus_fc_write_multiple(
    modbus_function_codes_state_t *state,
    const uint8_t *rx_frame,
    uint16_t rx_len,
    uint8_t *tx_buffer,
    uint16_t *tx_len)
{
    if (rx_len < 9) return MODBUS_FC_RESULT_EXCEPTION;

    uint16_t start_addr = (uint16_t)((rx_frame[2] << 8) | rx_frame[3]);
    uint16_t reg_count = (uint16_t)((rx_frame[4] << 8) | rx_frame[5]);
    uint8_t byte_count = rx_frame[6];

    if (reg_count < 1 || reg_count > 123) return MODBUS_FC_RESULT_EXCEPTION;
    if (byte_count != (uint8_t)(reg_count * 2)) return MODBUS_FC_RESULT_EXCEPTION;
    if (!modbus_reg_addr_valid(start_addr, reg_count)) return MODBUS_FC_RESULT_EXCEPTION;

    if (!state->write_protect) {
        for (uint16_t i = 0; i < reg_count; i++) {
            state->holding_registers[start_addr + i] =
                (uint16_t)((rx_frame[7 + i * 2] << 8) |
                           rx_frame[8 + i * 2]);
        }
    }

    memcpy(tx_buffer, rx_frame, 6);
    *tx_len = 6;
    state->multi_write_addr = start_addr;
    state->multi_write_count = reg_count;
    state->multi_write_active = 1;
    state->last_result = MODBUS_FC_RESULT_OK;
    return MODBUS_FC_RESULT_OK;
}

static modbus_fc_result_t modbus_fc_diagnostics(
    modbus_function_codes_state_t *state,
    const uint8_t *rx_frame,
    uint16_t rx_len,
    uint8_t *tx_buffer,
    uint16_t *tx_len)
{
    if (rx_len < 8) return MODBUS_FC_RESULT_EXCEPTION;

    uint16_t sub_func = (uint16_t)((rx_frame[2] << 8) | rx_frame[3]);

    memcpy(tx_buffer, rx_frame, 6);

    switch (sub_func) {
    case 0x0000:
        *tx_len = 6;
        break;
    case 0x0001:
        tx_buffer[4] = 0xFF;
        tx_buffer[5] = 0x00;
        *tx_len = 6;
        break;
    case 0x000A:
        tx_buffer[4] = (uint8_t)(state->fc_counters[1] >> 8);
        tx_buffer[5] = (uint8_t)(state->fc_counters[1] & 0xFF);
        *tx_len = 6;
        break;
    default:
        *tx_len = 6;
        break;
    }

    state->last_result = MODBUS_FC_RESULT_OK;
    return MODBUS_FC_RESULT_OK;
}

static modbus_fc_result_t modbus_fc_device_id(
    modbus_function_codes_state_t *state,
    const uint8_t *rx_frame,
    uint16_t rx_len,
    uint8_t *tx_buffer,
    uint16_t *tx_len)
{
    if (rx_len < 7) return MODBUS_FC_RESULT_EXCEPTION;

    uint8_t mei_type = rx_frame[2];
    uint8_t read_code = rx_frame[3];
    uint8_t object_id = rx_frame[4];
    (void)object_id;

    if (mei_type != 0x0E || read_code > 0x04) return MODBUS_FC_RESULT_EXCEPTION;

    tx_buffer[0] = rx_frame[0];
    tx_buffer[1] = rx_frame[1];
    tx_buffer[2] = 0x0E;
    tx_buffer[3] = read_code;
    tx_buffer[4] = 0x02;
    tx_buffer[5] = 0x01;
    tx_buffer[6] = 0x01;
    tx_buffer[7] = 0xAB;
    tx_buffer[8] = 0x02;
    tx_buffer[9] = 0x01;
    tx_buffer[10] = 0x00;
    *tx_len = 11;

    state->last_result = MODBUS_FC_RESULT_OK;
    return MODBUS_FC_RESULT_OK;
}

void modbus_function_codes_init(modbus_function_codes_state_t *state)
{
    state->initialized = 1;
    memset(state->holding_registers, 0, sizeof(state->holding_registers));
    state->reg_count = MODBUS_HOLDING_REGS;
    state->last_function_code = 0;
    state->last_result = MODBUS_FC_RESULT_OK;
    memset(state->fc_counters, 0, sizeof(state->fc_counters));
    state->broadcast_count = 0;
    state->write_protect = 0;
    state->multi_write_active = 0;
    state->multi_write_addr = 0;
    state->multi_write_count = 0;
}

void modbus_function_codes_update(modbus_function_codes_state_t *state)
{
    if (!state->initialized) return;

    if (state->multi_write_active) {
        state->multi_write_active = 0;
    }
}

void modbus_fc_dispatch(modbus_function_codes_state_t *state)
{
    if (!state->initialized) return;

    uint8_t rx_frame[16] = {0};
    uint8_t tx_buffer[32] = {0};
    uint16_t rx_len = 8;
    uint16_t tx_len = 0;

    rx_frame[0] = 1;
    rx_frame[1] = MODBUS_FC_RESULT_OK == 0 ? 0x03 : 0x06;
    rx_frame[2] = 0x00;
    rx_frame[3] = 0x00;
    rx_frame[4] = 0x00;
    rx_frame[5] = 0x01;
    rx_frame[6] = 0x00;
    rx_frame[7] = 0x01;
    rx_len = 8;

    uint8_t fc = state->last_function_code;
    modbus_fc_result_t result = MODBUS_FC_RESULT_EXCEPTION;

    switch (fc) {
    case 0x03:
        result = modbus_fc_read_holding(state, rx_frame, rx_len,
                                        tx_buffer, &tx_len);
        break;
    case 0x06:
        result = modbus_fc_write_single(state, rx_frame, rx_len,
                                         tx_buffer, &tx_len);
        break;
    case 0x10:
        result = modbus_fc_write_multiple(state, rx_frame, rx_len,
                                           tx_buffer, &tx_len);
        break;
    case 0x08:
        result = modbus_fc_diagnostics(state, rx_frame, rx_len,
                                        tx_buffer, &tx_len);
        break;
    case 0x2B:
        result = modbus_fc_device_id(state, rx_frame, rx_len,
                                      tx_buffer, &tx_len);
        break;
    default:
        result = MODBUS_FC_RESULT_EXCEPTION;
        break;
    }

    state->last_result = result;
    if (fc < 16) {
        state->fc_counters[fc]++;
    }
}
