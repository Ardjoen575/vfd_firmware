#include "modbus_rtu.h"
#include <string.h>

typedef enum {
    MODBUS_FC_READ_COILS       = 0x01,
    MODBUS_FC_READ_DISCRETE    = 0x02,
    MODBUS_FC_READ_HOLDING     = 0x03,
    MODBUS_FC_READ_INPUT       = 0x04,
    MODBUS_FC_WRITE_SINGLE     = 0x06,
    MODBUS_FC_DIAGNOSTICS      = 0x08,
    MODBUS_FC_WRITE_MULTIPLE   = 0x10,
    MODBUS_FC_READ_DEVICE_ID   = 0x2B
} modbus_fc_t;

typedef enum {
    MODBUS_EXC_ILLEGAL_FUNC    = 0x01,
    MODBUS_EXC_ILLEGAL_ADDR    = 0x02,
    MODBUS_EXC_ILLEGAL_VALUE   = 0x03,
    MODBUS_EXC_DEVICE_BUSY     = 0x06
} modbus_exception_t;

static uint16_t modbus_crc16_calc(const uint8_t *data, uint16_t len)
{
    uint16_t crc = 0xFFFF;
    for (uint16_t i = 0; i < len; i++) {
        crc ^= (uint16_t)data[i];
        for (uint8_t j = 0; j < 8; j++) {
            if (crc & 0x0001) {
                crc = (crc >> 1) ^ 0xA001;
            } else {
                crc >>= 1;
            }
        }
    }
    return crc;
}

static uint8_t modbus_validate_crc(modbus_rtu_state_t *state)
{
    if (state->rx_len < 4) return 0;

    uint16_t rx_crc = (uint16_t)(state->rx_buffer[state->rx_len - 2] |
                                 (state->rx_buffer[state->rx_len - 1] << 8));
    uint16_t calc_crc = modbus_crc16_calc(state->rx_buffer, state->rx_len - 2);

    return (rx_crc == calc_crc);
}

static void modbus_build_exception_response(modbus_rtu_state_t *state,
                                            uint8_t function_code,
                                            uint8_t exception_code)
{
    state->tx_buffer[0] = state->slave_address;
    state->tx_buffer[1] = function_code | 0x80;
    state->tx_buffer[2] = exception_code;
    uint16_t crc = modbus_crc16_calc(state->tx_buffer, 3);
    state->tx_buffer[3] = (uint8_t)(crc & 0xFF);
    state->tx_buffer[4] = (uint8_t)(crc >> 8);
    state->tx_len = 5;
}

static void modbus_validate_address_range(modbus_rtu_state_t *state,
                                          uint16_t start_addr,
                                          uint16_t count,
                                          uint8_t fc,
                                          uint8_t *valid)
{
    *valid = 1;

    switch (fc) {
    case MODBUS_FC_READ_COILS:
    case MODBUS_FC_WRITE_SINGLE:
        if (start_addr > 9999 || (start_addr + count) > 9999) *valid = 0;
        break;
    case MODBUS_FC_READ_DISCRETE:
        if (start_addr > 9999 || (start_addr + count) > 9999) *valid = 0;
        break;
    case MODBUS_FC_READ_HOLDING:
        if (start_addr > 9999 || (start_addr + count) > 9999) *valid = 0;
        break;
    case MODBUS_FC_READ_INPUT:
        if (start_addr > 9999 || (start_addr + count) > 9999) *valid = 0;
        break;
    case MODBUS_FC_WRITE_MULTIPLE:
        if (start_addr > 9999 || (start_addr + count) > 9999) *valid = 0;
        break;
    default:
        *valid = 0;
        break;
    }
}

static void modbus_handle_read_holding(modbus_rtu_state_t *state)
{
    uint16_t start_addr = (uint16_t)((state->rx_buffer[2] << 8) |
                                      state->rx_buffer[3]);
    uint16_t reg_count = (uint16_t)((state->rx_buffer[4] << 8) |
                                     state->rx_buffer[5]);
    uint8_t valid;

    modbus_validate_address_range(state, start_addr, reg_count,
                                  MODBUS_FC_READ_HOLDING, &valid);
    if (!valid || reg_count < 1 || reg_count > 125) {
        modbus_build_exception_response(state, MODBUS_FC_READ_HOLDING,
                                        MODBUS_EXC_ILLEGAL_ADDR);
        return;
    }

    uint8_t byte_count = (uint8_t)(reg_count * 2);
    state->tx_buffer[0] = state->slave_address;
    state->tx_buffer[1] = MODBUS_FC_READ_HOLDING;
    state->tx_buffer[2] = byte_count;

    for (uint16_t i = 0; i < reg_count; i++) {
        uint16_t reg_val = (uint16_t)((start_addr + i) * 10);
        state->tx_buffer[3 + i * 2] = (uint8_t)(reg_val >> 8);
        state->tx_buffer[4 + i * 2] = (uint8_t)(reg_val & 0xFF);
    }

    uint16_t crc = modbus_crc16_calc(state->tx_buffer, 3 + byte_count);
    state->tx_buffer[3 + byte_count] = (uint8_t)(crc & 0xFF);
    state->tx_buffer[4 + byte_count] = (uint8_t)(crc >> 8);
    state->tx_len = 3 + byte_count + 2;
}

static void modbus_handle_write_single(modbus_rtu_state_t *state)
{
    uint16_t reg_addr = (uint16_t)((state->rx_buffer[2] << 8) |
                                    state->rx_buffer[3]);
    uint16_t reg_value = (uint16_t)((state->rx_buffer[4] << 8) |
                                     state->rx_buffer[5]);
    uint8_t valid;

    (void)reg_value;

    modbus_validate_address_range(state, reg_addr, 1,
                                  MODBUS_FC_WRITE_SINGLE, &valid);
    if (!valid) {
        modbus_build_exception_response(state, MODBUS_FC_WRITE_SINGLE,
                                        MODBUS_EXC_ILLEGAL_ADDR);
        return;
    }

    memcpy(state->tx_buffer, state->rx_buffer, 6);
    state->tx_len = 6;
    state->tx_buffer[6] = 0;
    state->tx_buffer[7] = 0;
    uint16_t crc = modbus_crc16_calc(state->tx_buffer, 6);
    state->tx_buffer[6] = (uint8_t)(crc & 0xFF);
    state->tx_buffer[7] = (uint8_t)(crc >> 8);
    state->tx_len = 8;
}

static void modbus_handle_write_multiple(modbus_rtu_state_t *state)
{
    uint16_t start_addr = (uint16_t)((state->rx_buffer[2] << 8) |
                                      state->rx_buffer[3]);
    uint16_t reg_count = (uint16_t)((state->rx_buffer[4] << 8) |
                                     state->rx_buffer[5]);
    uint8_t byte_count = state->rx_buffer[6];
    uint8_t valid;

    modbus_validate_address_range(state, start_addr, reg_count,
                                  MODBUS_FC_WRITE_MULTIPLE, &valid);
    if (!valid || reg_count < 1 || reg_count > 123 ||
        byte_count != (uint8_t)(reg_count * 2)) {
        modbus_build_exception_response(state, MODBUS_FC_WRITE_MULTIPLE,
                                        MODBUS_EXC_ILLEGAL_VALUE);
        return;
    }

    memcpy(state->tx_buffer, state->rx_buffer, 6);
    state->tx_len = 6;
    state->tx_buffer[6] = 0;
    state->tx_buffer[7] = 0;
    uint16_t crc = modbus_crc16_calc(state->tx_buffer, 6);
    state->tx_buffer[6] = (uint8_t)(crc & 0xFF);
    state->tx_buffer[7] = (uint8_t)(crc >> 8);
    state->tx_len = 8;
}

static void modbus_handle_diagnostics(modbus_rtu_state_t *state)
{
    uint16_t sub_func = (uint16_t)((state->rx_buffer[2] << 8) |
                                    state->rx_buffer[3]);

    switch (sub_func) {
    case 0x0000:
        memcpy(state->tx_buffer, state->rx_buffer, 6);
        state->tx_buffer[6] = 0;
        state->tx_buffer[7] = 0;
        break;
    case 0x000A:
        state->tx_buffer[0] = state->slave_address;
        state->tx_buffer[1] = MODBUS_FC_DIAGNOSTICS;
        state->tx_buffer[2] = (uint8_t)(sub_func >> 8);
        state->tx_buffer[3] = (uint8_t)(sub_func & 0xFF);
        state->tx_buffer[4] = (uint8_t)(state->rx_message_count >> 8);
        state->tx_buffer[5] = (uint8_t)(state->rx_message_count & 0xFF);
        state->tx_len = 6;
        break;
    default:
        state->tx_buffer[0] = state->slave_address;
        state->tx_buffer[1] = MODBUS_FC_DIAGNOSTICS;
        state->tx_buffer[2] = (uint8_t)(sub_func >> 8);
        state->tx_buffer[3] = (uint8_t)(sub_func & 0xFF);
        state->tx_buffer[4] = 0;
        state->tx_buffer[5] = 0;
        state->tx_len = 6;
        break;
    }

    uint16_t crc = modbus_crc16_calc(state->tx_buffer, state->tx_len);
    state->tx_buffer[state->tx_len] = (uint8_t)(crc & 0xFF);
    state->tx_buffer[state->tx_len + 1] = (uint8_t)(crc >> 8);
    state->tx_len += 2;
}

static void modbus_handle_device_id(modbus_rtu_state_t *state)
{
    uint8_t mei_type = state->rx_buffer[2];
    uint8_t read_dev_id = state->rx_buffer[3];
    uint8_t object_id = state->rx_buffer[4];
    (void)object_id;

    if (mei_type != 0x0E || read_dev_id > 0x04) {
        modbus_build_exception_response(state, MODBUS_FC_READ_DEVICE_ID,
                                        MODBUS_EXC_ILLEGAL_VALUE);
        return;
    }

    state->tx_buffer[0] = state->slave_address;
    state->tx_buffer[1] = MODBUS_FC_READ_DEVICE_ID;
    state->tx_buffer[2] = 0x0E;
    state->tx_buffer[3] = read_dev_id;
    state->tx_buffer[4] = 0x01;
    state->tx_buffer[5] = 0x01;
    state->tx_buffer[6] = 0x01;
    state->tx_buffer[7] = 0xAB;
    state->tx_buffer[8] = 0x02;
    state->tx_buffer[9] = 0x01;
    state->tx_buffer[10] = 0x00;
    state->tx_len = 11;

    uint16_t crc = modbus_crc16_calc(state->tx_buffer, state->tx_len);
    state->tx_buffer[state->tx_len] = (uint8_t)(crc & 0xFF);
    state->tx_buffer[state->tx_len + 1] = (uint8_t)(crc >> 8);
    state->tx_len += 2;
}

void modbus_rtu_init(modbus_rtu_state_t *state)
{
    state->initialized = 1;
    state->slave_address = 1;
    state->baud_rate = 115200;
    state->parity = MODBUS_PARITY_EVEN;
    state->stop_bits = 1;
    state->data_bits = 8;
    state->state = MODBUS_STATE_IDLE;
    memset(state->rx_buffer, 0, MODBUS_RX_BUF_SIZE);
    state->rx_index = 0;
    state->rx_len = 0;
    memset(state->tx_buffer, 0, MODBUS_TX_BUF_SIZE);
    state->tx_len = 0;
    state->tx_index = 0;
    state->t15_us = 1500;
    state->t35_us = 3500;
    state->timer_t15 = 0;
    state->timer_t35 = 0;
    state->silence_detected = 0;
    state->last_char_time_us = 0;
    state->rx_message_count = 0;
    state->tx_message_count = 0;
    state->crc_error_count = 0;
    state->overrun_count = 0;
    state->timeout_count = 0;
}

void modbus_rtu_update(modbus_rtu_state_t *state)
{
    if (!state->initialized) return;

    switch (state->state) {
    case MODBUS_STATE_IDLE:
        state->timer_t35++;
        if (state->timer_t35 >= state->t35_us && state->silence_detected) {
            if (state->rx_index > 0) {
                state->rx_len = state->rx_index;
                state->state = MODBUS_STATE_PROCESSING;
            }
            state->silence_detected = 0;
            state->timer_t35 = 0;
        }
        break;

    case MODBUS_STATE_PROCESSING:
        modbus_handle_request(state);
        state->state = MODBUS_STATE_TRANSMITTING;
        state->tx_index = 0;
        break;

    case MODBUS_STATE_TRANSMITTING:
        state->tx_index++;
        if (state->tx_index >= state->tx_len) {
            state->state = MODBUS_STATE_IDLE;
            state->rx_index = 0;
            state->rx_len = 0;
            state->tx_len = 0;
            state->tx_index = 0;
            state->tx_message_count++;
        }
        break;

    case MODBUS_STATE_RECEIVING:
        state->last_char_time_us++;
        if (state->last_char_time_us > state->t35_us) {
            state->silence_detected = 1;
            state->last_char_time_us = 0;
        }
        break;

    case MODBUS_STATE_ERROR:
        state->state = MODBUS_STATE_IDLE;
        state->rx_index = 0;
        state->rx_len = 0;
        break;
    }
}

void modbus_handle_request(modbus_rtu_state_t *state)
{
    if (state->rx_len < 4) {
        state->crc_error_count++;
        return;
    }

    uint8_t addr = state->rx_buffer[0];
    if (addr != state->slave_address && addr != MODBUS_BROADCAST_ADDR) {
        state->rx_len = 0;
        return;
    }

    if (!modbus_validate_crc(state)) {
        state->crc_error_count++;
        state->rx_len = 0;
        return;
    }

    state->rx_message_count++;

    uint8_t fc = state->rx_buffer[1];

    switch (fc) {
    case MODBUS_FC_READ_HOLDING:
        modbus_handle_read_holding(state);
        break;
    case MODBUS_FC_WRITE_SINGLE:
        modbus_handle_write_single(state);
        break;
    case MODBUS_FC_WRITE_MULTIPLE:
        modbus_handle_write_multiple(state);
        break;
    case MODBUS_FC_DIAGNOSTICS:
        modbus_handle_diagnostics(state);
        break;
    case MODBUS_FC_READ_DEVICE_ID:
        modbus_handle_device_id(state);
        break;
    case MODBUS_FC_READ_COILS:
    case MODBUS_FC_READ_DISCRETE:
    case MODBUS_FC_READ_INPUT:
        modbus_build_exception_response(state, fc, MODBUS_EXC_ILLEGAL_FUNC);
        break;
    default:
        modbus_build_exception_response(state, fc, MODBUS_EXC_ILLEGAL_FUNC);
        break;
    }
}

void modbus_register_read(modbus_rtu_state_t *state)
{
    if (state->rx_len >= 8 && state->rx_buffer[1] == MODBUS_FC_READ_HOLDING) {
        modbus_handle_request(state);
    }
}

void modbus_register_write(modbus_rtu_state_t *state)
{
    uint8_t fc = state->rx_buffer[1];
    if (fc == MODBUS_FC_WRITE_SINGLE || fc == MODBUS_FC_WRITE_MULTIPLE) {
        modbus_handle_request(state);
    }
}
