#ifndef COMMUNICATION_MODBUS_MODBUS_DISCRETE_INPUTS_H
#define COMMUNICATION_MODBUS_MODBUS_DISCRETE_INPUTS_H

#include <stdint.h>

#define MODBUS_DI_COUNT 256
#define MODBUS_DI_BYTES (MODBUS_DI_COUNT / 8)

typedef struct {
    uint8_t initialized;
    uint8_t input_bits[MODBUS_DI_BYTES];
    uint16_t input_count;
    uint32_t read_count;
    uint16_t last_address;
    uint16_t last_count;
    uint8_t input_filter_ms;
    uint8_t filter_bits[MODBUS_DI_BYTES];
    uint8_t physical_inputs;
    uint8_t logical_status;
    uint8_t drive_running;
    uint8_t drive_faulted;
    uint8_t drive_warning;
    uint8_t at_setpoint;
    uint8_t remote_active;
} modbus_discrete_inputs_state_t;

void modbus_discrete_inputs_init(modbus_discrete_inputs_state_t *state);
void modbus_discrete_inputs_update(modbus_discrete_inputs_state_t *state);
void modbus_discrete_read(modbus_discrete_inputs_state_t *state);

#endif
