#ifndef COMMUNICATION_MODBUS_MODBUS_EXCEPTION_CODES_H
#define COMMUNICATION_MODBUS_MODBUS_EXCEPTION_CODES_H

#include <stdint.h>

#define MODBUS_EXC_ILLEGAL_FUNCTION   0x01
#define MODBUS_EXC_ILLEGAL_DATA_ADDR  0x02
#define MODBUS_EXC_ILLEGAL_DATA_VALUE 0x03
#define MODBUS_EXC_SLAVE_DEVICE_FAIL  0x04
#define MODBUS_EXC_ACKNOWLEDGE        0x05
#define MODBUS_EXC_SLAVE_DEVICE_BUSY  0x06
#define MODBUS_EXC_MEMORY_PARITY_ERR  0x08
#define MODBUS_EXC_GATEWAY_PATH_UNAVAIL 0x0A
#define MODBUS_EXC_GATEWAY_TARGET_FAIL  0x0B

typedef struct {
    uint8_t initialized;
    uint8_t last_exception_code;
    uint8_t last_function_code;
    uint8_t last_error_address[2];
    uint32_t exception_counts[16];
    uint32_t total_exception_count;
    uint8_t exception_history[10];
    uint8_t history_index;
    uint8_t device_busy;
    uint16_t busy_retry_ms;
    uint16_t busy_counter;
} modbus_exception_codes_state_t;

void modbus_exception_codes_init(modbus_exception_codes_state_t *state);
void modbus_exception_codes_update(modbus_exception_codes_state_t *state);
void modbus_exception_raise(modbus_exception_codes_state_t *state);

#endif
