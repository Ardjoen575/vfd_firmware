#include "abb_drives_profile.h"
#include <string.h>

static void abb_build_status_word(abb_drives_profile_state_t *state)
{
    state->status_word = 0;

    switch (state->state) {
    case ABB_STATE_NOT_READY_TO_SWITCH_ON:
        state->status_word = ABB_SW_SWITCH_ON_DISABLED;
        break;
    case ABB_STATE_SWITCH_ON_DISABLED:
        state->status_word = ABB_SW_SWITCH_ON_DISABLED | ABB_SW_VOLTAGE_ENABLED |
                             ABB_SW_REMOTE;
        break;
    case ABB_STATE_READY_TO_SWITCH_ON:
        state->status_word = ABB_SW_READY_TO_SWITCH_ON | ABB_SW_VOLTAGE_ENABLED |
                             ABB_SW_REMOTE;
        break;
    case ABB_STATE_SWITCHED_ON:
        state->status_word = ABB_SW_READY_TO_SWITCH_ON | ABB_SW_SWITCHED_ON |
                             ABB_SW_VOLTAGE_ENABLED | ABB_SW_REMOTE;
        break;
    case ABB_STATE_OPERATION_ENABLED:
        state->status_word = ABB_SW_READY_TO_SWITCH_ON | ABB_SW_SWITCHED_ON |
                             ABB_SW_OPERATION_ENABLED | ABB_SW_VOLTAGE_ENABLED |
                             ABB_SW_REMOTE | ABB_SW_AT_SETPOINT;
        break;
    case ABB_STATE_QUICK_STOP_ACTIVE:
        state->status_word = ABB_SW_READY_TO_SWITCH_ON | ABB_SW_SWITCHED_ON |
                             ABB_SW_QUICK_STOP | ABB_SW_VOLTAGE_ENABLED |
                             ABB_SW_REMOTE;
        break;
    case ABB_STATE_FAULT_REACTION_ACTIVE:
        state->status_word = ABB_SW_FAULT | ABB_SW_SWITCH_ON_DISABLED;
        break;
    case ABB_STATE_FAULT:
        state->status_word = ABB_SW_FAULT;
        break;
    }

    if (state->warning_code != 0) {
        state->status_word |= ABB_SW_WARNING;
    }
}

static void abb_process_control_word(abb_drives_profile_state_t *state)
{
    uint16_t cw = state->control_word;

    if (cw & ABB_CW_FAULT_RESET) {
        if (state->state == ABB_STATE_FAULT) {
            state->state = ABB_STATE_SWITCH_ON_DISABLED;
            state->fault_code = 0;
            state->fault_history[state->fault_history_index] = 1;
            state->fault_history_index = (state->fault_history_index + 1) % 8;
            state->state_change_counter++;
            return;
        }
    }

    switch (state->state) {
    case ABB_STATE_NOT_READY_TO_SWITCH_ON:
        state->state = ABB_STATE_SWITCH_ON_DISABLED;
        state->state_change_counter++;
        break;

    case ABB_STATE_SWITCH_ON_DISABLED:
        if (cw & ABB_CW_SHUTDOWN) {
            state->state = ABB_STATE_READY_TO_SWITCH_ON;
            state->state_change_counter++;
        }
        break;

    case ABB_STATE_READY_TO_SWITCH_ON:
        if (cw & ABB_CW_DISABLE_VOLTAGE) {
            state->state = ABB_STATE_SWITCH_ON_DISABLED;
            state->state_change_counter++;
        } else if (cw & (ABB_CW_SWITCH_ON | ABB_CW_ENABLE_OPERATION)) {
            state->state = ABB_STATE_SWITCHED_ON;
            state->state_change_counter++;
        }
        break;

    case ABB_STATE_SWITCHED_ON:
        if (cw & ABB_CW_DISABLE_VOLTAGE) {
            state->state = ABB_STATE_SWITCH_ON_DISABLED;
            state->state_change_counter++;
        } else if (cw & ABB_CW_SHUTDOWN) {
            state->state = ABB_STATE_READY_TO_SWITCH_ON;
            state->state_change_counter++;
        } else if (cw & ABB_CW_ENABLE_OPERATION) {
            state->state = ABB_STATE_OPERATION_ENABLED;
            state->state_change_counter++;
        } else if (cw & ABB_CW_QUICK_STOP) {
            state->state = ABB_STATE_QUICK_STOP_ACTIVE;
            state->state_change_counter++;
        }
        break;

    case ABB_STATE_OPERATION_ENABLED:
        if (cw & ABB_CW_DISABLE_VOLTAGE) {
            state->state = ABB_STATE_SWITCH_ON_DISABLED;
            state->state_change_counter++;
        } else if (cw & ABB_CW_DISABLE_OPERATION) {
            state->state = ABB_STATE_SWITCHED_ON;
            state->state_change_counter++;
        } else if (cw & ABB_CW_QUICK_STOP) {
            state->state = ABB_STATE_QUICK_STOP_ACTIVE;
            state->state_change_counter++;
        } else if (cw & ABB_CW_SHUTDOWN) {
            state->state = ABB_STATE_READY_TO_SWITCH_ON;
            state->state_change_counter++;
        } else if (cw & ABB_CW_RAMP_STOP) {
            state->speed_reference = 0;
        }
        break;

    case ABB_STATE_QUICK_STOP_ACTIVE:
        if (cw & ABB_CW_DISABLE_VOLTAGE) {
            state->state = ABB_STATE_SWITCH_ON_DISABLED;
            state->state_change_counter++;
        }
        break;

    case ABB_STATE_FAULT_REACTION_ACTIVE:
        state->state = ABB_STATE_FAULT;
        state->state_change_counter++;
        break;

    case ABB_STATE_FAULT:
        if (cw & ABB_CW_FAULT_RESET) {
            state->state = ABB_STATE_SWITCH_ON_DISABLED;
            state->fault_code = 0;
            state->state_change_counter++;
        }
        break;
    }
}

void abb_drives_profile_init(abb_drives_profile_state_t *state)
{
    state->initialized = 1;
    state->state = ABB_STATE_NOT_READY_TO_SWITCH_ON;
    state->prev_state = ABB_STATE_NOT_READY_TO_SWITCH_ON;
    state->control_word = 0x0000;
    state->status_word = 0x0000;
    state->speed_reference = 0;
    state->torque_reference = 0;
    state->actual_speed = 0;
    state->actual_torque = 0;
    state->actual_current = 0;
    state->fault_code = 0;
    state->warning_code = 0;
    memset(state->fault_history, 0, sizeof(state->fault_history));
    state->fault_history_index = 0;
    state->state_change_counter = 0;
    state->state_stable_counter = 0;
    state->run_time_ms = 0;
    state->speed_scale = 20000;
    state->torque_scale = 10000;
    state->current_scale = 10000;
}

void abb_drives_profile_update(abb_drives_profile_state_t *state)
{
    if (!state->initialized) return;

    state->run_time_ms++;

    abb_process_control_word(state);
    abb_build_status_word(state);
}

void profile_abb_state_transition(abb_drives_profile_state_t *state)
{
    if (!state->initialized) return;

    state->prev_state = state->state;
    abb_process_control_word(state);

    if (state->state != state->prev_state) {
        state->state_change_counter++;
        state->state_stable_counter = 0;
    } else {
        if (state->state_stable_counter < 255) {
            state->state_stable_counter++;
        }
    }

    abb_build_status_word(state);
}
