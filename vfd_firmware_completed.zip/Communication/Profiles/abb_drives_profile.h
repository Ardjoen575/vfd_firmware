#ifndef COMMUNICATION_PROFILES_ABB_DRIVES_PROFILE_H
#define COMMUNICATION_PROFILES_ABB_DRIVES_PROFILE_H

#include <stdint.h>

typedef enum {
    ABB_STATE_NOT_READY_TO_SWITCH_ON = 0,
    ABB_STATE_SWITCH_ON_DISABLED = 1,
    ABB_STATE_READY_TO_SWITCH_ON = 2,
    ABB_STATE_SWITCHED_ON = 3,
    ABB_STATE_OPERATION_ENABLED = 4,
    ABB_STATE_QUICK_STOP_ACTIVE = 5,
    ABB_STATE_FAULT_REACTION_ACTIVE = 6,
    ABB_STATE_FAULT = 7
} abb_drive_state_t;

#define ABB_CW_SHUTDOWN        0x0001
#define ABB_CW_SWITCH_ON       0x0002
#define ABB_CW_ENABLE_OPERATION 0x0004
#define ABB_CW_DISABLE_VOLTAGE 0x0008
#define ABB_CW_QUICK_STOP      0x0010
#define ABB_CW_DISABLE_OPERATION 0x0020
#define ABB_CW_FAULT_RESET     0x0040
#define ABB_CW_RAMP_STOP       0x0100
#define ABB_CW_RAMP_HOLD       0x0200
#define ABB_CW_REMOTE_CMD      0x0800

#define ABB_SW_READY_TO_SWITCH_ON 0x0001
#define ABB_SW_SWITCHED_ON      0x0002
#define ABB_SW_OPERATION_ENABLED 0x0004
#define ABB_SW_FAULT            0x0008
#define ABB_SW_VOLTAGE_ENABLED  0x0010
#define ABB_SW_QUICK_STOP       0x0020
#define ABB_SW_SWITCH_ON_DISABLED 0x0040
#define ABB_SW_WARNING          0x0080
#define ABB_SW_REMOTE           0x0200
#define ABB_SW_AT_SETPOINT      0x0400
#define ABB_SW_INTERNAL_LIMIT_ACTIVE 0x0800

typedef struct {
    uint8_t initialized;
    abb_drive_state_t state;
    abb_drive_state_t prev_state;
    uint16_t control_word;
    uint16_t status_word;
    int32_t speed_reference;
    int32_t torque_reference;
    int32_t actual_speed;
    int32_t actual_torque;
    int32_t actual_current;
    uint16_t fault_code;
    uint16_t warning_code;
    uint32_t fault_history[8];
    uint8_t fault_history_index;
    uint8_t state_change_counter;
    uint8_t state_stable_counter;
    uint32_t run_time_ms;
    uint16_t speed_scale;
    uint16_t torque_scale;
    uint16_t current_scale;
} abb_drives_profile_state_t;

void abb_drives_profile_init(abb_drives_profile_state_t *state);
void abb_drives_profile_update(abb_drives_profile_state_t *state);
void profile_abb_state_transition(abb_drives_profile_state_t *state);

#endif
