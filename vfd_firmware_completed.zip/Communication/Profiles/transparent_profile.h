#ifndef COMMUNICATION_PROFILES_TRANSPARENT_PROFILE_H
#define COMMUNICATION_PROFILES_TRANSPARENT_PROFILE_H

#include <stdint.h>

#define TRANSPARENT_MAX_WORDS 32
#define TRANSPARENT_NUM_MAPPINGS 32

typedef struct {
    uint16_t fieldbus_word_idx;
    uint16_t parameter_group;
    uint16_t parameter_index;
    uint8_t direction;
    uint8_t enabled;
} transparent_map_entry_t;

typedef struct {
    uint8_t initialized;
    uint16_t fieldbus_words_in[TRANSPARENT_MAX_WORDS];
    uint16_t fieldbus_words_out[TRANSPARENT_MAX_WORDS];
    uint8_t words_in_count;
    uint8_t words_out_count;
    transparent_map_entry_t mapping[TRANSPARENT_NUM_MAPPINGS];
    uint8_t mapping_count;
    uint8_t data_in_dirty;
    uint8_t data_out_dirty;
    uint32_t update_counter;
    uint8_t byte_swap_enabled;
    uint8_t word_swap_enabled;
    uint8_t profile_active;
} transparent_profile_state_t;

void transparent_profile_init(transparent_profile_state_t *state);
void transparent_profile_update(transparent_profile_state_t *state);
void profile_transparent_map(transparent_profile_state_t *state);

#endif
