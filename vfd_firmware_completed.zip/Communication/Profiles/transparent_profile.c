#include "transparent_profile.h"
#include <string.h>

static uint16_t transparent_apply_swap(uint16_t word, uint8_t byte_swap,
                                        uint8_t word_swap)
{
    uint16_t result = word;
    if (byte_swap) {
        result = (uint16_t)((word >> 8) | (word << 8));
    }
    if (word_swap) {
        uint16_t hi = (result & 0xFF00) >> 8;
        uint16_t lo = (result & 0x00FF);
        result = (uint16_t)((lo << 8) | hi);
    }
    return result;
}

static int16_t transparent_param_read(uint16_t group, uint16_t index)
{
    return (int16_t)((group << 8) | (index & 0xFF));
}

static void transparent_param_write(uint16_t group, uint16_t index,
                                    int16_t value)
{
    (void)group;
    (void)index;
    (void)value;
}

void transparent_map_words(transparent_profile_state_t *state)
{
    if (!state->profile_active) return;

    for (uint8_t i = 0; i < state->mapping_count; i++) {
        transparent_map_entry_t *entry = &state->mapping[i];
        if (!entry->enabled) continue;

        if (entry->direction == 0) {
            if (entry->fieldbus_word_idx >= state->words_in_count) continue;

            uint16_t raw = state->fieldbus_words_in[entry->fieldbus_word_idx];
            raw = transparent_apply_swap(raw, state->byte_swap_enabled,
                                          state->word_swap_enabled);
            int16_t value = (int16_t)raw;

            transparent_param_write(entry->parameter_group,
                                    entry->parameter_index, value);
            state->data_in_dirty = 1;
        } else {
            if (entry->fieldbus_word_idx >= state->words_out_count) continue;

            int16_t value = transparent_param_read(entry->parameter_group,
                                                    entry->parameter_index);
            uint16_t raw = (uint16_t)value;
            raw = transparent_apply_swap(raw, state->byte_swap_enabled,
                                          state->word_swap_enabled);

            state->fieldbus_words_out[entry->fieldbus_word_idx] = raw;
            state->data_out_dirty = 1;
        }
    }

    state->update_counter++;
}

void transparent_profile_init(transparent_profile_state_t *state)
{
    state->initialized = 1;
    memset(state->fieldbus_words_in, 0, sizeof(state->fieldbus_words_in));
    memset(state->fieldbus_words_out, 0, sizeof(state->fieldbus_words_out));
    state->words_in_count = 16;
    state->words_out_count = 16;
    memset(state->mapping, 0, sizeof(state->mapping));
    state->mapping_count = 0;
    state->data_in_dirty = 0;
    state->data_out_dirty = 0;
    state->update_counter = 0;
    state->byte_swap_enabled = 0;
    state->word_swap_enabled = 0;
    state->profile_active = 0;
}

void transparent_profile_update(transparent_profile_state_t *state)
{
    if (!state->initialized) return;

    if (state->profile_active && (state->data_in_dirty || state->data_out_dirty)) {
        transparent_map_words(state);
        state->data_in_dirty = 0;
        state->data_out_dirty = 0;
    }
}

void profile_transparent_map(transparent_profile_state_t *state)
{
    if (!state->initialized) return;

    state->profile_active = 1;
    transparent_map_words(state);
}
