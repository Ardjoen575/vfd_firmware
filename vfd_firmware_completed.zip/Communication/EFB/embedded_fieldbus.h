#ifndef COMMUNICATION_EFB_EMBEDDED_FIELDBUS_H
#define COMMUNICATION_EFB_EMBEDDED_FIELDBUS_H

#include <stdint.h>

#define EFB_RX_BUFFER_SIZE 256
#define EFB_TX_BUFFER_SIZE 256
#define EFB_MAX_DEVICES 8

typedef enum {
    EFB_TYPE_MODBUS = 0,
    EFB_TYPE_CANOPEN = 1,
    EFB_TYPE_DEVICENET = 2,
    EFB_TYPE_PROFIBUS = 3
} efb_type_t;

typedef enum {
    EFB_COMM_OK = 0,
    EFB_COMM_TIMEOUT = 1,
    EFB_COMM_CRC_ERROR = 2,
    EFB_COMM_BUS_OFF = 3
} efb_comm_status_t;

typedef struct {
    uint8_t initialized;
    efb_type_t fieldbus_type;
    efb_comm_status_t comm_status;
    uint8_t rx_buffer[EFB_RX_BUFFER_SIZE];
    uint16_t rx_len;
    uint16_t rx_index;
    uint8_t tx_buffer[EFB_TX_BUFFER_SIZE];
    uint16_t tx_len;
    uint8_t slave_address;
    uint32_t baud_rate;
    uint8_t parity;
    uint8_t stop_bits;
    uint8_t data_bits;
    uint16_t interframe_delay_us;
    uint32_t poll_counter;
    uint32_t message_count;
    uint32_t error_count;
    uint8_t input_image[64];
    uint8_t output_image[64];
    uint16_t input_size;
    uint16_t output_size;
    uint8_t output_dirty;
    uint8_t input_refresh_pending;
} embedded_fieldbus_state_t;

void embedded_fieldbus_init(embedded_fieldbus_state_t *state);
void embedded_fieldbus_update(embedded_fieldbus_state_t *state);
void efb_poll(embedded_fieldbus_state_t *state);

#endif
