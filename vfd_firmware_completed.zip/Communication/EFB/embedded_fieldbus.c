#include "embedded_fieldbus.h"
#include <string.h>

static void efb_process_rx_frame(embedded_fieldbus_state_t *state)
{
    if (state->rx_len < 4) return;

    uint8_t addr = state->rx_buffer[0];
    if (addr != state->slave_address && addr != 0x00) return;

    uint16_t crc_rx = (uint16_t)(state->rx_buffer[state->rx_len - 2] |
                                 (state->rx_buffer[state->rx_len - 1] << 8));
    uint16_t crc_calc = 0xFFFF;
    for (uint16_t i = 0; i < state->rx_len - 2; i++) {
        crc_calc ^= state->rx_buffer[i];
        for (uint8_t j = 0; j < 8; j++) {
            if (crc_calc & 0x0001) {
                crc_calc = (crc_calc >> 1) ^ 0xA001;
            } else {
                crc_calc >>= 1;
            }
        }
    }

    if (crc_calc != crc_rx) {
        state->comm_status = EFB_COMM_CRC_ERROR;
        state->error_count++;
        return;
    }

    state->comm_status = EFB_COMM_OK;
    state->message_count++;
    state->rx_len = 0;
}

static void efb_update_outputs(embedded_fieldbus_state_t *state)
{
    if (!state->output_dirty) return;

    if (state->output_size > 0 && state->output_size <= EFB_TX_BUFFER_SIZE) {
        memcpy(state->tx_buffer, state->output_image, state->output_size);
        state->tx_len = state->output_size;
    }
    state->output_dirty = 0;
}

static void efb_update_inputs(embedded_fieldbus_state_t *state)
{
    if (!state->input_refresh_pending) return;

    if (state->input_size > 0 && state->input_size <= sizeof(state->input_image)) {
        state->input_image[0] = (state->comm_status == EFB_COMM_OK) ? 0x01 : 0x00;
        state->input_image[1] = (uint8_t)(state->error_count & 0xFF);
    }
    state->input_refresh_pending = 0;
}

void embedded_fieldbus_init(embedded_fieldbus_state_t *state)
{
    state->initialized = 1;
    state->fieldbus_type = EFB_TYPE_MODBUS;
    state->comm_status = EFB_COMM_OK;
    memset(state->rx_buffer, 0, EFB_RX_BUFFER_SIZE);
    state->rx_len = 0;
    state->rx_index = 0;
    memset(state->tx_buffer, 0, EFB_TX_BUFFER_SIZE);
    state->tx_len = 0;
    state->slave_address = 1;
    state->baud_rate = 115200;
    state->parity = 1;
    state->stop_bits = 1;
    state->data_bits = 8;
    state->interframe_delay_us = 3500;
    state->poll_counter = 0;
    state->message_count = 0;
    state->error_count = 0;
    memset(state->input_image, 0, sizeof(state->input_image));
    memset(state->output_image, 0, sizeof(state->output_image));
    state->input_size = 0;
    state->output_size = 0;
    state->output_dirty = 0;
    state->input_refresh_pending = 0;
}

void embedded_fieldbus_update(embedded_fieldbus_state_t *state)
{
    if (!state->initialized) return;

    efb_update_outputs(state);
    efb_update_inputs(state);

    state->input_refresh_pending = 1;
}

void efb_poll(embedded_fieldbus_state_t *state)
{
    if (!state->initialized) return;

    state->poll_counter++;

    if (state->rx_len > 0) {
        efb_process_rx_frame(state);
    }

    efb_update_outputs(state);
    efb_update_inputs(state);

    if (state->poll_counter > 1000) {
        if (state->message_count == 0 && state->error_count > 3) {
            state->comm_status = EFB_COMM_TIMEOUT;
        }
        state->poll_counter = 0;
    }
}
