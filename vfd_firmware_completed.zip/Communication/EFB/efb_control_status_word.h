#ifndef COMMUNICATION_EFB_EFB_CONTROL_STATUS_WORD_H
#define COMMUNICATION_EFB_EFB_CONTROL_STATUS_WORD_H

#include <stdint.h>

typedef enum {
    EFB_STATE_NOT_READY = 0,
    EFB_STATE_INHIBIT = 1,
    EFB_STATE_READY_ON = 2,
    EFB_STATE_ENABLED = 3,
    EFB_STATE_OPERATION = 4,
    EFB_STATE_FAULT = 5,
    EFB_STATE_FAULT_ACTIVE = 6,
    EFB_STATE_OFF = 7
} efb_drive_state_t;

#define EFB_CTRL_CMD_NONE      0x0000
#define EFB_CTRL_CMD_START     0x0001
#define EFB_CTRL_CMD_STOP      0x0002
#define EFB_CTRL_CMD_FAULT_RESET 0x0004
#define EFB_CTRL_CMD_QUICK_STOP 0x0008
#define EFB_CTRL_CMD_COAST_STOP 0x0010
#define EFB_CTRL_CMD_RAMP_STOP  0x0020

#define EFB_STAT_READY          0x0001
#define EFB_STAT_ENABLED        0x0002
#define EFB_STAT_RUNNING        0x0004
#define EFB_STAT_FAULT          0x0008
#define EFB_STAT_WARNING        0x0010
#define EFB_STAT_AT_SETPOINT    0x0020
#define EFB_STAT_REMOTE         0x0040
#define EFB_STAT_LOCAL          0x0080

typedef struct {
    uint8_t initialized;
    uint16_t control_word;
    uint16_t status_word;
    efb_drive_state_t drive_state;
    efb_drive_state_t prev_state;
    uint16_t command_latch;
    uint16_t fault_code;
    uint16_t warning_code;
    uint8_t start_request;
    uint8_t stop_request;
    uint8_t reset_request;
    uint8_t quick_stop_request;
    uint16_t status_mask;
    uint8_t state_transition;
} efb_control_status_word_state_t;

void efb_control_status_word_init(efb_control_status_word_state_t *state);
void efb_control_status_word_update(efb_control_status_word_state_t *state);
void efb_ctrlword_update(efb_control_status_word_state_t *state);

#endif
