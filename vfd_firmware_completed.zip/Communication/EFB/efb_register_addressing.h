#ifndef COMMUNICATION_EFB_EFB_REGISTER_ADDRESSING_H
#define COMMUNICATION_EFB_EFB_REGISTER_ADDRESSING_H

#include <stdint.h>

#define EFB_MAX_PARAM_GROUPS 32
#define EFB_REGMAP_SIZE 512

typedef struct {
    uint16_t group;
    uint16_t index;
    uint16_t register_addr;
    uint8_t size;
    uint8_t access;
} efb_regmap_entry_t;

typedef struct {
    uint8_t initialized;
    efb_regmap_entry_t map[EFB_REGMAP_SIZE];
    uint16_t map_count;
    int16_t param_values[EFB_MAX_PARAM_GROUPS * 8];
    uint16_t param_count;
    uint16_t base_holding_register;
    uint16_t base_input_register;
    uint8_t read_ongoing;
    uint8_t write_ongoing;
    uint16_t current_register;
    int16_t current_value;
    uint32_t access_count;
} efb_register_addressing_state_t;

void efb_register_addressing_init(efb_register_addressing_state_t *state);
void efb_register_addressing_update(efb_register_addressing_state_t *state);
void efb_addr_resolve(efb_register_addressing_state_t *state);

#endif
