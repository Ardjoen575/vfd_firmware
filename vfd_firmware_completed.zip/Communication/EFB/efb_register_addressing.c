#include "efb_register_addressing.h"
#include <string.h>

static int16_t efb_param_store_read(uint16_t group, uint16_t index)
{
    return (int16_t)((group << 8) | (index & 0xFF));
}

static void efb_param_store_write(uint16_t group, uint16_t index, int16_t value)
{
    (void)group;
    (void)index;
    (void)value;
}

static int16_t efb_reg_map_find(efb_register_addressing_state_t *state,
                                uint16_t reg_addr,
                                uint8_t for_write)
{
    for (uint16_t i = 0; i < state->map_count; i++) {
        if (state->map[i].register_addr == reg_addr) {
            if (for_write && !(state->map[i].access & 0x02)) {
                return -1;
            }
            if (!for_write && !(state->map[i].access & 0x01)) {
                return -1;
            }
            return (int16_t)i;
        }
    }
    return -1;
}

int16_t efb_reg_read(efb_register_addressing_state_t *state, uint16_t reg_addr)
{
    int16_t entry_idx = efb_reg_map_find(state, reg_addr, 0);
    if (entry_idx < 0) {
        state->read_ongoing = 0;
        return 0;
    }

    int16_t value = efb_param_store_read(
        state->map[entry_idx].group,
        state->map[entry_idx].index);

    state->current_register = reg_addr;
    state->current_value = value;
    state->access_count++;
    state->read_ongoing = 0;
    return value;
}

int16_t efb_reg_write(efb_register_addressing_state_t *state,
                      uint16_t reg_addr,
                      int16_t value)
{
    int16_t entry_idx = efb_reg_map_find(state, reg_addr, 1);
    if (entry_idx < 0) {
        state->write_ongoing = 0;
        return -1;
    }

    efb_param_store_write(
        state->map[entry_idx].group,
        state->map[entry_idx].index,
        value);

    state->current_register = reg_addr;
    state->current_value = value;
    state->access_count++;
    state->write_ongoing = 0;
    return 0;
}

static void efb_map_add_entry(efb_register_addressing_state_t *state,
                              uint16_t group, uint16_t index,
                              uint16_t reg_addr, uint8_t size,
                              uint8_t access)
{
    if (state->map_count >= EFB_REGMAP_SIZE) return;

    state->map[state->map_count].group = group;
    state->map[state->map_count].index = index;
    state->map[state->map_count].register_addr = reg_addr;
    state->map[state->map_count].size = size;
    state->map[state->map_count].access = access;
    state->map_count++;
}

void efb_register_addressing_init(efb_register_addressing_state_t *state)
{
    state->initialized = 1;
    memset(state->map, 0, sizeof(state->map));
    state->map_count = 0;
    memset(state->param_values, 0, sizeof(state->param_values));
    state->param_count = 0;
    state->base_holding_register = 40001;
    state->base_input_register = 30001;
    state->read_ongoing = 0;
    state->write_ongoing = 0;
    state->current_register = 0;
    state->current_value = 0;
    state->access_count = 0;

    efb_map_add_entry(state, 0x01, 0x00, 40001, 2, 0x03);
    efb_map_add_entry(state, 0x01, 0x01, 40002, 2, 0x03);
    efb_map_add_entry(state, 0x01, 0x02, 40003, 2, 0x03);
    efb_map_add_entry(state, 0x10, 0x01, 40004, 2, 0x03);
    efb_map_add_entry(state, 0x10, 0x02, 40005, 2, 0x03);
}

void efb_register_addressing_update(efb_register_addressing_state_t *state)
{
    if (!state->initialized) return;

    if (state->read_ongoing) {
        efb_reg_read(state, state->current_register);
    }

    if (state->write_ongoing) {
        efb_reg_write(state, state->current_register, state->current_value);
    }
}

void efb_addr_resolve(efb_register_addressing_state_t *state)
{
    if (!state->initialized) return;

    state->read_ongoing = 1;
    efb_reg_read(state, state->current_register);
}
