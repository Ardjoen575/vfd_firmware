#include "efb_control_status_word.h"

static uint16_t efb_parse_control(uint16_t ctrl)
{
    uint16_t cmd = EFB_CTRL_CMD_NONE;

    if (ctrl & 0x0001) cmd |= EFB_CTRL_CMD_START;
    if (ctrl & 0x0002) cmd |= EFB_CTRL_CMD_STOP;
    if (ctrl & 0x0004) cmd |= EFB_CTRL_CMD_FAULT_RESET;
    if (ctrl & 0x0008) cmd |= EFB_CTRL_CMD_QUICK_STOP;
    if (ctrl & 0x0010) cmd |= EFB_CTRL_CMD_COAST_STOP;
    if (ctrl & 0x0020) cmd |= EFB_CTRL_CMD_RAMP_STOP;

    return cmd;
}

static void efb_state_machine(efb_control_status_word_state_t *state,
                              uint16_t cmd)
{
    state->prev_state = state->drive_state;

    switch (state->drive_state) {
    case EFB_STATE_NOT_READY:
        state->drive_state = EFB_STATE_INHIBIT;
        state->state_transition = 1;
        break;

    case EFB_STATE_INHIBIT:
        if (cmd & EFB_CTRL_CMD_START) {
            state->drive_state = EFB_STATE_READY_ON;
            state->state_transition = 1;
        }
        break;

    case EFB_STATE_READY_ON:
        if (cmd & EFB_CTRL_CMD_START) {
            state->drive_state = EFB_STATE_ENABLED;
            state->state_transition = 1;
        } else if (cmd & EFB_CTRL_CMD_STOP) {
            state->drive_state = EFB_STATE_INHIBIT;
            state->state_transition = 1;
        } else if (cmd & EFB_CTRL_CMD_FAULT_RESET) {
            state->drive_state = EFB_STATE_READY_ON;
            state->state_transition = 1;
        }
        break;

    case EFB_STATE_ENABLED:
        if (cmd & EFB_CTRL_CMD_START) {
            state->drive_state = EFB_STATE_OPERATION;
            state->state_transition = 1;
        } else if (cmd & EFB_CTRL_CMD_STOP) {
            state->drive_state = EFB_STATE_READY_ON;
            state->state_transition = 1;
        }
        break;

    case EFB_STATE_OPERATION:
        if (cmd & (EFB_CTRL_CMD_STOP | EFB_CTRL_CMD_RAMP_STOP)) {
            state->drive_state = EFB_STATE_ENABLED;
            state->state_transition = 1;
        } else if (cmd & EFB_CTRL_CMD_QUICK_STOP) {
            state->drive_state = EFB_STATE_READY_ON;
            state->state_transition = 1;
        } else if (cmd & EFB_CTRL_CMD_COAST_STOP) {
            state->drive_state = EFB_STATE_INHIBIT;
            state->state_transition = 1;
        }
        break;

    case EFB_STATE_FAULT:
        state->drive_state = EFB_STATE_FAULT_ACTIVE;
        state->state_transition = 1;
        break;

    case EFB_STATE_FAULT_ACTIVE:
        if (cmd & EFB_CTRL_CMD_FAULT_RESET) {
            state->drive_state = EFB_STATE_INHIBIT;
            state->fault_code = 0;
            state->state_transition = 1;
        }
        break;

    case EFB_STATE_OFF:
        state->drive_state = EFB_STATE_NOT_READY;
        state->state_transition = 1;
        break;
    }
}

static void efb_build_status(efb_control_status_word_state_t *state)
{
    state->status_word = 0;

    switch (state->drive_state) {
    case EFB_STATE_NOT_READY:
        state->status_word = 0x0000;
        break;
    case EFB_STATE_INHIBIT:
        state->status_word = EFB_STAT_READY | EFB_STAT_REMOTE;
        break;
    case EFB_STATE_READY_ON:
        state->status_word = EFB_STAT_READY | EFB_STAT_REMOTE;
        break;
    case EFB_STATE_ENABLED:
        state->status_word = EFB_STAT_READY | EFB_STAT_ENABLED | EFB_STAT_REMOTE;
        break;
    case EFB_STATE_OPERATION:
        state->status_word = EFB_STAT_READY | EFB_STAT_ENABLED |
                             EFB_STAT_RUNNING | EFB_STAT_REMOTE;
        break;
    case EFB_STATE_FAULT:
    case EFB_STATE_FAULT_ACTIVE:
        state->status_word = EFB_STAT_FAULT | EFB_STAT_REMOTE;
        break;
    case EFB_STATE_OFF:
        state->status_word = 0x0000;
        break;
    }

    if (state->warning_code != 0) {
        state->status_word |= EFB_STAT_WARNING;
    }

    state->status_word |= state->status_mask;
}

void efb_control_status_word_init(efb_control_status_word_state_t *state)
{
    state->initialized = 1;
    state->control_word = 0x0000;
    state->status_word = 0x0000;
    state->drive_state = EFB_STATE_NOT_READY;
    state->prev_state = EFB_STATE_NOT_READY;
    state->command_latch = 0;
    state->fault_code = 0;
    state->warning_code = 0;
    state->start_request = 0;
    state->stop_request = 0;
    state->reset_request = 0;
    state->quick_stop_request = 0;
    state->status_mask = 0;
    state->state_transition = 0;
}

void efb_control_status_word_update(efb_control_status_word_state_t *state)
{
    if (!state->initialized) return;

    state->state_transition = 0;

    if (state->start_request) {
        state->command_latch = EFB_CTRL_CMD_START;
        state->start_request = 0;
    } else if (state->stop_request) {
        state->command_latch = EFB_CTRL_CMD_STOP;
        state->stop_request = 0;
    } else if (state->reset_request) {
        state->command_latch = EFB_CTRL_CMD_FAULT_RESET;
        state->reset_request = 0;
    } else if (state->quick_stop_request) {
        state->command_latch = EFB_CTRL_CMD_QUICK_STOP;
        state->quick_stop_request = 0;
    }

    uint16_t cmd = efb_parse_control(state->control_word);
    if (cmd == EFB_CTRL_CMD_NONE && state->command_latch != 0) {
        cmd = state->command_latch;
        state->command_latch = 0;
    }

    efb_state_machine(state, cmd);
    efb_build_status(state);
}

void efb_ctrlword_update(efb_control_status_word_state_t *state)
{
    if (!state->initialized) return;

    uint16_t cmd = efb_parse_control(state->control_word);
    efb_state_machine(state, cmd);
    efb_build_status(state);
}
