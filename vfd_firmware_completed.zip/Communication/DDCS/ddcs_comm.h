#ifndef COMMUNICATION_DDCS_DDCS_COMM_H
#define COMMUNICATION_DDCS_DDCS_COMM_H

#include <stdint.h>

#define DDCS_RX_FIFO_SIZE 256
#define DDCS_TX_FIFO_SIZE 256
#define DDCS_FRAME_DELIMITER 0x7E
#define DDCS_MAX_NODE_ID 0x1F

typedef enum {
    DDCS_LINK_DOWN = 0,
    DDCS_LINK_UP = 1,
    DDCS_LINK_NEGOTIATING = 2
} ddcs_link_state_t;

typedef struct {
    uint8_t initialized;
    uint8_t node_id;
    ddcs_link_state_t link_state;
    uint8_t rx_buffer[DDCS_RX_FIFO_SIZE];
    uint16_t rx_head;
    uint16_t rx_tail;
    uint16_t rx_count;
    uint8_t rx_escape;
    uint8_t tx_buffer[DDCS_TX_FIFO_SIZE];
    uint16_t tx_head;
    uint16_t tx_tail;
    uint16_t tx_count;
    uint32_t rx_frame_count;
    uint32_t tx_frame_count;
    uint32_t crc_error_count;
    uint32_t overrun_count;
    uint16_t poll_interval_ms;
    uint16_t poll_counter;
} ddcs_comm_state_t;

void ddcs_comm_init(ddcs_comm_state_t *state);
void ddcs_comm_update(ddcs_comm_state_t *state);
void ddcs_send(ddcs_comm_state_t *state);
void ddcs_receive(ddcs_comm_state_t *state);

#endif
