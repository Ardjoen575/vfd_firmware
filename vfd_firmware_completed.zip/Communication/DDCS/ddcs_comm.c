#include "ddcs_comm.h"
#include <string.h>

static uint16_t ddcs_crc16(const uint8_t *data, uint16_t len)
{
    uint16_t crc = 0xFFFF;
    for (uint16_t i = 0; i < len; i++) {
        crc ^= (uint16_t)data[i] << 8;
        for (uint8_t j = 0; j < 8; j++) {
            if (crc & 0x8000) {
                crc = (crc << 1) ^ 0x1021;
            } else {
                crc <<= 1;
            }
        }
    }
    return crc;
}

static void ddcs_link_negotiate(ddcs_comm_state_t *state)
{
    if (state->rx_frame_count > 0 && state->crc_error_count < 3) {
        state->link_state = DDCS_LINK_UP;
    } else if (state->crc_error_count >= 10) {
        state->link_state = DDCS_LINK_DOWN;
    }
}

void ddcs_comm_init(ddcs_comm_state_t *state)
{
    state->initialized = 1;
    state->node_id = 1;
    state->link_state = DDCS_LINK_DOWN;
    memset(state->rx_buffer, 0, DDCS_RX_FIFO_SIZE);
    memset(state->tx_buffer, 0, DDCS_TX_FIFO_SIZE);
    state->rx_head = 0;
    state->rx_tail = 0;
    state->rx_count = 0;
    state->rx_escape = 0;
    state->tx_head = 0;
    state->tx_tail = 0;
    state->tx_count = 0;
    state->rx_frame_count = 0;
    state->tx_frame_count = 0;
    state->crc_error_count = 0;
    state->overrun_count = 0;
    state->poll_interval_ms = 2;
    state->poll_counter = 0;
}

void ddcs_comm_update(ddcs_comm_state_t *state)
{
    if (!state->initialized) return;

    state->poll_counter++;
    if (state->poll_counter >= state->poll_interval_ms) {
        state->poll_counter = 0;

        if (state->rx_count > 0) {
            ddcs_receive(state);
        }

        if (state->tx_count > 0) {
            ddcs_send(state);
        }
    }

    if (state->link_state == DDCS_LINK_NEGOTIATING) {
        ddcs_link_negotiate(state);
    }

    if (state->link_state == DDCS_LINK_DOWN && (state->rx_frame_count == 0)) {
        state->link_state = DDCS_LINK_NEGOTIATING;
    }
}

void ddcs_send(ddcs_comm_state_t *state)
{
    uint8_t frame[DDCS_TX_FIFO_SIZE + 4];
    uint16_t frame_len = state->tx_count;
    uint16_t idx = 0;
    (void)frame;

    if (frame_len == 0 || state->link_state != DDCS_LINK_UP) return;

    frame[idx++] = DDCS_FRAME_DELIMITER;
    frame[idx++] = state->node_id;

    for (uint16_t i = 0; i < frame_len; i++) {
        uint8_t byte = state->tx_buffer[(state->tx_head + i) % DDCS_TX_FIFO_SIZE];
        if (byte == DDCS_FRAME_DELIMITER || byte == 0x7D) {
            frame[idx++] = 0x7D;
        }
        frame[idx++] = byte;
    }

    uint16_t crc = ddcs_crc16(&state->tx_buffer[state->tx_head], frame_len);
    frame[idx++] = (uint8_t)(crc >> 8);
    frame[idx++] = (uint8_t)(crc & 0xFF);
    frame[idx++] = DDCS_FRAME_DELIMITER;

    state->tx_head = (state->tx_head + frame_len) % DDCS_TX_FIFO_SIZE;
    state->tx_count = 0;
    state->tx_frame_count++;
}

void ddcs_receive(ddcs_comm_state_t *state)
{
    uint8_t temp_rx[DDCS_RX_FIFO_SIZE];
    uint16_t temp_len = 0;
    uint8_t escape = 0;
    uint8_t in_frame = 0;

    while (state->rx_count > 0) {
        uint8_t byte = state->rx_buffer[state->rx_tail];
        state->rx_tail = (state->rx_tail + 1) % DDCS_RX_FIFO_SIZE;
        state->rx_count--;

        if (byte == DDCS_FRAME_DELIMITER) {
            if (in_frame) {
                if (temp_len >= 4) {
                    uint16_t rx_crc = (uint16_t)(temp_rx[temp_len - 2] << 8) |
                                      temp_rx[temp_len - 1];
                    uint16_t calc_crc = ddcs_crc16(temp_rx, temp_len - 2);

                    if (rx_crc == calc_crc && temp_rx[0] == state->node_id) {
                        for (uint16_t i = 1; i < temp_len - 2; i++) {
                            state->rx_buffer[state->rx_tail] = temp_rx[i];
                            state->rx_tail = (state->rx_tail + 1) % DDCS_RX_FIFO_SIZE;
                            state->rx_count++;
                        }
                        state->rx_frame_count++;
                    } else {
                        state->crc_error_count++;
                    }
                }
                temp_len = 0;
                in_frame = 0;
            } else {
                in_frame = 1;
                temp_len = 0;
            }
            escape = 0;
        } else if (byte == 0x7D) {
            escape = 1;
        } else {
            if (escape) {
                escape = 0;
            }
            if (in_frame && temp_len < DDCS_RX_FIFO_SIZE) {
                temp_rx[temp_len++] = byte;
            }
        }
    }
}
