#ifndef COMMUNICATION_DDCS_D2D_DDCS_RECEIVE_H
#define COMMUNICATION_DDCS_D2D_DDCS_RECEIVE_H

#include <stdint.h>

#define D2D_RX_BUFFER_SIZE 8
#define D2D_RX_TIMEOUT_MS 100

typedef struct {
    uint8_t initialized;
    uint8_t local_node_id;
    uint8_t rx_buffer[D2D_RX_BUFFER_SIZE];
    uint8_t rx_len;
    uint8_t rx_valid;
    uint8_t frame_type;
    uint8_t source_node_id;
    int16_t received_speed_ref;
    int16_t received_torque_ref;
    uint16_t received_status_word;
    uint16_t received_control_word;
    uint16_t rx_sequence;
    uint32_t rx_message_count;
    uint32_t timeout_count;
    uint32_t checksum_error_count;
    uint16_t timeout_ms;
    uint16_t timeout_counter;
    uint8_t follower_data_valid;
} d2d_ddcs_receive_state_t;

void d2d_ddcs_receive_init(d2d_ddcs_receive_state_t *state);
void d2d_ddcs_receive_update(d2d_ddcs_receive_state_t *state);
void d2d_receive_frame(d2d_ddcs_receive_state_t *state);

#endif
