#include "d2d_ddcs_transmit.h"
#include <string.h>

static void d2d_build_speed_frame(d2d_ddcs_transmit_state_t *state)
{
    state->tx_buffer[0] = D2D_MSG_SPEED_REF;
    state->tx_buffer[1] = state->master_node_id;
    state->tx_buffer[2] = state->follower_ids[state->current_follower];
    state->tx_buffer[3] = (uint8_t)(state->sequence_number >> 8);
    state->tx_buffer[4] = (uint8_t)(state->sequence_number & 0xFF);
    state->tx_buffer[5] = (uint8_t)((state->speed_reference >> 8) & 0xFF);
    state->tx_buffer[6] = (uint8_t)(state->speed_reference & 0xFF);
    state->tx_buffer[7] = 0x00;
    state->tx_buffer[7] ^= state->tx_buffer[0] ^ state->tx_buffer[1] ^
                          state->tx_buffer[2] ^ state->tx_buffer[3] ^
                          state->tx_buffer[4] ^ state->tx_buffer[5] ^
                          state->tx_buffer[6];
    state->tx_len = D2D_FRAME_SIZE;
}

static void d2d_build_torque_frame(d2d_ddcs_transmit_state_t *state)
{
    state->tx_buffer[0] = D2D_MSG_TORQUE_REF;
    state->tx_buffer[1] = state->master_node_id;
    state->tx_buffer[2] = state->follower_ids[state->current_follower];
    state->tx_buffer[3] = (uint8_t)(state->sequence_number >> 8);
    state->tx_buffer[4] = (uint8_t)(state->sequence_number & 0xFF);
    state->tx_buffer[5] = (uint8_t)((state->torque_reference >> 8) & 0xFF);
    state->tx_buffer[6] = (uint8_t)(state->torque_reference & 0xFF);
    state->tx_buffer[7] = 0x00;
    state->tx_buffer[7] ^= state->tx_buffer[0] ^ state->tx_buffer[1] ^
                          state->tx_buffer[2] ^ state->tx_buffer[3] ^
                          state->tx_buffer[4] ^ state->tx_buffer[5] ^
                          state->tx_buffer[6];
    state->tx_len = D2D_FRAME_SIZE;
}

static void d2d_build_status_frame(d2d_ddcs_transmit_state_t *state)
{
    state->tx_buffer[0] = D2D_MSG_STATUS;
    state->tx_buffer[1] = state->master_node_id;
    state->tx_buffer[2] = state->follower_ids[state->current_follower];
    state->tx_buffer[3] = (uint8_t)(state->sequence_number >> 8);
    state->tx_buffer[4] = (uint8_t)(state->sequence_number & 0xFF);
    state->tx_buffer[5] = (uint8_t)((state->status_word >> 8) & 0xFF);
    state->tx_buffer[6] = (uint8_t)(state->status_word & 0xFF);
    state->tx_buffer[7] = 0x00;
    state->tx_buffer[7] ^= state->tx_buffer[0] ^ state->tx_buffer[1] ^
                          state->tx_buffer[2] ^ state->tx_buffer[3] ^
                          state->tx_buffer[4] ^ state->tx_buffer[5] ^
                          state->tx_buffer[6];
    state->tx_len = D2D_FRAME_SIZE;
}

void d2d_ddcs_transmit_init(d2d_ddcs_transmit_state_t *state)
{
    state->initialized = 1;
    state->master_node_id = 1;
    memset(state->follower_ids, 0, D2D_MAX_FOLLOWERS);
    state->follower_count = 0;
    state->current_follower = 0;
    state->speed_reference = 0;
    state->torque_reference = 0;
    state->status_word = 0;
    state->control_word = 0;
    memset(state->tx_buffer, 0, D2D_FRAME_SIZE);
    state->tx_len = 0;
    state->sequence_number = 0;
    state->tx_message_count = 0;
    state->transmit_interval_ms = 2;
    state->interval_counter = 0;
    state->transmit_enabled = 0;
}

void d2d_ddcs_transmit_update(d2d_ddcs_transmit_state_t *state)
{
    if (!state->initialized || !state->transmit_enabled) return;
    if (state->follower_count == 0) return;

    state->interval_counter++;
    if (state->interval_counter < state->transmit_interval_ms) return;
    state->interval_counter = 0;

    d2d_transmit_frame(state);
}

void d2d_transmit_frame(d2d_ddcs_transmit_state_t *state)
{
    if (state->follower_count == 0) return;

    state->sequence_number++;

    switch (state->sequence_number % 3) {
    case 0:
        d2d_build_speed_frame(state);
        break;
    case 1:
        d2d_build_torque_frame(state);
        break;
    case 2:
        d2d_build_status_frame(state);
        break;
    }

    state->current_follower = (state->current_follower + 1) % state->follower_count;
    state->tx_message_count++;
}
