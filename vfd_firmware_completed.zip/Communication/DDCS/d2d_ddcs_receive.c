#include "d2d_ddcs_receive.h"
#include "d2d_ddcs_transmit.h"
#include <string.h>

static uint8_t d2d_validate_checksum(const uint8_t *data, uint8_t len)
{
    uint8_t xor = 0;
    for (uint8_t i = 0; i < len - 1; i++) {
        xor ^= data[i];
    }
    return xor == data[len - 1];
}

static void d2d_parse_frame(d2d_ddcs_receive_state_t *state)
{
    if (!d2d_validate_checksum(state->rx_buffer, state->rx_len)) {
        state->checksum_error_count++;
        state->rx_valid = 0;
        return;
    }

    state->frame_type = state->rx_buffer[0];

    if (state->rx_buffer[2] != state->local_node_id) {
        state->rx_valid = 0;
        return;
    }

    state->source_node_id = state->rx_buffer[1];
    state->rx_sequence = (uint16_t)(state->rx_buffer[3] << 8) |
                         state->rx_buffer[4];

    switch (state->frame_type) {
    case D2D_MSG_SPEED_REF:
        state->received_speed_ref = (int16_t)(state->rx_buffer[5] << 8) |
                                     state->rx_buffer[6];
        break;
    case D2D_MSG_TORQUE_REF:
        state->received_torque_ref = (int16_t)(state->rx_buffer[5] << 8) |
                                      state->rx_buffer[6];
        break;
    case D2D_MSG_STATUS:
        state->received_status_word = (uint16_t)(state->rx_buffer[5] << 8) |
                                       state->rx_buffer[6];
        break;
    case D2D_MSG_CONTROL:
        state->received_control_word = (uint16_t)(state->rx_buffer[5] << 8) |
                                        state->rx_buffer[6];
        break;
    default:
        state->rx_valid = 0;
        return;
    }

    state->rx_valid = 1;
    state->follower_data_valid = 1;
    state->rx_message_count++;
    state->timeout_counter = 0;
}

void d2d_ddcs_receive_init(d2d_ddcs_receive_state_t *state)
{
    state->initialized = 1;
    state->local_node_id = 2;
    memset(state->rx_buffer, 0, D2D_RX_BUFFER_SIZE);
    state->rx_len = 0;
    state->rx_valid = 0;
    state->frame_type = 0;
    state->source_node_id = 0;
    state->received_speed_ref = 0;
    state->received_torque_ref = 0;
    state->received_status_word = 0;
    state->received_control_word = 0;
    state->rx_sequence = 0;
    state->rx_message_count = 0;
    state->timeout_count = 0;
    state->checksum_error_count = 0;
    state->timeout_ms = D2D_RX_TIMEOUT_MS;
    state->timeout_counter = 0;
    state->follower_data_valid = 0;
}

void d2d_ddcs_receive_update(d2d_ddcs_receive_state_t *state)
{
    if (!state->initialized) return;

    state->timeout_counter++;
    if (state->timeout_counter < state->timeout_ms) return;
    state->timeout_counter = 0;

    if (state->rx_valid) {
        d2d_receive_frame(state);
    }

    if (state->timeout_counter == 0 && !state->rx_valid) {
        state->timeout_count++;
        state->follower_data_valid = 0;
        state->received_speed_ref = 0;
        state->received_torque_ref = 0;
    }
}

void d2d_receive_frame(d2d_ddcs_receive_state_t *state)
{
    d2d_parse_frame(state);
}
