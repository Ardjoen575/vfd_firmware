#ifndef COMMUNICATION_DDCS_D2D_DDCS_TRANSMIT_H
#define COMMUNICATION_DDCS_D2D_DDCS_TRANSMIT_H

#include <stdint.h>

#define D2D_FRAME_SIZE 8
#define D2D_MAX_FOLLOWERS 4

typedef enum {
    D2D_MSG_SPEED_REF = 0x01,
    D2D_MSG_TORQUE_REF = 0x02,
    D2D_MSG_STATUS = 0x03,
    D2D_MSG_CONTROL = 0x04
} d2d_message_type_t;

typedef struct {
    uint8_t initialized;
    uint8_t master_node_id;
    uint8_t follower_ids[D2D_MAX_FOLLOWERS];
    uint8_t follower_count;
    uint8_t current_follower;
    int16_t speed_reference;
    int16_t torque_reference;
    uint16_t status_word;
    uint16_t control_word;
    uint8_t tx_buffer[D2D_FRAME_SIZE];
    uint8_t tx_len;
    uint16_t sequence_number;
    uint32_t tx_message_count;
    uint16_t transmit_interval_ms;
    uint16_t interval_counter;
    uint8_t transmit_enabled;
} d2d_ddcs_transmit_state_t;

void d2d_ddcs_transmit_init(d2d_ddcs_transmit_state_t *state);
void d2d_ddcs_transmit_update(d2d_ddcs_transmit_state_t *state);
void d2d_transmit_frame(d2d_ddcs_transmit_state_t *state);

#endif
