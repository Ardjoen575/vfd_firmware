#ifndef MISC_USER_LOCK_H
#define MISC_USER_LOCK_H

#include <stdint.h>

#define USER_LOCK_PIN_LENGTH     4U
#define USER_LOCK_PIN_DEFAULT    0x0000U
#define USER_LOCK_MAX_ATTEMPTS   3U
#define USER_LOCK_TIMEOUT_S     30U

typedef enum {
    LOCK_STATE_UNLOCKED   = 0,
    LOCK_STATE_LOCKED     = 1,
    LOCK_STATE_LOCKOUT    = 2,
    LOCK_STATE_PIN_ENTRY  = 3,
    LOCK_STATE_PIN_CHANGE = 4,
} lock_state_t;

typedef struct {
    uint8_t      initialized;
    lock_state_t state;
    uint8_t      locked;
    uint16_t     user_pin;
    uint8_t      pin_buffer[USER_LOCK_PIN_LENGTH];
    uint8_t      pin_index;
    uint8_t      failed_attempts;
    uint32_t     lockout_timer_s;
    uint8_t      param_lock_active;
    uint16_t     locked_params[32];
    uint8_t      locked_param_count;
} user_lock_state_t;

void user_lock_init(user_lock_state_t *state);
void user_lock_update(user_lock_state_t *state);
uint8_t user_lock_check(user_lock_state_t *state, uint16_t param_id);
void user_lock_enter_pin(user_lock_state_t *state, uint16_t pin);
void user_lock_change_pin(user_lock_state_t *state,
                           uint16_t old_pin, uint16_t new_pin);

#endif
