#include "user_parameter_sets.h"
#include "param_checksum.h"
#include <string.h>

#define FLASH_R_BASE       0x40023C00UL
#define FLASH_KEYR         (*(volatile uint32_t *)(FLASH_R_BASE + 0x04UL))
#define FLASH_SR           (*(volatile uint32_t *)(FLASH_R_BASE + 0x0CUL))
#define FLASH_CR           (*(volatile uint32_t *)(FLASH_R_BASE + 0x10UL))
#define FLASH_KEY1         0x45670123UL
#define FLASH_KEY2         0xCDEF89ABUL
#define FLASH_CR_STRT      (1UL << 16)
#define FLASH_CR_SER       (1UL << 1)
#define FLASH_CR_PG        (1UL << 0)
#define FLASH_CR_LOCK      (1UL << 31)
#define FLASH_SR_BSY       (1UL << 16)
#define FLASH_SR_EOP       (1UL << 0)
#define FLASH_CR_SNB_Pos   3U

static void flash_unlock(void)
{
    if (FLASH_CR & FLASH_CR_LOCK) {
        FLASH_KEYR = FLASH_KEY1;
        FLASH_KEYR = FLASH_KEY2;
        __asm__ volatile ("dsb");
        __asm__ volatile ("isb");
    }
}

static void flash_lock(void)
{
    FLASH_CR |= FLASH_CR_LOCK;
}

static uint8_t flash_wait_ready(void)
{
    while (FLASH_SR & FLASH_SR_BSY) {
    }
    return 1;
}

static uint8_t flash_erase_sector(uint32_t addr)
{
    uint32_t sector = (addr - 0x08000000UL) / 0x00008000UL;

    flash_unlock();
    flash_wait_ready();

    FLASH_CR &= ~(0x0FUL << FLASH_CR_SNB_Pos);
    FLASH_CR |= (sector << FLASH_CR_SNB_Pos);
    FLASH_CR |= FLASH_CR_SER;
    __asm__ volatile ("dsb");
    __asm__ volatile ("isb");

    FLASH_CR |= FLASH_CR_STRT;
    __asm__ volatile ("dsb");
    __asm__ volatile ("isb");

    flash_wait_ready();
    FLASH_CR &= ~FLASH_CR_SER;
    flash_lock();

    return 1;
}

uint8_t user_set_save(user_parameter_sets_state_t *state, uint8_t set_id)
{
    userset_flash_block_t block;
    uint32_t flash_addr;
    volatile uint32_t *flash_ptr;
    uint32_t i;
    uint32_t word;

    if (state == 0 || set_id >= USER_SET_COUNT) {
        if (state) state->last_error = USERSET_ERR_INVALID_ID;
        return 0;
    }

    state->save_in_progress = 1;

    memset(&block, 0, sizeof(block));
    block.magic       = USER_SET_MAGIC;
    block.param_count = state->param_count;
    block.version     = state->set_version[set_id] + 1;

    memcpy(block.data, state->params,
           state->param_count * sizeof(int32_t));

    block.checksum = param_checksum_calc(block.data, block.param_count);

    flash_addr = USER_SET_FLASH_BASE + ((uint32_t)set_id * USER_SET_SIZE);

    if (!flash_erase_sector(flash_addr)) {
        state->last_error = USERSET_ERR_FLASH_ERASE;
        state->save_in_progress = 0;
        return 0;
    }

    flash_unlock();
    FLASH_CR |= FLASH_CR_PG;

    flash_ptr = (volatile uint32_t *)flash_addr;
    word = 0;
    flash_ptr[0] = block.magic;
    flash_wait_ready();
    flash_ptr[1] = ((uint32_t)block.param_count << 16) | block.checksum;
    flash_wait_ready();
    flash_ptr[2] = block.version;
    flash_wait_ready();

    for (i = 0; i < block.param_count; i++) {
        flash_ptr[3 + i] = (uint32_t)block.data[i];
        flash_wait_ready();
    }

    FLASH_CR &= ~FLASH_CR_PG;
    flash_lock();

    state->set_valid[set_id] = 1;
    state->set_version[set_id] = block.version;
    state->last_save_tick = 0;
    state->save_in_progress = 0;
    state->last_error = USERSET_ERR_NONE;

    return 1;
}

uint8_t user_set_load(user_parameter_sets_state_t *state, uint8_t set_id)
{
    const volatile uint32_t *flash_ptr;
    uint32_t magic;
    uint16_t count;
    uint16_t checksum;
    uint16_t computed_crc;
    uint32_t i;

    if (state == 0 || set_id >= USER_SET_COUNT) {
        if (state) state->last_error = USERSET_ERR_INVALID_ID;
        return 0;
    }

    state->load_in_progress = 1;

    flash_ptr = (const volatile uint32_t *)(USER_SET_FLASH_BASE +
                                             ((uint32_t)set_id * USER_SET_SIZE));

    magic = flash_ptr[0];
    if (magic != USER_SET_MAGIC) {
        state->last_error = USERSET_ERR_MAGIC;
        state->load_in_progress = 0;
        return 0;
    }

    count    = (uint16_t)(flash_ptr[1] >> 16);
    checksum = (uint16_t)(flash_ptr[1] & 0xFFFF);

    if (count == 0 || count > USER_SET_PARAMS_MAX) {
        state->last_error = USERSET_ERR_INVALID_ID;
        state->load_in_progress = 0;
        return 0;
    }

    for (i = 0; i < count; i++) {
        state->params[i] = (int32_t)flash_ptr[3 + i];
    }

    computed_crc = param_checksum_calc(state->params, count);
    if (computed_crc != checksum) {
        state->last_error = USERSET_ERR_CHECKSUM;
        state->load_in_progress = 0;
        return 0;
    }

    state->param_count = count;
    state->active_set_id = set_id;
    state->set_valid[set_id] = 1;
    state->set_version[set_id] = flash_ptr[2];
    state->last_load_tick = 0;
    state->load_in_progress = 0;
    state->last_error = USERSET_ERR_NONE;

    return 1;
}

void user_parameter_sets_init(user_parameter_sets_state_t *state)
{
    uint8_t i;

    if (state == 0) return;

    memset(state, 0, sizeof(user_parameter_sets_state_t));
    state->initialized = 1;
    state->active_set_id = 0;
    state->param_count = 0;

    for (i = 0; i < USER_SET_COUNT; i++) {
        state->set_valid[i] = 0;
        state->set_version[i] = 0;
    }
}

void user_parameter_sets_update(user_parameter_sets_state_t *state)
{
    if (state == 0 || !state->initialized) return;

    if (state->save_in_progress) {
        state->last_save_tick++;
    }
    if (state->load_in_progress) {
        state->last_load_tick++;
    }
}
