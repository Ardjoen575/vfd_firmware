#include "router_mode_bcu.h"
#include <string.h>

static uint8_t bcu_route_lookup(router_mode_bcu_state_t *state, uint8_t dst_node,
                                 uint8_t *next_hop)
{
    uint8_t i;

    for (i = 0; i < state->node_count && i < BCU_NODE_MAX; i++) {
        if (state->route_table[i] == dst_node && state->nodes[i].online) {
            *next_hop = i;
            return 1;
        }
    }

    *next_hop = 0xFF;
    return 0;
}

static void bcu_process_frame(router_mode_bcu_state_t *state)
{
    bcu_frame_t *rx = &state->rx_buffer;
    uint8_t next_hop;

    if (rx->dst_node == state->node_id) {
        state->nodes[state->node_id].msg_rx_count++;
        return;
    }

    if (state->role == BCU_ROLE_ROUTER || state->role == BCU_ROLE_BRIDGE) {
        if (bcu_route_lookup(state, rx->dst_node, &next_hop)) {
            memcpy(&state->tx_buffer, rx, sizeof(bcu_frame_t));
            state->routing_packets++;
        } else {
            state->dropped_packets++;
        }
    }
}

static void bcu_send_heartbeat(router_mode_bcu_state_t *state)
{
    bcu_frame_t *tx = &state->tx_buffer;

    tx->node_id   = state->node_id;
    tx->msg_type  = BCU_MSG_HEARTBEAT;
    tx->src_node  = state->node_id;
    tx->dst_node  = 0xFF;
    tx->length    = 0;
    tx->checksum  = 0;
}

uint8_t router_mode_activate(router_mode_bcu_state_t *state, bcu_role_t role)
{
    uint8_t i;

    if (state == 0) return 0;
    if (role == BCU_ROLE_DISABLED) {
        state->active = 0;
        state->role = BCU_ROLE_DISABLED;
        state->routing_enabled = 0;
        state->brake_control_enabled = 0;
        return 1;
    }

    state->role = role;
    state->active = 1;

    switch (role) {
    case BCU_ROLE_MASTER:
        state->node_id = 0x01;
        state->routing_enabled = 1;
        state->brake_control_enabled = 1;
        break;
    case BCU_ROLE_SLAVE:
        state->routing_enabled = 0;
        state->brake_control_enabled = 0;
        break;
    case BCU_ROLE_ROUTER:
        state->routing_enabled = 1;
        state->brake_control_enabled = 0;
        break;
    case BCU_ROLE_BRIDGE:
        state->routing_enabled = 1;
        state->brake_control_enabled = 1;
        break;
    default:
        break;
    }

    state->node_count = 0;
    state->routing_packets = 0;
    state->dropped_packets = 0;
    state->uptime_ms = 0;

    for (i = 0; i < BCU_NODE_MAX; i++) {
        state->nodes[i].node_id    = 0;
        state->nodes[i].online     = 0;
        state->nodes[i].node_type  = 0;
        state->nodes[i].last_heartbeat = 0;
    }

    return 1;
}

void router_mode_bcu_init(router_mode_bcu_state_t *state)
{
    if (state == 0) return;

    memset(state, 0, sizeof(router_mode_bcu_state_t));
    state->initialized       = 1;
    state->role              = BCU_ROLE_DISABLED;
    state->active            = 0;
    state->routing_enabled   = 0;
    state->brake_control_enabled = 0;
    state->node_id           = 0;
}

void router_mode_bcu_update(router_mode_bcu_state_t *state)
{
    uint8_t i;

    if (state == 0 || !state->initialized) return;
    if (!state->active) return;

    state->uptime_ms++;

    if (state->uptime_ms % BCU_HEARTBEAT_MS == 0) {
        bcu_send_heartbeat(state);
        state->nodes[state->node_id].last_heartbeat = state->uptime_ms;
    }

    for (i = 0; i < state->node_count && i < BCU_NODE_MAX; i++) {
        if (state->nodes[i].online && i != state->node_id) {
            uint32_t elapsed = state->uptime_ms -
                               state->nodes[i].last_heartbeat;
            if (elapsed > (BCU_TIMEOUT_MS * 3)) {
                state->nodes[i].online = 0;
            }
        }
    }

    bcu_process_frame(state);
}
