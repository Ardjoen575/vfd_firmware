#ifndef MISC_ROUTER_MODE_BCU_H
#define MISC_ROUTER_MODE_BCU_H

#include <stdint.h>

#define BCU_NODE_MAX             16U
#define BCU_FRAME_MAX_LEN        64U
#define BCU_BAUDRATE_KBPS       125U
#define BCU_TIMEOUT_MS          100U
#define BCU_HEARTBEAT_MS        500U

typedef enum {
    BCU_ROLE_DISABLED      = 0,
    BCU_ROLE_MASTER        = 1,
    BCU_ROLE_SLAVE         = 2,
    BCU_ROLE_ROUTER        = 3,
    BCU_ROLE_BRIDGE        = 4,
} bcu_role_t;

typedef enum {
    BCU_MSG_ROUTE_REQUEST  = 0x01,
    BCU_MSG_ROUTE_RESPONSE = 0x02,
    BCU_MSG_DATA_TRANSFER  = 0x03,
    BCU_MSG_HEARTBEAT      = 0x04,
    BCU_MSG_NODE_STATUS    = 0x05,
    BCU_MSG_BRAKE_COMMAND  = 0x10,
    BCU_MSG_BRAKE_STATUS   = 0x11,
} bcu_msg_type_t;

typedef struct __attribute__((packed)) {
    uint8_t  node_id;
    uint8_t  msg_type;
    uint8_t  src_node;
    uint8_t  dst_node;
    uint8_t  length;
    uint8_t  data[BCU_FRAME_MAX_LEN - 5];
    uint8_t  checksum;
} bcu_frame_t;

typedef struct {
    uint8_t     node_id;
    uint8_t     online;
    uint8_t     node_type;
    uint32_t    last_heartbeat;
    uint32_t    msg_rx_count;
    uint32_t    msg_tx_count;
    uint32_t    error_count;
} bcu_node_t;

typedef struct {
    uint8_t    initialized;
    bcu_role_t role;
    uint8_t    active;
    uint8_t    routing_enabled;
    uint8_t    brake_control_enabled;
    uint8_t    node_count;
    uint32_t   route_table[BCU_NODE_MAX];
    uint32_t   uptime_ms;
    uint32_t   routing_packets;
    uint32_t   dropped_packets;
    uint32_t   last_rx_time;
    uint32_t   last_tx_time;
    bcu_node_t nodes[BCU_NODE_MAX];
    bcu_frame_t tx_buffer;
    bcu_frame_t rx_buffer;
} router_mode_bcu_state_t;

void router_mode_bcu_init(router_mode_bcu_state_t *state);
void router_mode_bcu_update(router_mode_bcu_state_t *state);
uint8_t router_mode_activate(router_mode_bcu_state_t *state, bcu_role_t role);

#endif
