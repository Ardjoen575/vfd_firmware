#ifndef MISC_REDUCED_RUN_H
#define MISC_REDUCED_RUN_H

#include <stdint.h>

#define RRUN_SPEED_SCALE_PERCENT   25U
#define RRUN_TORQUE_SCALE_PERCENT  30U
#define RRUN_CURRENT_LIMIT_SCALE   40U
#define RRUN_DC_BUS_REDUCED_V     400U
#define RRUN_MAX_DURATION_S       300U
#define RRUN_ACTIVATION_DELAY_S     2U
#define RRUN_RAMP_TIME_S            5U

typedef enum {
    RRUN_STATE_INACTIVE    = 0,
    RRUN_STATE_PENDING     = 1,
    RRUN_STATE_ACTIVE      = 2,
    RRUN_STATE_FAULT       = 3,
    RRUN_STATE_EXPIRED     = 4,
    RRUN_STATE_FORCED_OFF  = 5,
} reduced_run_state_t;

typedef struct {
    uint8_t             initialized;
    reduced_run_state_t state;
    uint8_t             trigger_source;
    uint8_t             emergency_override;
    uint32_t            activation_timer_s;
    uint32_t            duration_s;
    uint32_t            max_duration_s;
    int32_t             original_speed_ref;
    int32_t             original_torque_ref;
    int32_t             original_current_limit;
    int32_t             reduced_speed_ref;
    int32_t             reduced_torque_ref;
    int32_t             reduced_current_limit;
    uint8_t             speed_reduced;
    uint8_t             torque_reduced;
    uint8_t             current_limited;
    uint32_t            active_counter;
} reduced_run_state_t;

void reduced_run_init(reduced_run_state_t *state);
void reduced_run_update(reduced_run_state_t *state);
uint8_t reduced_run_activate(reduced_run_state_t *state, uint8_t trigger);
uint8_t reduced_run_deactivate(reduced_run_state_t *state);

#endif
