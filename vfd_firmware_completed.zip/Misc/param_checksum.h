#ifndef MISC_PARAM_CHECKSUM_H
#define MISC_PARAM_CHECKSUM_H

#include <stdint.h>

#define PARAM_COUNT_MAX      4096U
#define PARAM_CRC_POLY       0x1021U
#define PARAM_CRC_INIT       0xFFFFU

typedef struct {
    uint8_t  initialized;
    uint16_t computed_crc;
    uint16_t stored_crc;
    uint8_t  crc_valid;
    uint8_t  auto_verify;
    uint16_t param_count;
    uint32_t verify_counter;
    uint32_t last_verify_tick;
} param_checksum_state_t;

void param_checksum_init(param_checksum_state_t *state);
void param_checksum_update(param_checksum_state_t *state);
uint16_t param_checksum_calc(const int32_t *params, uint16_t count);
uint8_t param_checksum_verify(param_checksum_state_t *state,
                               const int32_t *params, uint16_t count);

#endif
