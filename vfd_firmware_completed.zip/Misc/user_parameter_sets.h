#ifndef MISC_USER_PARAMETER_SETS_H
#define MISC_USER_PARAMETER_SETS_H

#include <stdint.h>

#define USER_SET_COUNT          4U
#define USER_SET_PARAMS_MAX  4096U
#define USER_SET_FLASH_BASE  0x08004000UL
#define USER_SET_SIZE         0x00001000UL
#define USER_SET_MAGIC        0x5553A5A5UL

typedef enum {
    USERSET_ERR_NONE          = 0,
    USERSET_ERR_INVALID_ID    = 1,
    USERSET_ERR_FLASH_ERASE   = 2,
    USERSET_ERR_FLASH_WRITE   = 3,
    USERSET_ERR_FLASH_READ    = 4,
    USERSET_ERR_CHECKSUM      = 5,
    USERSET_ERR_MAGIC         = 6,
    USERSET_ERR_STORAGE       = 7,
} userset_error_t;

typedef struct __attribute__((packed)) {
    uint32_t magic;
    uint16_t param_count;
    uint16_t checksum;
    uint32_t version;
    int32_t  data[USER_SET_PARAMS_MAX];
} userset_flash_block_t;

typedef struct {
    uint8_t         initialized;
    uint8_t         active_set_id;
    uint8_t         pending_set_id;
    uint8_t         save_in_progress;
    uint8_t         load_in_progress;
    userset_error_t last_error;
    uint32_t        last_save_tick;
    uint32_t        last_load_tick;
    uint8_t         set_valid[USER_SET_COUNT];
    uint32_t        set_version[USER_SET_COUNT];
    uint16_t        param_count;
    int32_t         params[USER_SET_PARAMS_MAX];
} user_parameter_sets_state_t;

void user_parameter_sets_init(user_parameter_sets_state_t *state);
void user_parameter_sets_update(user_parameter_sets_state_t *state);
uint8_t user_set_save(user_parameter_sets_state_t *state, uint8_t set_id);
uint8_t user_set_load(user_parameter_sets_state_t *state, uint8_t set_id);

#endif
