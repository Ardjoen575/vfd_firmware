#include "reduced_run.h"
#include <string.h>

uint8_t reduced_run_activate(reduced_run_state_t *state, uint8_t trigger)
{
    if (state == 0) return 0;
    if (state->state == RRUN_STATE_ACTIVE) return 0;
    if (state->state == RRUN_STATE_FAULT) return 0;
    if (state->state == RRUN_STATE_EXPIRED) return 0;

    state->trigger_source = trigger;
    state->state = RRUN_STATE_PENDING;
    state->activation_timer_s = 0;

    state->original_speed_ref     = 0;
    state->original_torque_ref    = 0;
    state->original_current_limit = 0;

    state->reduced_speed_ref      = 0;
    state->reduced_torque_ref     = 0;
    state->reduced_current_limit  = 0;

    state->speed_reduced  = 0;
    state->torque_reduced = 0;
    state->current_limited = 0;

    return 1;
}

uint8_t reduced_run_deactivate(reduced_run_state_t *state)
{
    if (state == 0) return 0;

    if (state->state == RRUN_STATE_ACTIVE) {
        state->state = RRUN_STATE_FORCED_OFF;
    } else {
        state->state = RRUN_STATE_INACTIVE;
    }

    if (state->speed_reduced) {
        state->speed_reduced = 0;
    }
    if (state->torque_reduced) {
        state->torque_reduced = 0;
    }
    if (state->current_limited) {
        state->current_limited = 0;
    }

    state->activation_timer_s = 0;
    state->duration_s = 0;

    return 1;
}

void reduced_run_init(reduced_run_state_t *state)
{
    if (state == 0) return;

    memset(state, 0, sizeof(reduced_run_state_t));
    state->initialized       = 1;
    state->state             = RRUN_STATE_INACTIVE;
    state->trigger_source    = 0;
    state->emergency_override = 0;
    state->max_duration_s    = RRUN_MAX_DURATION_S;
}

void reduced_run_update(reduced_run_state_t *state)
{
    if (state == 0 || !state->initialized) return;

    switch (state->state) {

    case RRUN_STATE_INACTIVE:
        break;

    case RRUN_STATE_PENDING:
        state->activation_timer_s++;
        if (state->activation_timer_s >= RRUN_ACTIVATION_DELAY_S) {
            state->state = RRUN_STATE_ACTIVE;

            state->original_speed_ref     = state->reduced_speed_ref;
            state->original_torque_ref    = state->reduced_torque_ref;
            state->original_current_limit = state->reduced_current_limit;

            state->reduced_speed_ref = (state->original_speed_ref *
                                        RRUN_SPEED_SCALE_PERCENT) / 100;

            state->reduced_torque_ref = (state->original_torque_ref *
                                         RRUN_TORQUE_SCALE_PERCENT) / 100;

            state->reduced_current_limit = (state->original_current_limit *
                                            RRUN_CURRENT_LIMIT_SCALE) / 100;

            state->speed_reduced  = (state->original_speed_ref > 0) ? 1 : 0;
            state->torque_reduced = (state->original_torque_ref > 0) ? 1 : 0;
            state->current_limited = (state->original_current_limit > 0) ? 1 : 0;

            state->duration_s = 0;
            state->active_counter++;
        }
        break;

    case RRUN_STATE_ACTIVE:
        state->duration_s++;
        if (state->duration_s >= state->max_duration_s) {
            state->state = RRUN_STATE_EXPIRED;
            state->speed_reduced = 0;
            state->torque_reduced = 0;
            state->current_limited = 0;
        }
        break;

    case RRUN_STATE_FAULT:
        state->state = RRUN_STATE_INACTIVE;
        state->speed_reduced = 0;
        state->torque_reduced = 0;
        state->current_limited = 0;
        break;

    case RRUN_STATE_EXPIRED:
        if (state->emergency_override) {
            state->duration_s = 0;
            state->state = RRUN_STATE_ACTIVE;
            state->speed_reduced = 1;
            state->torque_reduced = 1;
            state->current_limited = 1;
        }
        break;

    case RRUN_STATE_FORCED_OFF:
        state->state = RRUN_STATE_INACTIVE;
        state->duration_s = 0;
        break;

    default:
        break;
    }
}
