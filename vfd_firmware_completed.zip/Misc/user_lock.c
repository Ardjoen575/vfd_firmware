#include "user_lock.h"
#include <string.h>

uint8_t user_lock_check(user_lock_state_t *state, uint16_t param_id)
{
    uint8_t i;

    if (state == 0) return 1;
    if (!state->locked) return 1;
    if (state->state == LOCK_STATE_LOCKOUT) return 0;

    if (state->state == LOCK_STATE_UNLOCKED) {
        if (!state->param_lock_active) return 1;
        for (i = 0; i < state->locked_param_count && i < 32; i++) {
            if (state->locked_params[i] == param_id) {
                return 0;
            }
        }
        return 1;
    }

    return 0;
}

void user_lock_enter_pin(user_lock_state_t *state, uint16_t pin)
{
    if (state == 0) return;

    if (state->state == LOCK_STATE_LOCKOUT) {
        return;
    }

    if (pin == state->user_pin) {
        state->state = LOCK_STATE_UNLOCKED;
        state->failed_attempts = 0;
        state->lockout_timer_s = 0;
    } else {
        state->failed_attempts++;
        if (state->failed_attempts >= USER_LOCK_MAX_ATTEMPTS) {
            state->state = LOCK_STATE_LOCKOUT;
            state->lockout_timer_s = USER_LOCK_TIMEOUT_S;
        }
    }
}

void user_lock_change_pin(user_lock_state_t *state,
                           uint16_t old_pin, uint16_t new_pin)
{
    if (state == 0) return;

    if (state->state != LOCK_STATE_UNLOCKED) return;

    if (old_pin == state->user_pin) {
        state->user_pin = new_pin;
        state->state = LOCK_STATE_LOCKED;
    }
}

void user_lock_init(user_lock_state_t *state)
{
    uint8_t i;
    if (state == 0) return;

    memset(state, 0, sizeof(user_lock_state_t));
    state->initialized = 1;
    state->locked   = 0;
    state->state    = LOCK_STATE_UNLOCKED;
    state->user_pin = USER_LOCK_PIN_DEFAULT;
    state->pin_index = 0;
    state->failed_attempts = 0;
    state->lockout_timer_s = 0;
    state->param_lock_active = 0;
    state->locked_param_count = 0;
    memset(state->pin_buffer, 0, USER_LOCK_PIN_LENGTH);
    for (i = 0; i < 32; i++) {
        state->locked_params[i] = 0;
    }
}

void user_lock_update(user_lock_state_t *state)
{
    if (state == 0 || !state->initialized) return;

    if (state->state == LOCK_STATE_LOCKOUT) {
        if (state->lockout_timer_s > 0) {
            state->lockout_timer_s--;
        } else {
            state->state = LOCK_STATE_LOCKED;
            state->failed_attempts = 0;
        }
    }
}
