#ifndef CORE_SYSTEM_CONFIG_H
#define CORE_SYSTEM_CONFIG_H

#include <stdint.h>

/* MCU Definition */
#define STM32F407xx
#define HSE_VALUE                8000000UL
#define HSI_VALUE               16000000UL

/* System Clock */
#define SYSTEM_CORE_CLOCK      168000000UL
#define APB1_TIMER_CLOCK        84000000UL
#define APB2_TIMER_CLOCK       168000000UL
#define APB1_CLOCK              42000000UL
#define APB2_CLOCK              84000000UL
#define AHB_CLOCK              168000000UL

/* PWM Configuration */
#define PWM_FREQUENCY              10000U
#define PWM_PERIOD_TICKS          ((APB2_TIMER_CLOCK / (PWM_FREQUENCY * 2UL)) - 1U)
#define PWM_DEADTIME_NS              500U
#define PWM_DEADTIME_TICKS         ((SYSTEM_CORE_CLOCK / 1000000UL) * (PWM_DEADTIME_NS) / 1000UL)

/* ADC Configuration */
#define ADC_SAMPLING_FREQ          20000U
#define ADC_NUM_CHANNELS               8U
#define ADC_RESOLUTION_BITS           12U
#define ADC_VREF_MV                 3300U
#define ADC_DMA_BUFFER_SIZE     (ADC_NUM_CHANNELS * 2U)

/* Control Loop */
#define CONTROL_LOOP_FREQ          10000U
#define CONTROL_LOOP_PERIOD_US    (1000000UL / CONTROL_LOOP_FREQ)
#define CURRENT_LOOP_FREQ          10000U
#define SPEED_LOOP_FREQ             1000U
#define FLUX_LOOP_FREQ               200U

/* DC Bus */
#define DC_BUS_NOMINAL_VOLTAGE       540U
#define DC_BUS_MAX_VOLTAGE           800U
#define DC_BUS_MIN_VOLTAGE           450U
#define DC_BUS_OVERVOLTAGE_TRIP      780U
#define DC_BUS_UNDERVOLTAGE_TRIP     400U
#define DC_BUS_BRAKING_THRESHOLD     750U

/* Protection Thresholds */
#define MOTOR_MAX_CURRENT_AMPS        300
#define MOTOR_MAX_SPEED_RPM         10000U
#define IGBT_MAX_TEMP_C               120
#define HEATSINK_MAX_TEMP_C            85

/* Memory Map - STM32F407xG (1MB Flash, 192KB SRAM) */
#define FLASH_BASE              0x08000000UL
#define FLASH_SIZE              (1024U * 1024U)
#define FLASH_END               (FLASH_BASE + FLASH_SIZE)

#define SRAM_BASE               0x20000000UL
#define SRAM_SIZE               (128U * 1024U)
#define SRAM_END                (SRAM_BASE + SRAM_SIZE)

#define CCMRAM_BASE             0x10000000UL
#define CCMRAM_SIZE             (64U * 1024U)
#define CCMRAM_END              (CCMRAM_BASE + CCMRAM_SIZE)

#define BKPSRAM_BASE            0x40024000UL
#define BKPSRAM_SIZE            (4U * 1024U)

/* Peripheral Base Addresses */
#define PERIPH_BASE             0x40000000UL
#define APB1PERIPH_BASE         PERIPH_BASE
#define APB2PERIPH_BASE         (PERIPH_BASE + 0x00010000UL)
#define AHB1PERIPH_BASE         (PERIPH_BASE + 0x00020000UL)
#define AHB2PERIPH_BASE         (PERIPH_BASE + 0x10000000UL)
#define AHB3PERIPH_BASE         (PERIPH_BASE + 0x60000000UL)

/* GPIO Base Addresses */
#define GPIOA_BASE              (AHB1PERIPH_BASE + 0x0000UL)
#define GPIOB_BASE              (AHB1PERIPH_BASE + 0x0400UL)
#define GPIOC_BASE              (AHB1PERIPH_BASE + 0x0800UL)
#define GPIOD_BASE              (AHB1PERIPH_BASE + 0x0C00UL)
#define GPIOE_BASE              (AHB1PERIPH_BASE + 0x1000UL)

/* Timer Base Addresses */
#define TIM1_BASE               (APB2PERIPH_BASE + 0x0000UL)
#define TIM2_BASE               (APB1PERIPH_BASE + 0x0000UL)
#define TIM3_BASE               (APB1PERIPH_BASE + 0x0400UL)
#define TIM4_BASE               (APB1PERIPH_BASE + 0x0800UL)
#define TIM5_BASE               (APB1PERIPH_BASE + 0x0C00UL)
#define TIM8_BASE               (APB2PERIPH_BASE + 0x0400UL)

/* ADC Base Addresses */
#define ADC1_BASE               (APB2PERIPH_BASE + 0x2000UL)
#define ADC2_BASE               (APB2PERIPH_BASE + 0x2100UL)
#define ADC3_BASE               (APB2PERIPH_BASE + 0x2200UL)
#define ADC_COMMON_BASE         (APB2PERIPH_BASE + 0x2300UL)

/* Communication Peripheral Base Addresses */
#define USART1_BASE             (APB2PERIPH_BASE + 0x1000UL)
#define USART2_BASE             (APB1PERIPH_BASE + 0x4400UL)
#define USART3_BASE             (APB1PERIPH_BASE + 0x4800UL)
#define UART4_BASE              (APB1PERIPH_BASE + 0x4C00UL)
#define UART5_BASE              (APB1PERIPH_BASE + 0x5000UL)
#define SPI1_BASE               (APB2PERIPH_BASE + 0x3000UL)
#define SPI2_BASE               (APB1PERIPH_BASE + 0x3800UL)
#define SPI3_BASE               (APB1PERIPH_BASE + 0x3C00UL)
#define I2C1_BASE               (APB1PERIPH_BASE + 0x5400UL)
#define I2C2_BASE               (APB1PERIPH_BASE + 0x5800UL)
#define I2C3_BASE               (APB1PERIPH_BASE + 0x5C00UL)
#define CAN1_BASE               (APB1PERIPH_BASE + 0x6400UL)
#define CAN2_BASE               (APB1PERIPH_BASE + 0x6800UL)
#define USB_OTG_FS_BASE         (AHB2PERIPH_BASE + 0x00000000UL)
#define ETHERNET_BASE           (AHB1PERIPH_BASE + 0x8000UL)

/* DMA Base Addresses */
#define DMA1_BASE               (AHB1PERIPH_BASE + 0x6000UL)
#define DMA2_BASE               (AHB1PERIPH_BASE + 0x6400UL)

/* CRC, RNG, RTC */
#define CRC_BASE                (AHB1PERIPH_BASE + 0x3000UL)
#define RNG_BASE                (AHB2PERIPH_BASE + 0x0800UL)
#define RTC_BASE               (APB1PERIPH_BASE + 0x2800UL)
#define FLASH_R_BASE            (AHB1PERIPH_BASE + 0x3C00UL)

/* FreeRTOS Configuration */
#include "FreeRTOSConfig.h"

#if (configSUPPORT_STATIC_ALLOCATION == 1)
#define RTOS_USE_STATIC_ALLOCATION    1
#else
#define RTOS_USE_STATIC_ALLOCATION    0
#endif

/* Task Stack Sizes (in words) */
#define STACK_SIZE_CONTROL_LOOP         512U
#define STACK_SIZE_COMMUNICATION        384U
#define STACK_SIZE_USER_INTERFACE       384U
#define STACK_SIZE_MONITORING           256U
#define STACK_SIZE_DIAGNOSTICS          384U
#define STACK_SIZE_STATE_MACHINE        256U
#define STACK_SIZE_SAFETY               256U
#define STACK_SIZE_IDLE_TASK            128U

/* Task Priorities (higher number = higher priority) */
#define PRIORITY_CONTROL_LOOP            (configMAX_PRIORITIES - 1)
#define PRIORITY_STATE_MACHINE           (configMAX_PRIORITIES - 2)
#define PRIORITY_SAFETY                  (configMAX_PRIORITIES - 3)
#define PRIORITY_COMMUNICATION           (configMAX_PRIORITIES - 4)
#define PRIORITY_MONITORING              (configMAX_PRIORITIES - 5)
#define PRIORITY_DIAGNOSTICS             (configMAX_PRIORITIES - 6)
#define PRIORITY_USER_INTERFACE          (configMAX_PRIORITIES - 7)

/* Task Periods in ticks (assuming 1 kHz tick = 1 ms) */
#define PERIOD_CONTROL_LOOP_TICKS         1U
#define PERIOD_COMMUNICATION_TICKS        1U
#define PERIOD_MONITORING_TICKS          10U
#define PERIOD_USER_INTERFACE_TICKS      10U
#define PERIOD_DIAGNOSTICS_TICKS        100U
#define PERIOD_STATE_MACHINE_TICKS        1U
#define PERIOD_SAFETY_TICKS               1U

/* Queue Sizes */
#define QUEUE_LENGTH_CONTROL_CMD          8U
#define QUEUE_LENGTH_DRIVE_EVENT         16U
#define QUEUE_LENGTH_MEASUREMENT          8U
#define QUEUE_LENGTH_DIAG_EVENT          32U
#define QUEUE_LENGTH_COMMS_TX            16U

/* BSP Init Macros */
#define BSP_ENABLE_ALL_CLOCKS()  do { \
    __HAL_RCC_GPIOA_CLK_ENABLE(); \
    __HAL_RCC_GPIOB_CLK_ENABLE(); \
    __HAL_RCC_GPIOC_CLK_ENABLE(); \
    __HAL_RCC_GPIOD_CLK_ENABLE(); \
    __HAL_RCC_GPIOE_CLK_ENABLE(); \
    __HAL_RCC_TIM1_CLK_ENABLE();  \
    __HAL_RCC_TIM8_CLK_ENABLE();  \
    __HAL_RCC_ADC1_CLK_ENABLE();  \
    __HAL_RCC_ADC2_CLK_ENABLE();  \
    __HAL_RCC_USART1_CLK_ENABLE(); \
    __HAL_RCC_USART2_CLK_ENABLE(); \
    __HAL_RCC_CAN1_CLK_ENABLE();  \
    __HAL_RCC_SPI1_CLK_ENABLE();  \
    __HAL_RCC_I2C1_CLK_ENABLE();  \
    __HAL_RCC_DMA1_CLK_ENABLE();  \
    __HAL_RCC_DMA2_CLK_ENABLE();  \
} while(0)

#endif /* CORE_SYSTEM_CONFIG_H */
