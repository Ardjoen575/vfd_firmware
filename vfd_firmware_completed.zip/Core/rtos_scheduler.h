#ifndef CORE_RTOS_SCHEDULER_H
#define CORE_RTOS_SCHEDULER_H

#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"

extern QueueHandle_t control_cmd_queue;
extern QueueHandle_t drive_event_queue;
extern QueueHandle_t measurement_queue;
extern QueueHandle_t diag_event_queue;
extern SemaphoreHandle_t adc_data_ready_sem;
extern SemaphoreHandle_t param_mutex;

extern TaskHandle_t control_task_handle;
extern TaskHandle_t comms_task_handle;
extern TaskHandle_t ui_task_handle;
extern TaskHandle_t monitoring_task_handle;
extern TaskHandle_t diagnostics_task_handle;
extern TaskHandle_t state_task_handle;
extern TaskHandle_t safety_task_handle;

void rtos_scheduler_init(void);
void rtos_scheduler_run(void);

#endif /* CORE_RTOS_SCHEDULER_H */
