#ifndef CORE_STATE_MACHINE_H
#define CORE_STATE_MACHINE_H

#include <stdint.h>
#include "vf_control.h"

typedef void (*state_change_callback_t)(drive_state_t old_state, drive_state_t new_state);

typedef struct {
    drive_state_t           current_state;
    drive_state_t           previous_state;
    drive_state_t           target_state;
    drive_state_t           fault_return_state;
    fault_record_t          active_fault;
    uint32_t                state_entry_time_ms;
    uint32_t                fault_entry_time_ms;
    uint32_t                fault_count;
    bool                    pre_charge_done;
    bool                    dc_bus_charged;
    bool                    safety_relay_closed;
    bool                    run_command_active;
    bool                    stop_command_active;
    bool                    emergency_stop_active;
    bool                    fault_reset_requested;
    uint32_t                last_transition_ms;
    state_change_callback_t on_state_change;
} state_machine_t;

void state_machine_init(void);
void state_machine_run(void);

void state_machine_request_run(void);
void state_machine_request_stop(void);
void state_machine_request_emergency_stop(void);
void state_machine_request_fault_reset(void);
void state_machine_raise_fault(fault_code_t code, fault_severity_t severity);
void state_machine_register_callback(state_change_callback_t cb);
drive_state_t state_machine_get_state(void);
bool state_machine_is_running(void);
bool state_machine_is_faulted(void);

#endif /* CORE_STATE_MACHINE_H */
