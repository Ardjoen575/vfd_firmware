#include "state_machine.h"
#include "rtos_scheduler.h"
#include "system_config.h"
#include <string.h>

static state_machine_t sm;

static const char *state_name(drive_state_t s);
static bool transition_to(drive_state_t new_state);
static bool evaluate_transition(drive_state_t target);
static void enter_state(drive_state_t s);
static void exit_state(drive_state_t s);
static void handle_not_ready(void);
static void handle_ready_on(void);
static void handle_ready_run(void);
static void handle_running(void);
static void handle_fault_reaction(void);
static void handle_fault(void);
static void handle_fault_reset(void);
static void handle_emergency_stop(void);
static void process_fault(fault_code_t code, fault_severity_t severity);
static void notify_state_change(drive_state_t old_state, drive_state_t new_state);

static uint32_t get_system_time_ms(void)
{
    return xTaskGetTickCount();
}

void state_machine_init(void)
{
    memset(&sm, 0, sizeof(sm));
    sm.current_state     = DRIVE_STATE_NOT_READY;
    sm.previous_state    = DRIVE_STATE_NOT_READY;
    sm.target_state      = DRIVE_STATE_NOT_READY;
    sm.state_entry_time_ms = get_system_time_ms();
    sm.pre_charge_done   = false;
    sm.dc_bus_charged     = false;
    sm.safety_relay_closed = false;
    sm.run_command_active  = false;
    sm.emergency_stop_active = false;
    sm.fault_reset_requested = false;
    sm.fault_count        = 0U;
    sm.on_state_change    = NULL;
}

void state_machine_run(void)
{
    drive_state_t current = sm.current_state;

    switch (current) {
    case DRIVE_STATE_NOT_READY:
        handle_not_ready();
        break;
    case DRIVE_STATE_SWITCH_ON_DISABLED:
        handle_not_ready();
        break;
    case DRIVE_STATE_READY_ON:
        handle_ready_on();
        break;
    case DRIVE_STATE_READY_RUN:
        handle_ready_run();
        break;
    case DRIVE_STATE_RUNNING:
        handle_running();
        break;
    case DRIVE_STATE_FAULT_REACTION:
        handle_fault_reaction();
        break;
    case DRIVE_STATE_FAULT:
        handle_fault();
        break;
    case DRIVE_STATE_FAULT_RESET:
        handle_fault_reset();
        break;
    case DRIVE_STATE_EMERGENCY_STOP:
        handle_emergency_stop();
        break;
    default:
        sm.target_state = DRIVE_STATE_NOT_READY;
        break;
    }

    sm.emergency_stop_active   = false;
    sm.run_command_active       = false;
    sm.stop_command_active      = false;
    sm.fault_reset_requested    = false;
}

static void handle_not_ready(void)
{
    sm.target_state = DRIVE_STATE_NOT_READY;

    if (sm.dc_bus_charged && sm.pre_charge_done) {
        sm.target_state = DRIVE_STATE_READY_ON;
    } else if (sm.dc_bus_charged) {
        sm.target_state = DRIVE_STATE_SWITCH_ON_DISABLED;
    }

    evaluate_transition(sm.target_state);
}

static void handle_ready_on(void)
{
    sm.target_state = DRIVE_STATE_READY_ON;

    if (sm.run_command_active && sm.dc_bus_charged) {
        sm.target_state = DRIVE_STATE_READY_RUN;
    }

    evaluate_transition(sm.target_state);
}

static void handle_ready_run(void)
{
    sm.target_state = DRIVE_STATE_READY_RUN;

    if (sm.stop_command_active) {
        sm.target_state = DRIVE_STATE_READY_ON;
    } else if (sm.run_command_active && sm.dc_bus_charged) {
        sm.target_state = DRIVE_STATE_RUNNING;
    }

    evaluate_transition(sm.target_state);
}

static void handle_running(void)
{
    sm.target_state = DRIVE_STATE_RUNNING;

    if (sm.emergency_stop_active) {
        sm.target_state = DRIVE_STATE_EMERGENCY_STOP;
    } else if (sm.stop_command_active) {
        sm.target_state = DRIVE_STATE_READY_ON;
    }

    evaluate_transition(sm.target_state);
}

static void handle_fault_reaction(void)
{
    sm.target_state = sm.fault_return_state;

    if (sm.emergency_stop_active) {
        sm.target_state = DRIVE_STATE_EMERGENCY_STOP;
    }

    evaluate_transition(sm.target_state);
}

static void handle_fault(void)
{
    sm.target_state = DRIVE_STATE_FAULT;

    if (sm.fault_reset_requested) {
        sm.target_state = DRIVE_STATE_FAULT_RESET;
    }

    evaluate_transition(sm.target_state);
}

static void handle_fault_reset(void)
{
    sm.target_state = DRIVE_STATE_FAULT;

    if (sm.dc_bus_charged && sm.pre_charge_done) {
        sm.target_state = DRIVE_STATE_READY_ON;
    } else {
        sm.target_state = DRIVE_STATE_SWITCH_ON_DISABLED;
    }

    evaluate_transition(sm.target_state);
}

static void handle_emergency_stop(void)
{
    sm.target_state = DRIVE_STATE_EMERGENCY_STOP;

    if (!sm.emergency_stop_active) {
        sm.target_state = DRIVE_STATE_FAULT;
        sm.fault_return_state = DRIVE_STATE_FAULT;
    }

    evaluate_transition(sm.target_state);
}

static bool transition_to(drive_state_t new_state)
{
    if (new_state == sm.current_state) {
        return false;
    }

    exit_state(sm.current_state);
    drive_state_t old = sm.current_state;
    sm.current_state  = new_state;
    sm.last_transition_ms = get_system_time_ms();
    enter_state(new_state);
    notify_state_change(old, new_state);
    return true;
}

static bool evaluate_transition(drive_state_t target)
{
    if (target != sm.current_state) {
        return transition_to(target);
    }
    return false;
}

static void enter_state(drive_state_t s)
{
    sm.previous_state     = sm.current_state;
    sm.state_entry_time_ms = get_system_time_ms();

    switch (s) {
    case DRIVE_STATE_READY_ON:
        /* Close main contactor / safety relay */
        sm.safety_relay_closed = true;
        break;
    case DRIVE_STATE_READY_RUN:
        /* Energize gate drivers */
        break;
    case DRIVE_STATE_RUNNING:
        /* Reset soft-start ramp */
        /* Enable PWM outputs */
        break;
    case DRIVE_STATE_FAULT:
        /* Disable PWM outputs */
        /* Open main contactor */
        sm.safety_relay_closed = false;
        sm.fault_entry_time_ms = get_system_time_ms();
        break;
    case DRIVE_STATE_EMERGENCY_STOP:
        /* Immediate PWM disable */
        /* Coast stop */
        sm.safety_relay_closed = false;
        break;
    case DRIVE_STATE_FAULT_RESET:
        /* Latch relays open until reset complete */
        sm.safety_relay_closed = false;
        break;
    default:
        break;
    }
}

static void exit_state(drive_state_t s)
{
    switch (s) {
    case DRIVE_STATE_RUNNING:
        /* Ramp down PWM, disable outputs */
        break;
    case DRIVE_STATE_FAULT:
        sm.active_fault.code     = FAULT_NONE;
        sm.active_fault.severity = FAULT_SEVERITY_INFO;
        sm.active_fault.latched  = false;
        break;
    default:
        break;
    }
}

void state_machine_request_run(void)
{
    sm.run_command_active = true;
    sm.stop_command_active = false;
}

void state_machine_request_stop(void)
{
    sm.stop_command_active = true;
    sm.run_command_active  = false;
}

void state_machine_request_emergency_stop(void)
{
    sm.emergency_stop_active = true;
    sm.run_command_active    = false;
    sm.stop_command_active   = false;
}

void state_machine_request_fault_reset(void)
{
    if (sm.current_state == DRIVE_STATE_FAULT) {
        sm.fault_reset_requested = true;
    }
}

void state_machine_raise_fault(fault_code_t code, fault_severity_t severity)
{
    sm.fault_return_state = sm.current_state;
    process_fault(code, severity);
    transition_to(DRIVE_STATE_FAULT_REACTION);

    switch (severity) {
    case FAULT_SEVERITY_FATAL:
    case FAULT_SEVERITY_CRITICAL:
        transition_to(DRIVE_STATE_FAULT);
        break;
    case FAULT_SEVERITY_WARNING:
    case FAULT_SEVERITY_INFO:
        break;
    default:
        transition_to(DRIVE_STATE_FAULT);
        break;
    }
}

void state_machine_register_callback(state_change_callback_t cb)
{
    sm.on_state_change = cb;
}

drive_state_t state_machine_get_state(void)
{
    return sm.current_state;
}

bool state_machine_is_running(void)
{
    return (sm.current_state == DRIVE_STATE_RUNNING);
}

bool state_machine_is_faulted(void)
{
    return (sm.current_state == DRIVE_STATE_FAULT ||
            sm.current_state == DRIVE_STATE_FAULT_REACTION);
}

static void process_fault(fault_code_t code, fault_severity_t severity)
{
    sm.active_fault.code        = code;
    sm.active_fault.severity    = severity;
    sm.active_fault.timestamp_ms = get_system_time_ms();
    sm.active_fault.occurrence_count++;
    sm.active_fault.latched     = true;
    sm.fault_count++;

    fault_record_t event = sm.active_fault;

    if (diag_event_queue != NULL) {
        xQueueSend(diag_event_queue, &event, 0);
    }

    drive_event_t de;
    de.type        = EVENT_FAULT_OCCURRED;
    de.timestamp_ms = get_system_time_ms();
    de.data        = &event;
    de.data_len    = sizeof(event);

    if (drive_event_queue != NULL) {
        xQueueSend(drive_event_queue, &de, 0);
    }
}

static void notify_state_change(drive_state_t old_state, drive_state_t new_state)
{
    if (sm.on_state_change != NULL) {
        sm.on_state_change(old_state, new_state);
    }

    drive_event_t event;
    event.type         = EVENT_STATE_CHANGE;
    event.timestamp_ms  = sm.last_transition_ms;
    event.data         = NULL;
    event.data_len     = 0;

    if (drive_event_queue != NULL) {
        xQueueSend(drive_event_queue, &event, 0);
    }
}

static const char *state_name(drive_state_t s)
{
    switch (s) {
    case DRIVE_STATE_NOT_READY:          return "NOT_READY";
    case DRIVE_STATE_SWITCH_ON_DISABLED: return "SWITCH_ON_DISABLED";
    case DRIVE_STATE_READY_ON:           return "READY_ON";
    case DRIVE_STATE_READY_RUN:          return "READY_RUN";
    case DRIVE_STATE_RUNNING:            return "RUNNING";
    case DRIVE_STATE_FAULT_REACTION:     return "FAULT_REACTION";
    case DRIVE_STATE_FAULT:              return "FAULT";
    case DRIVE_STATE_FAULT_RESET:        return "FAULT_RESET";
    case DRIVE_STATE_EMERGENCY_STOP:     return "EMERGENCY_STOP";
    default:                              return "UNKNOWN";
    }
}
