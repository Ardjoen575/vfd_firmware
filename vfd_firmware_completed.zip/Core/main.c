#include "system_config.h"
#include "vf_control.h"
#include "rtos_scheduler.h"
#include "state_machine.h"

#include "stm32f4xx_hal.h"

static void system_clock_config(void);
static void bsp_peripheral_init(void);
static void bsp_watchdog_init(void);

int main(void)
{
    HAL_Init();
    system_clock_config();
    bsp_watchdog_init();
    bsp_peripheral_init();

    state_machine_init();
    rtos_scheduler_init();

    rtos_scheduler_run();

    for (;;) {
        /* Execution never reaches here -- vTaskStartScheduler does not return */
    }

    return 0;
}

static void system_clock_config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
    RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};

    HAL_PWR_EnableBkUpAccess();

    __HAL_RCC_HSE_CONFIG(RCC_HSE_ON);

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE
                                     | RCC_OSCILLATORTYPE_LSE;
    RCC_OscInitStruct.HSEState       = RCC_HSE_ON;
    RCC_OscInitStruct.LSEState       = RCC_LSE_ON;
    RCC_OscInitStruct.PLL.PLLState   = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource  = RCC_PLLSOURCE_HSE;
    RCC_OscInitStruct.PLL.PLLM       = (HSE_VALUE / 1000000U);
    RCC_OscInitStruct.PLL.PLLN       = 336;
    RCC_OscInitStruct.PLL.PLLP       = RCC_PLLP_DIV2;
    RCC_OscInitStruct.PLL.PLLQ       = 7;

    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
        for (;;) {}
    }

    HAL_PWREx_EnableOverDrive();

    RCC_ClkInitStruct.ClockType      = RCC_CLOCKTYPE_HCLK
                                     | RCC_CLOCKTYPE_SYSCLK
                                     | RCC_CLOCKTYPE_PCLK1
                                     | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK) {
        for (;;) {}
    }

    PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_I2S;
    PeriphClkInitStruct.PLLI2S.PLLI2SN       = 192;
    PeriphClkInitStruct.PLLI2S.PLLI2SR       = 2;

    if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK) {
        for (;;) {}
    }

    SystemCoreClockUpdate();
}

static void bsp_peripheral_init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    BSP_ENABLE_ALL_CLOCKS();

    /* PWM fault and enable input pins */
    GPIO_InitStruct.Mode  = GPIO_MODE_IT_FALLING;
    GPIO_InitStruct.Pull  = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Pin   = GPIO_PIN_12;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    /* Enable gate driver fault interrupt */
    HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

    /* User button / fault reset */
    GPIO_InitStruct.Mode  = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull  = GPIO_NOPULL;
    GPIO_InitStruct.Pin   = GPIO_PIN_0;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* Status LEDs */
    GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull  = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Pin   = GPIO_PIN_12 | GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

    HAL_GPIO_WritePin(GPIOD,
                      GPIO_PIN_12 | GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15,
                      GPIO_PIN_RESET);

    /* ADC init callback registered, DMA transfers started */
    /* PWM init with complementary channels and deadtime */
    /* Communication peripherals init (USART, CAN, SPI) */
    /* Set NVIC priority grouping to 4 bits pre-emption priority */
    HAL_NVIC_SetPriorityGrouping(NVIC_PRIORITYGROUP_4);
}

static void bsp_watchdog_init(void)
{
    IWDG_HandleTypeDef hiwdg;
    hiwdg.Instance       = IWDG;
    hiwdg.Init.Prescaler = IWDG_PRESCALER_64;
    hiwdg.Init.Reload    = 4095;
    /* Watchdog started after RTOS tasks are running */
    UNUSED(hiwdg);
}

void HAL_IWDG_MspInit(IWDG_HandleTypeDef *hiwdg)
{
    if (hiwdg->Instance == IWDG) {
        (void)hiwdg;
    }
}

void SystemClock_Config(void)
{
    system_clock_config();
}
