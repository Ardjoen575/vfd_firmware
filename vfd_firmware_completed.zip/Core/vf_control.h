#ifndef CORE_VF_CONTROL_H
#define CORE_VF_CONTROL_H

#include <stdint.h>
#include <stdbool.h>

/* Drive State Enum */
typedef enum {
    DRIVE_STATE_NOT_READY = 0,
    DRIVE_STATE_SWITCH_ON_DISABLED,
    DRIVE_STATE_READY_ON,
    DRIVE_STATE_READY_RUN,
    DRIVE_STATE_RUNNING,
    DRIVE_STATE_FAULT_REACTION,
    DRIVE_STATE_FAULT,
    DRIVE_STATE_FAULT_RESET,
    DRIVE_STATE_EMERGENCY_STOP
} drive_state_t;

/* Motor Control Mode */
typedef enum {
    CONTROL_MODE_SCALAR_VF       = 0,
    CONTROL_MODE_DTC             = 1,
    CONTROL_MODE_FOC_VOLTAGE     = 2,
    CONTROL_MODE_FOC_CURRENT     = 3,
    CONTROL_MODE_SENSORLESS_DTC  = 4,
    CONTROL_MODE_ENCODER_FOC     = 5,
    CONTROL_MODE_OPEN_LOOP       = 6,
    CONTROL_MODE_DWELL           = 7,
    CONTROL_MODE_DC_INJECTION    = 8
} control_mode_t;

/* Run / Stop Command */
typedef enum {
    CMD_STOP               = 0,
    CMD_RUN_FORWARD        = 1,
    CMD_RUN_REVERSE        = 2,
    CMD_COAST              = 3,
    CMD_EMERGENCY_STOP     = 4,
    CMD_FAULT_RESET        = 5,
    CMD_DWELL_ENABLE       = 6,
    CMD_DC_INJECTION       = 7,
    CMD_STOP_IDLE          = 8
} drive_command_t;

/* Motor Direction */
typedef enum {
    DIR_FORWARD = 0,
    DIR_REVERSE = 1
} motor_direction_t;

/* Fault Severity */
typedef enum {
    FAULT_SEVERITY_INFO     = 0,
    FAULT_SEVERITY_WARNING  = 1,
    FAULT_SEVERITY_CRITICAL = 2,
    FAULT_SEVERITY_FATAL    = 3
} fault_severity_t;

/* Fault Code Enumeration */
typedef enum {
    FAULT_NONE                        = 0,
    FAULT_OVERCURRENT                 = 1,
    FAULT_OVERVOLTAGE_DC_BUS          = 2,
    FAULT_UNDERVOLTAGE_DC_BUS         = 3,
    FAULT_OVERTEMP_IGBT               = 4,
    FAULT_OVERTEMP_HEATSINK           = 5,
    FAULT_OVERTEMP_MOTOR              = 6,
    FAULT_OVERSPEED                   = 7,
    FAULT_PHASE_LOSS_INPUT            = 8,
    FAULT_PHASE_LOSS_OUTPUT           = 9,
    FAULT_EARTH_FAULT                 = 10,
    FAULT_GATE_DRIVER                 = 11,
    FAULT_MOTOR_STALL                 = 12,
    FAULT_ENCODER_LOSS                = 13,
    FAULT_COMMUNICATION_LOSS          = 14,
    FAULT_CPU_OVERLOAD                = 15,
    FAULT_EEPROM_ERROR                = 16,
    FAULT_PARAMETER_ERROR             = 17,
    FAULT_EXTERNAL_TRIP               = 18,
    FAULT_INT_WATCHDOG                = 19,
    FAULT_SAFETY_TORQUE_OFF           = 20,
    FAULT_HARDWARE_OVERCURRENT        = 21,
    FAULT_BRAKE_CHOPPER_OVERLOAD      = 22,
    FAULT_DC_BUS_RIPPLE               = 23,
    FAULT_PRE_CHARGE_FAILURE          = 24,
    FAULT_ANALOG_INPUT_LOSS           = 25,
    FAULT_MAX
} fault_code_t;

/* Fault Record */
typedef struct {
    fault_code_t     code;
    fault_severity_t severity;
    uint32_t         timestamp_ms;
    uint32_t         occurrence_count;
    uint16_t         dc_bus_voltage;
    uint16_t         motor_current;
    uint16_t         heatsink_temp;
    uint16_t         motor_speed;
    bool             latched;
} fault_record_t;

/* Drive Parameters (persistent configuration) */
typedef struct {
    float    motor_rated_voltage;
    float    motor_rated_current;
    float    motor_rated_frequency;
    float    motor_rated_speed_rpm;
    float    motor_pole_pairs;
    float    motor_rs;                 /* stator resistance */
    float    motor_ls;                 /* stator inductance */
    float    motor_flux;               /* rotor flux linkage */
    float    motor_inertia;
    float    motor_rated_power;
    float    accel_time_s;
    float    decel_time_s;
    float    min_frequency;
    float    max_frequency;
    float    vf_boost_voltage;
    float    vf_boost_frequency;
    float    vf_base_frequency;
    float    vf_base_voltage;
    float    dc_bus_nominal;
    float    dc_bus_braking_threshold;
    float    current_limit_motor;
    float    current_limit_generator;
    float    overcurrent_trip;
    float    overspeed_trip;
    float    speed_kp;
    float    speed_ki;
    float    current_kp;
    float    current_ki;
    float    flux_kp;
    float    flux_ki;
    uint8_t  control_mode;
    uint8_t  pwm_frequency_khz;
    uint8_t  encoder_ppr;
    bool     flying_start_enabled;
    bool     dc_braking_enabled;
    bool     auto_reset_enabled;
    uint8_t  auto_reset_attempts;
    uint16_t auto_reset_delay_ms;
    uint16_t motor_start_delay_ms;
    float    dc_braking_current;
    float    dc_braking_time_s;
    float    skip_frequency_1;
    float    skip_frequency_2;
    float    skip_bandwidth;
    uint32_t checksum;
} drive_params_t;

/* ADC Readings (raw + converted) */
typedef struct {
    uint16_t raw[8];
    float    ia;
    float    ib;
    float    ic;
    float    dc_bus;
    float    heatsink_temp;
    float    ambient_temp;
    float    analog_in_1;
    float    analog_in_2;
} adc_readings_t;

/* Motor State Snapshot */
typedef struct {
    float    ia;
    float    ib;
    float    ic;
    float    id;
    float    iq;
    float    vd;
    float    vq;
    float    va;
    float    vb;
    float    vc;
    float    dc_bus_voltage;
    float    speed_rpm;
    float    speed_ref_rpm;
    float    frequency_hz;
    float    torque_nm;
    float    power_kw;
    float    motor_temp_c;
    float    heatsink_temp_c;
    float    modulation_index;
    float    electrical_angle;
    float    mechanical_angle;
    int16_t  pwm_duty_a;
    int16_t  pwm_duty_b;
    int16_t  pwm_duty_c;
} motor_state_t;

/* Control Reference (setpoint) */
typedef struct {
    control_mode_t   mode;
    drive_command_t  cmd;
    motor_direction_t direction;
    float            speed_ref_rpm;
    float            frequency_ref_hz;
    float            torque_ref_nm;
    float            flux_ref;
    float            id_ref;
    float            iq_ref;
    float            dc_current_target;
    uint8_t          digital_outputs;
    bool             enable;
    bool             brake_release;
} control_reference_t;

/* Drive Event for inter-task communication */
typedef enum {
    EVENT_NONE             = 0,
    EVENT_STATE_CHANGE     = 1,
    EVENT_FAULT_OCCURRED   = 2,
    EVENT_FAULT_CLEARED    = 3,
    EVENT_RUN_COMMAND      = 4,
    EVENT_STOP_COMMAND     = 5,
    EVENT_SPEED_REF_CHANGE = 6,
    EVENT_OVERCURRENT_WARN = 7,
    EVENT_OVERVOLTAGE_WARN = 8,
    EVENT_OVERTEMP_WARN    = 9,
    EVENT_COMMS_TIMEOUT    = 10,
    EVENT_DC_BUS_READY     = 11,
    EVENT_PRE_CHARGE_DONE  = 12,
    EVENT_PARAM_UPDATE     = 13,
    EVENT_BRAKE_ENGAGED    = 14,
    EVENT_BRAKE_RELEASED   = 15,
    EVENT_EMERGENCY_STOP   = 16,
    EVENT_SAFETY_VIOLATION = 17,
    EVENT_SHUTDOWN         = 18,
    EVENT_HEARTBEAT        = 19,
    EVENT_MOTOR_DATA_READY = 20,
    EVENT_MAX
} drive_event_type_t;

typedef struct {
    drive_event_type_t type;
    uint32_t           timestamp_ms;
    void              *data;
    uint32_t           data_len;
} drive_event_t;

/* Control Command Queue Item */
typedef struct {
    control_reference_t ref;
    uint32_t            sequence;
    uint32_t            timestamp_ms;
} control_cmd_t;

#endif /* CORE_VF_CONTROL_H */
