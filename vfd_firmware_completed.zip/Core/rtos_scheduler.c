#include "rtos_scheduler.h"
#include "system_config.h"
#include "vf_control.h"

QueueHandle_t  control_cmd_queue   = NULL;
QueueHandle_t  drive_event_queue   = NULL;
QueueHandle_t  measurement_queue   = NULL;
QueueHandle_t  diag_event_queue    = NULL;
SemaphoreHandle_t adc_data_ready_sem = NULL;
SemaphoreHandle_t param_mutex        = NULL;

TaskHandle_t control_task_handle     = NULL;
TaskHandle_t comms_task_handle       = NULL;
TaskHandle_t ui_task_handle          = NULL;
TaskHandle_t monitoring_task_handle  = NULL;
TaskHandle_t diagnostics_task_handle = NULL;
TaskHandle_t state_task_handle       = NULL;
TaskHandle_t safety_task_handle      = NULL;

#if (RTOS_USE_STATIC_ALLOCATION == 1)
static StackType_t control_task_stack[STACK_SIZE_CONTROL_LOOP];
static StackType_t comms_task_stack[STACK_SIZE_COMMUNICATION];
static StackType_t ui_task_stack[STACK_SIZE_USER_INTERFACE];
static StackType_t monitoring_task_stack[STACK_SIZE_MONITORING];
static StackType_t diagnostics_task_stack[STACK_SIZE_DIAGNOSTICS];
static StackType_t state_task_stack[STACK_SIZE_STATE_MACHINE];
static StackType_t safety_task_stack[STACK_SIZE_SAFETY];
static StaticTask_t control_task_tcb;
static StaticTask_t comms_task_tcb;
static StaticTask_t ui_task_tcb;
static StaticTask_t monitoring_task_tcb;
static StaticTask_t diagnostics_task_tcb;
static StaticTask_t state_task_tcb;
static StaticTask_t safety_task_tcb;
#endif

static void task_control_loop(void *pvParameters);
static void task_communication(void *pvParameters);
static void task_user_interface(void *pvParameters);
static void task_monitoring(void *pvParameters);
static void task_diagnostics(void *pvParameters);
static void task_state_machine_wrapper(void *pvParameters);
static void task_safety(void *pvParameters);

static void watchdog_refresh(void);

static BaseType_t create_all_tasks(void);
static BaseType_t create_all_queues(void);
static BaseType_t create_all_semaphores(void);

static volatile uint32_t system_tick_ms = 0U;

void rtos_scheduler_init(void)
{
    if (create_all_queues() != pdPASS) {
        for (;;) {}
    }

    if (create_all_semaphores() != pdPASS) {
        for (;;) {}
    }

    if (create_all_tasks() != pdPASS) {
        for (;;) {}
    }
}

void rtos_scheduler_run(void)
{
    vTaskStartScheduler();

    for (;;) {
        /* vTaskStartScheduler does not return if successful */
    }
}

static BaseType_t create_all_queues(void)
{
    control_cmd_queue = xQueueCreate(QUEUE_LENGTH_CONTROL_CMD, sizeof(control_cmd_t));
    if (control_cmd_queue == NULL) {
        return pdFAIL;
    }

    drive_event_queue = xQueueCreate(QUEUE_LENGTH_DRIVE_EVENT, sizeof(drive_event_t));
    if (drive_event_queue == NULL) {
        return pdFAIL;
    }

    measurement_queue = xQueueCreate(QUEUE_LENGTH_MEASUREMENT, sizeof(adc_readings_t));
    if (measurement_queue == NULL) {
        return pdFAIL;
    }

    diag_event_queue = xQueueCreate(QUEUE_LENGTH_DIAG_EVENT, sizeof(fault_record_t));
    if (diag_event_queue == NULL) {
        return pdFAIL;
    }

    return pdPASS;
}

static BaseType_t create_all_semaphores(void)
{
    adc_data_ready_sem = xSemaphoreCreateBinary();
    if (adc_data_ready_sem == NULL) {
        return pdFAIL;
    }

    param_mutex = xSemaphoreCreateMutex();
    if (param_mutex == NULL) {
        return pdFAIL;
    }

    return pdPASS;
}

static BaseType_t create_all_tasks(void)
{
    BaseType_t ret;

#if (RTOS_USE_STATIC_ALLOCATION == 1)
    ret = xTaskCreateStatic(task_control_loop,
                            "CtrlLoop",
                            STACK_SIZE_CONTROL_LOOP,
                            NULL,
                            PRIORITY_CONTROL_LOOP,
                            control_task_stack,
                            &control_task_tcb);
#else
    ret = xTaskCreate(task_control_loop,
                      "CtrlLoop",
                      STACK_SIZE_CONTROL_LOOP,
                      NULL,
                      PRIORITY_CONTROL_LOOP,
                      &control_task_handle);
#endif
    if (ret != pdPASS) return pdFAIL;

#if (RTOS_USE_STATIC_ALLOCATION == 1)
    ret = xTaskCreateStatic(task_communication,
                            "Comms",
                            STACK_SIZE_COMMUNICATION,
                            NULL,
                            PRIORITY_COMMUNICATION,
                            comms_task_stack,
                            &comms_task_tcb);
#else
    ret = xTaskCreate(task_communication,
                      "Comms",
                      STACK_SIZE_COMMUNICATION,
                      NULL,
                      PRIORITY_COMMUNICATION,
                      &comms_task_handle);
#endif
    if (ret != pdPASS) return pdFAIL;

#if (RTOS_USE_STATIC_ALLOCATION == 1)
    ret = xTaskCreateStatic(task_user_interface,
                            "UI",
                            STACK_SIZE_USER_INTERFACE,
                            NULL,
                            PRIORITY_USER_INTERFACE,
                            ui_task_stack,
                            &ui_task_tcb);
#else
    ret = xTaskCreate(task_user_interface,
                      "UI",
                      STACK_SIZE_USER_INTERFACE,
                      NULL,
                      PRIORITY_USER_INTERFACE,
                      &ui_task_handle);
#endif
    if (ret != pdPASS) return pdFAIL;

#if (RTOS_USE_STATIC_ALLOCATION == 1)
    ret = xTaskCreateStatic(task_monitoring,
                            "Monitor",
                            STACK_SIZE_MONITORING,
                            NULL,
                            PRIORITY_MONITORING,
                            monitoring_task_stack,
                            &monitoring_task_tcb);
#else
    ret = xTaskCreate(task_monitoring,
                      "Monitor",
                      STACK_SIZE_MONITORING,
                      NULL,
                      PRIORITY_MONITORING,
                      &monitoring_task_handle);
#endif
    if (ret != pdPASS) return pdFAIL;

#if (RTOS_USE_STATIC_ALLOCATION == 1)
    ret = xTaskCreateStatic(task_diagnostics,
                            "Diagn",
                            STACK_SIZE_DIAGNOSTICS,
                            NULL,
                            PRIORITY_DIAGNOSTICS,
                            diagnostics_task_stack,
                            &diagnostics_task_tcb);
#else
    ret = xTaskCreate(task_diagnostics,
                      "Diagn",
                      STACK_SIZE_DIAGNOSTICS,
                      NULL,
                      PRIORITY_DIAGNOSTICS,
                      &diagnostics_task_handle);
#endif
    if (ret != pdPASS) return pdFAIL;

#if (RTOS_USE_STATIC_ALLOCATION == 1)
    ret = xTaskCreateStatic(task_state_machine_wrapper,
                            "State",
                            STACK_SIZE_STATE_MACHINE,
                            NULL,
                            PRIORITY_STATE_MACHINE,
                            state_task_stack,
                            &state_task_tcb);
#else
    ret = xTaskCreate(task_state_machine_wrapper,
                      "State",
                      STACK_SIZE_STATE_MACHINE,
                      NULL,
                      PRIORITY_STATE_MACHINE,
                      &state_task_handle);
#endif
    if (ret != pdPASS) return pdFAIL;

#if (RTOS_USE_STATIC_ALLOCATION == 1)
    ret = xTaskCreateStatic(task_safety,
                            "Safety",
                            STACK_SIZE_SAFETY,
                            NULL,
                            PRIORITY_SAFETY,
                            safety_task_stack,
                            &safety_task_tcb);
#else
    ret = xTaskCreate(task_safety,
                      "Safety",
                      STACK_SIZE_SAFETY,
                      NULL,
                      PRIORITY_SAFETY,
                      &safety_task_handle);
#endif
    if (ret != pdPASS) return pdFAIL;

    return pdPASS;
}

static void task_control_loop(void *pvParameters)
{
    TickType_t xLastWakeTime = xTaskGetTickCount();
    adc_readings_t adc_data;
    control_reference_t ref;
    control_cmd_t cmd;

    (void)pvParameters;

    for (;;) {
        if (xQueueReceive(control_cmd_queue, &cmd, 0) == pdPASS) {
            ref = cmd.ref;
        }

        if (xSemaphoreTake(adc_data_ready_sem, pdMS_TO_TICKS(1)) == pdPASS) {
            if (xQueueReceive(measurement_queue, &adc_data, 0) == pdPASS) {
                /* Clarke / Park transforms, current PI controllers, SVPWM */
                /* PWM duty cycle updates written to TIM1 CCR registers */
            }
        }

        vTaskDelayUntil(&xLastWakeTime, PERIOD_CONTROL_LOOP_TICKS);
    }
}

static void task_communication(void *pvParameters)
{
    TickType_t xLastWakeTime = xTaskGetTickCount();
    drive_event_t event;
    motor_state_t motor_data;

    (void)pvParameters;

    for (;;) {
        if (xQueueReceive(drive_event_queue, &event, 0) == pdPASS) {
            if (event.type == EVENT_MOTOR_DATA_READY && event.data != NULL) {
                motor_data = *(motor_state_t *)event.data;
                /* Pack motor_data into Modbus / CANopen / Ethernet response buffer */
            }
            /* Handle other events: fault notifications, state changes */
        }

        /* Service Modbus RTU, CANopen, Modbus TCP, web UI requests */
        /* Process incoming communication frames from UART/CAN/Ethernet ISR buffers */

        vTaskDelayUntil(&xLastWakeTime, PERIOD_COMMUNICATION_TICKS);
    }
}

static void task_user_interface(void *pvParameters)
{
    TickType_t xLastWakeTime = xTaskGetTickCount();
    GPIO_PinState btn_state;
    static uint8_t debounce_cnt = 0;

    (void)pvParameters;

    for (;;) {
        btn_state = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0);
        if (btn_state == GPIO_PIN_SET) {
            if (debounce_cnt < 50) {
                debounce_cnt++;
                if (debounce_cnt == 50) {
                    drive_event_t event = {
                        .type = EVENT_FAULT_CLEARED,
                        .timestamp_ms = system_tick_ms,
                        .data = NULL,
                        .data_len = 0
                    };
                    xQueueSend(drive_event_queue, &event, 0);
                }
            }
        } else {
            debounce_cnt = 0;
        }

        /* Update status LEDs based on drive state */
        /* Scan keypad or encoder inputs */
        /* Update local display */

        vTaskDelayUntil(&xLastWakeTime, PERIOD_USER_INTERFACE_TICKS);
    }
}

static void task_monitoring(void *pvParameters)
{
    TickType_t xLastWakeTime = xTaskGetTickCount();
    drive_event_t event;

    (void)pvParameters;

    for (;;) {
        /* Sample analog watchdog thresholds */
        /* Check DC bus against over/under voltage limits */
        /* Check IGBT / heatsink / motor temperature limits */
        /* Check motor current against overload curve (I²t) */
        /* Check motor speed against overspeed limits */
        /* Update power (kW), energy (kWh), torque estimates */

        event.type    = EVENT_HEARTBEAT;
        event.timestamp_ms = system_tick_ms;
        event.data    = NULL;
        event.data_len = 0;
        xQueueSend(drive_event_queue, &event, 0);

        watchdog_refresh();

        vTaskDelayUntil(&xLastWakeTime, PERIOD_MONITORING_TICKS);
    }
}

static void task_diagnostics(void *pvParameters)
{
    TickType_t xLastWakeTime = xTaskGetTickCount();
    fault_record_t fault;
    static uint32_t hourly_runtime_s = 0U;
    static uint32_t total_runtime_s  = 0U;

    (void)pvParameters;

    for (;;) {
        if (xQueueReceive(diag_event_queue, &fault, 0) == pdPASS) {
            /* Log fault record to EEPROM / Flash non-volatile storage */
            /* Push fault over communication bus */
            /* Update fault history buffer (last N faults) */
        }

        hourly_runtime_s += (PERIOD_DIAGNOSTICS_TICKS * 10U);
        if (hourly_runtime_s >= 3600U) {
            hourly_runtime_s = 0U;
            total_runtime_s  += 3600U;
            /* Persist runtime counters to EEPROM */
        }

        /* Fan speed control based on heatsink temperature */
        /* Self-test routines */
        /* Communication watchdog timeout checking */

        vTaskDelayUntil(&xLastWakeTime, PERIOD_DIAGNOSTICS_TICKS);
    }
}

static void task_state_machine_wrapper(void *pvParameters)
{
    TickType_t xLastWakeTime = xTaskGetTickCount();

    (void)pvParameters;

    for (;;) {
        state_machine_run();
        vTaskDelayUntil(&xLastWakeTime, PERIOD_STATE_MACHINE_TICKS);
    }
}

static void task_safety(void *pvParameters)
{
    TickType_t xLastWakeTime = xTaskGetTickCount();

    (void)pvParameters;

    for (;;) {
        /* Safety torque off (STO) input monitoring */
        /* Hardware-enforced output disable if STO active */
        /* Redundant ADC cross-check */
        /* Watchdog service verification */

        vTaskDelayUntil(&xLastWakeTime, PERIOD_SAFETY_TICKS);
    }
}

static void watchdog_refresh(void)
{
    HAL_IWDG_Refresh(&hiwdg);
}

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;

    if (hadc->Instance == ADC1) {
        adc_readings_t adc_data;
        /* Fill adc_data from DMA buffer */
        xQueueSendFromISR(measurement_queue, &adc_data, &xHigherPriorityTaskWoken);
        xSemaphoreGiveFromISR(adc_data_ready_sem, &xHigherPriorityTaskWoken);
    }

    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance == TIM2) {
        system_tick_ms++;
    }
}
