#include "panel_comm.h"
#include <string.h>

static uint8_t panel_uart_putc(uint8_t ch)
{
    uint32_t timeout = 1000000UL;

    while (!(PANEL_UART_SR & UART_SR_TXE) && --timeout) {
    }

    if (timeout == 0) return 0;

    PANEL_UART_DR = ch;
    return 1;
}

static uint8_t panel_uart_getc(uint8_t *ch)
{
    if (PANEL_UART_SR & UART_SR_RXNE) {
        *ch = (uint8_t)(PANEL_UART_DR & 0xFFUL);
        return 1;
    }
    return 0;
}

static void panel_stuff_byte(panel_comm_state_t *state, uint8_t raw,
                              uint8_t *out, uint8_t *out_len,
                              uint8_t max_len)
{
    if (*out_len >= max_len) return;

    if (raw == PANEL_SOF || raw == PANEL_EOF || raw == PANEL_ESC) {
        if (*out_len + 1 < max_len) {
            out[(*out_len)++] = PANEL_ESC;
        }
    }
    out[(*out_len)++] = raw;
}

static uint8_t panel_calc_checksum(const panel_frame_t *frame)
{
    uint8_t sum = 0;
    uint8_t i;

    sum ^= frame->command;
    sum ^= frame->length;

    for (i = 0; i < frame->length && i < (PANEL_FRAME_MAX_LEN - 4); i++) {
        sum ^= frame->data[i];
    }

    return sum;
}

uint8_t panel_send_frame(panel_comm_state_t *state, const panel_frame_t *frame)
{
    uint8_t stuffed[PANEL_FRAME_MAX_LEN * 2 + 4];
    uint8_t stuffed_len = 0;
    uint8_t i;
    uint32_t timeout;

    if (state == 0 || frame == 0) return 0;
    if (frame->length > (PANEL_FRAME_MAX_LEN - 4)) return 0;

    stuffed[stuffed_len++] = PANEL_SOF;

    panel_stuff_byte(state, frame->command, stuffed, &stuffed_len,
                     sizeof(stuffed));
    panel_stuff_byte(state, frame->length, stuffed, &stuffed_len,
                     sizeof(stuffed));

    for (i = 0; i < frame->length; i++) {
        panel_stuff_byte(state, frame->data[i], stuffed, &stuffed_len,
                         sizeof(stuffed));
    }

    panel_stuff_byte(state, frame->checksum, stuffed, &stuffed_len,
                     sizeof(stuffed));

    stuffed[stuffed_len++] = PANEL_EOF;

    timeout = 2000000UL;
    while (!(PANEL_UART_SR & UART_SR_TC) && --timeout) {
    }

    for (i = 0; i < stuffed_len; i++) {
        if (!panel_uart_putc(stuffed[i])) {
            return 0;
        }
    }

    state->total_tx++;
    return 1;
}

uint8_t panel_parse_frame(panel_comm_state_t *state)
{
    uint8_t ch;
    uint8_t parse_state = 0;
    uint8_t frame_idx = 0;
    uint8_t escape = 0;

    if (state == 0) return 0;

    state->rx_complete = 0;
    state->rx_error = 0;

    while (panel_uart_getc(&ch)) {
        state->total_rx++;

        if (escape) {
            escape = 0;
            if (frame_idx < sizeof(state->rx_buffer)) {
                state->rx_buffer[frame_idx++] = ch;
            }
            continue;
        }

        if (ch == PANEL_ESC) {
            escape = 1;
            continue;
        }

        if (parse_state == 0) {
            if (ch == PANEL_SOF) {
                parse_state = 1;
                frame_idx = 0;
            }
            continue;
        }

        if (ch == PANEL_EOF) {
            if (frame_idx >= 3) {
                panel_frame_t *f = &state->rx_frame;
                uint8_t cksum;

                f->sof = 0;
                f->command = state->rx_buffer[0];
                f->length  = state->rx_buffer[1];

                if (f->length > (PANEL_FRAME_MAX_LEN - 4)) {
                    state->rx_errors++;
                    parse_state = 0;
                    continue;
                }

                memcpy(f->data, &state->rx_buffer[2], f->length);

                cksum = panel_calc_checksum(f);

                f->checksum = state->rx_buffer[2 + f->length];
                f->eof = PANEL_EOF;

                if (cksum == f->checksum) {
                    state->rx_complete = 1;
                    return 1;
                } else {
                    state->rx_errors++;
                }
            }
            parse_state = 0;
            continue;
        }

        if (frame_idx < sizeof(state->rx_buffer)) {
            state->rx_buffer[frame_idx++] = ch;
        }
    }

    return 0;
}

void panel_comm_init(panel_comm_state_t *state)
{
    if (state == 0) return;

    memset(state, 0, sizeof(panel_comm_state_t));
    state->initialized = 1;
}

void panel_comm_update(panel_comm_state_t *state)
{
    if (state == 0 || !state->initialized) return;

    panel_parse_frame(state);
}
