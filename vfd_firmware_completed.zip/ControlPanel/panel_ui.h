#ifndef CONTROLPANEL_PANEL_UI_H
#define CONTROLPANEL_PANEL_UI_H

#include <stdint.h>

#define LCD_COLS          16U
#define LCD_ROWS           2U
#define LED_7SEG_COUNT     4U
#define MENU_MAX_ITEMS    16U
#define MENU_MAX_DEPTH     8U

typedef enum {
    KEY_NONE   = 0x00,
    KEY_UP     = 0x01,
    KEY_DOWN   = 0x02,
    KEY_LEFT   = 0x04,
    KEY_RIGHT  = 0x08,
    KEY_ENTER  = 0x10,
    KEY_BACK   = 0x20,
    KEY_START  = 0x40,
    KEY_STOP   = 0x80,
} key_code_t;

typedef enum {
    SCREEN_MAIN      = 0,
    SCREEN_MENU      = 1,
    SCREEN_PARAM     = 2,
    SCREEN_EDIT      = 3,
    SCREEN_FAULT     = 4,
    SCREEN_WARNING   = 5,
    SCREEN_SERVICE   = 6,
    SCREEN_STARTUP   = 7,
} screen_id_t;

typedef struct {
    const char *name;
    uint16_t    param_id;
    screen_id_t target;
} menu_item_t;

typedef struct {
    uint8_t      initialized;
    uint8_t      backlight_on;
    screen_id_t  current_screen;
    screen_id_t  prev_screen;
    uint8_t      menu_cursor;
    uint8_t      menu_item_count;
    uint8_t      menu_depth;
    uint16_t     edit_param_id;
    int32_t      edit_value;
    uint8_t      edit_digit_pos;
    uint8_t      edit_blink;
    uint8_t      key_debounce;
    key_code_t   last_key;
    uint32_t     blink_timer;
    uint8_t      lcd_buffer[LCD_COLS * LCD_ROWS];
    uint8_t      seg7_buffer[LED_7SEG_COUNT];
    uint8_t      led_run;
    uint8_t      led_fault;
    uint8_t      led_start;
    uint8_t      led_stop;
    menu_item_t  menu_items[MENU_MAX_ITEMS];
} panel_ui_state_t;

void panel_ui_init(panel_ui_state_t *state);
void panel_ui_update(panel_ui_state_t *state);
void panel_render(panel_ui_state_t *state);
void panel_keypress(panel_ui_state_t *state, key_code_t key);

#endif
