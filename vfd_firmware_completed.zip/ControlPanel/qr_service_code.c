#include "qr_service_code.h"
#include <string.h>
#include <stdio.h>

static const char qr_base64_chars[] =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

static void qr_encode_base64_url(char *out, const uint8_t *data, uint8_t len)
{
    uint8_t i, j;

    for (i = 0, j = 0; i < len; i += 3) {
        uint32_t triple = ((uint32_t)data[i] << 16);
        if (i + 1 < len) triple |= ((uint32_t)data[i + 1] << 8);
        if (i + 2 < len) triple |= (uint32_t)data[i + 2];

        out[j++] = qr_base64_chars[(triple >> 18) & 0x3F];
        out[j++] = qr_base64_chars[(triple >> 12) & 0x3F];

        if (i + 1 < len) {
            out[j++] = qr_base64_chars[(triple >> 6) & 0x3F];
        } else {
            out[j++] = '-';
        }

        if (i + 2 < len) {
            out[j++] = qr_base64_chars[triple & 0x3F];
        } else {
            out[j++] = '-';
        }
    }
    out[j] = '\0';
}

uint8_t qr_code_generate(qr_service_code_state_t *state)
{
    char fault_str[32] = "NONE";
    char encoded_sn[32];
    char encoded_fw[16];
    char encoded_run[16];
    uint8_t raw[8];
    uint16_t drive_code;
    uint8_t i;

    if (state == 0) return 0;

    state->state = QR_STATE_GENERATING;

    /* Faults -> hex string */
    if (state->fault_count > 0 && state->fault_count <= QR_FAULT_CODES_MAX) {
        fault_str[0] = '\0';
        for (i = 0; i < state->fault_count && i < QR_FAULT_CODES_MAX; i++) {
            char buf[6];
            snprintf(buf, sizeof(buf), "%04X",
                     state->active_faults[i]);
            strncat(fault_str, buf, sizeof(fault_str) - 1);
        }
    }

    /* Drive type + run hours -> raw encode */
    drive_code = state->drive_type;
    raw[0] = (uint8_t)(drive_code >> 8);
    raw[1] = (uint8_t)(drive_code & 0xFF);
    raw[2] = (uint8_t)(state->run_hours >> 24);
    raw[3] = (uint8_t)(state->run_hours >> 16);
    raw[4] = (uint8_t)(state->run_hours >> 8);
    raw[5] = (uint8_t)(state->run_hours & 0xFF);
    raw[6] = 0;
    raw[7] = 0;
    qr_encode_base64_url(encoded_run, raw, 6);

    qr_encode_base64_url(encoded_sn,
                          (const uint8_t *)state->drive_serial,
                          (uint8_t)strlen(state->drive_serial));

    qr_encode_base64_url(encoded_fw,
                          (const uint8_t *)state->firmware_version,
                          (uint8_t)strlen(state->firmware_version));

    snprintf(state->qr_string, QR_CODE_MAX_LEN,
             "VFD;SN=%s;FW=%s;TYPE=%04X;RUN=%s;FLT=%s",
             encoded_sn, encoded_fw, state->drive_type,
             encoded_run, fault_str);

    state->state = QR_STATE_READY;
    state->display_timer = 0;
    state->display_timeout_ms = 30000;
    state->request_pending = 0;

    return 1;
}

void qr_service_code_init(qr_service_code_state_t *state)
{
    if (state == 0) return;

    memset(state, 0, sizeof(qr_service_code_state_t));
    state->initialized  = 1;
    state->state        = QR_STATE_IDLE;
    state->request_pending = 0;
    state->display_timeout_ms = 30000;
    state->fault_count  = 0;
}

void qr_service_code_update(qr_service_code_state_t *state)
{
    if (state == 0 || !state->initialized) return;

    if (state->state == QR_STATE_DISPLAYING) {
        state->display_timer++;
        if (state->display_timer >= state->display_timeout_ms) {
            state->state = QR_STATE_TIMEOUT;
            state->display_timer = 0;
        }
    }

    if (state->state == QR_STATE_TIMEOUT) {
        state->state = QR_STATE_IDLE;
    }

    if (state->request_pending) {
        qr_code_generate(state);
        state->state = QR_STATE_READY;
    }
}
