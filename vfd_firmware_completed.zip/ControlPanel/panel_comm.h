#ifndef CONTROLPANEL_PANEL_COMM_H
#define CONTROLPANEL_PANEL_COMM_H

#include <stdint.h>

#define PANEL_FRAME_MAX_LEN    32U
#define PANEL_SOF              0xA5U
#define PANEL_EOF              0x5AU
#define PANEL_ESC              0x1BU

#define PANEL_CMD_READ_PARAM   0x01U
#define PANEL_CMD_WRITE_PARAM  0x02U
#define PANEL_CMD_READ_STATUS  0x03U
#define PANEL_CMD_START_DRIVE  0x04U
#define PANEL_CMD_STOP_DRIVE   0x05U
#define PANEL_CMD_RESET_FAULT  0x06U
#define PANEL_CMD_GET_FAULTS   0x07U
#define PANEL_CMD_KEY_EVENT    0x08U
#define PANEL_CMD_LCD_WRITE    0x09U
#define PANEL_CMD_ACK          0x80U
#define PANEL_CMD_NACK         0x81U

#define PANEL_UART             ((volatile uint32_t *)0x40011000UL)
#define PANEL_UART_SR          (PANEL_UART[0])
#define PANEL_UART_DR          (PANEL_UART[1])
#define UART_SR_TXE            (1UL << 7)
#define UART_SR_RXNE           (1UL << 5)
#define UART_SR_TC             (1UL << 6)

typedef struct __attribute__((packed)) {
    uint8_t  sof;
    uint8_t  command;
    uint8_t  length;
    uint8_t  data[PANEL_FRAME_MAX_LEN - 4];
    uint8_t  checksum;
    uint8_t  eof;
} panel_frame_t;

typedef struct {
    uint8_t  initialized;
    uint8_t  tx_busy;
    uint8_t  rx_complete;
    uint8_t  rx_error;
    uint8_t  rx_index;
    uint8_t  rx_buffer[PANEL_FRAME_MAX_LEN * 2];
    uint8_t  tx_buffer[PANEL_FRAME_MAX_LEN];
    uint8_t  escape_next;
    panel_frame_t rx_frame;
    panel_frame_t tx_frame;
    uint32_t  tx_timeout;
    uint32_t  rx_timeout;
    uint32_t  total_tx;
    uint32_t  total_rx;
    uint32_t  rx_errors;
} panel_comm_state_t;

void panel_comm_init(panel_comm_state_t *state);
void panel_comm_update(panel_comm_state_t *state);
uint8_t panel_send_frame(panel_comm_state_t *state, const panel_frame_t *frame);
uint8_t panel_parse_frame(panel_comm_state_t *state);

#endif
