#include "panel_ui.h"
#include <string.h>
#include <stdio.h>

static void panel_render_main_screen(panel_ui_state_t *state)
{
    snprintf((char *)state->lcd_buffer, LCD_COLS + 1,
             "VFD Ready     ");
    snprintf((char *)state->lcd_buffer + LCD_COLS, LCD_COLS + 1,
             "0.0 Hz  0.0 A ");
}

static void panel_render_menu_screen(panel_ui_state_t *state)
{
    uint8_t i;
    uint8_t visible = state->menu_cursor;

    if (state->menu_cursor + 1 < LCD_ROWS) {
        visible = 0;
    } else if (state->menu_cursor >= state->menu_item_count) {
        visible = (state->menu_item_count > LCD_ROWS)
                  ? (state->menu_item_count - LCD_ROWS) : 0;
    } else {
        visible = state->menu_cursor - 1;
    }

    for (i = 0; i < LCD_ROWS && (visible + i) < state->menu_item_count; i++) {
        char line[LCD_COLS + 1];
        uint8_t prefix = ((visible + i) == state->menu_cursor) ? '>' : ' ';
        snprintf(line, sizeof(line), "%c%-15s", prefix,
                 state->menu_items[visible + i].name);
        memcpy(&state->lcd_buffer[i * LCD_COLS], line, LCD_COLS);
    }
}

static void panel_render_param_screen(panel_ui_state_t *state)
{
    snprintf((char *)state->lcd_buffer, LCD_COLS + 1,
             "P%04X           ", state->edit_param_id);
    snprintf((char *)state->lcd_buffer + LCD_COLS, LCD_COLS + 1,
             "%12d ", state->edit_value);
}

static void panel_render_edit_screen(panel_ui_state_t *state)
{
    uint8_t pos = state->edit_digit_pos;
    char val_str[13];
    int i;

    snprintf(val_str, sizeof(val_str), "%12d", state->edit_value);

    if (state->edit_blink) {
        i = (int)(11 - pos);
        if (i >= 0 && i < 12 && val_str[i] == ' ') {
            val_str[i] = '_';
        }
    }

    snprintf((char *)state->lcd_buffer, LCD_COLS + 1,
             "Edit P%04X     ", state->edit_param_id);
    snprintf((char *)state->lcd_buffer + LCD_COLS, LCD_COLS + 1,
             "%s", val_str);
}

static void panel_render_fault_screen(panel_ui_state_t *state)
{
    snprintf((char *)state->lcd_buffer, LCD_COLS + 1,
             "FAULT          ");
    snprintf((char *)state->lcd_buffer + LCD_COLS, LCD_COLS + 1,
             "Code: %04X     ", state->edit_param_id);
}

static void panel_update_leds(panel_ui_state_t *state)
{
    state->led_run   = 0;
    state->led_fault = 0;
    state->led_start = 0;
    state->led_stop  = 0;
}

static void panel_clear_lcd(panel_ui_state_t *state)
{
    memset(state->lcd_buffer, ' ', LCD_COLS * LCD_ROWS);
}

void panel_render(panel_ui_state_t *state)
{
    if (state == 0) return;

    panel_clear_lcd(state);
    panel_update_leds(state);

    switch (state->current_screen) {
    case SCREEN_MAIN:
        panel_render_main_screen(state);
        state->led_run = 1;
        break;
    case SCREEN_MENU:
        panel_render_menu_screen(state);
        break;
    case SCREEN_PARAM:
        panel_render_param_screen(state);
        break;
    case SCREEN_EDIT:
        panel_render_edit_screen(state);
        state->led_start = 1;
        break;
    case SCREEN_FAULT:
        panel_render_fault_screen(state);
        state->led_fault = 1;
        break;
    case SCREEN_WARNING:
        snprintf((char *)state->lcd_buffer, LCD_COLS + 1,
                 "WARNING        ");
        snprintf((char *)state->lcd_buffer + LCD_COLS, LCD_COLS + 1,
                 "Check drive    ");
        state->led_fault = 1;
        break;
    case SCREEN_SERVICE:
        snprintf((char *)state->lcd_buffer, LCD_COLS + 1,
                 "SERVICE MODE   ");
        snprintf((char *)state->lcd_buffer + LCD_COLS, LCD_COLS + 1,
                 "Contact mfg.   ");
        break;
    case SCREEN_STARTUP:
        snprintf((char *)state->lcd_buffer, LCD_COLS + 1,
                 "VFD Starting.. ");
        snprintf((char *)state->lcd_buffer + LCD_COLS, LCD_COLS + 1,
                 "Self-test OK   ");
        break;
    default:
        break;
    }
}

void panel_keypress(panel_ui_state_t *state, key_code_t key)
{
    if (state == 0) return;

    if (key == state->last_key) {
        state->key_debounce++;
        if (state->key_debounce < 3) return;
    } else {
        state->key_debounce = 0;
    }
    state->last_key = key;

    switch (state->current_screen) {

    case SCREEN_MAIN:
    case SCREEN_STARTUP:
        if (key == KEY_ENTER) {
            state->prev_screen = state->current_screen;
            state->current_screen = SCREEN_MENU;
            state->menu_cursor = 0;
        }
        if (key == KEY_START) {
            state->led_start = 1;
        }
        if (key == KEY_STOP) {
            state->led_stop = 1;
        }
        break;

    case SCREEN_MENU:
        if (key == KEY_UP && state->menu_cursor > 0) {
            state->menu_cursor--;
        }
        if (key == KEY_DOWN && state->menu_cursor < (state->menu_item_count - 1)) {
            state->menu_cursor++;
        }
        if (key == KEY_ENTER && state->menu_cursor < state->menu_item_count) {
            screen_id_t target = state->menu_items[state->menu_cursor].target;
            if (target != SCREEN_MENU) {
                state->prev_screen = SCREEN_MENU;
                state->current_screen = target;
                state->edit_param_id = state->menu_items[state->menu_cursor].param_id;
            }
        }
        if (key == KEY_BACK) {
            state->current_screen = SCREEN_MAIN;
        }
        break;

    case SCREEN_PARAM:
        if (key == KEY_ENTER) {
            state->prev_screen = SCREEN_PARAM;
            state->current_screen = SCREEN_EDIT;
            state->edit_digit_pos = 0;
            state->edit_blink = 1;
        }
        if (key == KEY_UP) {
            state->edit_param_id++;
        }
        if (key == KEY_DOWN) {
            state->edit_param_id--;
        }
        if (key == KEY_BACK) {
            state->current_screen = SCREEN_MENU;
        }
        break;

    case SCREEN_EDIT:
        if (key == KEY_UP) {
            int32_t inc = 1;
            uint8_t d;
            for (d = 0; d < state->edit_digit_pos; d++) inc *= 10;
            state->edit_value += inc;
        }
        if (key == KEY_DOWN) {
            int32_t dec = 1;
            uint8_t d;
            for (d = 0; d < state->edit_digit_pos; d++) dec *= 10;
            state->edit_value -= dec;
        }
        if (key == KEY_LEFT && state->edit_digit_pos < 11) {
            state->edit_digit_pos++;
        }
        if (key == KEY_RIGHT && state->edit_digit_pos > 0) {
            state->edit_digit_pos--;
        }
        if (key == KEY_ENTER) {
            state->current_screen = SCREEN_PARAM;
        }
        if (key == KEY_BACK) {
            state->current_screen = SCREEN_PARAM;
        }
        break;

    case SCREEN_FAULT:
        if (key == KEY_STOP || key == KEY_BACK) {
            state->current_screen = SCREEN_MAIN;
        }
        break;

    case SCREEN_WARNING:
        if (key == KEY_BACK) {
            state->current_screen = SCREEN_MAIN;
        }
        break;

    case SCREEN_SERVICE:
        if (key == KEY_BACK) {
            state->current_screen = SCREEN_MAIN;
        }
        break;

    default:
        break;
    }
}

void panel_ui_init(panel_ui_state_t *state)
{
    if (state == 0) return;

    memset(state, 0, sizeof(panel_ui_state_t));
    state->initialized  = 1;
    state->backlight_on = 1;
    state->current_screen = SCREEN_STARTUP;
    state->prev_screen  = SCREEN_STARTUP;
    state->menu_cursor  = 0;
    state->menu_item_count = 0;
    state->menu_depth   = 0;
    state->edit_digit_pos = 0;
    state->led_run   = 0;
    state->led_fault = 0;
    state->led_start = 0;
    state->led_stop  = 0;
}

void panel_ui_update(panel_ui_state_t *state)
{
    if (state == 0 || !state->initialized) return;

    state->blink_timer++;
    if (state->edit_blink && (state->blink_timer & 8)) {
        state->edit_blink = 0;
    } else if (state->current_screen == SCREEN_EDIT && !(state->blink_timer & 8)) {
        state->edit_blink = 1;
    }

    panel_render(state);
}
