#ifndef CONTROLPANEL_QR_SERVICE_CODE_H
#define CONTROLPANEL_QR_SERVICE_CODE_H

#include <stdint.h>

#define QR_CODE_MAX_LEN     256U
#define QR_DRIVE_SN_LEN      16U
#define QR_FW_VERSION_LEN     8U
#define QR_FAULT_CODES_MAX    4U

typedef enum {
    QR_STATE_IDLE       = 0,
    QR_STATE_GENERATING = 1,
    QR_STATE_READY      = 2,
    QR_STATE_DISPLAYING = 3,
    QR_STATE_TIMEOUT    = 4,
} qr_state_t;

typedef struct {
    uint8_t  initialized;
    qr_state_t state;
    uint8_t  request_pending;
    uint32_t display_timer;
    uint32_t display_timeout_ms;
    char     drive_serial[QR_DRIVE_SN_LEN + 1];
    char     firmware_version[QR_FW_VERSION_LEN + 1];
    uint16_t active_faults[QR_FAULT_CODES_MAX];
    uint8_t  fault_count;
    uint16_t drive_type;
    uint32_t run_hours;
    char     qr_string[QR_CODE_MAX_LEN + 1];
} qr_service_code_state_t;

void qr_service_code_init(qr_service_code_state_t *state);
void qr_service_code_update(qr_service_code_state_t *state);
uint8_t qr_code_generate(qr_service_code_state_t *state);

#endif
