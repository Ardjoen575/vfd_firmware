#ifndef IOBUS_IO_BUS_FAN_ID_H
#define IOBUS_IO_BUS_FAN_ID_H

/* I/O bus fan identification (grp 209) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} io_bus_fan_id_state_t;

void io_bus_fan_id_init(io_bus_fan_id_state_t *state);
void io_bus_fan_id_update(io_bus_fan_id_state_t *state);
void iobus_fan_identify(io_bus_fan_id_state_t *state);

#endif /* IOBUS_IO_BUS_FAN_ID_H */
