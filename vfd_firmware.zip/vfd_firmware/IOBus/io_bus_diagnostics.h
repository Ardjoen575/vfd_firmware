#ifndef IOBUS_IO_BUS_DIAGNOSTICS_H
#define IOBUS_IO_BUS_DIAGNOSTICS_H

/* I/O bus diagnostics (grp 208) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} io_bus_diagnostics_state_t;

void io_bus_diagnostics_init(io_bus_diagnostics_state_t *state);
void io_bus_diagnostics_update(io_bus_diagnostics_state_t *state);
void iobus_diag_check(io_bus_diagnostics_state_t *state);

#endif /* IOBUS_IO_BUS_DIAGNOSTICS_H */
