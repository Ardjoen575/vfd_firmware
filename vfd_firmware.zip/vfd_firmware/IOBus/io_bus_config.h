#ifndef IOBUS_IO_BUS_CONFIG_H
#define IOBUS_IO_BUS_CONFIG_H

/* I/O bus configuration (grp 206) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} io_bus_config_state_t;

void io_bus_config_init(io_bus_config_state_t *state);
void io_bus_config_update(io_bus_config_state_t *state);
void iobus_configure(io_bus_config_state_t *state);

#endif /* IOBUS_IO_BUS_CONFIG_H */
