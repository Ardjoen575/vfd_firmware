#ifndef IOBUS_IO_BUS_SERVICE_H
#define IOBUS_IO_BUS_SERVICE_H

/* I/O bus service (grp 207) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} io_bus_service_state_t;

void io_bus_service_init(io_bus_service_state_t *state);
void io_bus_service_update(io_bus_service_state_t *state);
void iobus_service_tick(io_bus_service_state_t *state);

#endif /* IOBUS_IO_BUS_SERVICE_H */
