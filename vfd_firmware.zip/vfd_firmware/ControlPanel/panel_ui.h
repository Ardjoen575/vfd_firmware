#ifndef CONTROLPANEL_PANEL_UI_H
#define CONTROLPANEL_PANEL_UI_H

/* 7-seg/LCD display, keypad, menu navigation */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} panel_ui_state_t;

void panel_ui_init(panel_ui_state_t *state);
void panel_ui_update(panel_ui_state_t *state);
void panel_ui_render(panel_ui_state_t *state);
void panel_ui_handle_keypress(panel_ui_state_t *state);

#endif /* CONTROLPANEL_PANEL_UI_H */
