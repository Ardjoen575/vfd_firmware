#ifndef CONTROLPANEL_QR_SERVICE_CODE_H
#define CONTROLPANEL_QR_SERVICE_CODE_H

/* QR code generation for mobile service app */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} qr_service_code_state_t;

void qr_service_code_init(qr_service_code_state_t *state);
void qr_service_code_update(qr_service_code_state_t *state);
void qr_generate_service_code(qr_service_code_state_t *state);

#endif /* CONTROLPANEL_QR_SERVICE_CODE_H */
