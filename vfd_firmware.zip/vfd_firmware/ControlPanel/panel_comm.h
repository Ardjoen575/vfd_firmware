#ifndef CONTROLPANEL_PANEL_COMM_H
#define CONTROLPANEL_PANEL_COMM_H

/* Panel port communication protocol (grp 49) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} panel_comm_state_t;

void panel_comm_init(panel_comm_state_t *state);
void panel_comm_update(panel_comm_state_t *state);
void panel_comm_send_frame(panel_comm_state_t *state);
void panel_comm_parse_frame(panel_comm_state_t *state);

#endif /* CONTROLPANEL_PANEL_COMM_H */
