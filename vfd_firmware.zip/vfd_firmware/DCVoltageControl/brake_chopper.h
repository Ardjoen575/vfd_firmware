#ifndef DCVOLTAGECONTROL_BRAKE_CHOPPER_H
#define DCVOLTAGECONTROL_BRAKE_CHOPPER_H

/* Brake chopper control (grp 43) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} brake_chopper_state_t;

void brake_chopper_init(brake_chopper_state_t *state);
void brake_chopper_update(brake_chopper_state_t *state);
void chopper_pwm_update(brake_chopper_state_t *state);

#endif /* DCVOLTAGECONTROL_BRAKE_CHOPPER_H */
