#ifndef DCVOLTAGECONTROL_OVERVOLTAGE_CONTROL_H
#define DCVOLTAGECONTROL_OVERVOLTAGE_CONTROL_H

/* DC bus overvoltage control */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} overvoltage_control_state_t;

void overvoltage_control_init(overvoltage_control_state_t *state);
void overvoltage_control_update(overvoltage_control_state_t *state);
void overvoltage_regulate(overvoltage_control_state_t *state);

#endif /* DCVOLTAGECONTROL_OVERVOLTAGE_CONTROL_H */
