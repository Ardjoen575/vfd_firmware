#ifndef DCVOLTAGECONTROL_UNDERVOLTAGE_CONTROL_H
#define DCVOLTAGECONTROL_UNDERVOLTAGE_CONTROL_H

/* Power loss ride-through */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} undervoltage_control_state_t;

void undervoltage_control_init(undervoltage_control_state_t *state);
void undervoltage_control_update(undervoltage_control_state_t *state);
void undervoltage_ridethrough(undervoltage_control_state_t *state);

#endif /* DCVOLTAGECONTROL_UNDERVOLTAGE_CONTROL_H */
