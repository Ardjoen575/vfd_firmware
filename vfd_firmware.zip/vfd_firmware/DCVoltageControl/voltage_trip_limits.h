#ifndef DCVOLTAGECONTROL_VOLTAGE_TRIP_LIMITS_H
#define DCVOLTAGECONTROL_VOLTAGE_TRIP_LIMITS_H

/* Voltage control and trip limits */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} voltage_trip_limits_state_t;

void voltage_trip_limits_init(voltage_trip_limits_state_t *state);
void voltage_trip_limits_update(voltage_trip_limits_state_t *state);
void voltage_check_trip(voltage_trip_limits_state_t *state);

#endif /* DCVOLTAGECONTROL_VOLTAGE_TRIP_LIMITS_H */
