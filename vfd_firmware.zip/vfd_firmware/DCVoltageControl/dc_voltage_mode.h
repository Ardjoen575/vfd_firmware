#ifndef DCVOLTAGECONTROL_DC_VOLTAGE_MODE_H
#define DCVOLTAGECONTROL_DC_VOLTAGE_MODE_H

/* DC voltage control mode */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} dc_voltage_mode_state_t;

void dc_voltage_mode_init(dc_voltage_mode_state_t *state);
void dc_voltage_mode_update(dc_voltage_mode_state_t *state);
void dcvolt_mode_step(dc_voltage_mode_state_t *state);

#endif /* DCVOLTAGECONTROL_DC_VOLTAGE_MODE_H */
