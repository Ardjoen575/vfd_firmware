#ifndef CONTROLLOCATIONS_CONTROL_LOCATION_H
#define CONTROLLOCATIONS_CONTROL_LOCATION_H

/* Local vs external control switching */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} control_location_state_t;

void control_location_init(control_location_state_t *state);
void control_location_update(control_location_state_t *state);
void control_location_get_active(control_location_state_t *state);
void control_location_force_local(control_location_state_t *state);

#endif /* CONTROLLOCATIONS_CONTROL_LOCATION_H */
