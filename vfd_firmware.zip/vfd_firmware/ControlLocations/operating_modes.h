#ifndef CONTROLLOCATIONS_OPERATING_MODES_H
#define CONTROLLOCATIONS_OPERATING_MODES_H

/* Speed/Torque/Frequency/DC-voltage/Special mode selection */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} operating_modes_state_t;

void operating_modes_init(operating_modes_state_t *state);
void operating_modes_update(operating_modes_state_t *state);
void opmode_select(operating_modes_state_t *state);
void opmode_get_current(operating_modes_state_t *state);

#endif /* CONTROLLOCATIONS_OPERATING_MODES_H */
