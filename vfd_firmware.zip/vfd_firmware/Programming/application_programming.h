#ifndef PROGRAMMING_APPLICATION_PROGRAMMING_H
#define PROGRAMMING_APPLICATION_PROGRAMMING_H

/* IEC 61131-3 application program hooks */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} application_programming_state_t;

void application_programming_init(application_programming_state_t *state);
void application_programming_update(application_programming_state_t *state);
void app_prog_call_hook(application_programming_state_t *state);

#endif /* PROGRAMMING_APPLICATION_PROGRAMMING_H */
