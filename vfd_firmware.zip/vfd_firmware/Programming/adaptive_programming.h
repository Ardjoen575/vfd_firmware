#ifndef PROGRAMMING_ADAPTIVE_PROGRAMMING_H
#define PROGRAMMING_ADAPTIVE_PROGRAMMING_H

/* Adaptive programming block engine */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} adaptive_programming_state_t;

void adaptive_programming_init(adaptive_programming_state_t *state);
void adaptive_programming_update(adaptive_programming_state_t *state);
void adpt_prog_run_blocks(adaptive_programming_state_t *state);

#endif /* PROGRAMMING_ADAPTIVE_PROGRAMMING_H */
