#ifndef PROGRAMMING_PARAM_PROGRAMMING_H
#define PROGRAMMING_PARAM_PROGRAMMING_H

/* Parameter-based configuration engine */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} param_programming_state_t;

void param_programming_init(param_programming_state_t *state);
void param_programming_update(param_programming_state_t *state);
void param_prog_apply(param_programming_state_t *state);

#endif /* PROGRAMMING_PARAM_PROGRAMMING_H */
