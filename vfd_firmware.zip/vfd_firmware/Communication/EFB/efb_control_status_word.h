#ifndef COMMUNICATION_EFB_EFB_CONTROL_STATUS_WORD_H
#define COMMUNICATION_EFB_EFB_CONTROL_STATUS_WORD_H

/* EFB control/status word handling */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} efb_control_status_word_state_t;

void efb_control_status_word_init(efb_control_status_word_state_t *state);
void efb_control_status_word_update(efb_control_status_word_state_t *state);
void efb_ctrlword_update(efb_control_status_word_state_t *state);

#endif /* COMMUNICATION_EFB_EFB_CONTROL_STATUS_WORD_H */
