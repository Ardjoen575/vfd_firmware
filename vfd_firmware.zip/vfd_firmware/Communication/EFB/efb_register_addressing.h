#ifndef COMMUNICATION_EFB_EFB_REGISTER_ADDRESSING_H
#define COMMUNICATION_EFB_EFB_REGISTER_ADDRESSING_H

/* EFB register addressing */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} efb_register_addressing_state_t;

void efb_register_addressing_init(efb_register_addressing_state_t *state);
void efb_register_addressing_update(efb_register_addressing_state_t *state);
void efb_addr_resolve(efb_register_addressing_state_t *state);

#endif /* COMMUNICATION_EFB_EFB_REGISTER_ADDRESSING_H */
