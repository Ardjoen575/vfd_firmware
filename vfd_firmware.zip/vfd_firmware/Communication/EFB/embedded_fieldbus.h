#ifndef COMMUNICATION_EFB_EMBEDDED_FIELDBUS_H
#define COMMUNICATION_EFB_EMBEDDED_FIELDBUS_H

/* Embedded fieldbus interface (grp 58) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} embedded_fieldbus_state_t;

void embedded_fieldbus_init(embedded_fieldbus_state_t *state);
void embedded_fieldbus_update(embedded_fieldbus_state_t *state);
void efb_poll(embedded_fieldbus_state_t *state);

#endif /* COMMUNICATION_EFB_EMBEDDED_FIELDBUS_H */
