#ifndef COMMUNICATION_PROFILES_TRANSPARENT_PROFILE_H
#define COMMUNICATION_PROFILES_TRANSPARENT_PROFILE_H

/* Transparent profile handling */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} transparent_profile_state_t;

void transparent_profile_init(transparent_profile_state_t *state);
void transparent_profile_update(transparent_profile_state_t *state);
void profile_transparent_map(transparent_profile_state_t *state);

#endif /* COMMUNICATION_PROFILES_TRANSPARENT_PROFILE_H */
