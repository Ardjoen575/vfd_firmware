#ifndef COMMUNICATION_PROFILES_ABB_DRIVES_PROFILE_H
#define COMMUNICATION_PROFILES_ABB_DRIVES_PROFILE_H

/* ABB Drives profile state machine */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} abb_drives_profile_state_t;

void abb_drives_profile_init(abb_drives_profile_state_t *state);
void abb_drives_profile_update(abb_drives_profile_state_t *state);
void profile_abb_state_transition(abb_drives_profile_state_t *state);

#endif /* COMMUNICATION_PROFILES_ABB_DRIVES_PROFILE_H */
