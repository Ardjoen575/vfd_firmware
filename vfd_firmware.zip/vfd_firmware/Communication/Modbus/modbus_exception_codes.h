#ifndef COMMUNICATION_MODBUS_MODBUS_EXCEPTION_CODES_H
#define COMMUNICATION_MODBUS_MODBUS_EXCEPTION_CODES_H

/* Modbus exception code handling */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} modbus_exception_codes_state_t;

void modbus_exception_codes_init(modbus_exception_codes_state_t *state);
void modbus_exception_codes_update(modbus_exception_codes_state_t *state);
void modbus_exception_raise(modbus_exception_codes_state_t *state);

#endif /* COMMUNICATION_MODBUS_MODBUS_EXCEPTION_CODES_H */
