#ifndef COMMUNICATION_MODBUS_MODBUS_ERROR_REGISTERS_H
#define COMMUNICATION_MODBUS_MODBUS_ERROR_REGISTERS_H

/* Error code registers 400090-400100 */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} modbus_error_registers_state_t;

void modbus_error_registers_init(modbus_error_registers_state_t *state);
void modbus_error_registers_update(modbus_error_registers_state_t *state);
void modbus_error_reg_get(modbus_error_registers_state_t *state);

#endif /* COMMUNICATION_MODBUS_MODBUS_ERROR_REGISTERS_H */
