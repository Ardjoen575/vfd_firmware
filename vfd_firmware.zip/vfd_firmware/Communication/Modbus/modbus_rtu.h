#ifndef COMMUNICATION_MODBUS_MODBUS_RTU_H
#define COMMUNICATION_MODBUS_MODBUS_RTU_H

/* Modbus RTU core + register map */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} modbus_rtu_state_t;

void modbus_rtu_init(modbus_rtu_state_t *state);
void modbus_rtu_update(modbus_rtu_state_t *state);
void modbus_handle_request(modbus_rtu_state_t *state);
void modbus_register_read(modbus_rtu_state_t *state);
void modbus_register_write(modbus_rtu_state_t *state);

#endif /* COMMUNICATION_MODBUS_MODBUS_RTU_H */
