#ifndef COMMUNICATION_MODBUS_MODBUS_DISCRETE_INPUTS_H
#define COMMUNICATION_MODBUS_MODBUS_DISCRETE_INPUTS_H

/* Discrete inputs 1xxxx reference set */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} modbus_discrete_inputs_state_t;

void modbus_discrete_inputs_init(modbus_discrete_inputs_state_t *state);
void modbus_discrete_inputs_update(modbus_discrete_inputs_state_t *state);
void modbus_discrete_read(modbus_discrete_inputs_state_t *state);

#endif /* COMMUNICATION_MODBUS_MODBUS_DISCRETE_INPUTS_H */
