#ifndef COMMUNICATION_MODBUS_MODBUS_FUNCTION_CODES_H
#define COMMUNICATION_MODBUS_MODBUS_FUNCTION_CODES_H

/* Modbus function code handlers */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} modbus_function_codes_state_t;

void modbus_function_codes_init(modbus_function_codes_state_t *state);
void modbus_function_codes_update(modbus_function_codes_state_t *state);
void modbus_fc_dispatch(modbus_function_codes_state_t *state);

#endif /* COMMUNICATION_MODBUS_MODBUS_FUNCTION_CODES_H */
