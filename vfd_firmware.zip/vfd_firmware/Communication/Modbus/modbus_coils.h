#ifndef COMMUNICATION_MODBUS_MODBUS_COILS_H
#define COMMUNICATION_MODBUS_MODBUS_COILS_H

/* Coils 0xxxx reference set */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} modbus_coils_state_t;

void modbus_coils_init(modbus_coils_state_t *state);
void modbus_coils_update(modbus_coils_state_t *state);
void modbus_coil_read(modbus_coils_state_t *state);
void modbus_coil_write(modbus_coils_state_t *state);

#endif /* COMMUNICATION_MODBUS_MODBUS_COILS_H */
