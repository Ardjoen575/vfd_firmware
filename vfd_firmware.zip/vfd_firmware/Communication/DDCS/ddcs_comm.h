#ifndef COMMUNICATION_DDCS_DDCS_COMM_H
#define COMMUNICATION_DDCS_DDCS_COMM_H

/* DDCS communication (grp 60) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} ddcs_comm_state_t;

void ddcs_comm_init(ddcs_comm_state_t *state);
void ddcs_comm_update(ddcs_comm_state_t *state);
void ddcs_send(ddcs_comm_state_t *state);
void ddcs_receive(ddcs_comm_state_t *state);

#endif /* COMMUNICATION_DDCS_DDCS_COMM_H */
