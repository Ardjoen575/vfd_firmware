#ifndef COMMUNICATION_DDCS_D2D_DDCS_TRANSMIT_H
#define COMMUNICATION_DDCS_D2D_DDCS_TRANSMIT_H

/* D2D and DDCS transmit data (grp 61) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} d2d_ddcs_transmit_state_t;

void d2d_ddcs_transmit_init(d2d_ddcs_transmit_state_t *state);
void d2d_ddcs_transmit_update(d2d_ddcs_transmit_state_t *state);
void d2d_transmit_frame(d2d_ddcs_transmit_state_t *state);

#endif /* COMMUNICATION_DDCS_D2D_DDCS_TRANSMIT_H */
