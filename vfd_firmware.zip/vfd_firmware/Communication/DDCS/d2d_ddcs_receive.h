#ifndef COMMUNICATION_DDCS_D2D_DDCS_RECEIVE_H
#define COMMUNICATION_DDCS_D2D_DDCS_RECEIVE_H

/* D2D and DDCS receive data (grp 62) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} d2d_ddcs_receive_state_t;

void d2d_ddcs_receive_init(d2d_ddcs_receive_state_t *state);
void d2d_ddcs_receive_update(d2d_ddcs_receive_state_t *state);
void d2d_receive_frame(d2d_ddcs_receive_state_t *state);

#endif /* COMMUNICATION_DDCS_D2D_DDCS_RECEIVE_H */
