#ifndef COMMUNICATION_FBA_FBA_A_DATA_IN_H
#define COMMUNICATION_FBA_FBA_A_DATA_IN_H

/* FBA A data in (grp 52) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} fba_a_data_in_state_t;

void fba_a_data_in_init(fba_a_data_in_state_t *state);
void fba_a_data_in_update(fba_a_data_in_state_t *state);
void fba_a_read_data_in(fba_a_data_in_state_t *state);

#endif /* COMMUNICATION_FBA_FBA_A_DATA_IN_H */
