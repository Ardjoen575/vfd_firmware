#ifndef COMMUNICATION_FBA_FBA_B_DATA_IN_H
#define COMMUNICATION_FBA_FBA_B_DATA_IN_H

/* FBA B data in (grp 55) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} fba_b_data_in_state_t;

void fba_b_data_in_init(fba_b_data_in_state_t *state);
void fba_b_data_in_update(fba_b_data_in_state_t *state);
void fba_b_read_data_in(fba_b_data_in_state_t *state);

#endif /* COMMUNICATION_FBA_FBA_B_DATA_IN_H */
