#ifndef COMMUNICATION_FBA_FBA_B_DATA_OUT_H
#define COMMUNICATION_FBA_FBA_B_DATA_OUT_H

/* FBA B data out (grp 56) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} fba_b_data_out_state_t;

void fba_b_data_out_init(fba_b_data_out_state_t *state);
void fba_b_data_out_update(fba_b_data_out_state_t *state);
void fba_b_write_data_out(fba_b_data_out_state_t *state);

#endif /* COMMUNICATION_FBA_FBA_B_DATA_OUT_H */
