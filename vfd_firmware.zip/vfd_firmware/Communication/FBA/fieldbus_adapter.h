#ifndef COMMUNICATION_FBA_FIELDBUS_ADAPTER_H
#define COMMUNICATION_FBA_FIELDBUS_ADAPTER_H

/* Fieldbus adapter core (grp 50) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} fieldbus_adapter_state_t;

void fieldbus_adapter_init(fieldbus_adapter_state_t *state);
void fieldbus_adapter_update(fieldbus_adapter_state_t *state);
void fba_init(fieldbus_adapter_state_t *state);
void fba_poll(fieldbus_adapter_state_t *state);

#endif /* COMMUNICATION_FBA_FIELDBUS_ADAPTER_H */
