#ifndef COMMUNICATION_FBA_FBA_B_SETTINGS_H
#define COMMUNICATION_FBA_FBA_B_SETTINGS_H

/* FBA B settings (grp 54) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} fba_b_settings_state_t;

void fba_b_settings_init(fba_b_settings_state_t *state);
void fba_b_settings_update(fba_b_settings_state_t *state);
void fba_b_configure(fba_b_settings_state_t *state);

#endif /* COMMUNICATION_FBA_FBA_B_SETTINGS_H */
