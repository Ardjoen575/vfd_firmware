#ifndef COMMUNICATION_FBA_FBA_A_SETTINGS_H
#define COMMUNICATION_FBA_FBA_A_SETTINGS_H

/* FBA A settings (grp 51) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} fba_a_settings_state_t;

void fba_a_settings_init(fba_a_settings_state_t *state);
void fba_a_settings_update(fba_a_settings_state_t *state);
void fba_a_configure(fba_a_settings_state_t *state);

#endif /* COMMUNICATION_FBA_FBA_A_SETTINGS_H */
