#ifndef COMMUNICATION_FBA_FBA_A_DATA_OUT_H
#define COMMUNICATION_FBA_FBA_A_DATA_OUT_H

/* FBA A data out (grp 53) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} fba_a_data_out_state_t;

void fba_a_data_out_init(fba_a_data_out_state_t *state);
void fba_a_data_out_update(fba_a_data_out_state_t *state);
void fba_a_write_data_out(fba_a_data_out_state_t *state);

#endif /* COMMUNICATION_FBA_FBA_A_DATA_OUT_H */
