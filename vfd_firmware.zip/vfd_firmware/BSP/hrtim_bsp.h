#ifndef BSP_HRTIM_BSP_H
#define BSP_HRTIM_BSP_H
void hrtim_bsp_init(void);
#endif
