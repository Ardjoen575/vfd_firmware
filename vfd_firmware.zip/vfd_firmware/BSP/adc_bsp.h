#ifndef BSP_ADC_BSP_H
#define BSP_ADC_BSP_H
void adc_bsp_init(void);
#endif
