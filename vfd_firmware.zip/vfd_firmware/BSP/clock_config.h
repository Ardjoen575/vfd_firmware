#ifndef BSP_CLOCK_CONFIG_H
#define BSP_CLOCK_CONFIG_H
void clock_config_init(void);
#endif
