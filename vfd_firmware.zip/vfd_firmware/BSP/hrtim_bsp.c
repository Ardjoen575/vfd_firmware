#include "hrtim_bsp.h"
void hrtim_bsp_init(void)
{
    /* TODO: implement */
}
