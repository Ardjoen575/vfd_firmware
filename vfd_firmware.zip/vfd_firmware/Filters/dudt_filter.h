#ifndef FILTERS_DUDT_FILTER_H
#define FILTERS_DUDT_FILTER_H

/* du/dt filter support */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} dudt_filter_state_t;

void dudt_filter_init(dudt_filter_state_t *state);
void dudt_filter_update(dudt_filter_state_t *state);
void dudt_filter_apply(dudt_filter_state_t *state);

#endif /* FILTERS_DUDT_FILTER_H */
