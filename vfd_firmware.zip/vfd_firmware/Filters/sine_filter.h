#ifndef FILTERS_SINE_FILTER_H
#define FILTERS_SINE_FILTER_H

/* Sine filter support */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} sine_filter_state_t;

void sine_filter_init(sine_filter_state_t *state);
void sine_filter_update(sine_filter_state_t *state);
void sine_filter_apply(sine_filter_state_t *state);

#endif /* FILTERS_SINE_FILTER_H */
