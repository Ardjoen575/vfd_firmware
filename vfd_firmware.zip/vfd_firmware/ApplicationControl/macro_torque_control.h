#ifndef APPLICATIONCONTROL_MACRO_TORQUE_CONTROL_H
#define APPLICATIONCONTROL_MACRO_TORQUE_CONTROL_H

/* Torque control macro defaults + wiring */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} macro_torque_control_state_t;

void macro_torque_control_init(macro_torque_control_state_t *state);
void macro_torque_control_update(macro_torque_control_state_t *state);
void macro_torque_apply(macro_torque_control_state_t *state);

#endif /* APPLICATIONCONTROL_MACRO_TORQUE_CONTROL_H */
