#ifndef APPLICATIONCONTROL_MACRO_FIELDBUS_H
#define APPLICATIONCONTROL_MACRO_FIELDBUS_H

/* Fieldbus control macro defaults + wiring */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} macro_fieldbus_state_t;

void macro_fieldbus_init(macro_fieldbus_state_t *state);
void macro_fieldbus_update(macro_fieldbus_state_t *state);
void macro_fieldbus_apply(macro_fieldbus_state_t *state);

#endif /* APPLICATIONCONTROL_MACRO_FIELDBUS_H */
