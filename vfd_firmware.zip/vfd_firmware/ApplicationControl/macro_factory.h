#ifndef APPLICATIONCONTROL_MACRO_FACTORY_H
#define APPLICATIONCONTROL_MACRO_FACTORY_H

/* Factory macro defaults + wiring */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} macro_factory_state_t;

void macro_factory_init(macro_factory_state_t *state);
void macro_factory_update(macro_factory_state_t *state);
void macro_factory_apply(macro_factory_state_t *state);

#endif /* APPLICATIONCONTROL_MACRO_FACTORY_H */
