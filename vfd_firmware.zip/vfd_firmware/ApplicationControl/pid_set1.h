#ifndef APPLICATIONCONTROL_PID_SET1_H
#define APPLICATIONCONTROL_PID_SET1_H

/* Process PID set 1 (grp 40) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} pid_set1_state_t;

void pid_set1_init(pid_set1_state_t *state);
void pid_set1_update(pid_set1_state_t *state);
void pid1_compute(pid_set1_state_t *state);

#endif /* APPLICATIONCONTROL_PID_SET1_H */
