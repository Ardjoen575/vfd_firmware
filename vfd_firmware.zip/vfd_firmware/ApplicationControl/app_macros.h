#ifndef APPLICATIONCONTROL_APP_MACROS_H
#define APPLICATIONCONTROL_APP_MACROS_H

/* Application macro dispatcher */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} app_macros_state_t;

void app_macros_init(app_macros_state_t *state);
void app_macros_update(app_macros_state_t *state);
void macro_apply_selected(app_macros_state_t *state);

#endif /* APPLICATIONCONTROL_APP_MACROS_H */
