#ifndef APPLICATIONCONTROL_MACRO_HAND_AUTO_H
#define APPLICATIONCONTROL_MACRO_HAND_AUTO_H

/* Hand/Auto macro defaults + wiring */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} macro_hand_auto_state_t;

void macro_hand_auto_init(macro_hand_auto_state_t *state);
void macro_hand_auto_update(macro_hand_auto_state_t *state);
void macro_hand_auto_apply(macro_hand_auto_state_t *state);

#endif /* APPLICATIONCONTROL_MACRO_HAND_AUTO_H */
