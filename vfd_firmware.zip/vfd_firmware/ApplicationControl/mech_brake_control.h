#ifndef APPLICATIONCONTROL_MECH_BRAKE_CONTROL_H
#define APPLICATIONCONTROL_MECH_BRAKE_CONTROL_H

/* Mechanical brake control (grp 44) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} mech_brake_control_state_t;

void mech_brake_control_init(mech_brake_control_state_t *state);
void mech_brake_control_update(mech_brake_control_state_t *state);
void mech_brake_open(mech_brake_control_state_t *state);
void mech_brake_close(mech_brake_control_state_t *state);

#endif /* APPLICATIONCONTROL_MECH_BRAKE_CONTROL_H */
