#ifndef APPLICATIONCONTROL_MOTOR_POTENTIOMETER_H
#define APPLICATIONCONTROL_MOTOR_POTENTIOMETER_H

/* Motor potentiometer function */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} motor_potentiometer_state_t;

void motor_potentiometer_init(motor_potentiometer_state_t *state);
void motor_potentiometer_update(motor_potentiometer_state_t *state);
void motpot_step(motor_potentiometer_state_t *state);

#endif /* APPLICATIONCONTROL_MOTOR_POTENTIOMETER_H */
