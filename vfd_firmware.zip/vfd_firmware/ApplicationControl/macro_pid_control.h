#ifndef APPLICATIONCONTROL_MACRO_PID_CONTROL_H
#define APPLICATIONCONTROL_MACRO_PID_CONTROL_H

/* PID control macro defaults + wiring */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} macro_pid_control_state_t;

void macro_pid_control_init(macro_pid_control_state_t *state);
void macro_pid_control_update(macro_pid_control_state_t *state);
void macro_pid_apply(macro_pid_control_state_t *state);

#endif /* APPLICATIONCONTROL_MACRO_PID_CONTROL_H */
