#ifndef APPLICATIONCONTROL_MACRO_SEQUENTIAL_H
#define APPLICATIONCONTROL_MACRO_SEQUENTIAL_H

/* Sequential control macro + constant-speed sequencing */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} macro_sequential_state_t;

void macro_sequential_init(macro_sequential_state_t *state);
void macro_sequential_update(macro_sequential_state_t *state);
void macro_sequential_apply(macro_sequential_state_t *state);

#endif /* APPLICATIONCONTROL_MACRO_SEQUENTIAL_H */
