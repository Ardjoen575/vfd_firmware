#ifndef APPLICATIONCONTROL_PID_SET2_H
#define APPLICATIONCONTROL_PID_SET2_H

/* Process PID set 2 (grp 41) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} pid_set2_state_t;

void pid_set2_init(pid_set2_state_t *state);
void pid_set2_update(pid_set2_state_t *state);
void pid2_compute(pid_set2_state_t *state);

#endif /* APPLICATIONCONTROL_PID_SET2_H */
