#ifndef STARTSTOP_SPEED_REF_RAMP_H
#define STARTSTOP_SPEED_REF_RAMP_H

/* Speed reference ramp (grp 23) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} speed_ref_ramp_state_t;

void speed_ref_ramp_init(speed_ref_ramp_state_t *state);
void speed_ref_ramp_update(speed_ref_ramp_state_t *state);
void speed_ref_ramp_step(speed_ref_ramp_state_t *state);

#endif /* STARTSTOP_SPEED_REF_RAMP_H */
