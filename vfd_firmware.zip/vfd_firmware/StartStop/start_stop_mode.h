#ifndef STARTSTOP_START_STOP_MODE_H
#define STARTSTOP_START_STOP_MODE_H

/* Start/stop mode configuration (grp 21) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} start_stop_mode_state_t;

void start_stop_mode_init(start_stop_mode_state_t *state);
void start_stop_mode_update(start_stop_mode_state_t *state);
void startstop_mode_configure(start_stop_mode_state_t *state);

#endif /* STARTSTOP_START_STOP_MODE_H */
