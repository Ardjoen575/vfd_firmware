#ifndef STARTSTOP_SPEED_REF_CONDITIONING_H
#define STARTSTOP_SPEED_REF_CONDITIONING_H

/* Speed reference conditioning (grp 24) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} speed_ref_conditioning_state_t;

void speed_ref_conditioning_init(speed_ref_conditioning_state_t *state);
void speed_ref_conditioning_update(speed_ref_conditioning_state_t *state);
void speed_ref_condition(speed_ref_conditioning_state_t *state);

#endif /* STARTSTOP_SPEED_REF_CONDITIONING_H */
