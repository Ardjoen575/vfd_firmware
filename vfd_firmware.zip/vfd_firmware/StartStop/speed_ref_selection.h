#ifndef STARTSTOP_SPEED_REF_SELECTION_H
#define STARTSTOP_SPEED_REF_SELECTION_H

/* Speed reference selection (grp 22) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} speed_ref_selection_state_t;

void speed_ref_selection_init(speed_ref_selection_state_t *state);
void speed_ref_selection_update(speed_ref_selection_state_t *state);
void speed_ref_select_source(speed_ref_selection_state_t *state);

#endif /* STARTSTOP_SPEED_REF_SELECTION_H */
