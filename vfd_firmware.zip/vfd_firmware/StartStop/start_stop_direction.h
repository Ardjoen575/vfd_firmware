#ifndef STARTSTOP_START_STOP_DIRECTION_H
#define STARTSTOP_START_STOP_DIRECTION_H

/* Start/stop/direction control (grp 20) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} start_stop_direction_state_t;

void start_stop_direction_init(start_stop_direction_state_t *state);
void start_stop_direction_update(start_stop_direction_state_t *state);
void start_cmd(start_stop_direction_state_t *state);
void stop_cmd(start_stop_direction_state_t *state);

#endif /* STARTSTOP_START_STOP_DIRECTION_H */
