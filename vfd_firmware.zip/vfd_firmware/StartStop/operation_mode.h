#ifndef STARTSTOP_OPERATION_MODE_H
#define STARTSTOP_OPERATION_MODE_H

/* Operation mode select (grp 19) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} operation_mode_state_t;

void operation_mode_init(operation_mode_state_t *state);
void operation_mode_update(operation_mode_state_t *state);
void opmode_apply(operation_mode_state_t *state);

#endif /* STARTSTOP_OPERATION_MODE_H */
