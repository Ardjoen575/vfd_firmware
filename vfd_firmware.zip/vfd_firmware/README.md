# vfd_firmware

Variable Frequency Drive firmware project skeleton, structured to mirror the
functional chapters and parameter groups of the ACS880 primary control
program firmware manual (3AUA0000085967 Rev V), for use as a development
reference while building original firmware.

## Layout
- `Core/` - entry point, shared types, RTOS scheduler, top-level state machine
- `BSP/` - board support package (clocks, GPIO map, timers, ADC, UART, watchdog)
- `Bootloader/` - firmware update / bootloader
- `Middleware/` - vendor HAL/CMSIS/RTOS (stubs - drop in your MCU vendor SDK)
- `MotorControl/`, `ReferenceChains/`, `StartStop/`, `DCVoltageControl/` - control algorithms
- `Protection/`, `Diagnostics/` - fault handling, monitoring, logging
- `Communication/` - Modbus RTU, embedded fieldbus, fieldbus adapter (FBA), DDCS
- `ParamStore/groups/` - one header per parameter group (real parameter names
  extracted from the manual), plus the flash storage engine
- `HWConfig/`, `IOBus/`, `ControlInterfaces/`, `ControlPanel/` - I/O and config
- `Docs/` - control chain diagrams, manual-to-code mapping, admin docs
- `Tests/` - unit / integration / hardware-in-the-loop test stubs

## Status
Auto-generated skeleton: struct/function signatures and parameter enums are
in place; algorithm bodies are TODO stubs for you to implement.
