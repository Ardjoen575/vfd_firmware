#ifndef MOTORCONTROL_DC_BRAKE_H
#define MOTORCONTROL_DC_BRAKE_H

/* DC injection braking */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} dc_brake_state_t;

void dc_brake_init(dc_brake_state_t *state);
void dc_brake_update(dc_brake_state_t *state);
void dc_brake_engage(dc_brake_state_t *state);

#endif /* MOTORCONTROL_DC_BRAKE_H */
