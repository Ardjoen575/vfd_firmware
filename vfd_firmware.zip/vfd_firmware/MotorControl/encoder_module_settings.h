#ifndef MOTORCONTROL_ENCODER_MODULE_SETTINGS_H
#define MOTORCONTROL_ENCODER_MODULE_SETTINGS_H

/* Encoder module settings (grp 91) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} encoder_module_settings_state_t;

void encoder_module_settings_init(encoder_module_settings_state_t *state);
void encoder_module_settings_update(encoder_module_settings_state_t *state);
void enc_module_configure(encoder_module_settings_state_t *state);

#endif /* MOTORCONTROL_ENCODER_MODULE_SETTINGS_H */
