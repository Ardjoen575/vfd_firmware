#ifndef MOTORCONTROL_OSCILLATION_DAMPING_H
#define MOTORCONTROL_OSCILLATION_DAMPING_H

/* Mechanical oscillation damping */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} oscillation_damping_state_t;

void oscillation_damping_init(oscillation_damping_state_t *state);
void oscillation_damping_update(oscillation_damping_state_t *state);
void osc_damp_apply(oscillation_damping_state_t *state);

#endif /* MOTORCONTROL_OSCILLATION_DAMPING_H */
