#ifndef MOTORCONTROL_AUTOPHASING_H
#define MOTORCONTROL_AUTOPHASING_H

/* Autophasing routine */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} autophasing_state_t;

void autophasing_init(autophasing_state_t *state);
void autophasing_update(autophasing_state_t *state);
void autophase_run(autophasing_state_t *state);

#endif /* MOTORCONTROL_AUTOPHASING_H */
