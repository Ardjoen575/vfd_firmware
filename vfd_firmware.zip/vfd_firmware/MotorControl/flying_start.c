#include "flying_start.h"

/* Catch a spinning motor
 * Implementation stub - fill in per manual section referenced in header.
 */

void flying_start_init(flying_start_state_t *state)
{
    state->initialized = 1;
    /* TODO: initialize module state */
}

void flying_start_update(flying_start_state_t *state)
{
    /* TODO: periodic update logic */
    (void)state;
}

void flying_start_search_speed(flying_start_state_t *state)
{
    /* TODO: implement flying_start_search_speed */
    (void)state;
}
