#ifndef MOTORCONTROL_HEXAGONAL_FLUX_H
#define MOTORCONTROL_HEXAGONAL_FLUX_H

/* Hexagonal motor flux pattern */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} hexagonal_flux_state_t;

void hexagonal_flux_init(hexagonal_flux_state_t *state);
void hexagonal_flux_update(hexagonal_flux_state_t *state);
void hex_flux_apply(hexagonal_flux_state_t *state);

#endif /* MOTORCONTROL_HEXAGONAL_FLUX_H */
