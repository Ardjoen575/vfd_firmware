#ifndef MOTORCONTROL_FLUX_BRAKING_H
#define MOTORCONTROL_FLUX_BRAKING_H

/* Flux braking */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} flux_braking_state_t;

void flux_braking_init(flux_braking_state_t *state);
void flux_braking_update(flux_braking_state_t *state);
void flux_brake_apply(flux_braking_state_t *state);

#endif /* MOTORCONTROL_FLUX_BRAKING_H */
