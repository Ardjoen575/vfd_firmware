#ifndef MOTORCONTROL_CRITICAL_SPEEDS_H
#define MOTORCONTROL_CRITICAL_SPEEDS_H

/* Critical speeds/frequencies avoidance */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} critical_speeds_state_t;

void critical_speeds_init(critical_speeds_state_t *state);
void critical_speeds_update(critical_speeds_state_t *state);
void critical_speed_filter(critical_speeds_state_t *state);

#endif /* MOTORCONTROL_CRITICAL_SPEEDS_H */
