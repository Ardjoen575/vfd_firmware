#ifndef MOTORCONTROL_REF_RAMP_H
#define MOTORCONTROL_REF_RAMP_H

/* Reference ramping engine */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} ref_ramp_state_t;

void ref_ramp_init(ref_ramp_state_t *state);
void ref_ramp_update(ref_ramp_state_t *state);
void ramp_step(ref_ramp_state_t *state);

#endif /* MOTORCONTROL_REF_RAMP_H */
