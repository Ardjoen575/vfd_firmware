#ifndef MOTORCONTROL_RESONANCE_ELIMINATION_H
#define MOTORCONTROL_RESONANCE_ELIMINATION_H

/* Resonance frequency elimination */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} resonance_elimination_state_t;

void resonance_elimination_init(resonance_elimination_state_t *state);
void resonance_elimination_update(resonance_elimination_state_t *state);
void resonance_filter_apply(resonance_elimination_state_t *state);

#endif /* MOTORCONTROL_RESONANCE_ELIMINATION_H */
