#ifndef MOTORCONTROL_ENCODER_1_CONFIG_H
#define MOTORCONTROL_ENCODER_1_CONFIG_H

/* Encoder 1 configuration (grp 92) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} encoder_1_config_state_t;

void encoder_1_config_init(encoder_1_config_state_t *state);
void encoder_1_config_update(encoder_1_config_state_t *state);
void enc1_read_position(encoder_1_config_state_t *state);

#endif /* MOTORCONTROL_ENCODER_1_CONFIG_H */
