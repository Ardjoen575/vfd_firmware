#ifndef MOTORCONTROL_DC_MAGNETIZATION_H
#define MOTORCONTROL_DC_MAGNETIZATION_H

/* DC magnetization */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} dc_magnetization_state_t;

void dc_magnetization_init(dc_magnetization_state_t *state);
void dc_magnetization_update(dc_magnetization_state_t *state);
void dc_mag_apply(dc_magnetization_state_t *state);

#endif /* MOTORCONTROL_DC_MAGNETIZATION_H */
