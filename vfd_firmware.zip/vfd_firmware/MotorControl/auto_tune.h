#ifndef MOTORCONTROL_AUTO_TUNE_H
#define MOTORCONTROL_AUTO_TUNE_H

/* Stator resistance measurement / motor ID run */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} auto_tune_state_t;

void auto_tune_init(auto_tune_state_t *state);
void auto_tune_update(auto_tune_state_t *state);
void autotune_run_id_run(auto_tune_state_t *state);

#endif /* MOTORCONTROL_AUTO_TUNE_H */
