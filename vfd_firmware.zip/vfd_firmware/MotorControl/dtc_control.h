#ifndef MOTORCONTROL_DTC_CONTROL_H
#define MOTORCONTROL_DTC_CONTROL_H

/* Direct Torque Control core */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} dtc_control_state_t;

void dtc_control_init(dtc_control_state_t *state);
void dtc_control_update(dtc_control_state_t *state);
void dtc_compute_torque_step(dtc_control_state_t *state);
void dtc_flux_estimate(dtc_control_state_t *state);

#endif /* MOTORCONTROL_DTC_CONTROL_H */
