#ifndef MOTORCONTROL_SPEED_CTRL_AUTOTUNE_H
#define MOTORCONTROL_SPEED_CTRL_AUTOTUNE_H

/* Speed controller autotune routine */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} speed_ctrl_autotune_state_t;

void speed_ctrl_autotune_init(speed_ctrl_autotune_state_t *state);
void speed_ctrl_autotune_update(speed_ctrl_autotune_state_t *state);
void speed_autotune_run(speed_ctrl_autotune_state_t *state);

#endif /* MOTORCONTROL_SPEED_CTRL_AUTOTUNE_H */
