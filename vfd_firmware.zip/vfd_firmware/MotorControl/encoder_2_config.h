#ifndef MOTORCONTROL_ENCODER_2_CONFIG_H
#define MOTORCONTROL_ENCODER_2_CONFIG_H

/* Encoder 2 configuration (grp 93) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} encoder_2_config_state_t;

void encoder_2_config_init(encoder_2_config_state_t *state);
void encoder_2_config_update(encoder_2_config_state_t *state);
void enc2_read_position(encoder_2_config_state_t *state);

#endif /* MOTORCONTROL_ENCODER_2_CONFIG_H */
