#ifndef MOTORCONTROL_JOGGING_H
#define MOTORCONTROL_JOGGING_H

/* Jog control */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} jogging_state_t;

void jogging_init(jogging_state_t *state);
void jogging_update(jogging_state_t *state);
void jog_start(jogging_state_t *state);
void jog_stop(jogging_state_t *state);

#endif /* MOTORCONTROL_JOGGING_H */
