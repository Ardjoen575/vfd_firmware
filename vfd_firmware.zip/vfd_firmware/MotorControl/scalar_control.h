#ifndef MOTORCONTROL_SCALAR_CONTROL_H
#define MOTORCONTROL_SCALAR_CONTROL_H

/* Scalar (V/f) motor control */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} scalar_control_state_t;

void scalar_control_init(scalar_control_state_t *state);
void scalar_control_update(scalar_control_state_t *state);
void scalar_ctrl_step(scalar_control_state_t *state);

#endif /* MOTORCONTROL_SCALAR_CONTROL_H */
