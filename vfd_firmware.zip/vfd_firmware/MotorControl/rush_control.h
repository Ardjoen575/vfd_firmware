#ifndef MOTORCONTROL_RUSH_CONTROL_H
#define MOTORCONTROL_RUSH_CONTROL_H

/* Rush control */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} rush_control_state_t;

void rush_control_init(rush_control_state_t *state);
void rush_control_update(rush_control_state_t *state);
void rush_control_apply(rush_control_state_t *state);

#endif /* MOTORCONTROL_RUSH_CONTROL_H */
