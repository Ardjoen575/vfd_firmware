#ifndef MOTORCONTROL_FLYING_START_H
#define MOTORCONTROL_FLYING_START_H

/* Catch a spinning motor */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} flying_start_state_t;

void flying_start_init(flying_start_state_t *state);
void flying_start_update(flying_start_state_t *state);
void flying_start_search_speed(flying_start_state_t *state);

#endif /* MOTORCONTROL_FLYING_START_H */
