#ifndef MOTORCONTROL_FEEDBACK_SELECTION_H
#define MOTORCONTROL_FEEDBACK_SELECTION_H

/* Motor feedback source selection (grp 90) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} feedback_selection_state_t;

void feedback_selection_init(feedback_selection_state_t *state);
void feedback_selection_update(feedback_selection_state_t *state);
void feedback_select_source(feedback_selection_state_t *state);

#endif /* MOTORCONTROL_FEEDBACK_SELECTION_H */
