#ifndef MOTORCONTROL_CONSTANT_SPEEDS_H
#define MOTORCONTROL_CONSTANT_SPEEDS_H

/* Constant speeds/frequencies */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} constant_speeds_state_t;

void constant_speeds_init(constant_speeds_state_t *state);
void constant_speeds_update(constant_speeds_state_t *state);
void const_speed_select(constant_speeds_state_t *state);

#endif /* MOTORCONTROL_CONSTANT_SPEEDS_H */
