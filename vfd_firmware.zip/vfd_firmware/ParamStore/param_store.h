#ifndef PARAMSTORE_PARAM_STORE_H
#define PARAMSTORE_PARAM_STORE_H

/* Parameter flash storage engine */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} param_store_state_t;

void param_store_init(param_store_state_t *state);
void param_store_update(param_store_state_t *state);
void param_store_load_all(param_store_state_t *state);
void param_store_save_all(param_store_state_t *state);

#endif /* PARAMSTORE_PARAM_STORE_H */
