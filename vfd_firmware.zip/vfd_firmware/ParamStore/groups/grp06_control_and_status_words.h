#ifndef VFD_PARAM_GRP06_CONTROL_AND_STATUS_WORDS_H
#define VFD_PARAM_GRP06_CONTROL_AND_STATUS_WORDS_H

/* Parameter group 06: Control and status words
 * Auto-generated from ACS880 primary control program firmware manual
 * 45 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 06) ---- */
typedef enum {
    PARAM_06_01_MAIN_CONTROL_WORD = 1, /* 06.01 Main control word */
    PARAM_06_02_APPLICATION_CONTROL = 2, /* 06.02 Application control */
    PARAM_06_03_FBA_A_TRANSPARENT = 3, /* 06.03 FBA A transparent */
    PARAM_06_04_FBA_B_TRANSPARENT = 4, /* 06.04 FBA B transparent */
    PARAM_06_05_EFB_TRANSPARENT = 5, /* 06.05 EFB transparent */
    PARAM_06_11_MAIN_STATUS_WORD = 11, /* 06.11 Main status word */
    PARAM_06_16_DRIVE_STATUS_WORD_1 = 16, /* 06.16 Drive status word 1 */
    PARAM_06_17_DRIVE_STATUS_WORD_2 = 17, /* 06.17 Drive status word 2 */
    PARAM_06_18_START_INHIBIT_STATUS = 18, /* 06.18 Start inhibit status */
    PARAM_06_19_SPEED_CONTROL = 19, /* 06.19 Speed control */
    PARAM_06_20_CONSTANT_SPEED = 20, /* 06.20 Constant speed */
    PARAM_06_21_DRIVE_STATUS_WORD_3 = 21, /* 06.21 Drive status word 3 */
    PARAM_06_25_DRIVE_INHIBIT_STATUS = 25, /* 06.25 Drive inhibit status */
    PARAM_06_29_MSW_BIT_10_SEL = 29, /* 06.29 MSW bit 10 sel */
    PARAM_06_30_MSW_BIT_11_SEL = 30, /* 06.30 MSW bit 11 sel */
    PARAM_06_31_MSW_BIT_12_SEL = 31, /* 06.31 MSW bit 12 sel */
    PARAM_06_32_MSW_BIT_13_SEL = 32, /* 06.32 MSW bit 13 sel */
    PARAM_06_33_MSW_BIT_14_SEL = 33, /* 06.33 MSW bit 14 sel */
    PARAM_06_36_LSU_STATUS_WORD = 36, /* 06.36 LSU Status Word */
    PARAM_06_39_INTERNAL_STATE = 39, /* 06.39 Internal state */
    PARAM_06_40_LSU_CW_USER_BIT_0 = 40, /* 06.40 LSU CW user bit 0 */
    PARAM_06_41_LSU_CW_USER_BIT_1 = 41, /* 06.41 LSU CW user bit 1 */
    PARAM_06_42_LSU_CW_USER_BIT_2 = 42, /* 06.42 LSU CW user bit 2 */
    PARAM_06_43_LSU_CW_USER_BIT_3 = 43, /* 06.43 LSU CW user bit 3 */
    PARAM_06_45_FOLLOWER_CW_USER = 45, /* 06.45 Follower CW user */
    PARAM_06_46_FOLLOWER_CW_USER = 46, /* 06.46 Follower CW user */
    PARAM_06_47_FOLLOWER_CW_USER = 47, /* 06.47 Follower CW user */
    PARAM_06_48_FOLLOWER_CW_USER = 48, /* 06.48 Follower CW user */
    PARAM_06_50_USER_STATUS_WORD_1 = 50, /* 06.50 User status word 1 */
    PARAM_06_60_USER_STATUS_WORD_1 = 60, /* 06.60 User status word 1 */
    PARAM_06_61_USER_STATUS_WORD_1 = 61, /* 06.61 User status word 1 */
    PARAM_06_62_USER_STATUS_WORD_1 = 62, /* 06.62 User status word 1 */
    PARAM_06_63_USER_STATUS_WORD_1 = 63, /* 06.63 User status word 1 */
    PARAM_06_64_USER_STATUS_WORD_1 = 64, /* 06.64 User status word 1 */
    PARAM_06_65_USER_STATUS_WORD_1 = 65, /* 06.65 User status word 1 */
    PARAM_06_66_USER_STATUS_WORD_1 = 66, /* 06.66 User status word 1 */
    PARAM_06_67_USER_STATUS_WORD_1 = 67, /* 06.67 User status word 1 */
    PARAM_06_68_USER_STATUS_WORD_1 = 68, /* 06.68 User status word 1 */
    PARAM_06_69_USER_STATUS_WORD_1 = 69, /* 06.69 User status word 1 */
    PARAM_06_70_USER_STATUS_WORD_1 = 70, /* 06.70 User status word 1 */
    PARAM_06_71_USER_STATUS_WORD_1 = 71, /* 06.71 User status word 1 */
    PARAM_06_72_USER_STATUS_WORD_1 = 72, /* 06.72 User status word 1 */
    PARAM_06_73_USER_STATUS_WORD_1 = 73, /* 06.73 User status word 1 */
    PARAM_06_74_USER_STATUS_WORD_1 = 74, /* 06.74 User status word 1 */
    PARAM_06_75_USER_STATUS_WORD_1 = 75, /* 06.75 User status word 1 */
} param_group_06_index_t;

/* ---- Live value storage (group 06) ---- */
typedef struct {
    float p01_main_control_word;  /* 06.01 Main control word */
    float p02_application_control;  /* 06.02 Application control */
    float p03_fba_a_transparent;  /* 06.03 FBA A transparent */
    float p04_fba_b_transparent;  /* 06.04 FBA B transparent */
    float p05_efb_transparent;  /* 06.05 EFB transparent */
    float p11_main_status_word;  /* 06.11 Main status word */
    float p16_drive_status_word_1;  /* 06.16 Drive status word 1 */
    float p17_drive_status_word_2;  /* 06.17 Drive status word 2 */
    float p18_start_inhibit_status;  /* 06.18 Start inhibit status */
    float p19_speed_control;  /* 06.19 Speed control */
    float p20_constant_speed;  /* 06.20 Constant speed */
    float p21_drive_status_word_3;  /* 06.21 Drive status word 3 */
    float p25_drive_inhibit_status;  /* 06.25 Drive inhibit status */
    float p29_msw_bit_10_sel;  /* 06.29 MSW bit 10 sel */
    float p30_msw_bit_11_sel;  /* 06.30 MSW bit 11 sel */
    float p31_msw_bit_12_sel;  /* 06.31 MSW bit 12 sel */
    float p32_msw_bit_13_sel;  /* 06.32 MSW bit 13 sel */
    float p33_msw_bit_14_sel;  /* 06.33 MSW bit 14 sel */
    float p36_lsu_status_word;  /* 06.36 LSU Status Word */
    float p39_internal_state;  /* 06.39 Internal state */
    float p40_lsu_cw_user_bit_0;  /* 06.40 LSU CW user bit 0 */
    float p41_lsu_cw_user_bit_1;  /* 06.41 LSU CW user bit 1 */
    float p42_lsu_cw_user_bit_2;  /* 06.42 LSU CW user bit 2 */
    float p43_lsu_cw_user_bit_3;  /* 06.43 LSU CW user bit 3 */
    float p45_follower_cw_user;  /* 06.45 Follower CW user */
    float p46_follower_cw_user;  /* 06.46 Follower CW user */
    float p47_follower_cw_user;  /* 06.47 Follower CW user */
    float p48_follower_cw_user;  /* 06.48 Follower CW user */
    float p50_user_status_word_1;  /* 06.50 User status word 1 */
    float p60_user_status_word_1;  /* 06.60 User status word 1 */
    float p61_user_status_word_1;  /* 06.61 User status word 1 */
    float p62_user_status_word_1;  /* 06.62 User status word 1 */
    float p63_user_status_word_1;  /* 06.63 User status word 1 */
    float p64_user_status_word_1;  /* 06.64 User status word 1 */
    float p65_user_status_word_1;  /* 06.65 User status word 1 */
    float p66_user_status_word_1;  /* 06.66 User status word 1 */
    float p67_user_status_word_1;  /* 06.67 User status word 1 */
    float p68_user_status_word_1;  /* 06.68 User status word 1 */
    float p69_user_status_word_1;  /* 06.69 User status word 1 */
    float p70_user_status_word_1;  /* 06.70 User status word 1 */
    float p71_user_status_word_1;  /* 06.71 User status word 1 */
    float p72_user_status_word_1;  /* 06.72 User status word 1 */
    float p73_user_status_word_1;  /* 06.73 User status word 1 */
    float p74_user_status_word_1;  /* 06.74 User status word 1 */
    float p75_user_status_word_1;  /* 06.75 User status word 1 */
} param_group_06_t;

extern param_group_06_t g_param_grp06;

void param_grp06_init(void);
void param_grp06_load_defaults(void);
int  param_grp06_get(uint8_t index, float *out_value);
int  param_grp06_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP06_CONTROL_AND_STATUS_WORDS_H */
