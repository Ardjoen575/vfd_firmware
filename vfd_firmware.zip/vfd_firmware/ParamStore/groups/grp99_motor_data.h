#ifndef VFD_PARAM_GRP99_MOTOR_DATA_H
#define VFD_PARAM_GRP99_MOTOR_DATA_H

/* Parameter group 99: Motor data
 * Auto-generated from ACS880 primary control program firmware manual
 * 14 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 99) ---- */
typedef enum {
    PARAM_99_03_MOTOR_TYPE = 3, /* 99.03 Motor type */
    PARAM_99_04_MOTOR_CONTROL_MODE = 4, /* 99.04 Motor control mode */
    PARAM_99_06_MOTOR_NOMINAL = 6, /* 99.06 Motor nominal */
    PARAM_99_07_MOTOR_NOMINAL = 7, /* 99.07 Motor nominal */
    PARAM_99_08_MOTOR_NOMINAL = 8, /* 99.08 Motor nominal */
    PARAM_99_09_MOTOR_NOMINAL = 9, /* 99.09 Motor nominal */
    PARAM_99_10_MOTOR_NOMINAL = 10, /* 99.10 Motor nominal */
    PARAM_99_11_MOTOR_NOMINAL_COS = 11, /* 99.11 Motor nominal cos */
    PARAM_99_12_MOTOR_NOMINAL = 12, /* 99.12 Motor nominal */
    PARAM_99_13_ID_RUN_REQUESTED = 13, /* 99.13 ID run requested */
    PARAM_99_14_LAST_ID_RUN = 14, /* 99.14 Last ID run */
    PARAM_99_15_MOTOR_POLEPAIRS = 15, /* 99.15 Motor polepairs */
    PARAM_99_16_MOTOR_PHASE_ORDER = 16, /* 99.16 Motor phase order */
    PARAM_99_18_SINE_FILTER = 18, /* 99.18 Sine filter */
} param_group_99_index_t;

/* ---- Live value storage (group 99) ---- */
typedef struct {
    float p03_motor_type;  /* 99.03 Motor type */
    float p04_motor_control_mode;  /* 99.04 Motor control mode */
    float p06_motor_nominal;  /* 99.06 Motor nominal */
    float p07_motor_nominal;  /* 99.07 Motor nominal */
    float p08_motor_nominal;  /* 99.08 Motor nominal */
    float p09_motor_nominal;  /* 99.09 Motor nominal */
    float p10_motor_nominal;  /* 99.10 Motor nominal */
    float p11_motor_nominal_cos;  /* 99.11 Motor nominal cos */
    float p12_motor_nominal;  /* 99.12 Motor nominal */
    float p13_id_run_requested;  /* 99.13 ID run requested */
    float p14_last_id_run;  /* 99.14 Last ID run */
    float p15_motor_polepairs;  /* 99.15 Motor polepairs */
    float p16_motor_phase_order;  /* 99.16 Motor phase order */
    float p18_sine_filter;  /* 99.18 Sine filter */
} param_group_99_t;

extern param_group_99_t g_param_grp99;

void param_grp99_init(void);
void param_grp99_load_defaults(void);
int  param_grp99_get(uint8_t index, float *out_value);
int  param_grp99_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP99_MOTOR_DATA_H */
