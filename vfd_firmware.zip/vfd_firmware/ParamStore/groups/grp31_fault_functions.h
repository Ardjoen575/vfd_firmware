#ifndef VFD_PARAM_GRP31_FAULT_FUNCTIONS_H
#define VFD_PARAM_GRP31_FAULT_FUNCTIONS_H

/* Parameter group 31: Fault functions
 * Auto-generated from ACS880 primary control program firmware manual
 * 36 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 31) ---- */
typedef enum {
    PARAM_31_01_EXTERNAL_EVENT_1 = 1, /* 31.01 External event 1 */
    PARAM_31_02_EXTERNAL_EVENT_1 = 2, /* 31.02 External event 1 */
    PARAM_31_03_EXTERNAL_EVENT_2 = 3, /* 31.03 External event 2 */
    PARAM_31_04_EXTERNAL_EVENT_2 = 4, /* 31.04 External event 2 */
    PARAM_31_05_EXTERNAL_EVENT_3 = 5, /* 31.05 External event 3 */
    PARAM_31_06_EXTERNAL_EVENT_3 = 6, /* 31.06 External event 3 */
    PARAM_31_07_EXTERNAL_EVENT_4 = 7, /* 31.07 External event 4 */
    PARAM_31_08_EXTERNAL_EVENT_4 = 8, /* 31.08 External event 4 */
    PARAM_31_09_EXTERNAL_EVENT_5 = 9, /* 31.09 External event 5 */
    PARAM_31_10_EXTERNAL_EVENT_5 = 10, /* 31.10 External event 5 */
    PARAM_31_11_FAULT_RESET = 11, /* 31.11 Fault reset */
    PARAM_31_12_AUTORESET_SELECTION = 12, /* 31.12 Autoreset selection */
    PARAM_31_13_USER_SELECTABLE = 13, /* 31.13 User selectable */
    PARAM_31_14_NUMBER_OF_TRIALS = 14, /* 31.14 Number of trials */
    PARAM_31_15_TOTAL_TRIALS_TIME = 15, /* 31.15 Total trials time */
    PARAM_31_16_DELAY_TIME = 16, /* 31.16 Delay time */
    PARAM_31_19_MOTOR_PHASE_LOSS = 19, /* 31.19 Motor phase loss */
    PARAM_31_20_EARTH_FAULT = 20, /* 31.20 Earth fault */
    PARAM_31_22_STO_INDICATION = 22, /* 31.22 STO indication */
    PARAM_31_23_WIRING_OR_EARTH_FAULT = 23, /* 31.23 Wiring or earth fault */
    PARAM_31_24_STALL_FUNCTION = 24, /* 31.24 Stall function */
    PARAM_31_25_STALL_CURRENT_LIMIT = 25, /* 31.25 Stall current limit */
    PARAM_31_26_STALL_SPEED_LIMIT = 26, /* 31.26 Stall speed limit */
    PARAM_31_27_STALL_FREQUENCY_LIMIT = 27, /* 31.27 Stall frequency limit */
    PARAM_31_28_STALL_TIME = 28, /* 31.28 Stall time */
    PARAM_31_30_OVERSPEED_TRIP = 30, /* 31.30 Overspeed trip */
    PARAM_31_32_EMERGENCY_RAMP = 32, /* 31.32 Emergency ramp */
    PARAM_31_33_EMERGENCY_RAMP = 33, /* 31.33 Emergency ramp */
    PARAM_31_35_MAIN_FAN_FAULT = 35, /* 31.35 Main fan fault */
    PARAM_31_36_AUX_FAN_FAULT = 36, /* 31.36 Aux fan fault */
    PARAM_31_37_RAMP_STOP = 37, /* 31.37 Ramp stop */
    PARAM_31_38_RAMP_STOP = 38, /* 31.38 Ramp stop */
    PARAM_31_40_DISABLE_WARNING = 40, /* 31.40 Disable warning */
    PARAM_31_42_OVERCURRENT_FAULT = 42, /* 31.42 Overcurrent fault */
    PARAM_31_54_FAULT_ACTION = 54, /* 31.54 Fault action */
    PARAM_31_55_EXT_I_O_COMM_LOSS = 55, /* 31.55 Ext I/O comm loss */
} param_group_31_index_t;

/* ---- Live value storage (group 31) ---- */
typedef struct {
    float p01_external_event_1;  /* 31.01 External event 1 */
    float p02_external_event_1;  /* 31.02 External event 1 */
    float p03_external_event_2;  /* 31.03 External event 2 */
    float p04_external_event_2;  /* 31.04 External event 2 */
    float p05_external_event_3;  /* 31.05 External event 3 */
    float p06_external_event_3;  /* 31.06 External event 3 */
    float p07_external_event_4;  /* 31.07 External event 4 */
    float p08_external_event_4;  /* 31.08 External event 4 */
    float p09_external_event_5;  /* 31.09 External event 5 */
    float p10_external_event_5;  /* 31.10 External event 5 */
    float p11_fault_reset;  /* 31.11 Fault reset */
    float p12_autoreset_selection;  /* 31.12 Autoreset selection */
    float p13_user_selectable;  /* 31.13 User selectable */
    float p14_number_of_trials;  /* 31.14 Number of trials */
    float p15_total_trials_time;  /* 31.15 Total trials time */
    float p16_delay_time;  /* 31.16 Delay time */
    float p19_motor_phase_loss;  /* 31.19 Motor phase loss */
    float p20_earth_fault;  /* 31.20 Earth fault */
    float p22_sto_indication;  /* 31.22 STO indication */
    float p23_wiring_or_earth_fault;  /* 31.23 Wiring or earth fault */
    float p24_stall_function;  /* 31.24 Stall function */
    float p25_stall_current_limit;  /* 31.25 Stall current limit */
    float p26_stall_speed_limit;  /* 31.26 Stall speed limit */
    float p27_stall_frequency_limit;  /* 31.27 Stall frequency limit */
    float p28_stall_time;  /* 31.28 Stall time */
    float p30_overspeed_trip;  /* 31.30 Overspeed trip */
    float p32_emergency_ramp;  /* 31.32 Emergency ramp */
    float p33_emergency_ramp;  /* 31.33 Emergency ramp */
    float p35_main_fan_fault;  /* 31.35 Main fan fault */
    float p36_aux_fan_fault;  /* 31.36 Aux fan fault */
    float p37_ramp_stop;  /* 31.37 Ramp stop */
    float p38_ramp_stop;  /* 31.38 Ramp stop */
    float p40_disable_warning;  /* 31.40 Disable warning */
    float p42_overcurrent_fault;  /* 31.42 Overcurrent fault */
    float p54_fault_action;  /* 31.54 Fault action */
    float p55_ext_i_o_comm_loss;  /* 31.55 Ext I/O comm loss */
} param_group_31_t;

extern param_group_31_t g_param_grp31;

void param_grp31_init(void);
void param_grp31_load_defaults(void);
int  param_grp31_get(uint8_t index, float *out_value);
int  param_grp31_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP31_FAULT_FUNCTIONS_H */
