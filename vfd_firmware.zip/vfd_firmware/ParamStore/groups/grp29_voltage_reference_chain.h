#ifndef VFD_PARAM_GRP29_VOLTAGE_REFERENCE_CHAIN_H
#define VFD_PARAM_GRP29_VOLTAGE_REFERENCE_CHAIN_H

/* Parameter group 29: Voltage reference chain
 * Auto-generated from ACS880 primary control program firmware manual
 * 30 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 29) ---- */
typedef enum {
    PARAM_29_01_TORQUE_REF_DC = 1, /* 29.01 Torque ref DC */
    PARAM_29_02_DC_VOLTAGE_REF = 2, /* 29.02 DC voltage ref */
    PARAM_29_03_DC_VOLTAGE_REF_USED_DISPLAYS_THE_DC_VOLTAGE_REFERENCE_BETWEEN = 3, /* 29.03 DC voltage ref used Displays the DC voltage reference between */
    PARAM_29_04_DC_VOLTAGE_REF = 4, /* 29.04 DC voltage ref */
    PARAM_29_05_FILTERED_DC_VOLTAGE = 5, /* 29.05 Filtered DC voltage */
    PARAM_29_06_DC_VOLTAGE_ERROR = 6, /* 29.06 DC voltage error */
    PARAM_29_07_POWER_REFERENCE = 7, /* 29.07 Power reference */
    PARAM_29_09_MINIMUM_DC = 9, /* 29.09 Minimum DC */
    PARAM_29_10_MAXIMUM_DC = 10, /* 29.10 Maximum DC */
    PARAM_29_11_DC_VOLTAGE_REF1 = 11, /* 29.11 DC voltage ref1 */
    PARAM_29_12_DC_VOLTAGE_REF2 = 12, /* 29.12 DC voltage ref2 */
    PARAM_29_13_DC_VOLTAGE_REF1 = 13, /* 29.13 DC voltage ref1 */
    PARAM_29_14_DC_VOLTAGE_REF1_2 = 14, /* 29.14 DC voltage ref1/2 */
    PARAM_29_17_DC_VOLTAGE_FILTER = 17, /* 29.17 DC voltage filter */
    PARAM_29_18_DC_VOLTAGE_RAMP = 18, /* 29.18 DC voltage ramp */
    PARAM_29_19_DC_VOLTAGE_RAMP_UP = 19, /* 29.19 DC voltage ramp up */
    PARAM_29_20_DC_VOLTAGE = 20, /* 29.20 DC voltage */
    PARAM_29_21_DC_VOLTAGE = 21, /* 29.21 DC voltage */
    PARAM_29_25_DC_CAPACITANCE = 25, /* 29.25 DC capacitance */
    PARAM_29_26_USED_DC = 26, /* 29.26 Used DC */
    PARAM_29_70_SPEED_DATA_POINT_1 = 70, /* 29.70 Speed data point 1 */
    PARAM_29_71_TORQUE_DATA_POINT_1 = 71, /* 29.71 Torque data point 1 */
    PARAM_29_72_SPEED_DATA_POINT_2 = 72, /* 29.72 Speed data point 2 */
    PARAM_29_73_TORQUE_DATA_POINT_2 = 73, /* 29.73 Torque data point 2 */
    PARAM_29_74_SPEED_DATA_POINT_3 = 74, /* 29.74 Speed data point 3 */
    PARAM_29_75_TORQUE_DATA_POINT_3 = 75, /* 29.75 Torque data point 3 */
    PARAM_29_76_SPEED_DATA_POINT_4 = 76, /* 29.76 Speed data point 4 */
    PARAM_29_77_TORQUE_DATA_POINT_4 = 77, /* 29.77 Torque data point 4 */
    PARAM_29_78_SPEED_DATA_POINT_5 = 78, /* 29.78 Speed data point 5 */
    PARAM_29_79_TORQUE_DATA_POINT_5 = 79, /* 29.79 Torque data point 5 */
} param_group_29_index_t;

/* ---- Live value storage (group 29) ---- */
typedef struct {
    float p01_torque_ref_dc;  /* 29.01 Torque ref DC */
    float p02_dc_voltage_ref;  /* 29.02 DC voltage ref */
    float p03_dc_voltage_ref_used_displays_the_dc_voltage_reference_between;  /* 29.03 DC voltage ref used Displays the DC voltage reference between */
    float p04_dc_voltage_ref;  /* 29.04 DC voltage ref */
    float p05_filtered_dc_voltage;  /* 29.05 Filtered DC voltage */
    float p06_dc_voltage_error;  /* 29.06 DC voltage error */
    float p07_power_reference;  /* 29.07 Power reference */
    float p09_minimum_dc;  /* 29.09 Minimum DC */
    float p10_maximum_dc;  /* 29.10 Maximum DC */
    float p11_dc_voltage_ref1;  /* 29.11 DC voltage ref1 */
    float p12_dc_voltage_ref2;  /* 29.12 DC voltage ref2 */
    float p13_dc_voltage_ref1;  /* 29.13 DC voltage ref1 */
    float p14_dc_voltage_ref1_2;  /* 29.14 DC voltage ref1/2 */
    float p17_dc_voltage_filter;  /* 29.17 DC voltage filter */
    float p18_dc_voltage_ramp;  /* 29.18 DC voltage ramp */
    float p19_dc_voltage_ramp_up;  /* 29.19 DC voltage ramp up */
    float p20_dc_voltage;  /* 29.20 DC voltage */
    float p21_dc_voltage;  /* 29.21 DC voltage */
    float p25_dc_capacitance;  /* 29.25 DC capacitance */
    float p26_used_dc;  /* 29.26 Used DC */
    float p70_speed_data_point_1;  /* 29.70 Speed data point 1 */
    float p71_torque_data_point_1;  /* 29.71 Torque data point 1 */
    float p72_speed_data_point_2;  /* 29.72 Speed data point 2 */
    float p73_torque_data_point_2;  /* 29.73 Torque data point 2 */
    float p74_speed_data_point_3;  /* 29.74 Speed data point 3 */
    float p75_torque_data_point_3;  /* 29.75 Torque data point 3 */
    float p76_speed_data_point_4;  /* 29.76 Speed data point 4 */
    float p77_torque_data_point_4;  /* 29.77 Torque data point 4 */
    float p78_speed_data_point_5;  /* 29.78 Speed data point 5 */
    float p79_torque_data_point_5;  /* 29.79 Torque data point 5 */
} param_group_29_t;

extern param_group_29_t g_param_grp29;

void param_grp29_init(void);
void param_grp29_load_defaults(void);
int  param_grp29_get(uint8_t index, float *out_value);
int  param_grp29_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP29_VOLTAGE_REFERENCE_CHAIN_H */
