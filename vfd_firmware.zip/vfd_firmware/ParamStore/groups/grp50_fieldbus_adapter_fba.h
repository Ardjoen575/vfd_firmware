#ifndef VFD_PARAM_GRP50_FIELDBUS_ADAPTER_FBA_H
#define VFD_PARAM_GRP50_FIELDBUS_ADAPTER_FBA_H

/* Parameter group 50: Fieldbus adapter FBA
 * Auto-generated from ACS880 primary control program firmware manual
 * 38 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 50) ---- */
typedef enum {
    PARAM_50_01_FBA_A_ENABLE = 1, /* 50.01 FBA A enable */
    PARAM_50_02_FBA_A_COMM_LOSS = 2, /* 50.02 FBA A comm loss */
    PARAM_50_03_FBA_A_COMM_LOSS_T = 3, /* 50.03 FBA A comm loss t */
    PARAM_50_04_FBA_A_REF1_TYPE = 4, /* 50.04 FBA A ref1 type */
    PARAM_50_05_FBA_A_REF2_TYPE = 5, /* 50.05 FBA A ref2 type */
    PARAM_50_07_FBA_A_ACTUAL_1_TYPE = 7, /* 50.07 FBA A actual 1 type */
    PARAM_50_08_FBA_A_ACTUAL_2_TYPE = 8, /* 50.08 FBA A actual 2 type */
    PARAM_50_09_FBA_A_SW = 9, /* 50.09 FBA A SW */
    PARAM_50_10_FBA_A_ACT1 = 10, /* 50.10 FBA A act1 */
    PARAM_50_11_FBA_A_ACT2 = 11, /* 50.11 FBA A act2 */
    PARAM_50_12_FBA_A_DEBUG_MODE = 12, /* 50.12 FBA A debug mode */
    PARAM_50_13_FBA_A_CONTROL_WORD = 13, /* 50.13 FBA A control word */
    PARAM_50_14_FBA_A_REFERENCE_1 = 14, /* 50.14 FBA A reference 1 */
    PARAM_50_15_FBA_A_REFERENCE_2 = 15, /* 50.15 FBA A reference 2 */
    PARAM_50_16_FBA_A_STATUS_WORD = 16, /* 50.16 FBA A status word */
    PARAM_50_17_FBA_A_ACTUAL_VALUE = 17, /* 50.17 FBA A actual value */
    PARAM_50_18_FBA_A_ACTUAL_VALUE = 18, /* 50.18 FBA A actual value */
    PARAM_50_21_FBA_A_TIMELEVEL_SEL = 21, /* 50.21 FBA A timelevel sel */
    PARAM_50_26_FBA_A_COMM = 26, /* 50.26 FBA A comm */
    PARAM_50_31_FBA_B_ENABLE = 31, /* 50.31 FBA B enable */
    PARAM_50_32_FBA_B_COMM_LOSS = 32, /* 50.32 FBA B comm loss */
    PARAM_50_33_FBA_B_COMM_LOSS = 33, /* 50.33 FBA B comm loss */
    PARAM_50_34_FBA_B_REF1_TYPE = 34, /* 50.34 FBA B ref1 type */
    PARAM_50_35_FBA_B_REF2_TYPE = 35, /* 50.35 FBA B ref2 type */
    PARAM_50_37_FBA_B_ACTUAL_1_TYPE_SELECTS_THE_TYPE_SOURCE_AND_SCALING_OF_ACTUAL_VALUE_1 = 37, /* 50.37 FBA B actual 1 type Selects the type/source and scaling of actual value 1 */
    PARAM_50_38_FBA_B_ACTUAL_2_TYPE_SELECTS_THE_TYPE_SOURCE_AND_SCALING_OF_ACTUAL_VALUE_2 = 38, /* 50.38 FBA B actual 2 type Selects the type/source and scaling of actual value 2 */
    PARAM_50_39_FBA_B_SW = 39, /* 50.39 FBA B SW */
    PARAM_50_40_FBA_B_ACT1 = 40, /* 50.40 FBA B act1 */
    PARAM_50_41_FBA_B_ACT2 = 41, /* 50.41 FBA B act2 */
    PARAM_50_42_FBA_B_DEBUG_MODE = 42, /* 50.42 FBA B debug mode */
    PARAM_50_43_FBA_B_CONTROL_WORD = 43, /* 50.43 FBA B control word */
    PARAM_50_44_FBA_B_REFERENCE_1 = 44, /* 50.44 FBA B reference 1 */
    PARAM_50_45_FBA_B_REFERENCE_2 = 45, /* 50.45 FBA B reference 2 */
    PARAM_50_46_FBA_B_STATUS_WORD = 46, /* 50.46 FBA B status word */
    PARAM_50_47_FBA_B_ACTUAL_VALUE = 47, /* 50.47 FBA B actual value */
    PARAM_50_48_FBA_B_ACTUAL_VALUE = 48, /* 50.48 FBA B actual value */
    PARAM_50_51_FBA_B_TIMELEVEL_SEL = 51, /* 50.51 FBA B timelevel sel */
    PARAM_50_56_FBA_B_COMM = 56, /* 50.56 FBA B comm */
} param_group_50_index_t;

/* ---- Live value storage (group 50) ---- */
typedef struct {
    float p01_fba_a_enable;  /* 50.01 FBA A enable */
    float p02_fba_a_comm_loss;  /* 50.02 FBA A comm loss */
    float p03_fba_a_comm_loss_t;  /* 50.03 FBA A comm loss t */
    float p04_fba_a_ref1_type;  /* 50.04 FBA A ref1 type */
    float p05_fba_a_ref2_type;  /* 50.05 FBA A ref2 type */
    float p07_fba_a_actual_1_type;  /* 50.07 FBA A actual 1 type */
    float p08_fba_a_actual_2_type;  /* 50.08 FBA A actual 2 type */
    float p09_fba_a_sw;  /* 50.09 FBA A SW */
    float p10_fba_a_act1;  /* 50.10 FBA A act1 */
    float p11_fba_a_act2;  /* 50.11 FBA A act2 */
    float p12_fba_a_debug_mode;  /* 50.12 FBA A debug mode */
    float p13_fba_a_control_word;  /* 50.13 FBA A control word */
    float p14_fba_a_reference_1;  /* 50.14 FBA A reference 1 */
    float p15_fba_a_reference_2;  /* 50.15 FBA A reference 2 */
    float p16_fba_a_status_word;  /* 50.16 FBA A status word */
    float p17_fba_a_actual_value;  /* 50.17 FBA A actual value */
    float p18_fba_a_actual_value;  /* 50.18 FBA A actual value */
    float p21_fba_a_timelevel_sel;  /* 50.21 FBA A timelevel sel */
    float p26_fba_a_comm;  /* 50.26 FBA A comm */
    float p31_fba_b_enable;  /* 50.31 FBA B enable */
    float p32_fba_b_comm_loss;  /* 50.32 FBA B comm loss */
    float p33_fba_b_comm_loss;  /* 50.33 FBA B comm loss */
    float p34_fba_b_ref1_type;  /* 50.34 FBA B ref1 type */
    float p35_fba_b_ref2_type;  /* 50.35 FBA B ref2 type */
    float p37_fba_b_actual_1_type_selects_the_type_source_and_scaling_of_actual_value_1;  /* 50.37 FBA B actual 1 type Selects the type/source and scaling of actual value 1 */
    float p38_fba_b_actual_2_type_selects_the_type_source_and_scaling_of_actual_value_2;  /* 50.38 FBA B actual 2 type Selects the type/source and scaling of actual value 2 */
    float p39_fba_b_sw;  /* 50.39 FBA B SW */
    float p40_fba_b_act1;  /* 50.40 FBA B act1 */
    float p41_fba_b_act2;  /* 50.41 FBA B act2 */
    float p42_fba_b_debug_mode;  /* 50.42 FBA B debug mode */
    float p43_fba_b_control_word;  /* 50.43 FBA B control word */
    float p44_fba_b_reference_1;  /* 50.44 FBA B reference 1 */
    float p45_fba_b_reference_2;  /* 50.45 FBA B reference 2 */
    float p46_fba_b_status_word;  /* 50.46 FBA B status word */
    float p47_fba_b_actual_value;  /* 50.47 FBA B actual value */
    float p48_fba_b_actual_value;  /* 50.48 FBA B actual value */
    float p51_fba_b_timelevel_sel;  /* 50.51 FBA B timelevel sel */
    float p56_fba_b_comm;  /* 50.56 FBA B comm */
} param_group_50_t;

extern param_group_50_t g_param_grp50;

void param_grp50_init(void);
void param_grp50_load_defaults(void);
int  param_grp50_get(uint8_t index, float *out_value);
int  param_grp50_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP50_FIELDBUS_ADAPTER_FBA_H */
