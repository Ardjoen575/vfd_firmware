#ifndef VFD_PARAM_GRP22_SPEED_REFERENCE_SELECTION_H
#define VFD_PARAM_GRP22_SPEED_REFERENCE_SELECTION_H

/* Parameter group 22: Speed reference selection
 * Auto-generated from ACS880 primary control program firmware manual
 * 44 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 22) ---- */
typedef enum {
    PARAM_22_01_SPEED_REF_UNLIMITED = 1, /* 22.01 Speed ref unlimited */
    PARAM_22_11_SPEED_REF1_SOURCE = 11, /* 22.11 Speed ref1 source */
    PARAM_22_12_SPEED_REF2_SOURCE = 12, /* 22.12 Speed ref2 source */
    PARAM_22_13_SPEED_REF1_FUNCTION = 13, /* 22.13 Speed ref1 function */
    PARAM_22_14_SPEED_REF1_2 = 14, /* 22.14 Speed ref1/2 */
    PARAM_22_15_SPEED_ADDITIVE_1 = 15, /* 22.15 Speed additive 1 */
    PARAM_22_16_SPEED_SHARE = 16, /* 22.16 Speed share */
    PARAM_22_17_SPEED_ADDITIVE_2 = 17, /* 22.17 Speed additive 2 */
    PARAM_22_21_CONSTANT_SPEED = 21, /* 22.21 Constant speed */
    PARAM_22_22_CONSTANT_SPEED = 22, /* 22.22 Constant speed */
    PARAM_22_23_CONSTANT_SPEED = 23, /* 22.23 Constant speed */
    PARAM_22_24_CONSTANT_SPEED = 24, /* 22.24 Constant speed */
    PARAM_22_26_CONSTANT_SPEED_1 = 26, /* 22.26 Constant speed 1 */
    PARAM_22_27_CONSTANT_SPEED_2 = 27, /* 22.27 Constant speed 2 */
    PARAM_22_28_CONSTANT_SPEED_3 = 28, /* 22.28 Constant speed 3 */
    PARAM_22_29_CONSTANT_SPEED_4 = 29, /* 22.29 Constant speed 4 */
    PARAM_22_30_CONSTANT_SPEED_5 = 30, /* 22.30 Constant speed 5 */
    PARAM_22_31_CONSTANT_SPEED_6 = 31, /* 22.31 Constant speed 6 */
    PARAM_22_32_CONSTANT_SPEED_7 = 32, /* 22.32 Constant speed 7 */
    PARAM_22_41_SPEED_REF_SAFE = 41, /* 22.41 Speed ref safe */
    PARAM_22_42_JOGGING_1_REF = 42, /* 22.42 Jogging 1 ref */
    PARAM_22_43_JOGGING_2_REF = 43, /* 22.43 Jogging 2 ref */
    PARAM_22_51_CRITICAL_SPEED = 51, /* 22.51 Critical speed */
    PARAM_22_52_CRITICAL_SPEED_1_LOW = 52, /* 22.52 Critical speed 1 low */
    PARAM_22_53_CRITICAL_SPEED_1 = 53, /* 22.53 Critical speed 1 */
    PARAM_22_54_CRITICAL_SPEED_2_LOW = 54, /* 22.54 Critical speed 2 low */
    PARAM_22_55_CRITICAL_SPEED_2 = 55, /* 22.55 Critical speed 2 */
    PARAM_22_56_CRITICAL_SPEED_3_LOW = 56, /* 22.56 Critical speed 3 low */
    PARAM_22_57_CRITICAL_SPEED_3 = 57, /* 22.57 Critical speed 3 */
    PARAM_22_71_MOTOR = 71, /* 22.71 Motor */
    PARAM_22_72_MOTOR = 72, /* 22.72 Motor */
    PARAM_22_73_MOTOR = 73, /* 22.73 Motor */
    PARAM_22_74_MOTOR = 74, /* 22.74 Motor */
    PARAM_22_75_MOTOR = 75, /* 22.75 Motor */
    PARAM_22_76_MOTOR = 76, /* 22.76 Motor */
    PARAM_22_77_MOTOR = 77, /* 22.77 Motor */
    PARAM_22_80_MOTOR = 80, /* 22.80 Motor */
    PARAM_22_81_SPEED_REFERENCE = 81, /* 22.81 Speed reference */
    PARAM_22_82_SPEED_REFERENCE = 82, /* 22.82 Speed reference */
    PARAM_22_83_SPEED_REFERENCE = 83, /* 22.83 Speed reference */
    PARAM_22_84_SPEED_REFERENCE = 84, /* 22.84 Speed reference */
    PARAM_22_85_SPEED_REFERENCE = 85, /* 22.85 Speed reference */
    PARAM_22_86_SPEED_REFERENCE = 86, /* 22.86 Speed reference */
    PARAM_22_87_SPEED_REFERENCE = 87, /* 22.87 Speed reference */
} param_group_22_index_t;

/* ---- Live value storage (group 22) ---- */
typedef struct {
    float p01_speed_ref_unlimited;  /* 22.01 Speed ref unlimited */
    float p11_speed_ref1_source;  /* 22.11 Speed ref1 source */
    float p12_speed_ref2_source;  /* 22.12 Speed ref2 source */
    float p13_speed_ref1_function;  /* 22.13 Speed ref1 function */
    float p14_speed_ref1_2;  /* 22.14 Speed ref1/2 */
    float p15_speed_additive_1;  /* 22.15 Speed additive 1 */
    float p16_speed_share;  /* 22.16 Speed share */
    float p17_speed_additive_2;  /* 22.17 Speed additive 2 */
    float p21_constant_speed;  /* 22.21 Constant speed */
    float p22_constant_speed;  /* 22.22 Constant speed */
    float p23_constant_speed;  /* 22.23 Constant speed */
    float p24_constant_speed;  /* 22.24 Constant speed */
    float p26_constant_speed_1;  /* 22.26 Constant speed 1 */
    float p27_constant_speed_2;  /* 22.27 Constant speed 2 */
    float p28_constant_speed_3;  /* 22.28 Constant speed 3 */
    float p29_constant_speed_4;  /* 22.29 Constant speed 4 */
    float p30_constant_speed_5;  /* 22.30 Constant speed 5 */
    float p31_constant_speed_6;  /* 22.31 Constant speed 6 */
    float p32_constant_speed_7;  /* 22.32 Constant speed 7 */
    float p41_speed_ref_safe;  /* 22.41 Speed ref safe */
    float p42_jogging_1_ref;  /* 22.42 Jogging 1 ref */
    float p43_jogging_2_ref;  /* 22.43 Jogging 2 ref */
    float p51_critical_speed;  /* 22.51 Critical speed */
    float p52_critical_speed_1_low;  /* 22.52 Critical speed 1 low */
    float p53_critical_speed_1;  /* 22.53 Critical speed 1 */
    float p54_critical_speed_2_low;  /* 22.54 Critical speed 2 low */
    float p55_critical_speed_2;  /* 22.55 Critical speed 2 */
    float p56_critical_speed_3_low;  /* 22.56 Critical speed 3 low */
    float p57_critical_speed_3;  /* 22.57 Critical speed 3 */
    float p71_motor;  /* 22.71 Motor */
    float p72_motor;  /* 22.72 Motor */
    float p73_motor;  /* 22.73 Motor */
    float p74_motor;  /* 22.74 Motor */
    float p75_motor;  /* 22.75 Motor */
    float p76_motor;  /* 22.76 Motor */
    float p77_motor;  /* 22.77 Motor */
    float p80_motor;  /* 22.80 Motor */
    float p81_speed_reference;  /* 22.81 Speed reference */
    float p82_speed_reference;  /* 22.82 Speed reference */
    float p83_speed_reference;  /* 22.83 Speed reference */
    float p84_speed_reference;  /* 22.84 Speed reference */
    float p85_speed_reference;  /* 22.85 Speed reference */
    float p86_speed_reference;  /* 22.86 Speed reference */
    float p87_speed_reference;  /* 22.87 Speed reference */
} param_group_22_t;

extern param_group_22_t g_param_grp22;

void param_grp22_init(void);
void param_grp22_load_defaults(void);
int  param_grp22_get(uint8_t index, float *out_value);
int  param_grp22_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP22_SPEED_REFERENCE_SELECTION_H */
