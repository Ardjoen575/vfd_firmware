#ifndef VFD_PARAM_GRP58_EMBEDDED_FIELDBUS_H
#define VFD_PARAM_GRP58_EMBEDDED_FIELDBUS_H

/* Parameter group 58: Embedded fieldbus
 * Auto-generated from ACS880 primary control program firmware manual
 * 29 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 58) ---- */
typedef enum {
    PARAM_58_01_PROTOCOL_ENABLE = 1, /* 58.01 Protocol enable */
    PARAM_58_02_PROTOCOL_ID = 2, /* 58.02 Protocol ID */
    PARAM_58_03_NODE_ADDRESS = 3, /* 58.03 Node address */
    PARAM_58_04_BAUD_RATE = 4, /* 58.04 Baud rate */
    PARAM_58_05_PARITY = 5, /* 58.05 Parity */
    PARAM_58_06_COMMUNICATION = 6, /* 58.06 Communication */
    PARAM_58_07_COMMUNICATION = 7, /* 58.07 Communication */
    PARAM_58_08_RECEIVED_PACKETS = 8, /* 58.08 Received packets */
    PARAM_58_09_TRANSMITTED_PACKETS_DISPLAYS_A_COUNT_OF_VALID_PACKETS_TRANSMITTED_BY_THE_DRIVE = 9, /* 58.09 Transmitted packets Displays a count of valid packets transmitted by the drive. */
    PARAM_58_10_ALL_PACKETS = 10, /* 58.10 All packets */
    PARAM_58_11_UART_ERRORS = 11, /* 58.11 UART errors */
    PARAM_58_12_CRC_ERRORS = 12, /* 58.12 CRC errors */
    PARAM_58_14_COMMUNICATION = 14, /* 58.14 Communication */
    PARAM_58_15_COMMUNICATION = 15, /* 58.15 Communication */
    PARAM_58_16_COMMUNICATION = 16, /* 58.16 Communication */
    PARAM_58_17_TRANSMIT_DELAY = 17, /* 58.17 Transmit delay */
    PARAM_58_18_EFB_CONTROL_WORD = 18, /* 58.18 EFB control word */
    PARAM_58_19_EFB_STATUS_WORD = 19, /* 58.19 EFB status word */
    PARAM_58_25_CONTROL_PROFILE = 25, /* 58.25 Control profile */
    PARAM_58_26_EFB_REF1_TYPE = 26, /* 58.26 EFB ref1 type */
    PARAM_58_27_EFB_REF2_TYPE = 27, /* 58.27 EFB ref2 type */
    PARAM_58_28_EFB_ACT1_TYPE = 28, /* 58.28 EFB act1 type */
    PARAM_58_29_EFB_ACT2_TYPE = 29, /* 58.29 EFB act2 type */
    PARAM_58_30_EFB_STATUS_WORD = 30, /* 58.30 EFB status word */
    PARAM_58_31_EFB_ACT1 = 31, /* 58.31 EFB act1 */
    PARAM_58_32_EFB_ACT2 = 32, /* 58.32 EFB act2 */
    PARAM_58_33_ADDRESSING_MODE = 33, /* 58.33 Addressing mode */
    PARAM_58_34_WORD_ORDER = 34, /* 58.34 Word order */
    PARAM_58_36_EFB_COMM = 36, /* 58.36 EFB comm */
} param_group_58_index_t;

/* ---- Live value storage (group 58) ---- */
typedef struct {
    float p01_protocol_enable;  /* 58.01 Protocol enable */
    float p02_protocol_id;  /* 58.02 Protocol ID */
    float p03_node_address;  /* 58.03 Node address */
    float p04_baud_rate;  /* 58.04 Baud rate */
    float p05_parity;  /* 58.05 Parity */
    float p06_communication;  /* 58.06 Communication */
    float p07_communication;  /* 58.07 Communication */
    float p08_received_packets;  /* 58.08 Received packets */
    float p09_transmitted_packets_displays_a_count_of_valid_packets_transmitted_by_the_drive;  /* 58.09 Transmitted packets Displays a count of valid packets transmitted by the drive. */
    float p10_all_packets;  /* 58.10 All packets */
    float p11_uart_errors;  /* 58.11 UART errors */
    float p12_crc_errors;  /* 58.12 CRC errors */
    float p14_communication;  /* 58.14 Communication */
    float p15_communication;  /* 58.15 Communication */
    float p16_communication;  /* 58.16 Communication */
    float p17_transmit_delay;  /* 58.17 Transmit delay */
    float p18_efb_control_word;  /* 58.18 EFB control word */
    float p19_efb_status_word;  /* 58.19 EFB status word */
    float p25_control_profile;  /* 58.25 Control profile */
    float p26_efb_ref1_type;  /* 58.26 EFB ref1 type */
    float p27_efb_ref2_type;  /* 58.27 EFB ref2 type */
    float p28_efb_act1_type;  /* 58.28 EFB act1 type */
    float p29_efb_act2_type;  /* 58.29 EFB act2 type */
    float p30_efb_status_word;  /* 58.30 EFB status word */
    float p31_efb_act1;  /* 58.31 EFB act1 */
    float p32_efb_act2;  /* 58.32 EFB act2 */
    float p33_addressing_mode;  /* 58.33 Addressing mode */
    float p34_word_order;  /* 58.34 Word order */
    float p36_efb_comm;  /* 58.36 EFB comm */
} param_group_58_t;

extern param_group_58_t g_param_grp58;

void param_grp58_init(void);
void param_grp58_load_defaults(void);
int  param_grp58_get(uint8_t index, float *out_value);
int  param_grp58_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP58_EMBEDDED_FIELDBUS_H */
