#ifndef VFD_PARAM_GRP13_STANDARD_AO_H
#define VFD_PARAM_GRP13_STANDARD_AO_H

/* Parameter group 13: Standard AO
 * Auto-generated from ACS880 primary control program firmware manual
 * 16 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 13) ---- */
typedef enum {
    PARAM_13_11_AO1_ACTUAL_VALUE = 11, /* 13.11 AO1 actual value */
    PARAM_13_12_AO1_SOURCE = 12, /* 13.12 AO1 source */
    PARAM_13_16_AO1_FILTER_TIME = 16, /* 13.16 AO1 filter time */
    PARAM_13_17_AO1_SOURCE_MIN = 17, /* 13.17 AO1 source min */
    PARAM_13_18_AO1_SOURCE_MAX = 18, /* 13.18 AO1 source max */
    PARAM_13_19_AO1_OUT_AT_AO1_SRC = 19, /* 13.19 AO1 out at AO1 src */
    PARAM_13_20_AO1_OUT_AT_AO1_SRC = 20, /* 13.20 AO1 out at AO1 src */
    PARAM_13_21_AO2_ACTUAL_VALUE = 21, /* 13.21 AO2 actual value */
    PARAM_13_22_AO2_SOURCE = 22, /* 13.22 AO2 source */
    PARAM_13_26_AO2_FILTER_TIME = 26, /* 13.26 AO2 filter time */
    PARAM_13_27_AO2_SOURCE_MIN = 27, /* 13.27 AO2 source min */
    PARAM_13_28_AO2_SOURCE_MAX = 28, /* 13.28 AO2 source max */
    PARAM_13_29_AO2_OUT_AT_AO2_SRC = 29, /* 13.29 AO2 out at AO2 src */
    PARAM_13_30_AO2_OUT_AT_AO2_SRC = 30, /* 13.30 AO2 out at AO2 src */
    PARAM_13_91_AO1_DATA_STORAGE = 91, /* 13.91 AO1 data storage */
    PARAM_13_92_AO2_DATA_STORAGE = 92, /* 13.92 AO2 data storage */
} param_group_13_index_t;

/* ---- Live value storage (group 13) ---- */
typedef struct {
    float p11_ao1_actual_value;  /* 13.11 AO1 actual value */
    float p12_ao1_source;  /* 13.12 AO1 source */
    float p16_ao1_filter_time;  /* 13.16 AO1 filter time */
    float p17_ao1_source_min;  /* 13.17 AO1 source min */
    float p18_ao1_source_max;  /* 13.18 AO1 source max */
    float p19_ao1_out_at_ao1_src;  /* 13.19 AO1 out at AO1 src */
    float p20_ao1_out_at_ao1_src;  /* 13.20 AO1 out at AO1 src */
    float p21_ao2_actual_value;  /* 13.21 AO2 actual value */
    float p22_ao2_source;  /* 13.22 AO2 source */
    float p26_ao2_filter_time;  /* 13.26 AO2 filter time */
    float p27_ao2_source_min;  /* 13.27 AO2 source min */
    float p28_ao2_source_max;  /* 13.28 AO2 source max */
    float p29_ao2_out_at_ao2_src;  /* 13.29 AO2 out at AO2 src */
    float p30_ao2_out_at_ao2_src;  /* 13.30 AO2 out at AO2 src */
    float p91_ao1_data_storage;  /* 13.91 AO1 data storage */
    float p92_ao2_data_storage;  /* 13.92 AO2 data storage */
} param_group_13_t;

extern param_group_13_t g_param_grp13;

void param_grp13_init(void);
void param_grp13_load_defaults(void);
int  param_grp13_get(uint8_t index, float *out_value);
int  param_grp13_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP13_STANDARD_AO_H */
