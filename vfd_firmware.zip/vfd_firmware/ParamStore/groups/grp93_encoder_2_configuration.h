#ifndef VFD_PARAM_GRP93_ENCODER_2_CONFIGURATION_H
#define VFD_PARAM_GRP93_ENCODER_2_CONFIGURATION_H

/* Parameter group 93: Encoder 2 configuration
 * Auto-generated from ACS880 primary control program firmware manual
 * 25 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 93) ---- */
typedef enum {
    PARAM_93_01_ENCODER_2_TYPE = 1, /* 93.01 Encoder 2 type */
    PARAM_93_02_ENCODER_2_SOURCE = 2, /* 93.02 Encoder 2 source */
    PARAM_93_10_PULSES_REVOLUTION = 10, /* 93.10 Pulses/revolution */
    PARAM_93_11_PULSE_ENCODER_TYPE = 11, /* 93.11 Pulse encoder type */
    PARAM_93_12_SPEED_CALCULATION = 12, /* 93.12 Speed calculation */
    PARAM_93_13_POSITION_ESTIMATION = 13, /* 93.13 Position estimation */
    PARAM_93_14_SPEED_ESTIMATION = 14, /* 93.14 Speed estimation */
    PARAM_93_15_TRANSIENT_FILTER = 15, /* 93.15 Transient filter */
    PARAM_93_17_ACCEPTED_PULSE_FREQ = 17, /* 93.17 Accepted pulse freq */
    PARAM_93_21_ENCODER_CABLE_FAULT = 21, /* 93.21 Encoder cable fault */
    PARAM_93_23_MAXIMUM_PULSE = 23, /* 93.23 Maximum pulse */
    PARAM_93_24_PULSE_EDGE_FILTERING = 24, /* 93.24 Pulse edge filtering */
    PARAM_93_25_PULSE = 25, /* 93.25 Pulse */
    PARAM_93_30_SERIAL_LINK_MODE = 30, /* 93.30 Serial link mode */
    PARAM_93_31_ENDAT_CALC_TIME = 31, /* 93.31 EnDat calc time */
    PARAM_93_32_SSI_CYCLE_TIME = 32, /* 93.32 SSI cycle time */
    PARAM_93_33_SSI_CLOCK_CYCLES = 33, /* 93.33 SSI clock cycles */
    PARAM_93_34_SSI_POSITION_MSB = 34, /* 93.34 SSI position msb */
    PARAM_93_35_SSI_REVOLUTION_MSB = 35, /* 93.35 SSI revolution msb */
    PARAM_93_36_SSI_DATA_FORMAT = 36, /* 93.36 SSI data format */
    PARAM_93_37_SSI_BAUD_RATE = 37, /* 93.37 SSI baud rate */
    PARAM_93_40_SSI_ZERO_PHASE = 40, /* 93.40 SSI zero phase */
    PARAM_93_45_HIPERFACE_PARITY = 45, /* 93.45 Hiperface parity */
    PARAM_93_46_HIPERFACE_BAUD_RATE_VISIBLE_WHEN_AN_ABSOLUTE_ENCODER_IS_SELECTED = 46, /* 93.46 Hiperface baud rate (Visible when an absolute encoder is selected) */
    PARAM_93_47_HIPERFACE_NODE = 47, /* 93.47 Hiperface node */
} param_group_93_index_t;

/* ---- Live value storage (group 93) ---- */
typedef struct {
    float p01_encoder_2_type;  /* 93.01 Encoder 2 type */
    float p02_encoder_2_source;  /* 93.02 Encoder 2 source */
    float p10_pulses_revolution;  /* 93.10 Pulses/revolution */
    float p11_pulse_encoder_type;  /* 93.11 Pulse encoder type */
    float p12_speed_calculation;  /* 93.12 Speed calculation */
    float p13_position_estimation;  /* 93.13 Position estimation */
    float p14_speed_estimation;  /* 93.14 Speed estimation */
    float p15_transient_filter;  /* 93.15 Transient filter */
    float p17_accepted_pulse_freq;  /* 93.17 Accepted pulse freq */
    float p21_encoder_cable_fault;  /* 93.21 Encoder cable fault */
    float p23_maximum_pulse;  /* 93.23 Maximum pulse */
    float p24_pulse_edge_filtering;  /* 93.24 Pulse edge filtering */
    float p25_pulse;  /* 93.25 Pulse */
    float p30_serial_link_mode;  /* 93.30 Serial link mode */
    float p31_endat_calc_time;  /* 93.31 EnDat calc time */
    float p32_ssi_cycle_time;  /* 93.32 SSI cycle time */
    float p33_ssi_clock_cycles;  /* 93.33 SSI clock cycles */
    float p34_ssi_position_msb;  /* 93.34 SSI position msb */
    float p35_ssi_revolution_msb;  /* 93.35 SSI revolution msb */
    float p36_ssi_data_format;  /* 93.36 SSI data format */
    float p37_ssi_baud_rate;  /* 93.37 SSI baud rate */
    float p40_ssi_zero_phase;  /* 93.40 SSI zero phase */
    float p45_hiperface_parity;  /* 93.45 Hiperface parity */
    float p46_hiperface_baud_rate_visible_when_an_absolute_encoder_is_selected;  /* 93.46 Hiperface baud rate (Visible when an absolute encoder is selected) */
    float p47_hiperface_node;  /* 93.47 Hiperface node */
} param_group_93_t;

extern param_group_93_t g_param_grp93;

void param_grp93_init(void);
void param_grp93_load_defaults(void);
int  param_grp93_get(uint8_t index, float *out_value);
int  param_grp93_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP93_ENCODER_2_CONFIGURATION_H */
