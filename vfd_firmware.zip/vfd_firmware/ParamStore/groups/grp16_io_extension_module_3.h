#ifndef VFD_PARAM_GRP16_IO_EXTENSION_MODULE_3_H
#define VFD_PARAM_GRP16_IO_EXTENSION_MODULE_3_H

/* Parameter group 16: IO extension module 3
 * Auto-generated from ACS880 primary control program firmware manual
 * 73 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 16) ---- */
typedef enum {
    PARAM_16_01_MODULE_3_TYPE = 1, /* 16.01 Module 3 type */
    PARAM_16_02_MODULE_3_LOCATION = 2, /* 16.02 Module 3 location */
    PARAM_16_03_MODULE_3_STATUS = 3, /* 16.03 Module 3 status */
    PARAM_16_05_DI_STATUS = 5, /* 16.05 DI status */
    PARAM_16_06_DI_DELAYED_STATUS = 6, /* 16.06 DI delayed status */
    PARAM_16_08_DI_FILTER_TIME = 8, /* 16.08 DI filter time */
    PARAM_16_09_DIO1_FUNCTION = 9, /* 16.09 DIO1 function */
    PARAM_16_11_DIO1_OUTPUT_SOURCE = 11, /* 16.11 DIO1 output source */
    PARAM_16_12_DI1_ON_DELAY = 12, /* 16.12 DI1 ON delay */
    PARAM_16_13_DI1_OFF_DELAY = 13, /* 16.13 DI1 OFF delay */
    PARAM_16_14_DIO2_FUNCTION = 14, /* 16.14 DIO2 function */
    PARAM_16_16_DIO2_OUTPUT_SOURCE = 16, /* 16.16 DIO2 output source */
    PARAM_16_17_DI2_ON_DELAY = 17, /* 16.17 DI2 ON delay */
    PARAM_16_18_DI2_OFF_DELAY = 18, /* 16.18 DI2 OFF delay */
    PARAM_16_19_DIO3_FUNCTION = 19, /* 16.19 DIO3 function */
    PARAM_16_20_AI_SUPERVISION = 20, /* 16.20 AI supervision */
    PARAM_16_21_DIO3_OUTPUT_SOURCE = 21, /* 16.21 DIO3 output source */
    PARAM_16_22_DI3_ON_DELAY = 22, /* 16.22 DI3 ON delay */
    PARAM_16_23_DI3_OFF_DELAY = 23, /* 16.23 DI3 OFF delay */
    PARAM_16_24_DIO4_FUNCTION = 24, /* 16.24 DIO4 function */
    PARAM_16_26_DIO4_OUTPUT_SOURCE = 26, /* 16.26 DIO4 output source */
    PARAM_16_27_DIO4_ON_DELAY = 27, /* 16.27 DIO4 ON delay */
    PARAM_16_28_DIO4_OFF_DELAY = 28, /* 16.28 DIO4 OFF delay */
    PARAM_16_29_AI1_HW_SWITCH = 29, /* 16.29 AI1 HW switch */
    PARAM_16_30_AI1_UNIT_SELECTION = 30, /* 16.30 AI1 unit selection */
    PARAM_16_31_RO_STATUS = 31, /* 16.31 RO status */
    PARAM_16_32_AI1_FILTER_TIME = 32, /* 16.32 AI1 filter time */
    PARAM_16_33_AI1_MIN = 33, /* 16.33 AI1 min */
    PARAM_16_34_RO1_SOURCE = 34, /* 16.34 RO1 source */
    PARAM_16_35_RO1_ON_DELAY = 35, /* 16.35 RO1 ON delay */
    PARAM_16_36_RO1_OFF_DELAY = 36, /* 16.36 RO1 OFF delay */
    PARAM_16_37_RO2_SOURCE = 37, /* 16.37 RO2 source */
    PARAM_16_38_RO2_ON_DELAY = 38, /* 16.38 RO2 ON delay */
    PARAM_16_39_RO2_OFF_DELAY = 39, /* 16.39 RO2 OFF delay */
    PARAM_16_41_AI2_ACTUAL_VALUE = 41, /* 16.41 AI2 actual value */
    PARAM_16_42_AI2_SCALED_VALUE = 42, /* 16.42 AI2 scaled value */
    PARAM_16_43_AI2_FORCE_DATA = 43, /* 16.43 AI2 force data */
    PARAM_16_44_AI2_HW_SWITCH = 44, /* 16.44 AI2 HW switch */
    PARAM_16_45_AI2_UNIT_SELECTION = 45, /* 16.45 AI2 unit selection */
    PARAM_16_46_AI2_FILTER_GAIN = 46, /* 16.46 AI2 filter gain */
    PARAM_16_47_AI2_FILTER_TIME = 47, /* 16.47 AI2 filter time */
    PARAM_16_48_AI2_MIN = 48, /* 16.48 AI2 min */
    PARAM_16_49_AI2_MAX = 49, /* 16.49 AI2 max */
    PARAM_16_50_AI2_SCALED_AT_AI2 = 50, /* 16.50 AI2 scaled at AI2 */
    PARAM_16_51_AI2_SCALED_AT_AI2 = 51, /* 16.51 AI2 scaled at AI2 */
    PARAM_16_56_AI3_ACTUAL_VALUE = 56, /* 16.56 AI3 actual value */
    PARAM_16_57_AI3_SCALED_VALUE = 57, /* 16.57 AI3 scaled value */
    PARAM_16_58_AI3_FORCE_DATA = 58, /* 16.58 AI3 force data */
    PARAM_16_59_AI3_HW_SWITCH = 59, /* 16.59 AI3 HW switch */
    PARAM_16_60_AI3_UNIT_SELECTION = 60, /* 16.60 AI3 unit selection */
    PARAM_16_61_AI3_FILTER_GAIN = 61, /* 16.61 AI3 filter gain */
    PARAM_16_62_AI3_FILTER_TIME = 62, /* 16.62 AI3 filter time */
    PARAM_16_63_AI3_MIN = 63, /* 16.63 AI3 min */
    PARAM_16_64_AI3_MAX = 64, /* 16.64 AI3 max */
    PARAM_16_65_AI3_SCALED_AT_AI3 = 65, /* 16.65 AI3 scaled at AI3 */
    PARAM_16_66_AI3_SCALED_AT_AI3 = 66, /* 16.66 AI3 scaled at AI3 */
    PARAM_16_71_AO_FORCE_SELECTION = 71, /* 16.71 AO force selection */
    PARAM_16_76_AO1_ACTUAL_VALUE = 76, /* 16.76 AO1 actual value */
    PARAM_16_77_AO1_SOURCE = 77, /* 16.77 AO1 source */
    PARAM_16_78_AO1_FORCE_DATA = 78, /* 16.78 AO1 force data */
    PARAM_16_79_AO1_FILTER_TIME = 79, /* 16.79 AO1 filter time */
    PARAM_16_80_AO1_SOURCE_MIN = 80, /* 16.80 AO1 source min */
    PARAM_16_81_AO1_SOURCE_MAX = 81, /* 16.81 AO1 source max */
    PARAM_16_82_AO1_OUT_AT_AO1_SRC = 82, /* 16.82 AO1 out at AO1 src */
    PARAM_16_83_AO1_OUT_AT_AO1_SRC = 83, /* 16.83 AO1 out at AO1 src */
    PARAM_16_86_AO2_ACTUAL_VALUE = 86, /* 16.86 AO2 actual value */
    PARAM_16_87_AO2_SOURCE = 87, /* 16.87 AO2 source */
    PARAM_16_88_AO2_FORCE_DATA = 88, /* 16.88 AO2 force data */
    PARAM_16_89_AO2_FILTER_TIME = 89, /* 16.89 AO2 filter time */
    PARAM_16_90_AO2_SOURCE_MIN = 90, /* 16.90 AO2 source min */
    PARAM_16_91_AO2_SOURCE_MAX = 91, /* 16.91 AO2 source max */
    PARAM_16_92_AO2_OUT_AT_AO2_SRC = 92, /* 16.92 AO2 out at AO2 src */
    PARAM_16_93_AO2_OUT_AT_AO2_SRC = 93, /* 16.93 AO2 out at AO2 src */
} param_group_16_index_t;

/* ---- Live value storage (group 16) ---- */
typedef struct {
    float p01_module_3_type;  /* 16.01 Module 3 type */
    float p02_module_3_location;  /* 16.02 Module 3 location */
    float p03_module_3_status;  /* 16.03 Module 3 status */
    float p05_di_status;  /* 16.05 DI status */
    float p06_di_delayed_status;  /* 16.06 DI delayed status */
    float p08_di_filter_time;  /* 16.08 DI filter time */
    float p09_dio1_function;  /* 16.09 DIO1 function */
    float p11_dio1_output_source;  /* 16.11 DIO1 output source */
    float p12_di1_on_delay;  /* 16.12 DI1 ON delay */
    float p13_di1_off_delay;  /* 16.13 DI1 OFF delay */
    float p14_dio2_function;  /* 16.14 DIO2 function */
    float p16_dio2_output_source;  /* 16.16 DIO2 output source */
    float p17_di2_on_delay;  /* 16.17 DI2 ON delay */
    float p18_di2_off_delay;  /* 16.18 DI2 OFF delay */
    float p19_dio3_function;  /* 16.19 DIO3 function */
    float p20_ai_supervision;  /* 16.20 AI supervision */
    float p21_dio3_output_source;  /* 16.21 DIO3 output source */
    float p22_di3_on_delay;  /* 16.22 DI3 ON delay */
    float p23_di3_off_delay;  /* 16.23 DI3 OFF delay */
    float p24_dio4_function;  /* 16.24 DIO4 function */
    float p26_dio4_output_source;  /* 16.26 DIO4 output source */
    float p27_dio4_on_delay;  /* 16.27 DIO4 ON delay */
    float p28_dio4_off_delay;  /* 16.28 DIO4 OFF delay */
    float p29_ai1_hw_switch;  /* 16.29 AI1 HW switch */
    float p30_ai1_unit_selection;  /* 16.30 AI1 unit selection */
    float p31_ro_status;  /* 16.31 RO status */
    float p32_ai1_filter_time;  /* 16.32 AI1 filter time */
    float p33_ai1_min;  /* 16.33 AI1 min */
    float p34_ro1_source;  /* 16.34 RO1 source */
    float p35_ro1_on_delay;  /* 16.35 RO1 ON delay */
    float p36_ro1_off_delay;  /* 16.36 RO1 OFF delay */
    float p37_ro2_source;  /* 16.37 RO2 source */
    float p38_ro2_on_delay;  /* 16.38 RO2 ON delay */
    float p39_ro2_off_delay;  /* 16.39 RO2 OFF delay */
    float p41_ai2_actual_value;  /* 16.41 AI2 actual value */
    float p42_ai2_scaled_value;  /* 16.42 AI2 scaled value */
    float p43_ai2_force_data;  /* 16.43 AI2 force data */
    float p44_ai2_hw_switch;  /* 16.44 AI2 HW switch */
    float p45_ai2_unit_selection;  /* 16.45 AI2 unit selection */
    float p46_ai2_filter_gain;  /* 16.46 AI2 filter gain */
    float p47_ai2_filter_time;  /* 16.47 AI2 filter time */
    float p48_ai2_min;  /* 16.48 AI2 min */
    float p49_ai2_max;  /* 16.49 AI2 max */
    float p50_ai2_scaled_at_ai2;  /* 16.50 AI2 scaled at AI2 */
    float p51_ai2_scaled_at_ai2;  /* 16.51 AI2 scaled at AI2 */
    float p56_ai3_actual_value;  /* 16.56 AI3 actual value */
    float p57_ai3_scaled_value;  /* 16.57 AI3 scaled value */
    float p58_ai3_force_data;  /* 16.58 AI3 force data */
    float p59_ai3_hw_switch;  /* 16.59 AI3 HW switch */
    float p60_ai3_unit_selection;  /* 16.60 AI3 unit selection */
    float p61_ai3_filter_gain;  /* 16.61 AI3 filter gain */
    float p62_ai3_filter_time;  /* 16.62 AI3 filter time */
    float p63_ai3_min;  /* 16.63 AI3 min */
    float p64_ai3_max;  /* 16.64 AI3 max */
    float p65_ai3_scaled_at_ai3;  /* 16.65 AI3 scaled at AI3 */
    float p66_ai3_scaled_at_ai3;  /* 16.66 AI3 scaled at AI3 */
    float p71_ao_force_selection;  /* 16.71 AO force selection */
    float p76_ao1_actual_value;  /* 16.76 AO1 actual value */
    float p77_ao1_source;  /* 16.77 AO1 source */
    float p78_ao1_force_data;  /* 16.78 AO1 force data */
    float p79_ao1_filter_time;  /* 16.79 AO1 filter time */
    float p80_ao1_source_min;  /* 16.80 AO1 source min */
    float p81_ao1_source_max;  /* 16.81 AO1 source max */
    float p82_ao1_out_at_ao1_src;  /* 16.82 AO1 out at AO1 src */
    float p83_ao1_out_at_ao1_src;  /* 16.83 AO1 out at AO1 src */
    float p86_ao2_actual_value;  /* 16.86 AO2 actual value */
    float p87_ao2_source;  /* 16.87 AO2 source */
    float p88_ao2_force_data;  /* 16.88 AO2 force data */
    float p89_ao2_filter_time;  /* 16.89 AO2 filter time */
    float p90_ao2_source_min;  /* 16.90 AO2 source min */
    float p91_ao2_source_max;  /* 16.91 AO2 source max */
    float p92_ao2_out_at_ao2_src;  /* 16.92 AO2 out at AO2 src */
    float p93_ao2_out_at_ao2_src;  /* 16.93 AO2 out at AO2 src */
} param_group_16_t;

extern param_group_16_t g_param_grp16;

void param_grp16_init(void);
void param_grp16_load_defaults(void);
int  param_grp16_get(uint8_t index, float *out_value);
int  param_grp16_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP16_IO_EXTENSION_MODULE_3_H */
