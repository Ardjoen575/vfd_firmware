#ifndef VFD_PARAM_GRP95_HW_CONFIGURATION_H
#define VFD_PARAM_GRP95_HW_CONFIGURATION_H

/* Parameter group 95: HW configuration
 * Auto-generated from ACS880 primary control program firmware manual
 * 15 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 95) ---- */
typedef enum {
    PARAM_95_01_SUPPLY_VOLTAGE = 1, /* 95.01 Supply voltage */
    PARAM_95_02_ADAPTIVE_VOLTAGE = 2, /* 95.02 Adaptive voltage */
    PARAM_95_04_CONTROL_BOARD = 4, /* 95.04 Control board */
    PARAM_95_08_DC_SWITCH = 8, /* 95.08 DC switch */
    PARAM_95_09_SWITCH_FUSE = 9, /* 95.09 Switch fuse */
    PARAM_95_13_REDUCED_RUN_MODE = 13, /* 95.13 Reduced run mode */
    PARAM_95_14_CONNECTED_MODULES_ONLY_VISIBLE_WITH_A_BCU_CONTROL_UNIT = 14, /* 95.14 Connected modules (Only visible with a BCU control unit) */
    PARAM_95_15_SPECIAL_HW = 15, /* 95.15 Special HW */
    PARAM_95_16_ROUTER_MODE = 16, /* 95.16 Router mode */
    PARAM_95_17_ROUTER_CHANNEL = 17, /* 95.17 Router channel */
    PARAM_95_20_HW_OPTIONS_WORD_1 = 20, /* 95.20 HW options word 1 */
    PARAM_95_21_HW_OPTIONS_WORD_2 = 21, /* 95.21 HW options word 2 */
    PARAM_95_30_PARALLEL_TYPE_LIST = 30, /* 95.30 Parallel type list */
    PARAM_95_31_PARALLEL_TYPE = 31, /* 95.31 Parallel type */
    PARAM_95_40_TRANSFORMATION_RATIO_DEFINES_THE_RATIO_OF_THE_STEP_UP_TRANSFORMER = 40, /* 95.40 Transformation ratio Defines the ratio of the step-up transformer. */
} param_group_95_index_t;

/* ---- Live value storage (group 95) ---- */
typedef struct {
    float p01_supply_voltage;  /* 95.01 Supply voltage */
    float p02_adaptive_voltage;  /* 95.02 Adaptive voltage */
    float p04_control_board;  /* 95.04 Control board */
    float p08_dc_switch;  /* 95.08 DC switch */
    float p09_switch_fuse;  /* 95.09 Switch fuse */
    float p13_reduced_run_mode;  /* 95.13 Reduced run mode */
    float p14_connected_modules_only_visible_with_a_bcu_control_unit;  /* 95.14 Connected modules (Only visible with a BCU control unit) */
    float p15_special_hw;  /* 95.15 Special HW */
    float p16_router_mode;  /* 95.16 Router mode */
    float p17_router_channel;  /* 95.17 Router channel */
    float p20_hw_options_word_1;  /* 95.20 HW options word 1 */
    float p21_hw_options_word_2;  /* 95.21 HW options word 2 */
    float p30_parallel_type_list;  /* 95.30 Parallel type list */
    float p31_parallel_type;  /* 95.31 Parallel type */
    float p40_transformation_ratio_defines_the_ratio_of_the_step_up_transformer;  /* 95.40 Transformation ratio Defines the ratio of the step-up transformer. */
} param_group_95_t;

extern param_group_95_t g_param_grp95;

void param_grp95_init(void);
void param_grp95_load_defaults(void);
int  param_grp95_get(uint8_t index, float *out_value);
int  param_grp95_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP95_HW_CONFIGURATION_H */
