#ifndef VFD_PARAM_GRP52_FBA_A_DATA_IN_H
#define VFD_PARAM_GRP52_FBA_A_DATA_IN_H

/* Parameter group 52: FBA A data in
 * Auto-generated from ACS880 primary control program firmware manual
 * 2 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 52) ---- */
typedef enum {
    PARAM_52_01_FBA_A_DATA_IN1 = 1, /* 52.01 FBA A data in1 */
    PARAM_52_12_FBA_A_DATA_IN12 = 12, /* 52.12 FBA A data in12 */
} param_group_52_index_t;

/* ---- Live value storage (group 52) ---- */
typedef struct {
    float p01_fba_a_data_in1;  /* 52.01 FBA A data in1 */
    float p12_fba_a_data_in12;  /* 52.12 FBA A data in12 */
} param_group_52_t;

extern param_group_52_t g_param_grp52;

void param_grp52_init(void);
void param_grp52_load_defaults(void);
int  param_grp52_get(uint8_t index, float *out_value);
int  param_grp52_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP52_FBA_A_DATA_IN_H */
