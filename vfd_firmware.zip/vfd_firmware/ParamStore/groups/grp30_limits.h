#ifndef VFD_PARAM_GRP30_LIMITS_H
#define VFD_PARAM_GRP30_LIMITS_H

/* Parameter group 30: Limits
 * Auto-generated from ACS880 primary control program firmware manual
 * 22 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 30) ---- */
typedef enum {
    PARAM_30_01_LIMIT_WORD_1 = 1, /* 30.01 Limit word 1 */
    PARAM_30_02_TORQUE_LIMIT_STATUS = 2, /* 30.02 Torque limit status */
    PARAM_30_11_MINIMUM_SPEED = 11, /* 30.11 Minimum speed */
    PARAM_30_12_MAXIMUM_SPEED = 12, /* 30.12 Maximum speed */
    PARAM_30_13_MINIMUM_FREQUENCY = 13, /* 30.13 Minimum frequency */
    PARAM_30_14_MAXIMUM = 14, /* 30.14 Maximum */
    PARAM_30_15_MAXIMUM_START = 15, /* 30.15 Maximum start */
    PARAM_30_16_MAXIMUM_START = 16, /* 30.16 Maximum start */
    PARAM_30_17_MAXIMUM_CURRENT = 17, /* 30.17 Maximum current */
    PARAM_30_18_MINIMUM_TORQUE_SEL = 18, /* 30.18 Minimum torque sel */
    PARAM_30_19_MINIMUM_TORQUE_1 = 19, /* 30.19 Minimum torque 1 */
    PARAM_30_20_MAXIMUM_TORQUE_1 = 20, /* 30.20 Maximum torque 1 */
    PARAM_30_21_MINIMUM_TORQUE_2 = 21, /* 30.21 Minimum torque 2 */
    PARAM_30_22_MAXIMUM_TORQUE_2 = 22, /* 30.22 Maximum torque 2 */
    PARAM_30_23_MINIMUM_TORQUE_2 = 23, /* 30.23 Minimum torque 2 */
    PARAM_30_24_MAXIMUM_TORQUE_2 = 24, /* 30.24 Maximum torque 2 */
    PARAM_30_25_MAXIMUM_TORQUE = 25, /* 30.25 Maximum torque */
    PARAM_30_26_POWER_MOTORING = 26, /* 30.26 Power motoring */
    PARAM_30_27_POWER_GENERATING = 27, /* 30.27 Power generating */
    PARAM_30_30_OVERVOLTAGE_CONTROL = 30, /* 30.30 Overvoltage control */
    PARAM_30_31_UNDERVOLTAGE = 31, /* 30.31 Undervoltage */
    PARAM_30_35_THERMAL_CURRENT = 35, /* 30.35 Thermal current */
} param_group_30_index_t;

/* ---- Live value storage (group 30) ---- */
typedef struct {
    float p01_limit_word_1;  /* 30.01 Limit word 1 */
    float p02_torque_limit_status;  /* 30.02 Torque limit status */
    float p11_minimum_speed;  /* 30.11 Minimum speed */
    float p12_maximum_speed;  /* 30.12 Maximum speed */
    float p13_minimum_frequency;  /* 30.13 Minimum frequency */
    float p14_maximum;  /* 30.14 Maximum */
    float p15_maximum_start;  /* 30.15 Maximum start */
    float p16_maximum_start;  /* 30.16 Maximum start */
    float p17_maximum_current;  /* 30.17 Maximum current */
    float p18_minimum_torque_sel;  /* 30.18 Minimum torque sel */
    float p19_minimum_torque_1;  /* 30.19 Minimum torque 1 */
    float p20_maximum_torque_1;  /* 30.20 Maximum torque 1 */
    float p21_minimum_torque_2;  /* 30.21 Minimum torque 2 */
    float p22_maximum_torque_2;  /* 30.22 Maximum torque 2 */
    float p23_minimum_torque_2;  /* 30.23 Minimum torque 2 */
    float p24_maximum_torque_2;  /* 30.24 Maximum torque 2 */
    float p25_maximum_torque;  /* 30.25 Maximum torque */
    float p26_power_motoring;  /* 30.26 Power motoring */
    float p27_power_generating;  /* 30.27 Power generating */
    float p30_overvoltage_control;  /* 30.30 Overvoltage control */
    float p31_undervoltage;  /* 30.31 Undervoltage */
    float p35_thermal_current;  /* 30.35 Thermal current */
} param_group_30_t;

extern param_group_30_t g_param_grp30;

void param_grp30_init(void);
void param_grp30_load_defaults(void);
int  param_grp30_get(uint8_t index, float *out_value);
int  param_grp30_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP30_LIMITS_H */
