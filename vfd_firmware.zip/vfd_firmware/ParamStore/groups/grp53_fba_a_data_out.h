#ifndef VFD_PARAM_GRP53_FBA_A_DATA_OUT_H
#define VFD_PARAM_GRP53_FBA_A_DATA_OUT_H

/* Parameter group 53: FBA A data out
 * Auto-generated from ACS880 primary control program firmware manual
 * 2 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 53) ---- */
typedef enum {
    PARAM_53_01_FBA_A_DATA_OUT1 = 1, /* 53.01 FBA A data out1 */
    PARAM_53_12_FBA_A_DATA_OUT12 = 12, /* 53.12 FBA A data out12 */
} param_group_53_index_t;

/* ---- Live value storage (group 53) ---- */
typedef struct {
    float p01_fba_a_data_out1;  /* 53.01 FBA A data out1 */
    float p12_fba_a_data_out12;  /* 53.12 FBA A data out12 */
} param_group_53_t;

extern param_group_53_t g_param_grp53;

void param_grp53_init(void);
void param_grp53_load_defaults(void);
int  param_grp53_get(uint8_t index, float *out_value);
int  param_grp53_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP53_FBA_A_DATA_OUT_H */
