#ifndef VFD_PARAM_GRP03_INPUT_REFERENCES_H
#define VFD_PARAM_GRP03_INPUT_REFERENCES_H

/* Parameter group 03: Input references
 * Auto-generated from ACS880 primary control program firmware manual
 * 15 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 03) ---- */
typedef enum {
    PARAM_03_01_PANEL_REFERENCE = 1, /* 03.01 Panel reference */
    PARAM_03_02_PANEL_REFERENCE_2 = 2, /* 03.02 Panel reference 2 */
    PARAM_03_05_FB_A_REFERENCE_1 = 5, /* 03.05 FB A reference 1 */
    PARAM_03_06_FB_A_REFERENCE_2 = 6, /* 03.06 FB A reference 2 */
    PARAM_03_07_FB_B_REFERENCE_1 = 7, /* 03.07 FB B reference 1 */
    PARAM_03_08_FB_B_REFERENCE_2 = 8, /* 03.08 FB B reference 2 */
    PARAM_03_09_EFB_REFERENCE_1 = 9, /* 03.09 EFB reference 1 */
    PARAM_03_10_EFB_REFERENCE_2 = 10, /* 03.10 EFB reference 2 */
    PARAM_03_11_DDCS_CONTROLLER_REF = 11, /* 03.11 DDCS controller ref */
    PARAM_03_12_DDCS_CONTROLLER_REF = 12, /* 03.12 DDCS controller ref */
    PARAM_03_13_M_F_OR_D2D_REF1 = 13, /* 03.13 M/F or D2D ref1 */
    PARAM_03_14_M_F_OR_D2D_REF2 = 14, /* 03.14 M/F or D2D ref2 */
    PARAM_03_30_FB_A_REFERENCE_1 = 30, /* 03.30 FB A reference 1 */
    PARAM_03_31_FB_A_REFERENCE_2 = 31, /* 03.31 FB A reference 2 */
    PARAM_03_51_IEC_APPLICATION = 51, /* 03.51 IEC application */
} param_group_03_index_t;

/* ---- Live value storage (group 03) ---- */
typedef struct {
    float p01_panel_reference;  /* 03.01 Panel reference */
    float p02_panel_reference_2;  /* 03.02 Panel reference 2 */
    float p05_fb_a_reference_1;  /* 03.05 FB A reference 1 */
    float p06_fb_a_reference_2;  /* 03.06 FB A reference 2 */
    float p07_fb_b_reference_1;  /* 03.07 FB B reference 1 */
    float p08_fb_b_reference_2;  /* 03.08 FB B reference 2 */
    float p09_efb_reference_1;  /* 03.09 EFB reference 1 */
    float p10_efb_reference_2;  /* 03.10 EFB reference 2 */
    float p11_ddcs_controller_ref;  /* 03.11 DDCS controller ref */
    float p12_ddcs_controller_ref;  /* 03.12 DDCS controller ref */
    float p13_m_f_or_d2d_ref1;  /* 03.13 M/F or D2D ref1 */
    float p14_m_f_or_d2d_ref2;  /* 03.14 M/F or D2D ref2 */
    float p30_fb_a_reference_1;  /* 03.30 FB A reference 1 */
    float p31_fb_a_reference_2;  /* 03.31 FB A reference 2 */
    float p51_iec_application;  /* 03.51 IEC application */
} param_group_03_t;

extern param_group_03_t g_param_grp03;

void param_grp03_init(void);
void param_grp03_load_defaults(void);
int  param_grp03_get(uint8_t index, float *out_value);
int  param_grp03_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP03_INPUT_REFERENCES_H */
