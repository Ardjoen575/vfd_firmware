#ifndef VFD_PARAM_GRP44_MECHANICAL_BRAKE_CONTROL_H
#define VFD_PARAM_GRP44_MECHANICAL_BRAKE_CONTROL_H

/* Parameter group 44: Mechanical brake control
 * Auto-generated from ACS880 primary control program firmware manual
 * 17 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 44) ---- */
typedef enum {
    PARAM_44_01_BRAKE_CONTROL_STATUS_DISPLAYS_THE_MECHANICAL_BRAKE_CONTROL_STATUS_WORD = 1, /* 44.01 Brake control status Displays the mechanical brake control status word. */
    PARAM_44_02_BRAKE_TORQUE = 2, /* 44.02 Brake torque */
    PARAM_44_03_BRAKE_OPEN_TORQUE = 3, /* 44.03 Brake open torque */
    PARAM_44_06_BRAKE_CONTROL = 6, /* 44.06 Brake control */
    PARAM_44_07_BRAKE_ACKNOWLEDGE = 7, /* 44.07 Brake acknowledge */
    PARAM_44_08_BRAKE_OPEN_DELAY = 8, /* 44.08 Brake open delay */
    PARAM_44_09_BRAKE_OPEN_TORQUE = 9, /* 44.09 Brake open torque */
    PARAM_44_10_BRAKE_OPEN_TORQUE = 10, /* 44.10 Brake open torque */
    PARAM_44_11_KEEP_BRAKE_CLOSED = 11, /* 44.11 Keep brake closed */
    PARAM_44_12_BRAKE_CLOSE_REQUEST_SELECTS_THE_SOURCE_OF_AN_EXTERNAL_BRAKE_CLOSE_REQUEST_SIGNAL = 12, /* 44.12 Brake close request Selects the source of an external brake close request signal. */
    PARAM_44_13_BRAKE_CLOSE_DELAY = 13, /* 44.13 Brake close delay */
    PARAM_44_14_BRAKE_CLOSE_LEVEL = 14, /* 44.14 Brake close level */
    PARAM_44_15_BRAKE_CLOSE_LEVEL = 15, /* 44.15 Brake close level */
    PARAM_44_16_BRAKE_REOPEN_DELAY = 16, /* 44.16 Brake reopen delay */
    PARAM_44_17_BRAKE_FAULT_FUNCTION = 17, /* 44.17 Brake fault function */
    PARAM_44_18_BRAKE_FAULT_DELAY = 18, /* 44.18 Brake fault delay */
    PARAM_44_21_FILTER_TIME_BRAKE = 21, /* 44.21 Filter time brake */
} param_group_44_index_t;

/* ---- Live value storage (group 44) ---- */
typedef struct {
    float p01_brake_control_status_displays_the_mechanical_brake_control_status_word;  /* 44.01 Brake control status Displays the mechanical brake control status word. */
    float p02_brake_torque;  /* 44.02 Brake torque */
    float p03_brake_open_torque;  /* 44.03 Brake open torque */
    float p06_brake_control;  /* 44.06 Brake control */
    float p07_brake_acknowledge;  /* 44.07 Brake acknowledge */
    float p08_brake_open_delay;  /* 44.08 Brake open delay */
    float p09_brake_open_torque;  /* 44.09 Brake open torque */
    float p10_brake_open_torque;  /* 44.10 Brake open torque */
    float p11_keep_brake_closed;  /* 44.11 Keep brake closed */
    float p12_brake_close_request_selects_the_source_of_an_external_brake_close_request_signal;  /* 44.12 Brake close request Selects the source of an external brake close request signal. */
    float p13_brake_close_delay;  /* 44.13 Brake close delay */
    float p14_brake_close_level;  /* 44.14 Brake close level */
    float p15_brake_close_level;  /* 44.15 Brake close level */
    float p16_brake_reopen_delay;  /* 44.16 Brake reopen delay */
    float p17_brake_fault_function;  /* 44.17 Brake fault function */
    float p18_brake_fault_delay;  /* 44.18 Brake fault delay */
    float p21_filter_time_brake;  /* 44.21 Filter time brake */
} param_group_44_t;

extern param_group_44_t g_param_grp44;

void param_grp44_init(void);
void param_grp44_load_defaults(void);
int  param_grp44_get(uint8_t index, float *out_value);
int  param_grp44_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP44_MECHANICAL_BRAKE_CONTROL_H */
