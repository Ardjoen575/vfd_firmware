#ifndef VFD_PARAM_GRP20_START_STOP_DIRECTION_H
#define VFD_PARAM_GRP20_START_STOP_DIRECTION_H

/* Parameter group 20: Start stop direction
 * Auto-generated from ACS880 primary control program firmware manual
 * 20 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 20) ---- */
typedef enum {
    PARAM_20_01_EXT1_COMMANDS = 1, /* 20.01 Ext1 commands */
    PARAM_20_02_EXT1_START_TRIGGER = 2, /* 20.02 Ext1 start trigger */
    PARAM_20_03_EXT1_IN1_SOURCE = 3, /* 20.03 Ext1 in1 source */
    PARAM_20_04_EXT1_IN2_SOURCE = 4, /* 20.04 Ext1 in2 source */
    PARAM_20_05_EXT1_IN3_SOURCE = 5, /* 20.05 Ext1 in3 source */
    PARAM_20_06_EXT2_COMMANDS = 6, /* 20.06 Ext2 commands */
    PARAM_20_07_EXT2_START_TRIGGER = 7, /* 20.07 Ext2 start trigger */
    PARAM_20_08_EXT2_IN1_SOURCE = 8, /* 20.08 Ext2 in1 source */
    PARAM_20_09_EXT2_IN2_SOURCE = 9, /* 20.09 Ext2 in2 source */
    PARAM_20_10_EXT2_IN3_SOURCE = 10, /* 20.10 Ext2 in3 source */
    PARAM_20_11_RUN_ENABLE_STOP = 11, /* 20.11 Run enable stop */
    PARAM_20_12_RUN_ENABLE_1 = 12, /* 20.12 Run enable 1 */
    PARAM_20_19_ENABLE_START = 19, /* 20.19 Enable start */
    PARAM_20_23_POSITIVE_SPEED = 23, /* 20.23 Positive speed */
    PARAM_20_24_NEGATIVE_SPEED = 24, /* 20.24 Negative speed */
    PARAM_20_25_JOGGING_ENABLE = 25, /* 20.25 Jogging enable */
    PARAM_20_26_JOGGING_1_START = 26, /* 20.26 Jogging 1 start */
    PARAM_20_27_JOGGING_2_START = 27, /* 20.27 Jogging 2 start */
    PARAM_20_29_LOCAL_START_TRIGGER = 29, /* 20.29 Local start trigger */
    PARAM_20_30_ENABLE_SIGNALS = 30, /* 20.30 Enable signals */
} param_group_20_index_t;

/* ---- Live value storage (group 20) ---- */
typedef struct {
    float p01_ext1_commands;  /* 20.01 Ext1 commands */
    float p02_ext1_start_trigger;  /* 20.02 Ext1 start trigger */
    float p03_ext1_in1_source;  /* 20.03 Ext1 in1 source */
    float p04_ext1_in2_source;  /* 20.04 Ext1 in2 source */
    float p05_ext1_in3_source;  /* 20.05 Ext1 in3 source */
    float p06_ext2_commands;  /* 20.06 Ext2 commands */
    float p07_ext2_start_trigger;  /* 20.07 Ext2 start trigger */
    float p08_ext2_in1_source;  /* 20.08 Ext2 in1 source */
    float p09_ext2_in2_source;  /* 20.09 Ext2 in2 source */
    float p10_ext2_in3_source;  /* 20.10 Ext2 in3 source */
    float p11_run_enable_stop;  /* 20.11 Run enable stop */
    float p12_run_enable_1;  /* 20.12 Run enable 1 */
    float p19_enable_start;  /* 20.19 Enable start */
    float p23_positive_speed;  /* 20.23 Positive speed */
    float p24_negative_speed;  /* 20.24 Negative speed */
    float p25_jogging_enable;  /* 20.25 Jogging enable */
    float p26_jogging_1_start;  /* 20.26 Jogging 1 start */
    float p27_jogging_2_start;  /* 20.27 Jogging 2 start */
    float p29_local_start_trigger;  /* 20.29 Local start trigger */
    float p30_enable_signals;  /* 20.30 Enable signals */
} param_group_20_t;

extern param_group_20_t g_param_grp20;

void param_grp20_init(void);
void param_grp20_load_defaults(void);
int  param_grp20_get(uint8_t index, float *out_value);
int  param_grp20_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP20_START_STOP_DIRECTION_H */
