#ifndef VFD_PARAM_GRP43_BRAKE_CHOPPER_H
#define VFD_PARAM_GRP43_BRAKE_CHOPPER_H

/* Parameter group 43: Brake chopper
 * Auto-generated from ACS880 primary control program firmware manual
 * 8 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 43) ---- */
typedef enum {
    PARAM_43_01_BRAKING_RESISTOR = 1, /* 43.01 Braking resistor */
    PARAM_43_06_BRAKE_CHOPPER = 6, /* 43.06 Brake chopper */
    PARAM_43_07_BRAKE_CHOPPER_RUN = 7, /* 43.07 Brake chopper run */
    PARAM_43_08_BRAKE_RESISTOR = 8, /* 43.08 Brake resistor */
    PARAM_43_09_BRAKE_RESISTOR = 9, /* 43.09 Brake resistor */
    PARAM_43_10_BRAKE_RESISTANCE = 10, /* 43.10 Brake resistance */
    PARAM_43_11_BRAKE_RESISTOR_FAULT = 11, /* 43.11 Brake resistor fault */
    PARAM_43_12_BRAKE_RESISTOR = 12, /* 43.12 Brake resistor */
} param_group_43_index_t;

/* ---- Live value storage (group 43) ---- */
typedef struct {
    float p01_braking_resistor;  /* 43.01 Braking resistor */
    float p06_brake_chopper;  /* 43.06 Brake chopper */
    float p07_brake_chopper_run;  /* 43.07 Brake chopper run */
    float p08_brake_resistor;  /* 43.08 Brake resistor */
    float p09_brake_resistor;  /* 43.09 Brake resistor */
    float p10_brake_resistance;  /* 43.10 Brake resistance */
    float p11_brake_resistor_fault;  /* 43.11 Brake resistor fault */
    float p12_brake_resistor;  /* 43.12 Brake resistor */
} param_group_43_t;

extern param_group_43_t g_param_grp43;

void param_grp43_init(void);
void param_grp43_load_defaults(void);
int  param_grp43_get(uint8_t index, float *out_value);
int  param_grp43_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP43_BRAKE_CHOPPER_H */
