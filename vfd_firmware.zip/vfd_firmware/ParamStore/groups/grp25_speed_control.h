#ifndef VFD_PARAM_GRP25_SPEED_CONTROL_H
#define VFD_PARAM_GRP25_SPEED_CONTROL_H

/* Parameter group 25: Speed control
 * Auto-generated from ACS880 primary control program firmware manual
 * 36 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 25) ---- */
typedef enum {
    PARAM_25_01_TORQUE_REFERENCE = 1, /* 25.01 Torque reference */
    PARAM_25_02_SPEED_PROPORTIONAL = 2, /* 25.02 Speed proportional */
    PARAM_25_03_SPEED_INTEGRATION = 3, /* 25.03 Speed integration */
    PARAM_25_04_SPEED_DERIVATION = 4, /* 25.04 Speed derivation */
    PARAM_25_05_DERIVATION_FILTER_TIME_DEFINES_THE_DERIVATION_FILTER_TIME_CONSTANT_SEE_PARAMETER = 5, /* 25.05 Derivation filter time Defines the derivation filter time constant. See parameter */
    PARAM_25_06_ACC_COMP = 6, /* 25.06 Acc comp */
    PARAM_25_07_ACC_COMP_FILTER_TIME = 7, /* 25.07 Acc comp filter time */
    PARAM_25_08_DROOPING_RATE = 8, /* 25.08 Drooping rate */
    PARAM_25_09_SPEED_CTRL = 9, /* 25.09 Speed ctrl */
    PARAM_25_10_SPEED_CTRL = 10, /* 25.10 Speed ctrl */
    PARAM_25_11_SPEED_CONTROL_MIN = 11, /* 25.11 Speed control min */
    PARAM_25_12_SPEED_CONTROL_MAX = 12, /* 25.12 Speed control max */
    PARAM_25_13_MIN_TORQ_SP_CTRL_EM = 13, /* 25.13 Min torq sp ctrl em */
    PARAM_25_14_MAX_TORQ_SP_CTRL_EM = 14, /* 25.14 Max torq sp ctrl em */
    PARAM_25_15_PROPORTIONAL_GAIN = 15, /* 25.15 Proportional gain */
    PARAM_25_18_SPEED_ADAPT_MIN = 18, /* 25.18 Speed adapt min */
    PARAM_25_19_SPEED_ADAPT_MAX = 19, /* 25.19 Speed adapt max */
    PARAM_25_21_KP_ADAPT_COEF_AT = 21, /* 25.21 Kp adapt coef at */
    PARAM_25_22_TI_ADAPT_COEF_AT_MIN = 22, /* 25.22 Ti adapt coef at min */
    PARAM_25_25_TORQUE_ADAPT_MAX = 25, /* 25.25 Torque adapt max */
    PARAM_25_26_TORQUE_ADAPT_FILT = 26, /* 25.26 Torque adapt filt */
    PARAM_25_27_KP_ADAPT_COEF_AT = 27, /* 25.27 Kp adapt coef at */
    PARAM_25_30_FLUX_ADAPTION = 30, /* 25.30 Flux adaption */
    PARAM_25_33_SPEED_CONTROLLER = 33, /* 25.33 Speed controller */
    PARAM_25_34_SPEED_CONTROLLER = 34, /* 25.34 Speed controller */
    PARAM_25_37_MECHANICAL_TIME = 37, /* 25.37 Mechanical time */
    PARAM_25_38_AUTOTUNE_TORQUE = 38, /* 25.38 Autotune torque */
    PARAM_25_39_AUTOTUNE_SPEED = 39, /* 25.39 Autotune speed */
    PARAM_25_40_AUTOTUNE_REPEAT = 40, /* 25.40 Autotune repeat */
    PARAM_25_41_TORQUE_REFERENCE = 41, /* 25.41 Torque reference */
    PARAM_25_42_INTEGRAL_TERM_ENABLE_SELECTS_A_SOURCE_THAT_ENABLES_DISABLES_THE_INTEGRAL_I_PART_OF = 42, /* 25.42 Integral term enable Selects a source that enables/disables the integral (I) part of */
    PARAM_25_53_TORQUE_PROP = 53, /* 25.53 Torque prop */
    PARAM_25_54_TORQUE_INTEGRAL = 54, /* 25.54 Torque integral */
    PARAM_25_55_TORQUE_DERIV = 55, /* 25.55 Torque deriv */
    PARAM_25_56_TORQUE_ACC = 56, /* 25.56 Torque acc */
    PARAM_25_57_TORQUE_REFERENCE = 57, /* 25.57 Torque reference */
} param_group_25_index_t;

/* ---- Live value storage (group 25) ---- */
typedef struct {
    float p01_torque_reference;  /* 25.01 Torque reference */
    float p02_speed_proportional;  /* 25.02 Speed proportional */
    float p03_speed_integration;  /* 25.03 Speed integration */
    float p04_speed_derivation;  /* 25.04 Speed derivation */
    float p05_derivation_filter_time_defines_the_derivation_filter_time_constant_see_parameter;  /* 25.05 Derivation filter time Defines the derivation filter time constant. See parameter */
    float p06_acc_comp;  /* 25.06 Acc comp */
    float p07_acc_comp_filter_time;  /* 25.07 Acc comp filter time */
    float p08_drooping_rate;  /* 25.08 Drooping rate */
    float p09_speed_ctrl;  /* 25.09 Speed ctrl */
    float p10_speed_ctrl;  /* 25.10 Speed ctrl */
    float p11_speed_control_min;  /* 25.11 Speed control min */
    float p12_speed_control_max;  /* 25.12 Speed control max */
    float p13_min_torq_sp_ctrl_em;  /* 25.13 Min torq sp ctrl em */
    float p14_max_torq_sp_ctrl_em;  /* 25.14 Max torq sp ctrl em */
    float p15_proportional_gain;  /* 25.15 Proportional gain */
    float p18_speed_adapt_min;  /* 25.18 Speed adapt min */
    float p19_speed_adapt_max;  /* 25.19 Speed adapt max */
    float p21_kp_adapt_coef_at;  /* 25.21 Kp adapt coef at */
    float p22_ti_adapt_coef_at_min;  /* 25.22 Ti adapt coef at min */
    float p25_torque_adapt_max;  /* 25.25 Torque adapt max */
    float p26_torque_adapt_filt;  /* 25.26 Torque adapt filt */
    float p27_kp_adapt_coef_at;  /* 25.27 Kp adapt coef at */
    float p30_flux_adaption;  /* 25.30 Flux adaption */
    float p33_speed_controller;  /* 25.33 Speed controller */
    float p34_speed_controller;  /* 25.34 Speed controller */
    float p37_mechanical_time;  /* 25.37 Mechanical time */
    float p38_autotune_torque;  /* 25.38 Autotune torque */
    float p39_autotune_speed;  /* 25.39 Autotune speed */
    float p40_autotune_repeat;  /* 25.40 Autotune repeat */
    float p41_torque_reference;  /* 25.41 Torque reference */
    float p42_integral_term_enable_selects_a_source_that_enables_disables_the_integral_i_part_of;  /* 25.42 Integral term enable Selects a source that enables/disables the integral (I) part of */
    float p53_torque_prop;  /* 25.53 Torque prop */
    float p54_torque_integral;  /* 25.54 Torque integral */
    float p55_torque_deriv;  /* 25.55 Torque deriv */
    float p56_torque_acc;  /* 25.56 Torque acc */
    float p57_torque_reference;  /* 25.57 Torque reference */
} param_group_25_t;

extern param_group_25_t g_param_grp25;

void param_grp25_init(void);
void param_grp25_load_defaults(void);
int  param_grp25_get(uint8_t index, float *out_value);
int  param_grp25_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP25_SPEED_CONTROL_H */
