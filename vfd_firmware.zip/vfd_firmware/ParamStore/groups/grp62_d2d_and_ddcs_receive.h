#ifndef VFD_PARAM_GRP62_D2D_AND_DDCS_RECEIVE_H
#define VFD_PARAM_GRP62_D2D_AND_DDCS_RECEIVE_H

/* Parameter group 62: D2D and DDCS receive
 * Auto-generated from ACS880 primary control program firmware manual
 * 40 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 62) ---- */
typedef enum {
    PARAM_62_01_M_F_DATA_1 = 1, /* 62.01 M/F data 1 */
    PARAM_62_02_M_F_DATA_2 = 2, /* 62.02 M/F data 2 */
    PARAM_62_03_M_F_DATA_3 = 3, /* 62.03 M/F data 3 */
    PARAM_62_04_FOLLOWER_NODE_2 = 4, /* 62.04 Follower node 2 */
    PARAM_62_05_FOLLOWER_NODE_2 = 5, /* 62.05 Follower node 2 */
    PARAM_62_06_FOLLOWER_NODE_2 = 6, /* 62.06 Follower node 2 */
    PARAM_62_07_FOLLOWER_NODE_3 = 7, /* 62.07 Follower node 3 */
    PARAM_62_08_FOLLOWER_NODE_3 = 8, /* 62.08 Follower node 3 */
    PARAM_62_09_FOLLOWER_NODE_3 = 9, /* 62.09 Follower node 3 */
    PARAM_62_10_FOLLOWER_NODE_4 = 10, /* 62.10 Follower node 4 */
    PARAM_62_11_FOLLOWER_NODE_4 = 11, /* 62.11 Follower node 4 */
    PARAM_62_12_FOLLOWER_NODE_4 = 12, /* 62.12 Follower node 4 */
    PARAM_62_25_MF_DATA_1_VALUE = 25, /* 62.25 MF data 1 value */
    PARAM_62_26_MF_DATA_2_VALUE = 26, /* 62.26 MF data 2 value */
    PARAM_62_27_MF_DATA_3_VALUE = 27, /* 62.27 MF data 3 value */
    PARAM_62_28_FOLLOWER_NODE_2 = 28, /* 62.28 Follower node 2 */
    PARAM_62_29_FOLLOWER_NODE_2 = 29, /* 62.29 Follower node 2 */
    PARAM_62_30_FOLLOWER_NODE_2 = 30, /* 62.30 Follower node 2 */
    PARAM_62_31_FOLLOWER_NODE_3 = 31, /* 62.31 Follower node 3 */
    PARAM_62_32_FOLLOWER_NODE_3 = 32, /* 62.32 Follower node 3 */
    PARAM_62_33_FOLLOWER_NODE_3 = 33, /* 62.33 Follower node 3 */
    PARAM_62_34_FOLLOWER_NODE_4 = 34, /* 62.34 Follower node 4 */
    PARAM_62_35_FOLLOWER_NODE_4 = 35, /* 62.35 Follower node 4 */
    PARAM_62_36_FOLLOWER_NODE_4 = 36, /* 62.36 Follower node 4 */
    PARAM_62_37_M_F_COMMUNICATION = 37, /* 62.37 M/F communication */
    PARAM_62_38_M_F_COMMUNICATION = 38, /* 62.38 M/F communication */
    PARAM_62_41_M_F_FOLLOWER_READY = 41, /* 62.41 M/F follower ready */
    PARAM_62_42_M_F_FOLLOWER_READY = 42, /* 62.42 M/F follower ready */
    PARAM_62_45_DATA_SET_1_DATA_1 = 45, /* 62.45 Data set 1 data 1 */
    PARAM_62_46_DATA_SET_1_DATA_2 = 46, /* 62.46 Data set 1 data 2 */
    PARAM_62_47_DATA_SET_1_DATA_3 = 47, /* 62.47 Data set 1 data 3 */
    PARAM_62_50_DATA_SET_3_DATA_3 = 50, /* 62.50 Data set 3 data 3 */
    PARAM_62_51_DATA_SET_10_DATA_1 = 51, /* 62.51 Data set 10 data 1 */
    PARAM_62_52_DATA_SET_10_DATA_2 = 52, /* 62.52 Data set 10 data 2 */
    PARAM_62_53_DATA_SET_10_DATA_3 = 53, /* 62.53 Data set 10 data 3 */
    PARAM_62_54_DATA_SET_12_DATA_1 = 54, /* 62.54 Data set 12 data 1 */
    PARAM_62_74_DATA_SET_24_DATA_3 = 74, /* 62.74 Data set 24 data 3 */
    PARAM_62_95_DATA_SET_1_DATA_1 = 95, /* 62.95 Data set 1 data 1 */
    PARAM_62_96_DATA_SET_1_DATA_2 = 96, /* 62.96 Data set 1 data 2 */
    PARAM_62_97_DATA_SET_1_DATA_3 = 97, /* 62.97 Data set 1 data 3 */
} param_group_62_index_t;

/* ---- Live value storage (group 62) ---- */
typedef struct {
    float p01_m_f_data_1;  /* 62.01 M/F data 1 */
    float p02_m_f_data_2;  /* 62.02 M/F data 2 */
    float p03_m_f_data_3;  /* 62.03 M/F data 3 */
    float p04_follower_node_2;  /* 62.04 Follower node 2 */
    float p05_follower_node_2;  /* 62.05 Follower node 2 */
    float p06_follower_node_2;  /* 62.06 Follower node 2 */
    float p07_follower_node_3;  /* 62.07 Follower node 3 */
    float p08_follower_node_3;  /* 62.08 Follower node 3 */
    float p09_follower_node_3;  /* 62.09 Follower node 3 */
    float p10_follower_node_4;  /* 62.10 Follower node 4 */
    float p11_follower_node_4;  /* 62.11 Follower node 4 */
    float p12_follower_node_4;  /* 62.12 Follower node 4 */
    float p25_mf_data_1_value;  /* 62.25 MF data 1 value */
    float p26_mf_data_2_value;  /* 62.26 MF data 2 value */
    float p27_mf_data_3_value;  /* 62.27 MF data 3 value */
    float p28_follower_node_2;  /* 62.28 Follower node 2 */
    float p29_follower_node_2;  /* 62.29 Follower node 2 */
    float p30_follower_node_2;  /* 62.30 Follower node 2 */
    float p31_follower_node_3;  /* 62.31 Follower node 3 */
    float p32_follower_node_3;  /* 62.32 Follower node 3 */
    float p33_follower_node_3;  /* 62.33 Follower node 3 */
    float p34_follower_node_4;  /* 62.34 Follower node 4 */
    float p35_follower_node_4;  /* 62.35 Follower node 4 */
    float p36_follower_node_4;  /* 62.36 Follower node 4 */
    float p37_m_f_communication;  /* 62.37 M/F communication */
    float p38_m_f_communication;  /* 62.38 M/F communication */
    float p41_m_f_follower_ready;  /* 62.41 M/F follower ready */
    float p42_m_f_follower_ready;  /* 62.42 M/F follower ready */
    float p45_data_set_1_data_1;  /* 62.45 Data set 1 data 1 */
    float p46_data_set_1_data_2;  /* 62.46 Data set 1 data 2 */
    float p47_data_set_1_data_3;  /* 62.47 Data set 1 data 3 */
    float p50_data_set_3_data_3;  /* 62.50 Data set 3 data 3 */
    float p51_data_set_10_data_1;  /* 62.51 Data set 10 data 1 */
    float p52_data_set_10_data_2;  /* 62.52 Data set 10 data 2 */
    float p53_data_set_10_data_3;  /* 62.53 Data set 10 data 3 */
    float p54_data_set_12_data_1;  /* 62.54 Data set 12 data 1 */
    float p74_data_set_24_data_3;  /* 62.74 Data set 24 data 3 */
    float p95_data_set_1_data_1;  /* 62.95 Data set 1 data 1 */
    float p96_data_set_1_data_2;  /* 62.96 Data set 1 data 2 */
    float p97_data_set_1_data_3;  /* 62.97 Data set 1 data 3 */
} param_group_62_t;

extern param_group_62_t g_param_grp62;

void param_grp62_init(void);
void param_grp62_load_defaults(void);
int  param_grp62_get(uint8_t index, float *out_value);
int  param_grp62_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP62_D2D_AND_DDCS_RECEIVE_H */
