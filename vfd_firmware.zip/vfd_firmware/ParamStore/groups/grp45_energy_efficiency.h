#ifndef VFD_PARAM_GRP45_ENERGY_EFFICIENCY_H
#define VFD_PARAM_GRP45_ENERGY_EFFICIENCY_H

/* Parameter group 45: Energy efficiency
 * Auto-generated from ACS880 primary control program firmware manual
 * 15 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 45) ---- */
typedef enum {
    PARAM_45_01_SAVED_GW_HOURS = 1, /* 45.01 Saved GW hours */
    PARAM_45_02_SAVED_MW_HOURS = 2, /* 45.02 Saved MW hours */
    PARAM_45_03_SAVED_KW_HOURS = 3, /* 45.03 Saved kW hours */
    PARAM_45_05_SAVED_MONEY = 5, /* 45.05 Saved money */
    PARAM_45_06_SAVED_MONEY = 6, /* 45.06 Saved money */
    PARAM_45_08_CO2_REDUCTION_IN = 8, /* 45.08 CO2 reduction in */
    PARAM_45_09_CO2_REDUCTION_IN = 9, /* 45.09 CO2 reduction in */
    PARAM_45_11_ENERGY_OPTIMIZER = 11, /* 45.11 Energy optimizer */
    PARAM_45_12_ENERGY_TARIFF_1 = 12, /* 45.12 Energy tariff 1 */
    PARAM_45_13_ENERGY_TARIFF_2 = 13, /* 45.13 Energy tariff 2 */
    PARAM_45_14_TARIFF_SELECTION = 14, /* 45.14 Tariff selection */
    PARAM_45_17_TARIFF_CURRENCY_UNIT = 17, /* 45.17 Tariff currency unit */
    PARAM_45_18_CO2_CONVERSION = 18, /* 45.18 CO2 conversion */
    PARAM_45_19_COMPARISON_POWER = 19, /* 45.19 Comparison power */
    PARAM_45_21_ENERGY_CALCULATIONS = 21, /* 45.21 Energy calculations */
} param_group_45_index_t;

/* ---- Live value storage (group 45) ---- */
typedef struct {
    float p01_saved_gw_hours;  /* 45.01 Saved GW hours */
    float p02_saved_mw_hours;  /* 45.02 Saved MW hours */
    float p03_saved_kw_hours;  /* 45.03 Saved kW hours */
    float p05_saved_money;  /* 45.05 Saved money */
    float p06_saved_money;  /* 45.06 Saved money */
    float p08_co2_reduction_in;  /* 45.08 CO2 reduction in */
    float p09_co2_reduction_in;  /* 45.09 CO2 reduction in */
    float p11_energy_optimizer;  /* 45.11 Energy optimizer */
    float p12_energy_tariff_1;  /* 45.12 Energy tariff 1 */
    float p13_energy_tariff_2;  /* 45.13 Energy tariff 2 */
    float p14_tariff_selection;  /* 45.14 Tariff selection */
    float p17_tariff_currency_unit;  /* 45.17 Tariff currency unit */
    float p18_co2_conversion;  /* 45.18 CO2 conversion */
    float p19_comparison_power;  /* 45.19 Comparison power */
    float p21_energy_calculations;  /* 45.21 Energy calculations */
} param_group_45_t;

extern param_group_45_t g_param_grp45;

void param_grp45_init(void);
void param_grp45_load_defaults(void);
int  param_grp45_get(uint8_t index, float *out_value);
int  param_grp45_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP45_ENERGY_EFFICIENCY_H */
