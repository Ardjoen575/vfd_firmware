#ifndef VFD_PARAM_GRP46_MONITORING_SCALING_SETTINGS_H
#define VFD_PARAM_GRP46_MONITORING_SCALING_SETTINGS_H

/* Parameter group 46: Monitoring scaling settings
 * Auto-generated from ACS880 primary control program firmware manual
 * 18 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 46) ---- */
typedef enum {
    PARAM_46_01_SPEED_SCALING = 1, /* 46.01 Speed scaling */
    PARAM_46_02_FREQUENCY_SCALING = 2, /* 46.02 Frequency scaling */
    PARAM_46_03_TORQUE_SCALING = 3, /* 46.03 Torque scaling */
    PARAM_46_04_POWER_SCALING = 4, /* 46.04 Power scaling */
    PARAM_46_05_CURRENT_SCALING = 5, /* 46.05 Current scaling */
    PARAM_46_06_SPEED_REF_ZERO = 6, /* 46.06 Speed ref zero */
    PARAM_46_07_FREQUENCY_REF_ZERO = 7, /* 46.07 Frequency ref zero */
    PARAM_46_11_FILTER_TIME_MOTOR = 11, /* 46.11 Filter time motor */
    PARAM_46_12_FILTER_TIME_OUTPUT = 12, /* 46.12 Filter time output */
    PARAM_46_13_FILTER_TIME_MOTOR = 13, /* 46.13 Filter time motor */
    PARAM_46_14_FILTER_TIME_POWER = 14, /* 46.14 Filter time power */
    PARAM_46_21_AT_SPEED_HYSTERESIS = 21, /* 46.21 At speed hysteresis */
    PARAM_46_22_AT_FREQUENCY = 22, /* 46.22 At frequency */
    PARAM_46_23_AT_TORQUE_HYSTERESIS_DEFINES_THE_AT_SETPOINT_LIMITS_FOR_TORQUE_CONTROL_OF_THE_DRIVE = 23, /* 46.23 At torque hysteresis Defines the “at setpoint” limits for torque control of the drive. */
    PARAM_46_31_ABOVE_SPEED_LIMIT = 31, /* 46.31 Above speed limit */
    PARAM_46_32_ABOVE_FREQUENCY = 32, /* 46.32 Above frequency */
    PARAM_46_33_ABOVE_TORQUE_LIMIT = 33, /* 46.33 Above torque limit */
    PARAM_46_42_TORQUE_DECIMALS = 42, /* 46.42 Torque decimals */
} param_group_46_index_t;

/* ---- Live value storage (group 46) ---- */
typedef struct {
    float p01_speed_scaling;  /* 46.01 Speed scaling */
    float p02_frequency_scaling;  /* 46.02 Frequency scaling */
    float p03_torque_scaling;  /* 46.03 Torque scaling */
    float p04_power_scaling;  /* 46.04 Power scaling */
    float p05_current_scaling;  /* 46.05 Current scaling */
    float p06_speed_ref_zero;  /* 46.06 Speed ref zero */
    float p07_frequency_ref_zero;  /* 46.07 Frequency ref zero */
    float p11_filter_time_motor;  /* 46.11 Filter time motor */
    float p12_filter_time_output;  /* 46.12 Filter time output */
    float p13_filter_time_motor;  /* 46.13 Filter time motor */
    float p14_filter_time_power;  /* 46.14 Filter time power */
    float p21_at_speed_hysteresis;  /* 46.21 At speed hysteresis */
    float p22_at_frequency;  /* 46.22 At frequency */
    float p23_at_torque_hysteresis_defines_the_at_setpoint_limits_for_torque_control_of_the_drive;  /* 46.23 At torque hysteresis Defines the “at setpoint” limits for torque control of the drive. */
    float p31_above_speed_limit;  /* 46.31 Above speed limit */
    float p32_above_frequency;  /* 46.32 Above frequency */
    float p33_above_torque_limit;  /* 46.33 Above torque limit */
    float p42_torque_decimals;  /* 46.42 Torque decimals */
} param_group_46_t;

extern param_group_46_t g_param_grp46;

void param_grp46_init(void);
void param_grp46_load_defaults(void);
int  param_grp46_get(uint8_t index, float *out_value);
int  param_grp46_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP46_MONITORING_SCALING_SETTINGS_H */
