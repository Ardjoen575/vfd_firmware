#ifndef VFD_PARAM_GRP94_LSU_CONTROL_H
#define VFD_PARAM_GRP94_LSU_CONTROL_H

/* Parameter group 94: LSU control
 * Auto-generated from ACS880 primary control program firmware manual
 * 13 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 94) ---- */
typedef enum {
    PARAM_94_01_LSU_CONTROL = 1, /* 94.01 LSU control */
    PARAM_94_02_LSU_PANEL = 2, /* 94.02 LSU panel */
    PARAM_94_04_INU_LSU_STATUS = 4, /* 94.04 INU-LSU status */
    PARAM_94_10_LSU_MAX_CHARGING = 10, /* 94.10 LSU max charging */
    PARAM_94_11_LSU_STOP_DELAY = 11, /* 94.11 LSU stop delay */
    PARAM_94_20_DC_VOLTAGE = 20, /* 94.20 DC voltage */
    PARAM_94_21_DC_VOLTAGE_REF = 21, /* 94.21 DC voltage ref */
    PARAM_94_22_USER_DC_VOLTAGE = 22, /* 94.22 User DC voltage */
    PARAM_94_30_REACTIVE_POWER = 30, /* 94.30 Reactive power */
    PARAM_94_31_REACTIVE_POWER_REF = 31, /* 94.31 Reactive power ref */
    PARAM_94_32_USER_REACTIVE_POWER = 32, /* 94.32 User reactive power */
    PARAM_94_40_POWER_MOT_LIMIT_ON = 40, /* 94.40 Power mot limit on */
    PARAM_94_41_POWER_GEN_LIMIT_ON = 41, /* 94.41 Power gen limit on */
} param_group_94_index_t;

/* ---- Live value storage (group 94) ---- */
typedef struct {
    float p01_lsu_control;  /* 94.01 LSU control */
    float p02_lsu_panel;  /* 94.02 LSU panel */
    float p04_inu_lsu_status;  /* 94.04 INU-LSU status */
    float p10_lsu_max_charging;  /* 94.10 LSU max charging */
    float p11_lsu_stop_delay;  /* 94.11 LSU stop delay */
    float p20_dc_voltage;  /* 94.20 DC voltage */
    float p21_dc_voltage_ref;  /* 94.21 DC voltage ref */
    float p22_user_dc_voltage;  /* 94.22 User DC voltage */
    float p30_reactive_power;  /* 94.30 Reactive power */
    float p31_reactive_power_ref;  /* 94.31 Reactive power ref */
    float p32_user_reactive_power;  /* 94.32 User reactive power */
    float p40_power_mot_limit_on;  /* 94.40 Power mot limit on */
    float p41_power_gen_limit_on;  /* 94.41 Power gen limit on */
} param_group_94_t;

extern param_group_94_t g_param_grp94;

void param_grp94_init(void);
void param_grp94_load_defaults(void);
int  param_grp94_get(uint8_t index, float *out_value);
int  param_grp94_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP94_LSU_CONTROL_H */
