#ifndef VFD_PARAM_GRP07_SYSTEM_INFO_H
#define VFD_PARAM_GRP07_SYSTEM_INFO_H

/* Parameter group 07: System info
 * Auto-generated from ACS880 primary control program firmware manual
 * 21 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 07) ---- */
typedef enum {
    PARAM_07_03_DRIVE_RATING_ID = 3, /* 07.03 Drive rating id */
    PARAM_07_04_FIRMWARE_NAME = 4, /* 07.04 Firmware name */
    PARAM_07_05_FIRMWARE_VERSION = 5, /* 07.05 Firmware version */
    PARAM_07_06_LOADING_PACKAGE = 6, /* 07.06 Loading package */
    PARAM_07_07_LOADING_PACKAGE = 7, /* 07.07 Loading package */
    PARAM_07_08_BOOTLOADER_VERSION = 8, /* 07.08 Bootloader version */
    PARAM_07_11_CPU_USAGE = 11, /* 07.11 Cpu usage */
    PARAM_07_13_PU_LOGIC_VERSION = 13, /* 07.13 PU logic version */
    PARAM_07_15_FPGA_LOGIC_VERSION = 15, /* 07.15 FPGA logic version */
    PARAM_07_21_APPLICATION = 21, /* 07.21 Application */
    PARAM_07_22_APPLICATION = 22, /* 07.22 Application */
    PARAM_07_23_APPLICATION_NAME = 23, /* 07.23 Application name */
    PARAM_07_24_APPLICATION_VERSION = 24, /* 07.24 Application version */
    PARAM_07_25_CUSTOMIZATION = 25, /* 07.25 Customization */
    PARAM_07_26_CUSTOMIZATION = 26, /* 07.26 Customization */
    PARAM_07_30_ADAPTIVE_PROGRAM = 30, /* 07.30 Adaptive program */
    PARAM_07_40_IEC_APPLICATION_CPU = 40, /* 07.40 IEC application Cpu */
    PARAM_07_41_IEC_APPLICATION_CPU = 41, /* 07.41 IEC application Cpu */
    PARAM_07_51_SLOT_1_OPTION = 51, /* 07.51 Slot 1 option */
    PARAM_07_52_SLOT_2_OPTION = 52, /* 07.52 Slot 2 option */
    PARAM_07_53_SLOT_3_OPTION = 53, /* 07.53 Slot 3 option */
} param_group_07_index_t;

/* ---- Live value storage (group 07) ---- */
typedef struct {
    float p03_drive_rating_id;  /* 07.03 Drive rating id */
    float p04_firmware_name;  /* 07.04 Firmware name */
    float p05_firmware_version;  /* 07.05 Firmware version */
    float p06_loading_package;  /* 07.06 Loading package */
    float p07_loading_package;  /* 07.07 Loading package */
    float p08_bootloader_version;  /* 07.08 Bootloader version */
    float p11_cpu_usage;  /* 07.11 Cpu usage */
    float p13_pu_logic_version;  /* 07.13 PU logic version */
    float p15_fpga_logic_version;  /* 07.15 FPGA logic version */
    float p21_application;  /* 07.21 Application */
    float p22_application;  /* 07.22 Application */
    float p23_application_name;  /* 07.23 Application name */
    float p24_application_version;  /* 07.24 Application version */
    float p25_customization;  /* 07.25 Customization */
    float p26_customization;  /* 07.26 Customization */
    float p30_adaptive_program;  /* 07.30 Adaptive program */
    float p40_iec_application_cpu;  /* 07.40 IEC application Cpu */
    float p41_iec_application_cpu;  /* 07.41 IEC application Cpu */
    float p51_slot_1_option;  /* 07.51 Slot 1 option */
    float p52_slot_2_option;  /* 07.52 Slot 2 option */
    float p53_slot_3_option;  /* 07.53 Slot 3 option */
} param_group_07_t;

extern param_group_07_t g_param_grp07;

void param_grp07_init(void);
void param_grp07_load_defaults(void);
int  param_grp07_get(uint8_t index, float *out_value);
int  param_grp07_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP07_SYSTEM_INFO_H */
