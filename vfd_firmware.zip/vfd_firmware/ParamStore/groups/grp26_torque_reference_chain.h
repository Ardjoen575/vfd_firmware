#ifndef VFD_PARAM_GRP26_TORQUE_REFERENCE_CHAIN_H
#define VFD_PARAM_GRP26_TORQUE_REFERENCE_CHAIN_H

/* Parameter group 26: Torque reference chain
 * Auto-generated from ACS880 primary control program firmware manual
 * 37 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 26) ---- */
typedef enum {
    PARAM_26_01_TORQUE_REFERENCE_TO = 1, /* 26.01 Torque reference to */
    PARAM_26_02_TORQUE_REFERENCE = 2, /* 26.02 Torque reference */
    PARAM_26_08_MINIMUM_TORQUE_REF = 8, /* 26.08 Minimum torque ref */
    PARAM_26_09_MAXIMUM_TORQUE_REF_DEFINES_THE_MAXIMUM_TORQUE_REFERENCE_ALLOWS_FOR_LOCAL = 9, /* 26.09 Maximum torque ref Defines the maximum torque reference. Allows for local */
    PARAM_26_11_TORQUE_REF1_SOURCE = 11, /* 26.11 Torque ref1 source */
    PARAM_26_12_TORQUE_REF2_SOURCE = 12, /* 26.12 Torque ref2 source */
    PARAM_26_13_TORQUE_REF1_FUNCTION_SELECTS_A_MATHEMATICAL_FUNCTION_BETWEEN_THE_REFERENCE = 13, /* 26.13 Torque ref1 function Selects a mathematical function between the reference */
    PARAM_26_14_TORQUE_REF1_2 = 14, /* 26.14 Torque ref1/2 */
    PARAM_26_15_LOAD_SHARE = 15, /* 26.15 Load share */
    PARAM_26_16_TORQUE_ADDITIVE_1 = 16, /* 26.16 Torque additive 1 */
    PARAM_26_17_TORQUE_REF_FILTER_TIME_DEFINES_A_LOW_PASS_FILTER_TIME_CONSTANT_FOR_THE_TORQUE = 17, /* 26.17 Torque ref filter time Defines a low-pass filter time constant for the torque */
    PARAM_26_18_TORQUE_RAMP_UP = 18, /* 26.18 Torque ramp up */
    PARAM_26_19_TORQUE_RAMP_DOWN = 19, /* 26.19 Torque ramp down */
    PARAM_26_25_TORQUE_ADDITIVE_2 = 25, /* 26.25 Torque additive 2 */
    PARAM_26_26_FORCE_TORQUE_REF = 26, /* 26.26 Force torque ref */
    PARAM_26_41_TORQUE_STEP = 41, /* 26.41 Torque step */
    PARAM_26_42_TORQUE_STEP_ENABLE = 42, /* 26.42 Torque step enable */
    PARAM_26_43_TORQUE_STEP_POINTER = 43, /* 26.43 Torque step pointer */
    PARAM_26_44_TORQUE_STEP_SOURCE = 44, /* 26.44 Torque step source */
    PARAM_26_51_OSCILLATION_DAMPING = 51, /* 26.51 Oscillation damping */
    PARAM_26_52_OSCILLATION_DAMPING = 52, /* 26.52 Oscillation damping */
    PARAM_26_53_OSCILLATION = 53, /* 26.53 Oscillation */
    PARAM_26_55_OSCILLATION_DAMPING = 55, /* 26.55 Oscillation damping */
    PARAM_26_56_OSCILLATION_DAMPING = 56, /* 26.56 Oscillation damping */
    PARAM_26_57_OSCILLATION_DAMPING = 57, /* 26.57 Oscillation damping */
    PARAM_26_58_OSCILLATION_DAMPING = 58, /* 26.58 Oscillation damping */
    PARAM_26_70_TORQUE_REFERENCE = 70, /* 26.70 Torque reference */
    PARAM_26_71_TORQUE_REFERENCE = 71, /* 26.71 Torque reference */
    PARAM_26_72_TORQUE_REFERENCE = 72, /* 26.72 Torque reference */
    PARAM_26_73_TORQUE_REFERENCE = 73, /* 26.73 Torque reference */
    PARAM_26_74_TORQUE_REF_RAMP_OUT_DISPLAYS_THE_TORQUE_REFERENCE_AFTER_LIMITING_AND_RAMPING_SEE = 74, /* 26.74 Torque ref ramp out Displays the torque reference after limiting and ramping. See */
    PARAM_26_75_TORQUE_REFERENCE = 75, /* 26.75 Torque reference */
    PARAM_26_76_TORQUE_REFERENCE = 76, /* 26.76 Torque reference */
    PARAM_26_77_TORQUE_REF_ADD_A = 77, /* 26.77 Torque ref add A */
    PARAM_26_78_TORQUE_REF_ADD_B = 78, /* 26.78 Torque ref add B */
    PARAM_26_81_RUSH_CONTROL_GAIN = 81, /* 26.81 Rush control gain */
    PARAM_26_82_RUSH_CONTROL = 82, /* 26.82 Rush control */
} param_group_26_index_t;

/* ---- Live value storage (group 26) ---- */
typedef struct {
    float p01_torque_reference_to;  /* 26.01 Torque reference to */
    float p02_torque_reference;  /* 26.02 Torque reference */
    float p08_minimum_torque_ref;  /* 26.08 Minimum torque ref */
    float p09_maximum_torque_ref_defines_the_maximum_torque_reference_allows_for_local;  /* 26.09 Maximum torque ref Defines the maximum torque reference. Allows for local */
    float p11_torque_ref1_source;  /* 26.11 Torque ref1 source */
    float p12_torque_ref2_source;  /* 26.12 Torque ref2 source */
    float p13_torque_ref1_function_selects_a_mathematical_function_between_the_reference;  /* 26.13 Torque ref1 function Selects a mathematical function between the reference */
    float p14_torque_ref1_2;  /* 26.14 Torque ref1/2 */
    float p15_load_share;  /* 26.15 Load share */
    float p16_torque_additive_1;  /* 26.16 Torque additive 1 */
    float p17_torque_ref_filter_time_defines_a_low_pass_filter_time_constant_for_the_torque;  /* 26.17 Torque ref filter time Defines a low-pass filter time constant for the torque */
    float p18_torque_ramp_up;  /* 26.18 Torque ramp up */
    float p19_torque_ramp_down;  /* 26.19 Torque ramp down */
    float p25_torque_additive_2;  /* 26.25 Torque additive 2 */
    float p26_force_torque_ref;  /* 26.26 Force torque ref */
    float p41_torque_step;  /* 26.41 Torque step */
    float p42_torque_step_enable;  /* 26.42 Torque step enable */
    float p43_torque_step_pointer;  /* 26.43 Torque step pointer */
    float p44_torque_step_source;  /* 26.44 Torque step source */
    float p51_oscillation_damping;  /* 26.51 Oscillation damping */
    float p52_oscillation_damping;  /* 26.52 Oscillation damping */
    float p53_oscillation;  /* 26.53 Oscillation */
    float p55_oscillation_damping;  /* 26.55 Oscillation damping */
    float p56_oscillation_damping;  /* 26.56 Oscillation damping */
    float p57_oscillation_damping;  /* 26.57 Oscillation damping */
    float p58_oscillation_damping;  /* 26.58 Oscillation damping */
    float p70_torque_reference;  /* 26.70 Torque reference */
    float p71_torque_reference;  /* 26.71 Torque reference */
    float p72_torque_reference;  /* 26.72 Torque reference */
    float p73_torque_reference;  /* 26.73 Torque reference */
    float p74_torque_ref_ramp_out_displays_the_torque_reference_after_limiting_and_ramping_see;  /* 26.74 Torque ref ramp out Displays the torque reference after limiting and ramping. See */
    float p75_torque_reference;  /* 26.75 Torque reference */
    float p76_torque_reference;  /* 26.76 Torque reference */
    float p77_torque_ref_add_a;  /* 26.77 Torque ref add A */
    float p78_torque_ref_add_b;  /* 26.78 Torque ref add B */
    float p81_rush_control_gain;  /* 26.81 Rush control gain */
    float p82_rush_control;  /* 26.82 Rush control */
} param_group_26_t;

extern param_group_26_t g_param_grp26;

void param_grp26_init(void);
void param_grp26_load_defaults(void);
int  param_grp26_get(uint8_t index, float *out_value);
int  param_grp26_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP26_TORQUE_REFERENCE_CHAIN_H */
