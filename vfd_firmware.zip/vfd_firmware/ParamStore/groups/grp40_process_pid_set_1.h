#ifndef VFD_PARAM_GRP40_PROCESS_PID_SET_1_H
#define VFD_PARAM_GRP40_PROCESS_PID_SET_1_H

/* Parameter group 40: Process PID set 1
 * Auto-generated from ACS880 primary control program firmware manual
 * 59 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 40) ---- */
typedef enum {
    PARAM_40_01_PROCESS_PID_OUTPUT = 1, /* 40.01 Process PID output */
    PARAM_40_02_PROCESS_PID = 2, /* 40.02 Process PID */
    PARAM_40_03_PROCESS_PID = 3, /* 40.03 Process PID */
    PARAM_40_04_PROCESS_PID = 4, /* 40.04 Process PID */
    PARAM_40_05_PROCESS_PID_TRIM = 5, /* 40.05 Process PID trim */
    PARAM_40_06_PROCESS_PID_STATUS = 6, /* 40.06 Process PID status */
    PARAM_40_07_SET_1_PID_OPERATION = 7, /* 40.07 Set 1 PID operation */
    PARAM_40_08_SET_1_FEEDBACK_1 = 8, /* 40.08 Set 1 feedback 1 */
    PARAM_40_09_SET_1_FEEDBACK_2 = 9, /* 40.09 Set 1 feedback 2 */
    PARAM_40_10_SET_1_FEEDBACK = 10, /* 40.10 Set 1 feedback */
    PARAM_40_11_SET_1_FEEDBACK_FILTER = 11, /* 40.11 Set 1 feedback filter */
    PARAM_40_12_SET_1_UNIT_SELECTION = 12, /* 40.12 Set 1 unit selection */
    PARAM_40_14_SET_1_SETPOINT = 14, /* 40.14 Set 1 setpoint */
    PARAM_40_15_SET_1_OUTPUT_SCALING_SEE_PARAMETER_40_14_SET_1_SETPOINT_SCALING = 15, /* 40.15 Set 1 output scaling See parameter 40.14 Set 1 setpoint scaling. */
    PARAM_40_16_SET_1_SETPOINT_1 = 16, /* 40.16 Set 1 setpoint 1 */
    PARAM_40_17_SET_1_SETPOINT_2 = 17, /* 40.17 Set 1 setpoint 2 */
    PARAM_40_18_SET_1_SETPOINT = 18, /* 40.18 Set 1 setpoint */
    PARAM_40_19_SET_1_INTERNAL = 19, /* 40.19 Set 1 internal */
    PARAM_40_20_SET_1_INTERNAL = 20, /* 40.20 Set 1 internal */
    PARAM_40_21_SET_1_INTERNAL = 21, /* 40.21 Set 1 internal */
    PARAM_40_22_SET_1_INTERNAL = 22, /* 40.22 Set 1 internal */
    PARAM_40_23_SET_1_INTERNAL = 23, /* 40.23 Set 1 internal */
    PARAM_40_24_SET_1_INTERNAL = 24, /* 40.24 Set 1 internal */
    PARAM_40_25_SET_1_SETPOINT = 25, /* 40.25 Set 1 setpoint */
    PARAM_40_26_SET_1_SETPOINT_MIN = 26, /* 40.26 Set 1 setpoint min */
    PARAM_40_27_SET_1_SETPOINT_MAX = 27, /* 40.27 Set 1 setpoint max */
    PARAM_40_28_SET_1_SETPOINT = 28, /* 40.28 Set 1 setpoint */
    PARAM_40_29_SET_1_SETPOINT = 29, /* 40.29 Set 1 setpoint */
    PARAM_40_30_SET_1_SETPOINT = 30, /* 40.30 Set 1 setpoint */
    PARAM_40_31_SET_1_DEVIATION = 31, /* 40.31 Set 1 deviation */
    PARAM_40_32_SET_1_GAIN = 32, /* 40.32 Set 1 gain */
    PARAM_40_33_SET_1_INTEGRATION = 33, /* 40.33 Set 1 integration */
    PARAM_40_34_SET_1_DERIVATION = 34, /* 40.34 Set 1 derivation */
    PARAM_40_35_SET_1_DERIVATION = 35, /* 40.35 Set 1 derivation */
    PARAM_40_36_SET_1_OUTPUT_MIN = 36, /* 40.36 Set 1 output min */
    PARAM_40_37_SET_1_OUTPUT_MAX = 37, /* 40.37 Set 1 output max */
    PARAM_40_38_SET_1_OUTPUT_FREEZE = 38, /* 40.38 Set 1 output freeze */
    PARAM_40_39_SET_1_DEADBAND = 39, /* 40.39 Set 1 deadband */
    PARAM_40_40_SET_1_DEADBAND = 40, /* 40.40 Set 1 deadband */
    PARAM_40_41_SET_1_SLEEP_MODE = 41, /* 40.41 Set 1 sleep mode */
    PARAM_40_42_SET_1_SLEEP_ENABLE = 42, /* 40.42 Set 1 sleep enable */
    PARAM_40_43_SET_1_SLEEP_LEVEL = 43, /* 40.43 Set 1 sleep level */
    PARAM_40_44_SET_1_SLEEP_DELAY = 44, /* 40.44 Set 1 sleep delay */
    PARAM_40_45_SET_1_SLEEP_BOOST = 45, /* 40.45 Set 1 sleep boost */
    PARAM_40_46_SET_1_SLEEP_BOOST = 46, /* 40.46 Set 1 sleep boost */
    PARAM_40_47_SET_1_WAKE_UP = 47, /* 40.47 Set 1 wake-up */
    PARAM_40_48_SET_1_WAKE_UP = 48, /* 40.48 Set 1 wake-up */
    PARAM_40_49_SET_1_TRACKING_MODE_ACTIVATES_OR_SELECTS_A_SOURCE_THAT_ACTIVATES_TRACKING_MODE_IN = 49, /* 40.49 Set 1 tracking mode Activates (or selects a source that activates) tracking mode. In */
    PARAM_40_50_SET_1_TRACKING_REF = 50, /* 40.50 Set 1 tracking ref */
    PARAM_40_51_SET_1_TRIM_MODE = 51, /* 40.51 Set 1 trim mode */
    PARAM_40_52_SET_1_TRIM_SELECTION = 52, /* 40.52 Set 1 trim selection */
    PARAM_40_53_SET_1_TRIMMED_REF = 53, /* 40.53 Set 1 trimmed ref */
    PARAM_40_54_SET_1_TRIM_MIX = 54, /* 40.54 Set 1 trim mix */
    PARAM_40_55_SET_1_TRIM_ADJUST = 55, /* 40.55 Set 1 trim adjust */
    PARAM_40_56_SET_1_TRIM_SOURCE = 56, /* 40.56 Set 1 trim source */
    PARAM_40_57_PID_SET1_SET2 = 57, /* 40.57 PID set1/set2 */
    PARAM_40_60_SET_1_PID_ACTIVATION = 60, /* 40.60 Set 1 PID activation */
    PARAM_40_91_FEEDBACK_DATA = 91, /* 40.91 Feedback data */
    PARAM_40_92_SETPOINT_DATA = 92, /* 40.92 Setpoint data */
} param_group_40_index_t;

/* ---- Live value storage (group 40) ---- */
typedef struct {
    float p01_process_pid_output;  /* 40.01 Process PID output */
    float p02_process_pid;  /* 40.02 Process PID */
    float p03_process_pid;  /* 40.03 Process PID */
    float p04_process_pid;  /* 40.04 Process PID */
    float p05_process_pid_trim;  /* 40.05 Process PID trim */
    float p06_process_pid_status;  /* 40.06 Process PID status */
    float p07_set_1_pid_operation;  /* 40.07 Set 1 PID operation */
    float p08_set_1_feedback_1;  /* 40.08 Set 1 feedback 1 */
    float p09_set_1_feedback_2;  /* 40.09 Set 1 feedback 2 */
    float p10_set_1_feedback;  /* 40.10 Set 1 feedback */
    float p11_set_1_feedback_filter;  /* 40.11 Set 1 feedback filter */
    float p12_set_1_unit_selection;  /* 40.12 Set 1 unit selection */
    float p14_set_1_setpoint;  /* 40.14 Set 1 setpoint */
    float p15_set_1_output_scaling_see_parameter_40_14_set_1_setpoint_scaling;  /* 40.15 Set 1 output scaling See parameter 40.14 Set 1 setpoint scaling. */
    float p16_set_1_setpoint_1;  /* 40.16 Set 1 setpoint 1 */
    float p17_set_1_setpoint_2;  /* 40.17 Set 1 setpoint 2 */
    float p18_set_1_setpoint;  /* 40.18 Set 1 setpoint */
    float p19_set_1_internal;  /* 40.19 Set 1 internal */
    float p20_set_1_internal;  /* 40.20 Set 1 internal */
    float p21_set_1_internal;  /* 40.21 Set 1 internal */
    float p22_set_1_internal;  /* 40.22 Set 1 internal */
    float p23_set_1_internal;  /* 40.23 Set 1 internal */
    float p24_set_1_internal;  /* 40.24 Set 1 internal */
    float p25_set_1_setpoint;  /* 40.25 Set 1 setpoint */
    float p26_set_1_setpoint_min;  /* 40.26 Set 1 setpoint min */
    float p27_set_1_setpoint_max;  /* 40.27 Set 1 setpoint max */
    float p28_set_1_setpoint;  /* 40.28 Set 1 setpoint */
    float p29_set_1_setpoint;  /* 40.29 Set 1 setpoint */
    float p30_set_1_setpoint;  /* 40.30 Set 1 setpoint */
    float p31_set_1_deviation;  /* 40.31 Set 1 deviation */
    float p32_set_1_gain;  /* 40.32 Set 1 gain */
    float p33_set_1_integration;  /* 40.33 Set 1 integration */
    float p34_set_1_derivation;  /* 40.34 Set 1 derivation */
    float p35_set_1_derivation;  /* 40.35 Set 1 derivation */
    float p36_set_1_output_min;  /* 40.36 Set 1 output min */
    float p37_set_1_output_max;  /* 40.37 Set 1 output max */
    float p38_set_1_output_freeze;  /* 40.38 Set 1 output freeze */
    float p39_set_1_deadband;  /* 40.39 Set 1 deadband */
    float p40_set_1_deadband;  /* 40.40 Set 1 deadband */
    float p41_set_1_sleep_mode;  /* 40.41 Set 1 sleep mode */
    float p42_set_1_sleep_enable;  /* 40.42 Set 1 sleep enable */
    float p43_set_1_sleep_level;  /* 40.43 Set 1 sleep level */
    float p44_set_1_sleep_delay;  /* 40.44 Set 1 sleep delay */
    float p45_set_1_sleep_boost;  /* 40.45 Set 1 sleep boost */
    float p46_set_1_sleep_boost;  /* 40.46 Set 1 sleep boost */
    float p47_set_1_wake_up;  /* 40.47 Set 1 wake-up */
    float p48_set_1_wake_up;  /* 40.48 Set 1 wake-up */
    float p49_set_1_tracking_mode_activates_or_selects_a_source_that_activates_tracking_mode_in;  /* 40.49 Set 1 tracking mode Activates (or selects a source that activates) tracking mode. In */
    float p50_set_1_tracking_ref;  /* 40.50 Set 1 tracking ref */
    float p51_set_1_trim_mode;  /* 40.51 Set 1 trim mode */
    float p52_set_1_trim_selection;  /* 40.52 Set 1 trim selection */
    float p53_set_1_trimmed_ref;  /* 40.53 Set 1 trimmed ref */
    float p54_set_1_trim_mix;  /* 40.54 Set 1 trim mix */
    float p55_set_1_trim_adjust;  /* 40.55 Set 1 trim adjust */
    float p56_set_1_trim_source;  /* 40.56 Set 1 trim source */
    float p57_pid_set1_set2;  /* 40.57 PID set1/set2 */
    float p60_set_1_pid_activation;  /* 40.60 Set 1 PID activation */
    float p91_feedback_data;  /* 40.91 Feedback data */
    float p92_setpoint_data;  /* 40.92 Setpoint data */
} param_group_40_t;

extern param_group_40_t g_param_grp40;

void param_grp40_init(void);
void param_grp40_load_defaults(void);
int  param_grp40_get(uint8_t index, float *out_value);
int  param_grp40_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP40_PROCESS_PID_SET_1_H */
