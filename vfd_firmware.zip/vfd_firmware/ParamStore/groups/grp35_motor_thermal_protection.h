#ifndef VFD_PARAM_GRP35_MOTOR_THERMAL_PROTECTION_H
#define VFD_PARAM_GRP35_MOTOR_THERMAL_PROTECTION_H

/* Parameter group 35: Motor thermal protection
 * Auto-generated from ACS880 primary control program firmware manual
 * 25 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 35) ---- */
typedef enum {
    PARAM_35_01_MOTOR_ESTIMATED = 1, /* 35.01 Motor estimated */
    PARAM_35_02_MEASURED = 2, /* 35.02 Measured */
    PARAM_35_03_MEASURED = 3, /* 35.03 Measured */
    PARAM_35_04_FPTC_STATUS_WORD = 4, /* 35.04 FPTC status word */
    PARAM_35_05_MOTOR_OVERLOAD = 5, /* 35.05 Motor overload */
    PARAM_35_11_TEMPERATURE_1 = 11, /* 35.11 Temperature 1 */
    PARAM_35_12_TEMPERATURE_1_FAULT = 12, /* 35.12 Temperature 1 fault */
    PARAM_35_13_TEMPERATURE_1 = 13, /* 35.13 Temperature 1 */
    PARAM_35_14_TEMPERATURE_1_AI = 14, /* 35.14 Temperature 1 AI */
    PARAM_35_21_TEMPERATURE_2 = 21, /* 35.21 Temperature 2 */
    PARAM_35_22_TEMPERATURE_2_FAULT = 22, /* 35.22 Temperature 2 fault */
    PARAM_35_23_TEMPERATURE_2 = 23, /* 35.23 Temperature 2 */
    PARAM_35_24_TEMPERATURE_2_AI = 24, /* 35.24 Temperature 2 AI */
    PARAM_35_30_FPTC_CONFIGURATION = 30, /* 35.30 FPTC configuration */
    PARAM_35_50_MOTOR_AMBIENT = 50, /* 35.50 Motor ambient */
    PARAM_35_51_MOTOR_LOAD_CURVE = 51, /* 35.51 Motor load curve */
    PARAM_35_52_ZERO_SPEED_LOAD = 52, /* 35.52 Zero speed load */
    PARAM_35_53_BREAK_POINT = 53, /* 35.53 Break point */
    PARAM_35_54_MOTOR_NOMINAL = 54, /* 35.54 Motor nominal */
    PARAM_35_55_MOTOR_THERMAL_TIME = 55, /* 35.55 Motor thermal time */
    PARAM_35_56_MOTOR_OVERLOAD = 56, /* 35.56 Motor overload */
    PARAM_35_57_MOTOR_OVERLOAD = 57, /* 35.57 Motor overload */
    PARAM_35_60_CABLE_TEMPERATURE = 60, /* 35.60 Cable temperature */
    PARAM_35_61_CABLE_NOMINAL = 61, /* 35.61 Cable nominal */
    PARAM_35_62_CABLE_THERMAL_RISE = 62, /* 35.62 Cable thermal rise */
} param_group_35_index_t;

/* ---- Live value storage (group 35) ---- */
typedef struct {
    float p01_motor_estimated;  /* 35.01 Motor estimated */
    float p02_measured;  /* 35.02 Measured */
    float p03_measured;  /* 35.03 Measured */
    float p04_fptc_status_word;  /* 35.04 FPTC status word */
    float p05_motor_overload;  /* 35.05 Motor overload */
    float p11_temperature_1;  /* 35.11 Temperature 1 */
    float p12_temperature_1_fault;  /* 35.12 Temperature 1 fault */
    float p13_temperature_1;  /* 35.13 Temperature 1 */
    float p14_temperature_1_ai;  /* 35.14 Temperature 1 AI */
    float p21_temperature_2;  /* 35.21 Temperature 2 */
    float p22_temperature_2_fault;  /* 35.22 Temperature 2 fault */
    float p23_temperature_2;  /* 35.23 Temperature 2 */
    float p24_temperature_2_ai;  /* 35.24 Temperature 2 AI */
    float p30_fptc_configuration;  /* 35.30 FPTC configuration */
    float p50_motor_ambient;  /* 35.50 Motor ambient */
    float p51_motor_load_curve;  /* 35.51 Motor load curve */
    float p52_zero_speed_load;  /* 35.52 Zero speed load */
    float p53_break_point;  /* 35.53 Break point */
    float p54_motor_nominal;  /* 35.54 Motor nominal */
    float p55_motor_thermal_time;  /* 35.55 Motor thermal time */
    float p56_motor_overload;  /* 35.56 Motor overload */
    float p57_motor_overload;  /* 35.57 Motor overload */
    float p60_cable_temperature;  /* 35.60 Cable temperature */
    float p61_cable_nominal;  /* 35.61 Cable nominal */
    float p62_cable_thermal_rise;  /* 35.62 Cable thermal rise */
} param_group_35_t;

extern param_group_35_t g_param_grp35;

void param_grp35_init(void);
void param_grp35_load_defaults(void);
int  param_grp35_get(uint8_t index, float *out_value);
int  param_grp35_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP35_MOTOR_THERMAL_PROTECTION_H */
