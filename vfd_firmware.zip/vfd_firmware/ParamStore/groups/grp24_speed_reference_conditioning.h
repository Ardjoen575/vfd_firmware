#ifndef VFD_PARAM_GRP24_SPEED_REFERENCE_CONDITIONING_H
#define VFD_PARAM_GRP24_SPEED_REFERENCE_CONDITIONING_H

/* Parameter group 24: Speed reference conditioning
 * Auto-generated from ACS880 primary control program firmware manual
 * 16 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 24) ---- */
typedef enum {
    PARAM_24_01_USED_SPEED = 1, /* 24.01 Used speed */
    PARAM_24_02_USED_SPEED = 2, /* 24.02 Used speed */
    PARAM_24_03_SPEED_ERROR_FILTERED = 3, /* 24.03 Speed error filtered */
    PARAM_24_04_SPEED_ERROR = 4, /* 24.04 Speed error */
    PARAM_24_11_SPEED_CORRECTION = 11, /* 24.11 Speed correction */
    PARAM_24_12_SPEED_ERROR_FILTER = 12, /* 24.12 Speed error filter */
    PARAM_24_13_RFE_SPEED_FILTER = 13, /* 24.13 RFE speed filter */
    PARAM_24_14_FREQUENCY_OF_ZERO = 14, /* 24.14 Frequency of zero */
    PARAM_24_15_DAMPING_OF_ZERO = 15, /* 24.15 Damping of zero */
    PARAM_24_16_FREQUENCY_OF_POLE = 16, /* 24.16 Frequency of pole */
    PARAM_24_17_DAMPING_OF_POLE = 17, /* 24.17 Damping of pole */
    PARAM_24_41_SPEED_ERROR_WINDOW = 41, /* 24.41 Speed error window */
    PARAM_24_42_SPEED_WINDOW = 42, /* 24.42 Speed window */
    PARAM_24_43_SPEED_ERROR_WINDOW = 43, /* 24.43 Speed error window */
    PARAM_24_44_SPEED_ERROR_WINDOW = 44, /* 24.44 Speed error window */
    PARAM_24_46_SPEED_ERROR_STEP = 46, /* 24.46 Speed error step */
} param_group_24_index_t;

/* ---- Live value storage (group 24) ---- */
typedef struct {
    float p01_used_speed;  /* 24.01 Used speed */
    float p02_used_speed;  /* 24.02 Used speed */
    float p03_speed_error_filtered;  /* 24.03 Speed error filtered */
    float p04_speed_error;  /* 24.04 Speed error */
    float p11_speed_correction;  /* 24.11 Speed correction */
    float p12_speed_error_filter;  /* 24.12 Speed error filter */
    float p13_rfe_speed_filter;  /* 24.13 RFE speed filter */
    float p14_frequency_of_zero;  /* 24.14 Frequency of zero */
    float p15_damping_of_zero;  /* 24.15 Damping of zero */
    float p16_frequency_of_pole;  /* 24.16 Frequency of pole */
    float p17_damping_of_pole;  /* 24.17 Damping of pole */
    float p41_speed_error_window;  /* 24.41 Speed error window */
    float p42_speed_window;  /* 24.42 Speed window */
    float p43_speed_error_window;  /* 24.43 Speed error window */
    float p44_speed_error_window;  /* 24.44 Speed error window */
    float p46_speed_error_step;  /* 24.46 Speed error step */
} param_group_24_t;

extern param_group_24_t g_param_grp24;

void param_grp24_init(void);
void param_grp24_load_defaults(void);
int  param_grp24_get(uint8_t index, float *out_value);
int  param_grp24_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP24_SPEED_REFERENCE_CONDITIONING_H */
