#ifndef VFD_PARAM_GRP12_STANDARD_AI_H
#define VFD_PARAM_GRP12_STANDARD_AI_H

/* Parameter group 12: Standard AI
 * Auto-generated from ACS880 primary control program firmware manual
 * 20 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 12) ---- */
typedef enum {
    PARAM_12_01_AI_TUNE = 1, /* 12.01 AI tune */
    PARAM_12_03_AI_SUPERVISION = 3, /* 12.03 AI supervision */
    PARAM_12_04_AI_SUPERVISION = 4, /* 12.04 AI supervision */
    PARAM_12_05_AI_SUPERVISION_FORCE_ACTIVATES_ANALOG_INPUT_SUPERVISION_SEPARATELY_FOR_EACH_CONTROL = 5, /* 12.05 AI supervision force Activates analog input supervision separately for each control */
    PARAM_12_11_AI1_ACTUAL_VALUE = 11, /* 12.11 AI1 actual value */
    PARAM_12_12_AI1_SCALED_VALUE = 12, /* 12.12 AI1 scaled value */
    PARAM_12_15_AI1_UNIT_SELECTION = 15, /* 12.15 AI1 unit selection */
    PARAM_12_16_AI1_FILTER_TIME = 16, /* 12.16 AI1 filter time */
    PARAM_12_17_AI1_MIN = 17, /* 12.17 AI1 min */
    PARAM_12_18_AI1_MAX = 18, /* 12.18 AI1 max */
    PARAM_12_19_AI1_SCALED_AT_AI1 = 19, /* 12.19 AI1 scaled at AI1 */
    PARAM_12_20_AI1_SCALED_AT_AI1 = 20, /* 12.20 AI1 scaled at AI1 */
    PARAM_12_21_AI2_ACTUAL_VALUE = 21, /* 12.21 AI2 actual value */
    PARAM_12_22_AI2_SCALED_VALUE = 22, /* 12.22 AI2 scaled value */
    PARAM_12_25_AI2_UNIT_SELECTION = 25, /* 12.25 AI2 unit selection */
    PARAM_12_26_AI2_FILTER_TIME = 26, /* 12.26 AI2 filter time */
    PARAM_12_27_AI2_MIN = 27, /* 12.27 AI2 min */
    PARAM_12_28_AI2_MAX = 28, /* 12.28 AI2 max */
    PARAM_12_29_AI2_SCALED_AT_AI2 = 29, /* 12.29 AI2 scaled at AI2 */
    PARAM_12_30_AI2_SCALED_AT_AI2 = 30, /* 12.30 AI2 scaled at AI2 */
} param_group_12_index_t;

/* ---- Live value storage (group 12) ---- */
typedef struct {
    float p01_ai_tune;  /* 12.01 AI tune */
    float p03_ai_supervision;  /* 12.03 AI supervision */
    float p04_ai_supervision;  /* 12.04 AI supervision */
    float p05_ai_supervision_force_activates_analog_input_supervision_separately_for_each_control;  /* 12.05 AI supervision force Activates analog input supervision separately for each control */
    float p11_ai1_actual_value;  /* 12.11 AI1 actual value */
    float p12_ai1_scaled_value;  /* 12.12 AI1 scaled value */
    float p15_ai1_unit_selection;  /* 12.15 AI1 unit selection */
    float p16_ai1_filter_time;  /* 12.16 AI1 filter time */
    float p17_ai1_min;  /* 12.17 AI1 min */
    float p18_ai1_max;  /* 12.18 AI1 max */
    float p19_ai1_scaled_at_ai1;  /* 12.19 AI1 scaled at AI1 */
    float p20_ai1_scaled_at_ai1;  /* 12.20 AI1 scaled at AI1 */
    float p21_ai2_actual_value;  /* 12.21 AI2 actual value */
    float p22_ai2_scaled_value;  /* 12.22 AI2 scaled value */
    float p25_ai2_unit_selection;  /* 12.25 AI2 unit selection */
    float p26_ai2_filter_time;  /* 12.26 AI2 filter time */
    float p27_ai2_min;  /* 12.27 AI2 min */
    float p28_ai2_max;  /* 12.28 AI2 max */
    float p29_ai2_scaled_at_ai2;  /* 12.29 AI2 scaled at AI2 */
    float p30_ai2_scaled_at_ai2;  /* 12.30 AI2 scaled at AI2 */
} param_group_12_t;

extern param_group_12_t g_param_grp12;

void param_grp12_init(void);
void param_grp12_load_defaults(void);
int  param_grp12_get(uint8_t index, float *out_value);
int  param_grp12_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP12_STANDARD_AI_H */
