#ifndef VFD_PARAM_GRP90_FEEDBACK_SELECTION_H
#define VFD_PARAM_GRP90_FEEDBACK_SELECTION_H

/* Parameter group 90: Feedback selection
 * Auto-generated from ACS880 primary control program firmware manual
 * 50 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 90) ---- */
typedef enum {
    PARAM_90_01_MOTOR_SPEED_FOR = 1, /* 90.01 Motor speed for */
    PARAM_90_02_MOTOR_POSITION = 2, /* 90.02 Motor position */
    PARAM_90_03_LOAD_SPEED = 3, /* 90.03 Load speed */
    PARAM_90_04_LOAD_POSITION = 4, /* 90.04 Load position */
    PARAM_90_05_LOAD_POSITION = 5, /* 90.05 Load position */
    PARAM_90_06_MOTOR_POSITION = 6, /* 90.06 Motor position */
    PARAM_90_07_LOAD_POSITION = 7, /* 90.07 Load position */
    PARAM_90_10_ENCODER_1_SPEED = 10, /* 90.10 Encoder 1 speed */
    PARAM_90_11_ENCODER_1_POSITION = 11, /* 90.11 Encoder 1 position */
    PARAM_90_12_ENCODER_1_MULTITURN = 12, /* 90.12 Encoder 1 multiturn */
    PARAM_90_13_ENCODER_1 = 13, /* 90.13 Encoder 1 */
    PARAM_90_14_ENCODER_1_POSITION = 14, /* 90.14 Encoder 1 position */
    PARAM_90_15_ENCODER_1 = 15, /* 90.15 Encoder 1 */
    PARAM_90_20_ENCODER_2_SPEED = 20, /* 90.20 Encoder 2 speed */
    PARAM_90_21_ENCODER_2_POSITION = 21, /* 90.21 Encoder 2 position */
    PARAM_90_22_ENCODER_2_MULTITURN = 22, /* 90.22 Encoder 2 multiturn */
    PARAM_90_23_ENCODER_2 = 23, /* 90.23 Encoder 2 */
    PARAM_90_24_ENCODER_2_POSITION = 24, /* 90.24 Encoder 2 position */
    PARAM_90_25_ENCODER_2 = 25, /* 90.25 Encoder 2 */
    PARAM_90_26_MOTOR_REVOLUTION = 26, /* 90.26 Motor revolution */
    PARAM_90_27_LOAD_REVOLUTION = 27, /* 90.27 Load revolution */
    PARAM_90_35_POS_COUNTER_STATUS = 35, /* 90.35 Pos counter status */
    PARAM_90_38_POS_COUNTER = 38, /* 90.38 Pos counter */
    PARAM_90_41_MOTOR_FEEDBACK = 41, /* 90.41 Motor feedback */
    PARAM_90_42_MOTOR_SPEED_FILTER = 42, /* 90.42 Motor speed filter */
    PARAM_90_43_MOTOR_GEAR = 43, /* 90.43 Motor gear */
    PARAM_90_44_MOTOR_GEAR = 44, /* 90.44 Motor gear */
    PARAM_90_45_MOTOR_FEEDBACK = 45, /* 90.45 Motor feedback */
    PARAM_90_46_FORCE_OPEN_LOOP = 46, /* 90.46 Force open loop */
    PARAM_90_48_MOTOR_POSITION_AXIS = 48, /* 90.48 Motor position axis */
    PARAM_90_49_MOTOR_POSITION = 49, /* 90.49 Motor position */
    PARAM_90_51_LOAD_FEEDBACK = 51, /* 90.51 Load feedback */
    PARAM_90_52_LOAD_SPEED_FILTER = 52, /* 90.52 Load speed filter */
    PARAM_90_53_LOAD_GEAR = 53, /* 90.53 Load gear */
    PARAM_90_54_LOAD_GEAR = 54, /* 90.54 Load gear */
    PARAM_90_55_LOAD_FEEDBACK_FAULT = 55, /* 90.55 Load feedback fault */
    PARAM_90_56_LOAD_POSITION_OFFSET = 56, /* 90.56 Load position offset */
    PARAM_90_57_LOAD_POSITION = 57, /* 90.57 Load position */
    PARAM_90_58_POS_COUNTER_INIT = 58, /* 90.58 Pos counter init */
    PARAM_90_59_POS_COUNTER_INIT = 59, /* 90.59 Pos counter init */
    PARAM_90_60_POS_COUNTER_ERROR = 60, /* 90.60 Pos counter error */
    PARAM_90_61_GEAR_NUMERATOR = 61, /* 90.61 Gear numerator */
    PARAM_90_62_GEAR_DENOMINATOR = 62, /* 90.62 Gear denominator */
    PARAM_90_63_FEED_CONSTANT = 63, /* 90.63 Feed constant */
    PARAM_90_64_FEED_CONSTANT = 64, /* 90.64 Feed constant */
    PARAM_90_65_POS_COUNTER_INIT = 65, /* 90.65 Pos counter init */
    PARAM_90_66_POS_COUNTER_INIT = 66, /* 90.66 Pos counter init */
    PARAM_90_67_POS_COUNTER_INIT = 67, /* 90.67 Pos counter init */
    PARAM_90_68_DISABLE_POS_COUNTER = 68, /* 90.68 Disable pos counter */
    PARAM_90_69_RESET_POS_COUNTER = 69, /* 90.69 Reset pos counter */
} param_group_90_index_t;

/* ---- Live value storage (group 90) ---- */
typedef struct {
    float p01_motor_speed_for;  /* 90.01 Motor speed for */
    float p02_motor_position;  /* 90.02 Motor position */
    float p03_load_speed;  /* 90.03 Load speed */
    float p04_load_position;  /* 90.04 Load position */
    float p05_load_position;  /* 90.05 Load position */
    float p06_motor_position;  /* 90.06 Motor position */
    float p07_load_position;  /* 90.07 Load position */
    float p10_encoder_1_speed;  /* 90.10 Encoder 1 speed */
    float p11_encoder_1_position;  /* 90.11 Encoder 1 position */
    float p12_encoder_1_multiturn;  /* 90.12 Encoder 1 multiturn */
    float p13_encoder_1;  /* 90.13 Encoder 1 */
    float p14_encoder_1_position;  /* 90.14 Encoder 1 position */
    float p15_encoder_1;  /* 90.15 Encoder 1 */
    float p20_encoder_2_speed;  /* 90.20 Encoder 2 speed */
    float p21_encoder_2_position;  /* 90.21 Encoder 2 position */
    float p22_encoder_2_multiturn;  /* 90.22 Encoder 2 multiturn */
    float p23_encoder_2;  /* 90.23 Encoder 2 */
    float p24_encoder_2_position;  /* 90.24 Encoder 2 position */
    float p25_encoder_2;  /* 90.25 Encoder 2 */
    float p26_motor_revolution;  /* 90.26 Motor revolution */
    float p27_load_revolution;  /* 90.27 Load revolution */
    float p35_pos_counter_status;  /* 90.35 Pos counter status */
    float p38_pos_counter;  /* 90.38 Pos counter */
    float p41_motor_feedback;  /* 90.41 Motor feedback */
    float p42_motor_speed_filter;  /* 90.42 Motor speed filter */
    float p43_motor_gear;  /* 90.43 Motor gear */
    float p44_motor_gear;  /* 90.44 Motor gear */
    float p45_motor_feedback;  /* 90.45 Motor feedback */
    float p46_force_open_loop;  /* 90.46 Force open loop */
    float p48_motor_position_axis;  /* 90.48 Motor position axis */
    float p49_motor_position;  /* 90.49 Motor position */
    float p51_load_feedback;  /* 90.51 Load feedback */
    float p52_load_speed_filter;  /* 90.52 Load speed filter */
    float p53_load_gear;  /* 90.53 Load gear */
    float p54_load_gear;  /* 90.54 Load gear */
    float p55_load_feedback_fault;  /* 90.55 Load feedback fault */
    float p56_load_position_offset;  /* 90.56 Load position offset */
    float p57_load_position;  /* 90.57 Load position */
    float p58_pos_counter_init;  /* 90.58 Pos counter init */
    float p59_pos_counter_init;  /* 90.59 Pos counter init */
    float p60_pos_counter_error;  /* 90.60 Pos counter error */
    float p61_gear_numerator;  /* 90.61 Gear numerator */
    float p62_gear_denominator;  /* 90.62 Gear denominator */
    float p63_feed_constant;  /* 90.63 Feed constant */
    float p64_feed_constant;  /* 90.64 Feed constant */
    float p65_pos_counter_init;  /* 90.65 Pos counter init */
    float p66_pos_counter_init;  /* 90.66 Pos counter init */
    float p67_pos_counter_init;  /* 90.67 Pos counter init */
    float p68_disable_pos_counter;  /* 90.68 Disable pos counter */
    float p69_reset_pos_counter;  /* 90.69 Reset pos counter */
} param_group_90_t;

extern param_group_90_t g_param_grp90;

void param_grp90_init(void);
void param_grp90_load_defaults(void);
int  param_grp90_get(uint8_t index, float *out_value);
int  param_grp90_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP90_FEEDBACK_SELECTION_H */
