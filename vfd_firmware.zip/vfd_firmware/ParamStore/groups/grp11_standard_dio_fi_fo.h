#ifndef VFD_PARAM_GRP11_STANDARD_DIO_FI_FO_H
#define VFD_PARAM_GRP11_STANDARD_DIO_FI_FO_H

/* Parameter group 11: Standard DIO FI FO
 * Auto-generated from ACS880 primary control program firmware manual
 * 23 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 11) ---- */
typedef enum {
    PARAM_11_01_DIO_STATUS = 1, /* 11.01 DIO status */
    PARAM_11_02_DIO_DELAYED_STATUS = 2, /* 11.02 DIO delayed status */
    PARAM_11_05_DIO1_FUNCTION = 5, /* 11.05 DIO1 function */
    PARAM_11_06_DIO1_OUTPUT_SOURCE = 6, /* 11.06 DIO1 output source */
    PARAM_11_07_DIO1_ON_DELAY = 7, /* 11.07 DIO1 ON delay */
    PARAM_11_08_DIO1_OFF_DELAY = 8, /* 11.08 DIO1 OFF delay */
    PARAM_11_09_DIO2_FUNCTION = 9, /* 11.09 DIO2 function */
    PARAM_11_10_DIO2_OUTPUT_SOURCE = 10, /* 11.10 DIO2 output source */
    PARAM_11_11_DIO2_ON_DELAY = 11, /* 11.11 DIO2 ON delay */
    PARAM_11_12_DIO2_OFF_DELAY = 12, /* 11.12 DIO2 OFF delay */
    PARAM_11_38_FREQ_IN_1_ACTUAL = 38, /* 11.38 Freq in 1 actual */
    PARAM_11_39_FREQ_IN_1_SCALED = 39, /* 11.39 Freq in 1 scaled */
    PARAM_11_42_FREQ_IN_1_MIN = 42, /* 11.42 Freq in 1 min */
    PARAM_11_43_FREQ_IN_1_MAX = 43, /* 11.43 Freq in 1 max */
    PARAM_11_44_FREQ_IN_1_AT_SCALED = 44, /* 11.44 Freq in 1 at scaled */
    PARAM_11_45_FREQ_IN_1_AT_SCALED = 45, /* 11.45 Freq in 1 at scaled */
    PARAM_11_54_FREQ_OUT_1_ACTUAL = 54, /* 11.54 Freq out 1 actual */
    PARAM_11_55_FREQ_OUT_1_SOURCE = 55, /* 11.55 Freq out 1 source */
    PARAM_11_58_FREQ_OUT_1_SRC_MIN = 58, /* 11.58 Freq out 1 src min */
    PARAM_11_59_FREQ_OUT_1_SRC_MAX = 59, /* 11.59 Freq out 1 src max */
    PARAM_11_60_FREQ_OUT_1_AT_SRC = 60, /* 11.60 Freq out 1 at src */
    PARAM_11_61_FREQ_OUT_1_AT_SRC = 61, /* 11.61 Freq out 1 at src */
    PARAM_11_81_DIO_FILTER_TIME = 81, /* 11.81 DIO filter time */
} param_group_11_index_t;

/* ---- Live value storage (group 11) ---- */
typedef struct {
    float p01_dio_status;  /* 11.01 DIO status */
    float p02_dio_delayed_status;  /* 11.02 DIO delayed status */
    float p05_dio1_function;  /* 11.05 DIO1 function */
    float p06_dio1_output_source;  /* 11.06 DIO1 output source */
    float p07_dio1_on_delay;  /* 11.07 DIO1 ON delay */
    float p08_dio1_off_delay;  /* 11.08 DIO1 OFF delay */
    float p09_dio2_function;  /* 11.09 DIO2 function */
    float p10_dio2_output_source;  /* 11.10 DIO2 output source */
    float p11_dio2_on_delay;  /* 11.11 DIO2 ON delay */
    float p12_dio2_off_delay;  /* 11.12 DIO2 OFF delay */
    float p38_freq_in_1_actual;  /* 11.38 Freq in 1 actual */
    float p39_freq_in_1_scaled;  /* 11.39 Freq in 1 scaled */
    float p42_freq_in_1_min;  /* 11.42 Freq in 1 min */
    float p43_freq_in_1_max;  /* 11.43 Freq in 1 max */
    float p44_freq_in_1_at_scaled;  /* 11.44 Freq in 1 at scaled */
    float p45_freq_in_1_at_scaled;  /* 11.45 Freq in 1 at scaled */
    float p54_freq_out_1_actual;  /* 11.54 Freq out 1 actual */
    float p55_freq_out_1_source;  /* 11.55 Freq out 1 source */
    float p58_freq_out_1_src_min;  /* 11.58 Freq out 1 src min */
    float p59_freq_out_1_src_max;  /* 11.59 Freq out 1 src max */
    float p60_freq_out_1_at_src;  /* 11.60 Freq out 1 at src */
    float p61_freq_out_1_at_src;  /* 11.61 Freq out 1 at src */
    float p81_dio_filter_time;  /* 11.81 DIO filter time */
} param_group_11_t;

extern param_group_11_t g_param_grp11;

void param_grp11_init(void);
void param_grp11_load_defaults(void);
int  param_grp11_get(uint8_t index, float *out_value);
int  param_grp11_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP11_STANDARD_DIO_FI_FO_H */
