#ifndef VFD_PARAM_GRP60_DDCS_COMMUNICATION_H
#define VFD_PARAM_GRP60_DDCS_COMMUNICATION_H

/* Parameter group 60: DDCS communication
 * Auto-generated from ACS880 primary control program firmware manual
 * 43 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 60) ---- */
typedef enum {
    PARAM_60_01_M_F_COMMUNICATION = 1, /* 60.01 M/F communication */
    PARAM_60_02_M_F_NODE_ADDRESS = 2, /* 60.02 M/F node address */
    PARAM_60_03_M_F_MODE = 3, /* 60.03 M/F mode */
    PARAM_60_05_M_F_HW_CONNECTION_SELECTS_THE_TOPOLOGY_OF_THE_MASTER_FOLLOWER_LINK = 5, /* 60.05 M/F HW connection Selects the topology of the master/follower link. */
    PARAM_60_07_M_F_LINK_CONTROL = 7, /* 60.07 M/F link control */
    PARAM_60_08_M_F_COMM_LOSS = 8, /* 60.08 M/F comm loss */
    PARAM_60_09_M_F_COMM_LOSS = 9, /* 60.09 M/F comm loss */
    PARAM_60_10_M_F_REF1_TYPE = 10, /* 60.10 M/F ref1 type */
    PARAM_60_11_M_F_REF2_TYPE = 11, /* 60.11 M/F ref2 type */
    PARAM_60_12_M_F_ACT1_TYPE = 12, /* 60.12 M/F act1 type */
    PARAM_60_13_M_F_ACT2_TYPE = 13, /* 60.13 M/F act2 type */
    PARAM_60_14_M_F_FOLLOWER = 14, /* 60.14 M/F follower */
    PARAM_60_15_FORCE_MASTER = 15, /* 60.15 Force master */
    PARAM_60_16_FORCE_FOLLOWER = 16, /* 60.16 Force follower */
    PARAM_60_17_FOLLOWER_FAULT_ACTION_EFFECTIVE_IN_THE_MASTER_ONLY_SELECTS_HOW_THE_DRIVE_REACTS_TO_A = 17, /* 60.17 Follower fault action (Effective in the master only.) Selects how the drive reacts to a */
    PARAM_60_18_FOLLOWER_ENABLE = 18, /* 60.18 Follower enable */
    PARAM_60_19_M_F_COMM = 19, /* 60.19 M/F comm */
    PARAM_60_20_M_F_COMM = 20, /* 60.20 M/F comm */
    PARAM_60_23_M_F_STATUS = 23, /* 60.23 M/F status */
    PARAM_60_24_M_F_STATUS = 24, /* 60.24 M/F status */
    PARAM_60_27_M_F_STATUS_SUPV = 27, /* 60.27 M/F status supv */
    PARAM_60_28_M_F_STATUS_SUPV = 28, /* 60.28 M/F status supv */
    PARAM_60_31_M_F_WAKE_UP_DELAY = 31, /* 60.31 M/F wake up delay */
    PARAM_60_32_M_F_COMM = 32, /* 60.32 M/F comm */
    PARAM_60_41_EXTENSION_ADAPTER = 41, /* 60.41 Extension adapter */
    PARAM_60_50_DDCS_CONTROLLER = 50, /* 60.50 DDCS controller */
    PARAM_60_51_DDCS_CONTROLLER = 51, /* 60.51 DDCS controller */
    PARAM_60_52_DDCS_CONTROLLER = 52, /* 60.52 DDCS controller */
    PARAM_60_55_DDCS_CONTROLLER = 55, /* 60.55 DDCS controller */
    PARAM_60_56_DDCS_CONTROLLER = 56, /* 60.56 DDCS controller */
    PARAM_60_57_DDCS_CONTROLLER = 57, /* 60.57 DDCS controller */
    PARAM_60_58_DDCS_CONTROLLER = 58, /* 60.58 DDCS controller */
    PARAM_60_59_DDCS_CONTROLLER = 59, /* 60.59 DDCS controller */
    PARAM_60_60_DDCS_CONTROLLER = 60, /* 60.60 DDCS controller */
    PARAM_60_61_DDCS_CONTROLLER = 61, /* 60.61 DDCS controller */
    PARAM_60_62_DDCS_CONTROLLER = 62, /* 60.62 DDCS controller */
    PARAM_60_63_DDCS_CONTROLLER = 63, /* 60.63 DDCS controller */
    PARAM_60_64_MAILBOX_DATASET = 64, /* 60.64 Mailbox dataset */
    PARAM_60_65_DDCS_CONTROLLER = 65, /* 60.65 DDCS controller */
    PARAM_60_71_INU_LSU = 71, /* 60.71 INU-LSU */
    PARAM_60_77_INU_LSU_LINK = 77, /* 60.77 INU-LSU link */
    PARAM_60_78_INU_LSU_COMM = 78, /* 60.78 INU-LSU comm */
    PARAM_60_79_INU_LSU_COMM = 79, /* 60.79 INU-LSU comm */
} param_group_60_index_t;

/* ---- Live value storage (group 60) ---- */
typedef struct {
    float p01_m_f_communication;  /* 60.01 M/F communication */
    float p02_m_f_node_address;  /* 60.02 M/F node address */
    float p03_m_f_mode;  /* 60.03 M/F mode */
    float p05_m_f_hw_connection_selects_the_topology_of_the_master_follower_link;  /* 60.05 M/F HW connection Selects the topology of the master/follower link. */
    float p07_m_f_link_control;  /* 60.07 M/F link control */
    float p08_m_f_comm_loss;  /* 60.08 M/F comm loss */
    float p09_m_f_comm_loss;  /* 60.09 M/F comm loss */
    float p10_m_f_ref1_type;  /* 60.10 M/F ref1 type */
    float p11_m_f_ref2_type;  /* 60.11 M/F ref2 type */
    float p12_m_f_act1_type;  /* 60.12 M/F act1 type */
    float p13_m_f_act2_type;  /* 60.13 M/F act2 type */
    float p14_m_f_follower;  /* 60.14 M/F follower */
    float p15_force_master;  /* 60.15 Force master */
    float p16_force_follower;  /* 60.16 Force follower */
    float p17_follower_fault_action_effective_in_the_master_only_selects_how_the_drive_reacts_to_a;  /* 60.17 Follower fault action (Effective in the master only.) Selects how the drive reacts to a */
    float p18_follower_enable;  /* 60.18 Follower enable */
    float p19_m_f_comm;  /* 60.19 M/F comm */
    float p20_m_f_comm;  /* 60.20 M/F comm */
    float p23_m_f_status;  /* 60.23 M/F status */
    float p24_m_f_status;  /* 60.24 M/F status */
    float p27_m_f_status_supv;  /* 60.27 M/F status supv */
    float p28_m_f_status_supv;  /* 60.28 M/F status supv */
    float p31_m_f_wake_up_delay;  /* 60.31 M/F wake up delay */
    float p32_m_f_comm;  /* 60.32 M/F comm */
    float p41_extension_adapter;  /* 60.41 Extension adapter */
    float p50_ddcs_controller;  /* 60.50 DDCS controller */
    float p51_ddcs_controller;  /* 60.51 DDCS controller */
    float p52_ddcs_controller;  /* 60.52 DDCS controller */
    float p55_ddcs_controller;  /* 60.55 DDCS controller */
    float p56_ddcs_controller;  /* 60.56 DDCS controller */
    float p57_ddcs_controller;  /* 60.57 DDCS controller */
    float p58_ddcs_controller;  /* 60.58 DDCS controller */
    float p59_ddcs_controller;  /* 60.59 DDCS controller */
    float p60_ddcs_controller;  /* 60.60 DDCS controller */
    float p61_ddcs_controller;  /* 60.61 DDCS controller */
    float p62_ddcs_controller;  /* 60.62 DDCS controller */
    float p63_ddcs_controller;  /* 60.63 DDCS controller */
    float p64_mailbox_dataset;  /* 60.64 Mailbox dataset */
    float p65_ddcs_controller;  /* 60.65 DDCS controller */
    float p71_inu_lsu;  /* 60.71 INU-LSU */
    float p77_inu_lsu_link;  /* 60.77 INU-LSU link */
    float p78_inu_lsu_comm;  /* 60.78 INU-LSU comm */
    float p79_inu_lsu_comm;  /* 60.79 INU-LSU comm */
} param_group_60_t;

extern param_group_60_t g_param_grp60;

void param_grp60_init(void);
void param_grp60_load_defaults(void);
int  param_grp60_get(uint8_t index, float *out_value);
int  param_grp60_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP60_DDCS_COMMUNICATION_H */
