#ifndef VFD_PARAM_GRP05_DIAGNOSTICS_H
#define VFD_PARAM_GRP05_DIAGNOSTICS_H

/* Parameter group 05: Diagnostics
 * Auto-generated from ACS880 primary control program firmware manual
 * 8 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 05) ---- */
typedef enum {
    PARAM_05_01_ON_TIME_COUNTER = 1, /* 05.01 On-time counter */
    PARAM_05_02_RUN_TIME_COUNTER = 2, /* 05.02 Run-time counter */
    PARAM_05_04_FAN_ON_TIME = 4, /* 05.04 Fan on-time */
    PARAM_05_09_TIME_FROM_POWER_UP_500_MICROSECOND_TICKS_ELAPSED_SINCE_THE_LAST_BOOT_OF_THE = 9, /* 05.09 Time from power-up 500-microsecond ticks elapsed since the last boot of the */
    PARAM_05_11_INVERTER = 11, /* 05.11 Inverter */
    PARAM_05_22_DIAGNOSTIC_WORD_3 = 22, /* 05.22 Diagnostic word 3 */
    PARAM_05_41_MAIN_FAN_SERVICE = 41, /* 05.41 Main fan service */
    PARAM_05_42_AUX_FAN_SERVICE = 42, /* 05.42 Aux. fan service */
} param_group_05_index_t;

/* ---- Live value storage (group 05) ---- */
typedef struct {
    float p01_on_time_counter;  /* 05.01 On-time counter */
    float p02_run_time_counter;  /* 05.02 Run-time counter */
    float p04_fan_on_time;  /* 05.04 Fan on-time */
    float p09_time_from_power_up_500_microsecond_ticks_elapsed_since_the_last_boot_of_the;  /* 05.09 Time from power-up 500-microsecond ticks elapsed since the last boot of the */
    float p11_inverter;  /* 05.11 Inverter */
    float p22_diagnostic_word_3;  /* 05.22 Diagnostic word 3 */
    float p41_main_fan_service;  /* 05.41 Main fan service */
    float p42_aux_fan_service;  /* 05.42 Aux. fan service */
} param_group_05_t;

extern param_group_05_t g_param_grp05;

void param_grp05_init(void);
void param_grp05_load_defaults(void);
int  param_grp05_get(uint8_t index, float *out_value);
int  param_grp05_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP05_DIAGNOSTICS_H */
