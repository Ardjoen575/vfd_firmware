#ifndef VFD_PARAM_GRP92_ENCODER_1_CONFIGURATION_H
#define VFD_PARAM_GRP92_ENCODER_1_CONFIGURATION_H

/* Parameter group 92: Encoder 1 configuration
 * Auto-generated from ACS880 primary control program firmware manual
 * 25 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 92) ---- */
typedef enum {
    PARAM_92_01_ENCODER_1_TYPE = 1, /* 92.01 Encoder 1 type */
    PARAM_92_02_ENCODER_1_SOURCE = 2, /* 92.02 Encoder 1 source */
    PARAM_92_10_PULSES_REVOLUTION = 10, /* 92.10 Pulses/revolution */
    PARAM_92_11_PULSE_ENCODER_TYPE = 11, /* 92.11 Pulse encoder type */
    PARAM_92_12_SPEED_CALCULATION = 12, /* 92.12 Speed calculation */
    PARAM_92_13_POSITION_ESTIMATION = 13, /* 92.13 Position estimation */
    PARAM_92_14_SPEED_ESTIMATION = 14, /* 92.14 Speed estimation */
    PARAM_92_15_TRANSIENT_FILTER = 15, /* 92.15 Transient filter */
    PARAM_92_17_ACCEPTED_PULSE_FREQ = 17, /* 92.17 Accepted pulse freq */
    PARAM_92_21_ENCODER_CABLE_FAULT = 21, /* 92.21 Encoder cable fault */
    PARAM_92_23_MAXIMUM_PULSE = 23, /* 92.23 Maximum pulse */
    PARAM_92_24_PULSE_EDGE_FILTERING = 24, /* 92.24 Pulse edge filtering */
    PARAM_92_25_PULSE = 25, /* 92.25 Pulse */
    PARAM_92_30_SERIAL_LINK_MODE = 30, /* 92.30 Serial link mode */
    PARAM_92_31_ENDAT_MAX = 31, /* 92.31 EnDat max */
    PARAM_92_32_SSI_CYCLE_TIME = 32, /* 92.32 SSI cycle time */
    PARAM_92_33_SSI_CLOCK_CYCLES = 33, /* 92.33 SSI clock cycles */
    PARAM_92_34_SSI_POSITION_MSB = 34, /* 92.34 SSI position msb */
    PARAM_92_35_SSI_REVOLUTION_MSB = 35, /* 92.35 SSI revolution msb */
    PARAM_92_36_SSI_DATA_FORMAT = 36, /* 92.36 SSI data format */
    PARAM_92_37_SSI_BAUD_RATE = 37, /* 92.37 SSI baud rate */
    PARAM_92_40_SSI_ZERO_PHASE = 40, /* 92.40 SSI zero phase */
    PARAM_92_45_HIPERFACE_PARITY = 45, /* 92.45 Hiperface parity */
    PARAM_92_46_HIPERFACE_BAUD_RATE_VISIBLE_WHEN_AN_ABSOLUTE_ENCODER_IS_SELECTED = 46, /* 92.46 Hiperface baud rate (Visible when an absolute encoder is selected) */
    PARAM_92_47_HIPERFACE_NODE = 47, /* 92.47 Hiperface node */
} param_group_92_index_t;

/* ---- Live value storage (group 92) ---- */
typedef struct {
    float p01_encoder_1_type;  /* 92.01 Encoder 1 type */
    float p02_encoder_1_source;  /* 92.02 Encoder 1 source */
    float p10_pulses_revolution;  /* 92.10 Pulses/revolution */
    float p11_pulse_encoder_type;  /* 92.11 Pulse encoder type */
    float p12_speed_calculation;  /* 92.12 Speed calculation */
    float p13_position_estimation;  /* 92.13 Position estimation */
    float p14_speed_estimation;  /* 92.14 Speed estimation */
    float p15_transient_filter;  /* 92.15 Transient filter */
    float p17_accepted_pulse_freq;  /* 92.17 Accepted pulse freq */
    float p21_encoder_cable_fault;  /* 92.21 Encoder cable fault */
    float p23_maximum_pulse;  /* 92.23 Maximum pulse */
    float p24_pulse_edge_filtering;  /* 92.24 Pulse edge filtering */
    float p25_pulse;  /* 92.25 Pulse */
    float p30_serial_link_mode;  /* 92.30 Serial link mode */
    float p31_endat_max;  /* 92.31 EnDat max */
    float p32_ssi_cycle_time;  /* 92.32 SSI cycle time */
    float p33_ssi_clock_cycles;  /* 92.33 SSI clock cycles */
    float p34_ssi_position_msb;  /* 92.34 SSI position msb */
    float p35_ssi_revolution_msb;  /* 92.35 SSI revolution msb */
    float p36_ssi_data_format;  /* 92.36 SSI data format */
    float p37_ssi_baud_rate;  /* 92.37 SSI baud rate */
    float p40_ssi_zero_phase;  /* 92.40 SSI zero phase */
    float p45_hiperface_parity;  /* 92.45 Hiperface parity */
    float p46_hiperface_baud_rate_visible_when_an_absolute_encoder_is_selected;  /* 92.46 Hiperface baud rate (Visible when an absolute encoder is selected) */
    float p47_hiperface_node;  /* 92.47 Hiperface node */
} param_group_92_t;

extern param_group_92_t g_param_grp92;

void param_grp92_init(void);
void param_grp92_load_defaults(void);
int  param_grp92_get(uint8_t index, float *out_value);
int  param_grp92_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP92_ENCODER_1_CONFIGURATION_H */
