#ifndef VFD_PARAM_GRP61_D2D_AND_DDCS_TRANSMIT_H
#define VFD_PARAM_GRP61_D2D_AND_DDCS_TRANSMIT_H

/* Parameter group 61: D2D and DDCS transmit
 * Auto-generated from ACS880 primary control program firmware manual
 * 18 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 61) ---- */
typedef enum {
    PARAM_61_01_M_F_DATA_1 = 1, /* 61.01 M/F data 1 */
    PARAM_61_02_M_F_DATA_2 = 2, /* 61.02 M/F data 2 */
    PARAM_61_03_M_F_DATA_3 = 3, /* 61.03 M/F data 3 */
    PARAM_61_25_M_F_DATA_1_VALUE = 25, /* 61.25 M/F data 1 value */
    PARAM_61_26_M_F_DATA_2_VALUE = 26, /* 61.26 M/F data 2 value */
    PARAM_61_27_M_F_DATA_3_VALUE = 27, /* 61.27 M/F data 3 value */
    PARAM_61_45_DATA_SET_2_DATA_1 = 45, /* 61.45 Data set 2 data 1 */
    PARAM_61_46_DATA_SET_2_DATA_2 = 46, /* 61.46 Data set 2 data 2 */
    PARAM_61_47_DATA_SET_2_DATA_3 = 47, /* 61.47 Data set 2 data 3 */
    PARAM_61_50_DATA_SET_4_DATA_3 = 50, /* 61.50 Data set 4 data 3 */
    PARAM_61_51_DATA_SET_11_DATA_1 = 51, /* 61.51 Data set 11 data 1 */
    PARAM_61_52_DATA_SET_11_DATA_2 = 52, /* 61.52 Data set 11 data 2 */
    PARAM_61_53_DATA_SET_11_DATA_3 = 53, /* 61.53 Data set 11 data 3 */
    PARAM_61_54_DATA_SET_13_DATA_1 = 54, /* 61.54 Data set 13 data 1 */
    PARAM_61_74_DATA_SET_25_DATA_3 = 74, /* 61.74 Data set 25 data 3 */
    PARAM_61_95_DATA_SET_2_DATA_1 = 95, /* 61.95 Data set 2 data 1 */
    PARAM_61_96_DATA_SET_2_DATA_2 = 96, /* 61.96 Data set 2 data 2 */
    PARAM_61_97_DATA_SET_2_DATA_3 = 97, /* 61.97 Data set 2 data 3 */
} param_group_61_index_t;

/* ---- Live value storage (group 61) ---- */
typedef struct {
    float p01_m_f_data_1;  /* 61.01 M/F data 1 */
    float p02_m_f_data_2;  /* 61.02 M/F data 2 */
    float p03_m_f_data_3;  /* 61.03 M/F data 3 */
    float p25_m_f_data_1_value;  /* 61.25 M/F data 1 value */
    float p26_m_f_data_2_value;  /* 61.26 M/F data 2 value */
    float p27_m_f_data_3_value;  /* 61.27 M/F data 3 value */
    float p45_data_set_2_data_1;  /* 61.45 Data set 2 data 1 */
    float p46_data_set_2_data_2;  /* 61.46 Data set 2 data 2 */
    float p47_data_set_2_data_3;  /* 61.47 Data set 2 data 3 */
    float p50_data_set_4_data_3;  /* 61.50 Data set 4 data 3 */
    float p51_data_set_11_data_1;  /* 61.51 Data set 11 data 1 */
    float p52_data_set_11_data_2;  /* 61.52 Data set 11 data 2 */
    float p53_data_set_11_data_3;  /* 61.53 Data set 11 data 3 */
    float p54_data_set_13_data_1;  /* 61.54 Data set 13 data 1 */
    float p74_data_set_25_data_3;  /* 61.74 Data set 25 data 3 */
    float p95_data_set_2_data_1;  /* 61.95 Data set 2 data 1 */
    float p96_data_set_2_data_2;  /* 61.96 Data set 2 data 2 */
    float p97_data_set_2_data_3;  /* 61.97 Data set 2 data 3 */
} param_group_61_t;

extern param_group_61_t g_param_grp61;

void param_grp61_init(void);
void param_grp61_load_defaults(void);
int  param_grp61_get(uint8_t index, float *out_value);
int  param_grp61_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP61_D2D_AND_DDCS_TRANSMIT_H */
