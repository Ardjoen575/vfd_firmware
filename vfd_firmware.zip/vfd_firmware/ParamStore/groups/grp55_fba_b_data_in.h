#ifndef VFD_PARAM_GRP55_FBA_B_DATA_IN_H
#define VFD_PARAM_GRP55_FBA_B_DATA_IN_H

/* Parameter group 55: FBA B data in
 * Auto-generated from ACS880 primary control program firmware manual
 * 2 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 55) ---- */
typedef enum {
    PARAM_55_01_FBA_B_DATA_IN1 = 1, /* 55.01 FBA B data in1 */
    PARAM_55_12_FBA_B_DATA_IN12 = 12, /* 55.12 FBA B data in12 */
} param_group_55_index_t;

/* ---- Live value storage (group 55) ---- */
typedef struct {
    float p01_fba_b_data_in1;  /* 55.01 FBA B data in1 */
    float p12_fba_b_data_in12;  /* 55.12 FBA B data in12 */
} param_group_55_t;

extern param_group_55_t g_param_grp55;

void param_grp55_init(void);
void param_grp55_load_defaults(void);
int  param_grp55_get(uint8_t index, float *out_value);
int  param_grp55_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP55_FBA_B_DATA_IN_H */
