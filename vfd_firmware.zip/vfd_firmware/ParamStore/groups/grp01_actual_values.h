#ifndef VFD_PARAM_GRP01_ACTUAL_VALUES_H
#define VFD_PARAM_GRP01_ACTUAL_VALUES_H

/* Parameter group 01: Actual values
 * Auto-generated from ACS880 primary control program firmware manual
 * 43 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 01) ---- */
typedef enum {
    PARAM_01_01_MOTOR_SPEED_USED = 1, /* 01.01 Motor speed used */
    PARAM_01_02_MOTOR_SPEED = 2, /* 01.02 Motor speed */
    PARAM_01_03_MOTOR_SPEED = 3, /* 01.03 Motor speed % */
    PARAM_01_04_ENCODER_1_SPEED = 4, /* 01.04 Encoder 1 speed */
    PARAM_01_05_ENCODER_2_SPEED = 5, /* 01.05 Encoder 2 speed */
    PARAM_01_06_OUTPUT_FREQUENCY = 6, /* 01.06 Output frequency */
    PARAM_01_07_MOTOR_CURRENT = 7, /* 01.07 Motor current */
    PARAM_01_08_MOTOR_CURRENT_OF = 8, /* 01.08 Motor current % of */
    PARAM_01_10_MOTOR_TORQUE = 10, /* 01.10 Motor torque */
    PARAM_01_11_DC_VOLTAGE = 11, /* 01.11 DC voltage */
    PARAM_01_13_OUTPUT_VOLTAGE = 13, /* 01.13 Output voltage */
    PARAM_01_14_OUTPUT_POWER = 14, /* 01.14 Output power */
    PARAM_01_15_OUTPUT_POWER_OF = 15, /* 01.15 Output power % of */
    PARAM_01_17_MOTOR_SHAFT_POWER = 17, /* 01.17 Motor shaft power */
    PARAM_01_18_INVERTER_GWH = 18, /* 01.18 Inverter GWh */
    PARAM_01_19_INVERTER_MWH = 19, /* 01.19 Inverter MWh */
    PARAM_01_20_INVERTER_KWH = 20, /* 01.20 Inverter kWh */
    PARAM_01_21_U_PHASE_CURRENT = 21, /* 01.21 U-phase current */
    PARAM_01_22_V_PHASE_CURRENT = 22, /* 01.22 V-phase current */
    PARAM_01_23_W_PHASE_CURRENT = 23, /* 01.23 W-phase current */
    PARAM_01_24_FLUX_ACTUAL = 24, /* 01.24 Flux actual % */
    PARAM_01_25_INU_MOMENTARY_COS = 25, /* 01.25 INU momentary cos */
    PARAM_01_29_SPEED_CHANGE_RATE = 29, /* 01.29 Speed change rate */
    PARAM_01_30_NOMINAL_TORQUE = 30, /* 01.30 Nominal torque */
    PARAM_01_31_AMBIENT = 31, /* 01.31 Ambient */
    PARAM_01_32_INVERTER_GWH = 32, /* 01.32 Inverter GWh */
    PARAM_01_33_INVERTER_MWH = 33, /* 01.33 Inverter MWh */
    PARAM_01_34_INVERTER_KWH = 34, /* 01.34 Inverter kWh */
    PARAM_01_35_MOT_REGEN_ENERGY = 35, /* 01.35 Mot - regen energy */
    PARAM_01_36_MOT_REGEN_ENERGY = 36, /* 01.36 Mot - regen energy */
    PARAM_01_37_MOT_REGEN_ENERGY = 37, /* 01.37 Mot - regen energy */
    PARAM_01_61_ABS_MOTOR_SPEED = 61, /* 01.61 Abs motor speed */
    PARAM_01_62_ABS_MOTOR_SPEED = 62, /* 01.62 Abs motor speed % */
    PARAM_01_63_ABS_OUTPUT = 63, /* 01.63 Abs output */
    PARAM_01_64_ABS_MOTOR_TORQUE = 64, /* 01.64 Abs motor torque */
    PARAM_01_65_ABS_OUTPUT_POWER = 65, /* 01.65 Abs output power */
    PARAM_01_66_ABS_OUTPUT_POWER = 66, /* 01.66 Abs output power % */
    PARAM_01_68_ABS_MOTOR_SHAFT = 68, /* 01.68 Abs motor shaft */
    PARAM_01_70_AMBIENT = 70, /* 01.70 Ambient */
    PARAM_01_71_STEP_UP_MOTOR = 71, /* 01.71 Step-up motor */
    PARAM_01_72_U_PHASE_RMS = 72, /* 01.72 U-phase RMS */
    PARAM_01_73_V_PHASE_RMS = 73, /* 01.73 V-phase RMS */
    PARAM_01_74_W_PHASE_RMS = 74, /* 01.74 W-phase RMS */
} param_group_01_index_t;

/* ---- Live value storage (group 01) ---- */
typedef struct {
    float p01_motor_speed_used;  /* 01.01 Motor speed used */
    float p02_motor_speed;  /* 01.02 Motor speed */
    float p03_motor_speed;  /* 01.03 Motor speed % */
    float p04_encoder_1_speed;  /* 01.04 Encoder 1 speed */
    float p05_encoder_2_speed;  /* 01.05 Encoder 2 speed */
    float p06_output_frequency;  /* 01.06 Output frequency */
    float p07_motor_current;  /* 01.07 Motor current */
    float p08_motor_current_of;  /* 01.08 Motor current % of */
    float p10_motor_torque;  /* 01.10 Motor torque */
    float p11_dc_voltage;  /* 01.11 DC voltage */
    float p13_output_voltage;  /* 01.13 Output voltage */
    float p14_output_power;  /* 01.14 Output power */
    float p15_output_power_of;  /* 01.15 Output power % of */
    float p17_motor_shaft_power;  /* 01.17 Motor shaft power */
    float p18_inverter_gwh;  /* 01.18 Inverter GWh */
    float p19_inverter_mwh;  /* 01.19 Inverter MWh */
    float p20_inverter_kwh;  /* 01.20 Inverter kWh */
    float p21_u_phase_current;  /* 01.21 U-phase current */
    float p22_v_phase_current;  /* 01.22 V-phase current */
    float p23_w_phase_current;  /* 01.23 W-phase current */
    float p24_flux_actual;  /* 01.24 Flux actual % */
    float p25_inu_momentary_cos;  /* 01.25 INU momentary cos */
    float p29_speed_change_rate;  /* 01.29 Speed change rate */
    float p30_nominal_torque;  /* 01.30 Nominal torque */
    float p31_ambient;  /* 01.31 Ambient */
    float p32_inverter_gwh;  /* 01.32 Inverter GWh */
    float p33_inverter_mwh;  /* 01.33 Inverter MWh */
    float p34_inverter_kwh;  /* 01.34 Inverter kWh */
    float p35_mot_regen_energy;  /* 01.35 Mot - regen energy */
    float p36_mot_regen_energy;  /* 01.36 Mot - regen energy */
    float p37_mot_regen_energy;  /* 01.37 Mot - regen energy */
    float p61_abs_motor_speed;  /* 01.61 Abs motor speed */
    float p62_abs_motor_speed;  /* 01.62 Abs motor speed % */
    float p63_abs_output;  /* 01.63 Abs output */
    float p64_abs_motor_torque;  /* 01.64 Abs motor torque */
    float p65_abs_output_power;  /* 01.65 Abs output power */
    float p66_abs_output_power;  /* 01.66 Abs output power % */
    float p68_abs_motor_shaft;  /* 01.68 Abs motor shaft */
    float p70_ambient;  /* 01.70 Ambient */
    float p71_step_up_motor;  /* 01.71 Step-up motor */
    float p72_u_phase_rms;  /* 01.72 U-phase RMS */
    float p73_v_phase_rms;  /* 01.73 V-phase RMS */
    float p74_w_phase_rms;  /* 01.74 W-phase RMS */
} param_group_01_t;

extern param_group_01_t g_param_grp01;

void param_grp01_init(void);
void param_grp01_load_defaults(void);
int  param_grp01_get(uint8_t index, float *out_value);
int  param_grp01_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP01_ACTUAL_VALUES_H */
