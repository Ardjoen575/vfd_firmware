#ifndef VFD_PARAM_GRP41_PROCESS_PID_SET_2_H
#define VFD_PARAM_GRP41_PROCESS_PID_SET_2_H

/* Parameter group 41: Process PID set 2
 * Auto-generated from ACS880 primary control program firmware manual
 * 50 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 41) ---- */
typedef enum {
    PARAM_41_07_SET_2_PID_OPERATION = 7, /* 41.07 Set 2 PID operation */
    PARAM_41_08_SET_2_FEEDBACK_1 = 8, /* 41.08 Set 2 feedback 1 */
    PARAM_41_09_SET_2_FEEDBACK_2 = 9, /* 41.09 Set 2 feedback 2 */
    PARAM_41_10_SET_2_FEEDBACK = 10, /* 41.10 Set 2 feedback */
    PARAM_41_11_SET_2_FEEDBACK_FILTER = 11, /* 41.11 Set 2 feedback filter */
    PARAM_41_12_SET_2_UNIT_SELECTION = 12, /* 41.12 Set 2 unit selection */
    PARAM_41_14_SET_2_SETPOINT = 14, /* 41.14 Set 2 setpoint */
    PARAM_41_15_SET_2_OUTPUT_SCALING_SEE_PARAMETER_40_15_SET_1_OUTPUT_SCALING = 15, /* 41.15 Set 2 output scaling See parameter 40.15 Set 1 output scaling. */
    PARAM_41_16_SET_2_SETPOINT_1 = 16, /* 41.16 Set 2 setpoint 1 */
    PARAM_41_17_SET_2_SETPOINT_2 = 17, /* 41.17 Set 2 setpoint 2 */
    PARAM_41_18_SET_2_SETPOINT = 18, /* 41.18 Set 2 setpoint */
    PARAM_41_19_SET_2_INTERNAL = 19, /* 41.19 Set 2 internal */
    PARAM_41_20_SET_2_INTERNAL = 20, /* 41.20 Set 2 internal */
    PARAM_41_21_SET_2_INTERNAL = 21, /* 41.21 Set 2 internal */
    PARAM_41_22_SET_2_INTERNAL = 22, /* 41.22 Set 2 internal */
    PARAM_41_23_SET_2_INTERNAL = 23, /* 41.23 Set 2 internal */
    PARAM_41_24_SET_2_INTERNAL = 24, /* 41.24 Set 2 internal */
    PARAM_41_25_SET_2_SETPOINT = 25, /* 41.25 Set 2 setpoint */
    PARAM_41_26_SET_2_SETPOINT_MIN = 26, /* 41.26 Set 2 setpoint min */
    PARAM_41_27_SET_2_SETPOINT_MAX = 27, /* 41.27 Set 2 setpoint max */
    PARAM_41_28_SET_2_SETPOINT = 28, /* 41.28 Set 2 setpoint */
    PARAM_41_29_SET_2_SETPOINT = 29, /* 41.29 Set 2 setpoint */
    PARAM_41_30_SET_2_SETPOINT = 30, /* 41.30 Set 2 setpoint */
    PARAM_41_31_SET_2_DEVIATION = 31, /* 41.31 Set 2 deviation */
    PARAM_41_32_SET_2_GAIN = 32, /* 41.32 Set 2 gain */
    PARAM_41_33_SET_2_INTEGRATION = 33, /* 41.33 Set 2 integration */
    PARAM_41_34_SET_2_DERIVATION = 34, /* 41.34 Set 2 derivation */
    PARAM_41_35_SET_2_DERIVATION = 35, /* 41.35 Set 2 derivation */
    PARAM_41_36_SET_2_OUTPUT_MIN = 36, /* 41.36 Set 2 output min */
    PARAM_41_37_SET_2_OUTPUT_MAX = 37, /* 41.37 Set 2 output max */
    PARAM_41_38_SET_2_OUTPUT_FREEZE = 38, /* 41.38 Set 2 output freeze */
    PARAM_41_39_SET_2_DEADBAND = 39, /* 41.39 Set 2 deadband */
    PARAM_41_40_SET_2_DEADBAND = 40, /* 41.40 Set 2 deadband */
    PARAM_41_41_SET_2_SLEEP_MODE = 41, /* 41.41 Set 2 sleep mode */
    PARAM_41_42_SET_2_SLEEP_ENABLE = 42, /* 41.42 Set 2 sleep enable */
    PARAM_41_43_SET_2_SLEEP_LEVEL = 43, /* 41.43 Set 2 sleep level */
    PARAM_41_44_SET_2_SLEEP_DELAY = 44, /* 41.44 Set 2 sleep delay */
    PARAM_41_45_SET_2_SLEEP_BOOST = 45, /* 41.45 Set 2 sleep boost */
    PARAM_41_46_SET_2_SLEEP_BOOST = 46, /* 41.46 Set 2 sleep boost */
    PARAM_41_47_SET_2_WAKE_UP = 47, /* 41.47 Set 2 wake-up */
    PARAM_41_48_SET_2_WAKE_UP = 48, /* 41.48 Set 2 wake-up */
    PARAM_41_49_SET_2_TRACKING_MODE_SEE_PARAMETER_40_49_SET_1_TRACKING_MODE = 49, /* 41.49 Set 2 tracking mode See parameter 40.49 Set 1 tracking mode. */
    PARAM_41_50_SET_2_TRACKING_REF = 50, /* 41.50 Set 2 tracking ref */
    PARAM_41_51_SET_2_TRIM_MODE = 51, /* 41.51 Set 2 trim mode */
    PARAM_41_52_SET_2_TRIM_SELECTION = 52, /* 41.52 Set 2 trim selection */
    PARAM_41_53_SET_2_TRIMMED_REF = 53, /* 41.53 Set 2 trimmed ref */
    PARAM_41_54_SET_2_TRIM_MIX = 54, /* 41.54 Set 2 trim mix */
    PARAM_41_55_SET_2_TRIM_ADJUST = 55, /* 41.55 Set 2 trim adjust */
    PARAM_41_56_SET_2_TRIM_SOURCE = 56, /* 41.56 Set 2 trim source */
    PARAM_41_60_SET_2_PID_ACTIVATION = 60, /* 41.60 Set 2 PID activation */
} param_group_41_index_t;

/* ---- Live value storage (group 41) ---- */
typedef struct {
    float p07_set_2_pid_operation;  /* 41.07 Set 2 PID operation */
    float p08_set_2_feedback_1;  /* 41.08 Set 2 feedback 1 */
    float p09_set_2_feedback_2;  /* 41.09 Set 2 feedback 2 */
    float p10_set_2_feedback;  /* 41.10 Set 2 feedback */
    float p11_set_2_feedback_filter;  /* 41.11 Set 2 feedback filter */
    float p12_set_2_unit_selection;  /* 41.12 Set 2 unit selection */
    float p14_set_2_setpoint;  /* 41.14 Set 2 setpoint */
    float p15_set_2_output_scaling_see_parameter_40_15_set_1_output_scaling;  /* 41.15 Set 2 output scaling See parameter 40.15 Set 1 output scaling. */
    float p16_set_2_setpoint_1;  /* 41.16 Set 2 setpoint 1 */
    float p17_set_2_setpoint_2;  /* 41.17 Set 2 setpoint 2 */
    float p18_set_2_setpoint;  /* 41.18 Set 2 setpoint */
    float p19_set_2_internal;  /* 41.19 Set 2 internal */
    float p20_set_2_internal;  /* 41.20 Set 2 internal */
    float p21_set_2_internal;  /* 41.21 Set 2 internal */
    float p22_set_2_internal;  /* 41.22 Set 2 internal */
    float p23_set_2_internal;  /* 41.23 Set 2 internal */
    float p24_set_2_internal;  /* 41.24 Set 2 internal */
    float p25_set_2_setpoint;  /* 41.25 Set 2 setpoint */
    float p26_set_2_setpoint_min;  /* 41.26 Set 2 setpoint min */
    float p27_set_2_setpoint_max;  /* 41.27 Set 2 setpoint max */
    float p28_set_2_setpoint;  /* 41.28 Set 2 setpoint */
    float p29_set_2_setpoint;  /* 41.29 Set 2 setpoint */
    float p30_set_2_setpoint;  /* 41.30 Set 2 setpoint */
    float p31_set_2_deviation;  /* 41.31 Set 2 deviation */
    float p32_set_2_gain;  /* 41.32 Set 2 gain */
    float p33_set_2_integration;  /* 41.33 Set 2 integration */
    float p34_set_2_derivation;  /* 41.34 Set 2 derivation */
    float p35_set_2_derivation;  /* 41.35 Set 2 derivation */
    float p36_set_2_output_min;  /* 41.36 Set 2 output min */
    float p37_set_2_output_max;  /* 41.37 Set 2 output max */
    float p38_set_2_output_freeze;  /* 41.38 Set 2 output freeze */
    float p39_set_2_deadband;  /* 41.39 Set 2 deadband */
    float p40_set_2_deadband;  /* 41.40 Set 2 deadband */
    float p41_set_2_sleep_mode;  /* 41.41 Set 2 sleep mode */
    float p42_set_2_sleep_enable;  /* 41.42 Set 2 sleep enable */
    float p43_set_2_sleep_level;  /* 41.43 Set 2 sleep level */
    float p44_set_2_sleep_delay;  /* 41.44 Set 2 sleep delay */
    float p45_set_2_sleep_boost;  /* 41.45 Set 2 sleep boost */
    float p46_set_2_sleep_boost;  /* 41.46 Set 2 sleep boost */
    float p47_set_2_wake_up;  /* 41.47 Set 2 wake-up */
    float p48_set_2_wake_up;  /* 41.48 Set 2 wake-up */
    float p49_set_2_tracking_mode_see_parameter_40_49_set_1_tracking_mode;  /* 41.49 Set 2 tracking mode See parameter 40.49 Set 1 tracking mode. */
    float p50_set_2_tracking_ref;  /* 41.50 Set 2 tracking ref */
    float p51_set_2_trim_mode;  /* 41.51 Set 2 trim mode */
    float p52_set_2_trim_selection;  /* 41.52 Set 2 trim selection */
    float p53_set_2_trimmed_ref;  /* 41.53 Set 2 trimmed ref */
    float p54_set_2_trim_mix;  /* 41.54 Set 2 trim mix */
    float p55_set_2_trim_adjust;  /* 41.55 Set 2 trim adjust */
    float p56_set_2_trim_source;  /* 41.56 Set 2 trim source */
    float p60_set_2_pid_activation;  /* 41.60 Set 2 PID activation */
} param_group_41_t;

extern param_group_41_t g_param_grp41;

void param_grp41_init(void);
void param_grp41_load_defaults(void);
int  param_grp41_get(uint8_t index, float *out_value);
int  param_grp41_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP41_PROCESS_PID_SET_2_H */
