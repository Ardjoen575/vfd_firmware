#ifndef VFD_PARAM_GRP15_IO_EXTENSION_MODULE_2_H
#define VFD_PARAM_GRP15_IO_EXTENSION_MODULE_2_H

/* Parameter group 15: IO extension module 2
 * Auto-generated from ACS880 primary control program firmware manual
 * 73 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 15) ---- */
typedef enum {
    PARAM_15_01_MODULE_2_TYPE = 1, /* 15.01 Module 2 type */
    PARAM_15_02_MODULE_2_LOCATION = 2, /* 15.02 Module 2 location */
    PARAM_15_03_MODULE_2_STATUS = 3, /* 15.03 Module 2 status */
    PARAM_15_05_DI_STATUS = 5, /* 15.05 DI status */
    PARAM_15_06_DI_DELAYED_STATUS = 6, /* 15.06 DI delayed status */
    PARAM_15_08_DI_FILTER_TIME = 8, /* 15.08 DI filter time */
    PARAM_15_09_DIO1_FUNCTION = 9, /* 15.09 DIO1 function */
    PARAM_15_11_DIO1_OUTPUT_SOURCE = 11, /* 15.11 DIO1 output source */
    PARAM_15_12_DI1_ON_DELAY = 12, /* 15.12 DI1 ON delay */
    PARAM_15_13_DI1_OFF_DELAY = 13, /* 15.13 DI1 OFF delay */
    PARAM_15_14_DIO2_FUNCTION = 14, /* 15.14 DIO2 function */
    PARAM_15_16_DIO2_OUTPUT_SOURCE = 16, /* 15.16 DIO2 output source */
    PARAM_15_17_DI2_ON_DELAY = 17, /* 15.17 DI2 ON delay */
    PARAM_15_18_DI2_OFF_DELAY = 18, /* 15.18 DI2 OFF delay */
    PARAM_15_19_DIO3_FUNCTION = 19, /* 15.19 DIO3 function */
    PARAM_15_20_AI_SUPERVISION = 20, /* 15.20 AI supervision */
    PARAM_15_21_DIO3_OUTPUT_SOURCE = 21, /* 15.21 DIO3 output source */
    PARAM_15_22_DI3_ON_DELAY = 22, /* 15.22 DI3 ON delay */
    PARAM_15_23_DI3_OFF_DELAY = 23, /* 15.23 DI3 OFF delay */
    PARAM_15_24_DIO4_FUNCTION = 24, /* 15.24 DIO4 function */
    PARAM_15_26_DIO4_OUTPUT_SOURCE = 26, /* 15.26 DIO4 output source */
    PARAM_15_27_DIO4_ON_DELAY = 27, /* 15.27 DIO4 ON delay */
    PARAM_15_28_DIO4_OFF_DELAY = 28, /* 15.28 DIO4 OFF delay */
    PARAM_15_29_AI1_HW_SWITCH = 29, /* 15.29 AI1 HW switch */
    PARAM_15_30_AI1_UNIT_SELECTION = 30, /* 15.30 AI1 unit selection */
    PARAM_15_31_RO_STATUS = 31, /* 15.31 RO status */
    PARAM_15_32_AI1_FILTER_TIME = 32, /* 15.32 AI1 filter time */
    PARAM_15_33_AI1_MIN = 33, /* 15.33 AI1 min */
    PARAM_15_34_RO1_SOURCE = 34, /* 15.34 RO1 source */
    PARAM_15_35_RO1_ON_DELAY = 35, /* 15.35 RO1 ON delay */
    PARAM_15_36_RO1_OFF_DELAY = 36, /* 15.36 RO1 OFF delay */
    PARAM_15_37_RO2_SOURCE = 37, /* 15.37 RO2 source */
    PARAM_15_38_RO2_ON_DELAY = 38, /* 15.38 RO2 ON delay */
    PARAM_15_39_RO2_OFF_DELAY = 39, /* 15.39 RO2 OFF delay */
    PARAM_15_41_AI2_ACTUAL_VALUE = 41, /* 15.41 AI2 actual value */
    PARAM_15_42_AI2_SCALED_VALUE = 42, /* 15.42 AI2 scaled value */
    PARAM_15_43_AI2_FORCE_DATA = 43, /* 15.43 AI2 force data */
    PARAM_15_44_AI2_HW_SWITCH = 44, /* 15.44 AI2 HW switch */
    PARAM_15_45_AI2_UNIT_SELECTION = 45, /* 15.45 AI2 unit selection */
    PARAM_15_46_AI2_FILTER_GAIN = 46, /* 15.46 AI2 filter gain */
    PARAM_15_47_AI2_FILTER_TIME = 47, /* 15.47 AI2 filter time */
    PARAM_15_48_AI2_MIN = 48, /* 15.48 AI2 min */
    PARAM_15_49_AI2_MAX = 49, /* 15.49 AI2 max */
    PARAM_15_50_AI2_SCALED_AT_AI2 = 50, /* 15.50 AI2 scaled at AI2 */
    PARAM_15_51_AI2_SCALED_AT_AI2 = 51, /* 15.51 AI2 scaled at AI2 */
    PARAM_15_56_AI3_ACTUAL_VALUE = 56, /* 15.56 AI3 actual value */
    PARAM_15_57_AI3_SCALED_VALUE = 57, /* 15.57 AI3 scaled value */
    PARAM_15_58_AI3_FORCE_DATA = 58, /* 15.58 AI3 force data */
    PARAM_15_59_AI3_HW_SWITCH = 59, /* 15.59 AI3 HW switch */
    PARAM_15_60_AI3_UNIT_SELECTION = 60, /* 15.60 AI3 unit selection */
    PARAM_15_61_AI3_FILTER_GAIN = 61, /* 15.61 AI3 filter gain */
    PARAM_15_62_AI3_FILTER_TIME = 62, /* 15.62 AI3 filter time */
    PARAM_15_63_AI3_MIN = 63, /* 15.63 AI3 min */
    PARAM_15_64_AI3_MAX = 64, /* 15.64 AI3 max */
    PARAM_15_65_AI3_SCALED_AT_AI3 = 65, /* 15.65 AI3 scaled at AI3 */
    PARAM_15_66_AI3_SCALED_AT_AI3 = 66, /* 15.66 AI3 scaled at AI3 */
    PARAM_15_71_AO_FORCE_SELECTION = 71, /* 15.71 AO force selection */
    PARAM_15_76_AO1_ACTUAL_VALUE = 76, /* 15.76 AO1 actual value */
    PARAM_15_77_AO1_SOURCE = 77, /* 15.77 AO1 source */
    PARAM_15_78_AO1_FORCE_DATA = 78, /* 15.78 AO1 force data */
    PARAM_15_79_AO1_FILTER_TIME = 79, /* 15.79 AO1 filter time */
    PARAM_15_80_AO1_SOURCE_MIN = 80, /* 15.80 AO1 source min */
    PARAM_15_81_AO1_SOURCE_MAX = 81, /* 15.81 AO1 source max */
    PARAM_15_82_AO1_OUT_AT_AO1_SRC = 82, /* 15.82 AO1 out at AO1 src */
    PARAM_15_83_AO1_OUT_AT_AO1_SRC = 83, /* 15.83 AO1 out at AO1 src */
    PARAM_15_86_AO2_ACTUAL_VALUE = 86, /* 15.86 AO2 actual value */
    PARAM_15_87_AO2_SOURCE = 87, /* 15.87 AO2 source */
    PARAM_15_88_AO2_FORCE_DATA = 88, /* 15.88 AO2 force data */
    PARAM_15_89_AO2_FILTER_TIME = 89, /* 15.89 AO2 filter time */
    PARAM_15_90_AO2_SOURCE_MIN = 90, /* 15.90 AO2 source min */
    PARAM_15_91_AO2_SOURCE_MAX = 91, /* 15.91 AO2 source max */
    PARAM_15_92_AO2_OUT_AT_AO2_SRC = 92, /* 15.92 AO2 out at AO2 src */
    PARAM_15_93_AO2_OUT_AT_AO2_SRC = 93, /* 15.93 AO2 out at AO2 src */
} param_group_15_index_t;

/* ---- Live value storage (group 15) ---- */
typedef struct {
    float p01_module_2_type;  /* 15.01 Module 2 type */
    float p02_module_2_location;  /* 15.02 Module 2 location */
    float p03_module_2_status;  /* 15.03 Module 2 status */
    float p05_di_status;  /* 15.05 DI status */
    float p06_di_delayed_status;  /* 15.06 DI delayed status */
    float p08_di_filter_time;  /* 15.08 DI filter time */
    float p09_dio1_function;  /* 15.09 DIO1 function */
    float p11_dio1_output_source;  /* 15.11 DIO1 output source */
    float p12_di1_on_delay;  /* 15.12 DI1 ON delay */
    float p13_di1_off_delay;  /* 15.13 DI1 OFF delay */
    float p14_dio2_function;  /* 15.14 DIO2 function */
    float p16_dio2_output_source;  /* 15.16 DIO2 output source */
    float p17_di2_on_delay;  /* 15.17 DI2 ON delay */
    float p18_di2_off_delay;  /* 15.18 DI2 OFF delay */
    float p19_dio3_function;  /* 15.19 DIO3 function */
    float p20_ai_supervision;  /* 15.20 AI supervision */
    float p21_dio3_output_source;  /* 15.21 DIO3 output source */
    float p22_di3_on_delay;  /* 15.22 DI3 ON delay */
    float p23_di3_off_delay;  /* 15.23 DI3 OFF delay */
    float p24_dio4_function;  /* 15.24 DIO4 function */
    float p26_dio4_output_source;  /* 15.26 DIO4 output source */
    float p27_dio4_on_delay;  /* 15.27 DIO4 ON delay */
    float p28_dio4_off_delay;  /* 15.28 DIO4 OFF delay */
    float p29_ai1_hw_switch;  /* 15.29 AI1 HW switch */
    float p30_ai1_unit_selection;  /* 15.30 AI1 unit selection */
    float p31_ro_status;  /* 15.31 RO status */
    float p32_ai1_filter_time;  /* 15.32 AI1 filter time */
    float p33_ai1_min;  /* 15.33 AI1 min */
    float p34_ro1_source;  /* 15.34 RO1 source */
    float p35_ro1_on_delay;  /* 15.35 RO1 ON delay */
    float p36_ro1_off_delay;  /* 15.36 RO1 OFF delay */
    float p37_ro2_source;  /* 15.37 RO2 source */
    float p38_ro2_on_delay;  /* 15.38 RO2 ON delay */
    float p39_ro2_off_delay;  /* 15.39 RO2 OFF delay */
    float p41_ai2_actual_value;  /* 15.41 AI2 actual value */
    float p42_ai2_scaled_value;  /* 15.42 AI2 scaled value */
    float p43_ai2_force_data;  /* 15.43 AI2 force data */
    float p44_ai2_hw_switch;  /* 15.44 AI2 HW switch */
    float p45_ai2_unit_selection;  /* 15.45 AI2 unit selection */
    float p46_ai2_filter_gain;  /* 15.46 AI2 filter gain */
    float p47_ai2_filter_time;  /* 15.47 AI2 filter time */
    float p48_ai2_min;  /* 15.48 AI2 min */
    float p49_ai2_max;  /* 15.49 AI2 max */
    float p50_ai2_scaled_at_ai2;  /* 15.50 AI2 scaled at AI2 */
    float p51_ai2_scaled_at_ai2;  /* 15.51 AI2 scaled at AI2 */
    float p56_ai3_actual_value;  /* 15.56 AI3 actual value */
    float p57_ai3_scaled_value;  /* 15.57 AI3 scaled value */
    float p58_ai3_force_data;  /* 15.58 AI3 force data */
    float p59_ai3_hw_switch;  /* 15.59 AI3 HW switch */
    float p60_ai3_unit_selection;  /* 15.60 AI3 unit selection */
    float p61_ai3_filter_gain;  /* 15.61 AI3 filter gain */
    float p62_ai3_filter_time;  /* 15.62 AI3 filter time */
    float p63_ai3_min;  /* 15.63 AI3 min */
    float p64_ai3_max;  /* 15.64 AI3 max */
    float p65_ai3_scaled_at_ai3;  /* 15.65 AI3 scaled at AI3 */
    float p66_ai3_scaled_at_ai3;  /* 15.66 AI3 scaled at AI3 */
    float p71_ao_force_selection;  /* 15.71 AO force selection */
    float p76_ao1_actual_value;  /* 15.76 AO1 actual value */
    float p77_ao1_source;  /* 15.77 AO1 source */
    float p78_ao1_force_data;  /* 15.78 AO1 force data */
    float p79_ao1_filter_time;  /* 15.79 AO1 filter time */
    float p80_ao1_source_min;  /* 15.80 AO1 source min */
    float p81_ao1_source_max;  /* 15.81 AO1 source max */
    float p82_ao1_out_at_ao1_src;  /* 15.82 AO1 out at AO1 src */
    float p83_ao1_out_at_ao1_src;  /* 15.83 AO1 out at AO1 src */
    float p86_ao2_actual_value;  /* 15.86 AO2 actual value */
    float p87_ao2_source;  /* 15.87 AO2 source */
    float p88_ao2_force_data;  /* 15.88 AO2 force data */
    float p89_ao2_filter_time;  /* 15.89 AO2 filter time */
    float p90_ao2_source_min;  /* 15.90 AO2 source min */
    float p91_ao2_source_max;  /* 15.91 AO2 source max */
    float p92_ao2_out_at_ao2_src;  /* 15.92 AO2 out at AO2 src */
    float p93_ao2_out_at_ao2_src;  /* 15.93 AO2 out at AO2 src */
} param_group_15_t;

extern param_group_15_t g_param_grp15;

void param_grp15_init(void);
void param_grp15_load_defaults(void);
int  param_grp15_get(uint8_t index, float *out_value);
int  param_grp15_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP15_IO_EXTENSION_MODULE_2_H */
