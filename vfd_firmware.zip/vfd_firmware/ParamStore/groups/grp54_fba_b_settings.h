#ifndef VFD_PARAM_GRP54_FBA_B_SETTINGS_H
#define VFD_PARAM_GRP54_FBA_B_SETTINGS_H

/* Parameter group 54: FBA B settings
 * Auto-generated from ACS880 primary control program firmware manual
 * 10 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 54) ---- */
typedef enum {
    PARAM_54_01_FBA_B_TYPE = 1, /* 54.01 FBA B type */
    PARAM_54_02_FBA_B_PAR2 = 2, /* 54.02 FBA B Par2 */
    PARAM_54_26_FBA_B_PAR26 = 26, /* 54.26 FBA B Par26 */
    PARAM_54_27_FBA_B_PAR_REFRESH = 27, /* 54.27 FBA B par refresh */
    PARAM_54_28_FBA_B_PAR_TABLE_VER = 28, /* 54.28 FBA B par table ver */
    PARAM_54_29_FBA_B_DRIVE_TYPE = 29, /* 54.29 FBA B drive type */
    PARAM_54_30_FBA_B_MAPPING_FILE = 30, /* 54.30 FBA B mapping file */
    PARAM_54_31_D2FBA_B_COMM = 31, /* 54.31 D2FBA B comm */
    PARAM_54_32_FBA_B_COMM_SW = 32, /* 54.32 FBA B comm SW */
    PARAM_54_33_FBA_B_APPL_SW_VER = 33, /* 54.33 FBA B appl SW ver */
} param_group_54_index_t;

/* ---- Live value storage (group 54) ---- */
typedef struct {
    float p01_fba_b_type;  /* 54.01 FBA B type */
    float p02_fba_b_par2;  /* 54.02 FBA B Par2 */
    float p26_fba_b_par26;  /* 54.26 FBA B Par26 */
    float p27_fba_b_par_refresh;  /* 54.27 FBA B par refresh */
    float p28_fba_b_par_table_ver;  /* 54.28 FBA B par table ver */
    float p29_fba_b_drive_type;  /* 54.29 FBA B drive type */
    float p30_fba_b_mapping_file;  /* 54.30 FBA B mapping file */
    float p31_d2fba_b_comm;  /* 54.31 D2FBA B comm */
    float p32_fba_b_comm_sw;  /* 54.32 FBA B comm SW */
    float p33_fba_b_appl_sw_ver;  /* 54.33 FBA B appl SW ver */
} param_group_54_t;

extern param_group_54_t g_param_grp54;

void param_grp54_init(void);
void param_grp54_load_defaults(void);
int  param_grp54_get(uint8_t index, float *out_value);
int  param_grp54_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP54_FBA_B_SETTINGS_H */
