#ifndef VFD_PARAM_GRP33_GENERIC_TIMER_COUNTER_H
#define VFD_PARAM_GRP33_GENERIC_TIMER_COUNTER_H

/* Parameter group 33: Generic timer counter
 * Auto-generated from ACS880 primary control program firmware manual
 * 35 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 33) ---- */
typedef enum {
    PARAM_33_01_COUNTER_STATUS = 1, /* 33.01 Counter status */
    PARAM_33_10_ON_TIME_1_ACTUAL = 10, /* 33.10 On-time 1 actual */
    PARAM_33_11_ON_TIME_1_WARN_LIMIT_SETS_THE_WARNING_LIMIT_FOR_ON_TIME_TIMER_1 = 11, /* 33.11 On-time 1 warn limit Sets the warning limit for on-time timer 1. */
    PARAM_33_12_ON_TIME_1_FUNCTION = 12, /* 33.12 On-time 1 function */
    PARAM_33_13_ON_TIME_1_SOURCE = 13, /* 33.13 On-time 1 source */
    PARAM_33_14_ON_TIME_1_WARN = 14, /* 33.14 On-time 1 warn */
    PARAM_33_20_ON_TIME_2_ACTUAL = 20, /* 33.20 On-time 2 actual */
    PARAM_33_21_ON_TIME_2_WARN_LIMIT_SETS_THE_WARNING_LIMIT_FOR_ON_TIME_TIMER_2 = 21, /* 33.21 On-time 2 warn limit Sets the warning limit for on-time timer 2. */
    PARAM_33_22_ON_TIME_2_FUNCTION = 22, /* 33.22 On-time 2 function */
    PARAM_33_23_ON_TIME_2_SOURCE = 23, /* 33.23 On-time 2 source */
    PARAM_33_24_ON_TIME_2_WARN = 24, /* 33.24 On-time 2 warn */
    PARAM_33_30_EDGE_COUNTER_1 = 30, /* 33.30 Edge counter 1 */
    PARAM_33_31_EDGE_COUNTER_1 = 31, /* 33.31 Edge counter 1 */
    PARAM_33_32_EDGE_COUNTER_1 = 32, /* 33.32 Edge counter 1 */
    PARAM_33_33_EDGE_COUNTER_1 = 33, /* 33.33 Edge counter 1 */
    PARAM_33_34_EDGE_COUNTER_1 = 34, /* 33.34 Edge counter 1 */
    PARAM_33_35_EDGE_COUNTER_1 = 35, /* 33.35 Edge counter 1 */
    PARAM_33_40_EDGE_COUNTER_2 = 40, /* 33.40 Edge counter 2 */
    PARAM_33_41_EDGE_COUNTER_2 = 41, /* 33.41 Edge counter 2 */
    PARAM_33_42_EDGE_COUNTER_2 = 42, /* 33.42 Edge counter 2 */
    PARAM_33_43_EDGE_COUNTER_2 = 43, /* 33.43 Edge counter 2 */
    PARAM_33_44_EDGE_COUNTER_2 = 44, /* 33.44 Edge counter 2 */
    PARAM_33_45_EDGE_COUNTER_2 = 45, /* 33.45 Edge counter 2 */
    PARAM_33_50_VALUE_COUNTER_1 = 50, /* 33.50 Value counter 1 */
    PARAM_33_51_VALUE_COUNTER_1 = 51, /* 33.51 Value counter 1 */
    PARAM_33_52_VALUE_COUNTER_1 = 52, /* 33.52 Value counter 1 */
    PARAM_33_53_VALUE_COUNTER_1 = 53, /* 33.53 Value counter 1 */
    PARAM_33_54_VALUE_COUNTER_1 = 54, /* 33.54 Value counter 1 */
    PARAM_33_55_VALUE_COUNTER_1 = 55, /* 33.55 Value counter 1 */
    PARAM_33_60_VALUE_COUNTER_2 = 60, /* 33.60 Value counter 2 */
    PARAM_33_61_VALUE_COUNTER_2 = 61, /* 33.61 Value counter 2 */
    PARAM_33_62_VALUE_COUNTER_2 = 62, /* 33.62 Value counter 2 */
    PARAM_33_63_VALUE_COUNTER_2 = 63, /* 33.63 Value counter 2 */
    PARAM_33_64_VALUE_COUNTER_2 = 64, /* 33.64 Value counter 2 */
    PARAM_33_65_VALUE_COUNTER_2 = 65, /* 33.65 Value counter 2 */
} param_group_33_index_t;

/* ---- Live value storage (group 33) ---- */
typedef struct {
    float p01_counter_status;  /* 33.01 Counter status */
    float p10_on_time_1_actual;  /* 33.10 On-time 1 actual */
    float p11_on_time_1_warn_limit_sets_the_warning_limit_for_on_time_timer_1;  /* 33.11 On-time 1 warn limit Sets the warning limit for on-time timer 1. */
    float p12_on_time_1_function;  /* 33.12 On-time 1 function */
    float p13_on_time_1_source;  /* 33.13 On-time 1 source */
    float p14_on_time_1_warn;  /* 33.14 On-time 1 warn */
    float p20_on_time_2_actual;  /* 33.20 On-time 2 actual */
    float p21_on_time_2_warn_limit_sets_the_warning_limit_for_on_time_timer_2;  /* 33.21 On-time 2 warn limit Sets the warning limit for on-time timer 2. */
    float p22_on_time_2_function;  /* 33.22 On-time 2 function */
    float p23_on_time_2_source;  /* 33.23 On-time 2 source */
    float p24_on_time_2_warn;  /* 33.24 On-time 2 warn */
    float p30_edge_counter_1;  /* 33.30 Edge counter 1 */
    float p31_edge_counter_1;  /* 33.31 Edge counter 1 */
    float p32_edge_counter_1;  /* 33.32 Edge counter 1 */
    float p33_edge_counter_1;  /* 33.33 Edge counter 1 */
    float p34_edge_counter_1;  /* 33.34 Edge counter 1 */
    float p35_edge_counter_1;  /* 33.35 Edge counter 1 */
    float p40_edge_counter_2;  /* 33.40 Edge counter 2 */
    float p41_edge_counter_2;  /* 33.41 Edge counter 2 */
    float p42_edge_counter_2;  /* 33.42 Edge counter 2 */
    float p43_edge_counter_2;  /* 33.43 Edge counter 2 */
    float p44_edge_counter_2;  /* 33.44 Edge counter 2 */
    float p45_edge_counter_2;  /* 33.45 Edge counter 2 */
    float p50_value_counter_1;  /* 33.50 Value counter 1 */
    float p51_value_counter_1;  /* 33.51 Value counter 1 */
    float p52_value_counter_1;  /* 33.52 Value counter 1 */
    float p53_value_counter_1;  /* 33.53 Value counter 1 */
    float p54_value_counter_1;  /* 33.54 Value counter 1 */
    float p55_value_counter_1;  /* 33.55 Value counter 1 */
    float p60_value_counter_2;  /* 33.60 Value counter 2 */
    float p61_value_counter_2;  /* 33.61 Value counter 2 */
    float p62_value_counter_2;  /* 33.62 Value counter 2 */
    float p63_value_counter_2;  /* 33.63 Value counter 2 */
    float p64_value_counter_2;  /* 33.64 Value counter 2 */
    float p65_value_counter_2;  /* 33.65 Value counter 2 */
} param_group_33_t;

extern param_group_33_t g_param_grp33;

void param_grp33_init(void);
void param_grp33_load_defaults(void);
int  param_grp33_get(uint8_t index, float *out_value);
int  param_grp33_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP33_GENERIC_TIMER_COUNTER_H */
