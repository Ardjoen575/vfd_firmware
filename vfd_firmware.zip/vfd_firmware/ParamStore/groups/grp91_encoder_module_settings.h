#ifndef VFD_PARAM_GRP91_ENCODER_MODULE_SETTINGS_H
#define VFD_PARAM_GRP91_ENCODER_MODULE_SETTINGS_H

/* Parameter group 91: Encoder module settings
 * Auto-generated from ACS880 primary control program firmware manual
 * 20 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 91) ---- */
typedef enum {
    PARAM_91_01_FEN_DI_STATUS = 1, /* 91.01 FEN DI status */
    PARAM_91_02_MODULE_1_STATUS = 2, /* 91.02 Module 1 status */
    PARAM_91_03_MODULE_2_STATUS = 3, /* 91.03 Module 2 status */
    PARAM_91_04_MODULE_1 = 4, /* 91.04 Module 1 */
    PARAM_91_06_MODULE_2 = 6, /* 91.06 Module 2 */
    PARAM_91_10_ENCODER_PARAMETER = 10, /* 91.10 Encoder parameter */
    PARAM_91_11_MODULE_1_TYPE = 11, /* 91.11 Module 1 type */
    PARAM_91_12_MODULE_1_LOCATION = 12, /* 91.12 Module 1 location */
    PARAM_91_13_MODULE_2_TYPE = 13, /* 91.13 Module 2 type */
    PARAM_91_14_MODULE_2_LOCATION = 14, /* 91.14 Module 2 location */
    PARAM_91_21_MODULE_1_TEMP = 21, /* 91.21 Module 1 temp */
    PARAM_91_22_MODULE_1_TEMP_FILTER = 22, /* 91.22 Module 1 temp filter */
    PARAM_91_24_MODULE_2_TEMP = 24, /* 91.24 Module 2 temp */
    PARAM_91_25_MODULE_2_TEMP_FILTER = 25, /* 91.25 Module 2 temp filter */
    PARAM_91_31_MODULE_1_TTL = 31, /* 91.31 Module 1 TTL */
    PARAM_91_32_MODULE_1_EMULATION = 32, /* 91.32 Module 1 emulation */
    PARAM_91_33_MODULE_1_EMULATED = 33, /* 91.33 Module 1 emulated */
    PARAM_91_41_MODULE_2_TTL = 41, /* 91.41 Module 2 TTL */
    PARAM_91_42_MODULE_2_EMULATION = 42, /* 91.42 Module 2 emulation */
    PARAM_91_43_MODULE_2_EMULATED = 43, /* 91.43 Module 2 emulated */
} param_group_91_index_t;

/* ---- Live value storage (group 91) ---- */
typedef struct {
    float p01_fen_di_status;  /* 91.01 FEN DI status */
    float p02_module_1_status;  /* 91.02 Module 1 status */
    float p03_module_2_status;  /* 91.03 Module 2 status */
    float p04_module_1;  /* 91.04 Module 1 */
    float p06_module_2;  /* 91.06 Module 2 */
    float p10_encoder_parameter;  /* 91.10 Encoder parameter */
    float p11_module_1_type;  /* 91.11 Module 1 type */
    float p12_module_1_location;  /* 91.12 Module 1 location */
    float p13_module_2_type;  /* 91.13 Module 2 type */
    float p14_module_2_location;  /* 91.14 Module 2 location */
    float p21_module_1_temp;  /* 91.21 Module 1 temp */
    float p22_module_1_temp_filter;  /* 91.22 Module 1 temp filter */
    float p24_module_2_temp;  /* 91.24 Module 2 temp */
    float p25_module_2_temp_filter;  /* 91.25 Module 2 temp filter */
    float p31_module_1_ttl;  /* 91.31 Module 1 TTL */
    float p32_module_1_emulation;  /* 91.32 Module 1 emulation */
    float p33_module_1_emulated;  /* 91.33 Module 1 emulated */
    float p41_module_2_ttl;  /* 91.41 Module 2 TTL */
    float p42_module_2_emulation;  /* 91.42 Module 2 emulation */
    float p43_module_2_emulated;  /* 91.43 Module 2 emulated */
} param_group_91_t;

extern param_group_91_t g_param_grp91;

void param_grp91_init(void);
void param_grp91_load_defaults(void);
int  param_grp91_get(uint8_t index, float *out_value);
int  param_grp91_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP91_ENCODER_MODULE_SETTINGS_H */
