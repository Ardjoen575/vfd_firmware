#ifndef VFD_PARAM_GRP47_DATA_STORAGE_H
#define VFD_PARAM_GRP47_DATA_STORAGE_H

/* Parameter group 47: Data storage
 * Auto-generated from ACS880 primary control program firmware manual
 * 32 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 47) ---- */
typedef enum {
    PARAM_47_01_DATA_STORAGE_1 = 1, /* 47.01 Data storage 1 */
    PARAM_47_02_DATA_STORAGE_2 = 2, /* 47.02 Data storage 2 */
    PARAM_47_03_DATA_STORAGE_3 = 3, /* 47.03 Data storage 3 */
    PARAM_47_04_DATA_STORAGE_4 = 4, /* 47.04 Data storage 4 */
    PARAM_47_05_DATA_STORAGE_5 = 5, /* 47.05 Data storage 5 */
    PARAM_47_06_DATA_STORAGE_6 = 6, /* 47.06 Data storage 6 */
    PARAM_47_07_DATA_STORAGE_7 = 7, /* 47.07 Data storage 7 */
    PARAM_47_08_DATA_STORAGE_8 = 8, /* 47.08 Data storage 8 */
    PARAM_47_11_DATA_STORAGE_1 = 11, /* 47.11 Data storage 1 */
    PARAM_47_12_DATA_STORAGE_2 = 12, /* 47.12 Data storage 2 */
    PARAM_47_13_DATA_STORAGE_3 = 13, /* 47.13 Data storage 3 */
    PARAM_47_14_DATA_STORAGE_4 = 14, /* 47.14 Data storage 4 */
    PARAM_47_15_DATA_STORAGE_5 = 15, /* 47.15 Data storage 5 */
    PARAM_47_16_DATA_STORAGE_6 = 16, /* 47.16 Data storage 6 */
    PARAM_47_17_DATA_STORAGE_7 = 17, /* 47.17 Data storage 7 */
    PARAM_47_18_DATA_STORAGE_8 = 18, /* 47.18 Data storage 8 */
    PARAM_47_21_DATA_STORAGE_1 = 21, /* 47.21 Data storage 1 */
    PARAM_47_22_DATA_STORAGE_2 = 22, /* 47.22 Data storage 2 */
    PARAM_47_23_DATA_STORAGE_3 = 23, /* 47.23 Data storage 3 */
    PARAM_47_24_DATA_STORAGE_4 = 24, /* 47.24 Data storage 4 */
    PARAM_47_25_DATA_STORAGE_5 = 25, /* 47.25 Data storage 5 */
    PARAM_47_26_DATA_STORAGE_6 = 26, /* 47.26 Data storage 6 */
    PARAM_47_27_DATA_STORAGE_7 = 27, /* 47.27 Data storage 7 */
    PARAM_47_28_DATA_STORAGE_8 = 28, /* 47.28 Data storage 8 */
    PARAM_47_31_DATA_STORAGE_1 = 31, /* 47.31 Data storage 1 */
    PARAM_47_32_DATA_STORAGE_2 = 32, /* 47.32 Data storage 2 */
    PARAM_47_33_DATA_STORAGE_3 = 33, /* 47.33 Data storage 3 */
    PARAM_47_34_DATA_STORAGE_4 = 34, /* 47.34 Data storage 4 */
    PARAM_47_35_DATA_STORAGE_5 = 35, /* 47.35 Data storage 5 */
    PARAM_47_36_DATA_STORAGE_6 = 36, /* 47.36 Data storage 6 */
    PARAM_47_37_DATA_STORAGE_7 = 37, /* 47.37 Data storage 7 */
    PARAM_47_38_DATA_STORAGE_8 = 38, /* 47.38 Data storage 8 */
} param_group_47_index_t;

/* ---- Live value storage (group 47) ---- */
typedef struct {
    float p01_data_storage_1;  /* 47.01 Data storage 1 */
    float p02_data_storage_2;  /* 47.02 Data storage 2 */
    float p03_data_storage_3;  /* 47.03 Data storage 3 */
    float p04_data_storage_4;  /* 47.04 Data storage 4 */
    float p05_data_storage_5;  /* 47.05 Data storage 5 */
    float p06_data_storage_6;  /* 47.06 Data storage 6 */
    float p07_data_storage_7;  /* 47.07 Data storage 7 */
    float p08_data_storage_8;  /* 47.08 Data storage 8 */
    float p11_data_storage_1;  /* 47.11 Data storage 1 */
    float p12_data_storage_2;  /* 47.12 Data storage 2 */
    float p13_data_storage_3;  /* 47.13 Data storage 3 */
    float p14_data_storage_4;  /* 47.14 Data storage 4 */
    float p15_data_storage_5;  /* 47.15 Data storage 5 */
    float p16_data_storage_6;  /* 47.16 Data storage 6 */
    float p17_data_storage_7;  /* 47.17 Data storage 7 */
    float p18_data_storage_8;  /* 47.18 Data storage 8 */
    float p21_data_storage_1;  /* 47.21 Data storage 1 */
    float p22_data_storage_2;  /* 47.22 Data storage 2 */
    float p23_data_storage_3;  /* 47.23 Data storage 3 */
    float p24_data_storage_4;  /* 47.24 Data storage 4 */
    float p25_data_storage_5;  /* 47.25 Data storage 5 */
    float p26_data_storage_6;  /* 47.26 Data storage 6 */
    float p27_data_storage_7;  /* 47.27 Data storage 7 */
    float p28_data_storage_8;  /* 47.28 Data storage 8 */
    float p31_data_storage_1;  /* 47.31 Data storage 1 */
    float p32_data_storage_2;  /* 47.32 Data storage 2 */
    float p33_data_storage_3;  /* 47.33 Data storage 3 */
    float p34_data_storage_4;  /* 47.34 Data storage 4 */
    float p35_data_storage_5;  /* 47.35 Data storage 5 */
    float p36_data_storage_6;  /* 47.36 Data storage 6 */
    float p37_data_storage_7;  /* 47.37 Data storage 7 */
    float p38_data_storage_8;  /* 47.38 Data storage 8 */
} param_group_47_t;

extern param_group_47_t g_param_grp47;

void param_grp47_init(void);
void param_grp47_load_defaults(void);
int  param_grp47_get(uint8_t index, float *out_value);
int  param_grp47_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP47_DATA_STORAGE_H */
