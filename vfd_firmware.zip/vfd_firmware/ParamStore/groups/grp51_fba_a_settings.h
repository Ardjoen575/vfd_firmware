#ifndef VFD_PARAM_GRP51_FBA_A_SETTINGS_H
#define VFD_PARAM_GRP51_FBA_A_SETTINGS_H

/* Parameter group 51: FBA A settings
 * Auto-generated from ACS880 primary control program firmware manual
 * 10 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 51) ---- */
typedef enum {
    PARAM_51_01_FBA_A_TYPE = 1, /* 51.01 FBA A type */
    PARAM_51_02_FBA_A_PAR2 = 2, /* 51.02 FBA A Par2 */
    PARAM_51_26_FBA_A_PAR26 = 26, /* 51.26 FBA A Par26 */
    PARAM_51_27_FBA_A_PAR_REFRESH = 27, /* 51.27 FBA A par refresh */
    PARAM_51_28_FBA_A_PAR_TABLE_VER = 28, /* 51.28 FBA A par table ver */
    PARAM_51_29_FBA_A_DRIVE_TYPE = 29, /* 51.29 FBA A drive type */
    PARAM_51_30_FBA_A_MAPPING_FILE = 30, /* 51.30 FBA A mapping file */
    PARAM_51_31_D2FBA_A_COMM = 31, /* 51.31 D2FBA A comm */
    PARAM_51_32_FBA_A_COMM_SW = 32, /* 51.32 FBA A comm SW */
    PARAM_51_33_FBA_A_APPL_SW_VER = 33, /* 51.33 FBA A appl SW ver */
} param_group_51_index_t;

/* ---- Live value storage (group 51) ---- */
typedef struct {
    float p01_fba_a_type;  /* 51.01 FBA A type */
    float p02_fba_a_par2;  /* 51.02 FBA A Par2 */
    float p26_fba_a_par26;  /* 51.26 FBA A Par26 */
    float p27_fba_a_par_refresh;  /* 51.27 FBA A par refresh */
    float p28_fba_a_par_table_ver;  /* 51.28 FBA A par table ver */
    float p29_fba_a_drive_type;  /* 51.29 FBA A drive type */
    float p30_fba_a_mapping_file;  /* 51.30 FBA A mapping file */
    float p31_d2fba_a_comm;  /* 51.31 D2FBA A comm */
    float p32_fba_a_comm_sw;  /* 51.32 FBA A comm SW */
    float p33_fba_a_appl_sw_ver;  /* 51.33 FBA A appl SW ver */
} param_group_51_t;

extern param_group_51_t g_param_grp51;

void param_grp51_init(void);
void param_grp51_load_defaults(void);
int  param_grp51_get(uint8_t index, float *out_value);
int  param_grp51_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP51_FBA_A_SETTINGS_H */
