#ifndef VFD_PARAM_GRP97_MOTOR_CONTROL_H
#define VFD_PARAM_GRP97_MOTOR_CONTROL_H

/* Parameter group 97: Motor control
 * Auto-generated from ACS880 primary control program firmware manual
 * 18 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 97) ---- */
typedef enum {
    PARAM_97_01_SWITCHING = 1, /* 97.01 Switching */
    PARAM_97_02_MINIMUM_SWITCHING = 2, /* 97.02 Minimum switching */
    PARAM_97_03_SLIP_GAIN = 3, /* 97.03 Slip gain */
    PARAM_97_04_VOLTAGE_RESERVE = 4, /* 97.04 Voltage reserve */
    PARAM_97_05_FLUX_BRAKING = 5, /* 97.05 Flux braking */
    PARAM_97_06_FLUX_REFERENCE = 6, /* 97.06 Flux reference */
    PARAM_97_07_USER_FLUX_REFERENCE = 7, /* 97.07 User flux reference */
    PARAM_97_08_OPTIMIZER_MINIMUM = 8, /* 97.08 Optimizer minimum */
    PARAM_97_09_SWITCHING_FREQ = 9, /* 97.09 Switching freq */
    PARAM_97_10_SIGNAL_INJECTION = 10, /* 97.10 Signal injection */
    PARAM_97_11_TR_TUNING = 11, /* 97.11 TR tuning */
    PARAM_97_12_IR_COMP_STEP_UP = 12, /* 97.12 IR comp step-up */
    PARAM_97_13_IR_COMPENSATION = 13, /* 97.13 IR compensation */
    PARAM_97_15_MOTOR_MODEL = 15, /* 97.15 Motor model */
    PARAM_97_18_HEXAGONAL_FIELD = 18, /* 97.18 Hexagonal field */
    PARAM_97_19_HEXAGONAL_FIELD = 19, /* 97.19 Hexagonal field */
    PARAM_97_32_MOTOR_TORQUE = 32, /* 97.32 Motor torque */
    PARAM_97_33_SPEED_ESTIMATE = 33, /* 97.33 Speed estimate */
} param_group_97_index_t;

/* ---- Live value storage (group 97) ---- */
typedef struct {
    float p01_switching;  /* 97.01 Switching */
    float p02_minimum_switching;  /* 97.02 Minimum switching */
    float p03_slip_gain;  /* 97.03 Slip gain */
    float p04_voltage_reserve;  /* 97.04 Voltage reserve */
    float p05_flux_braking;  /* 97.05 Flux braking */
    float p06_flux_reference;  /* 97.06 Flux reference */
    float p07_user_flux_reference;  /* 97.07 User flux reference */
    float p08_optimizer_minimum;  /* 97.08 Optimizer minimum */
    float p09_switching_freq;  /* 97.09 Switching freq */
    float p10_signal_injection;  /* 97.10 Signal injection */
    float p11_tr_tuning;  /* 97.11 TR tuning */
    float p12_ir_comp_step_up;  /* 97.12 IR comp step-up */
    float p13_ir_compensation;  /* 97.13 IR compensation */
    float p15_motor_model;  /* 97.15 Motor model */
    float p18_hexagonal_field;  /* 97.18 Hexagonal field */
    float p19_hexagonal_field;  /* 97.19 Hexagonal field */
    float p32_motor_torque;  /* 97.32 Motor torque */
    float p33_speed_estimate;  /* 97.33 Speed estimate */
} param_group_97_t;

extern param_group_97_t g_param_grp97;

void param_grp97_init(void);
void param_grp97_load_defaults(void);
int  param_grp97_get(uint8_t index, float *out_value);
int  param_grp97_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP97_MOTOR_CONTROL_H */
