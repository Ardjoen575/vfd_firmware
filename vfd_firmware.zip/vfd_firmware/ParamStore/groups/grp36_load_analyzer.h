#ifndef VFD_PARAM_GRP36_LOAD_ANALYZER_H
#define VFD_PARAM_GRP36_LOAD_ANALYZER_H

/* Parameter group 36: Load analyzer
 * Auto-generated from ACS880 primary control program firmware manual
 * 36 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 36) ---- */
typedef enum {
    PARAM_36_01_PVL_SIGNAL_SOURCE = 1, /* 36.01 PVL signal source */
    PARAM_36_02_PVL_FILTER_TIME = 2, /* 36.02 PVL filter time */
    PARAM_36_06_AL2_SIGNAL_SOURCE = 6, /* 36.06 AL2 signal source */
    PARAM_36_07_AL2_SIGNAL_SCALING = 7, /* 36.07 AL2 signal scaling */
    PARAM_36_08_LOGGER_FUNCTION = 8, /* 36.08 Logger function */
    PARAM_36_09_RESET_LOGGERS = 9, /* 36.09 Reset loggers */
    PARAM_36_10_PVL_PEAK_VALUE = 10, /* 36.10 PVL peak value */
    PARAM_36_11_PVL_PEAK_DATE = 11, /* 36.11 PVL peak date */
    PARAM_36_12_PVL_PEAK_TIME = 12, /* 36.12 PVL peak time */
    PARAM_36_13_PVL_CURRENT_AT_PEAK_DISPLAYS_THE_MOTOR_CURRENT_AT_THE_MOMENT_THE_PEAK_VALUE_WAS = 13, /* 36.13 PVL current at peak Displays the motor current at the moment the peak value was */
    PARAM_36_14_PVL_DC_VOLTAGE_AT = 14, /* 36.14 PVL DC voltage at */
    PARAM_36_15_PVL_SPEED_AT_PEAK = 15, /* 36.15 PVL speed at peak */
    PARAM_36_16_PVL_RESET_DATE = 16, /* 36.16 PVL reset date */
    PARAM_36_17_PVL_RESET_TIME = 17, /* 36.17 PVL reset time */
    PARAM_36_20_AL1_BELOW_10 = 20, /* 36.20 AL1 below 10% */
    PARAM_36_21_AL1_10_TO_20 = 21, /* 36.21 AL1 10 to 20% */
    PARAM_36_22_AL1_20_TO_30 = 22, /* 36.22 AL1 20 to 30% */
    PARAM_36_23_AL1_30_TO_40 = 23, /* 36.23 AL1 30 to 40% */
    PARAM_36_24_AL1_40_TO_50 = 24, /* 36.24 AL1 40 to 50% */
    PARAM_36_25_AL1_50_TO_60 = 25, /* 36.25 AL1 50 to 60% */
    PARAM_36_26_AL1_60_TO_70 = 26, /* 36.26 AL1 60 to 70% */
    PARAM_36_27_AL1_70_TO_80 = 27, /* 36.27 AL1 70 to 80% */
    PARAM_36_28_AL1_80_TO_90 = 28, /* 36.28 AL1 80 to 90% */
    PARAM_36_29_AL1_OVER_90 = 29, /* 36.29 AL1 over 90% */
    PARAM_36_40_AL2_BELOW_10 = 40, /* 36.40 AL2 below 10% */
    PARAM_36_41_AL2_10_TO_20 = 41, /* 36.41 AL2 10 to 20% */
    PARAM_36_42_AL2_20_TO_30 = 42, /* 36.42 AL2 20 to 30% */
    PARAM_36_43_AL2_30_TO_40 = 43, /* 36.43 AL2 30 to 40% */
    PARAM_36_44_AL2_40_TO_50 = 44, /* 36.44 AL2 40 to 50% */
    PARAM_36_45_AL2_50_TO_60 = 45, /* 36.45 AL2 50 to 60% */
    PARAM_36_46_AL2_60_TO_70 = 46, /* 36.46 AL2 60 to 70% */
    PARAM_36_47_AL2_70_TO_80 = 47, /* 36.47 AL2 70 to 80% */
    PARAM_36_48_AL2_80_TO_90 = 48, /* 36.48 AL2 80 to 90% */
    PARAM_36_49_AL2_OVER_90 = 49, /* 36.49 AL2 over 90% */
    PARAM_36_50_AL2_RESET_DATE = 50, /* 36.50 AL2 reset date */
    PARAM_36_51_AL2_RESET_TIME = 51, /* 36.51 AL2 reset time */
} param_group_36_index_t;

/* ---- Live value storage (group 36) ---- */
typedef struct {
    float p01_pvl_signal_source;  /* 36.01 PVL signal source */
    float p02_pvl_filter_time;  /* 36.02 PVL filter time */
    float p06_al2_signal_source;  /* 36.06 AL2 signal source */
    float p07_al2_signal_scaling;  /* 36.07 AL2 signal scaling */
    float p08_logger_function;  /* 36.08 Logger function */
    float p09_reset_loggers;  /* 36.09 Reset loggers */
    float p10_pvl_peak_value;  /* 36.10 PVL peak value */
    float p11_pvl_peak_date;  /* 36.11 PVL peak date */
    float p12_pvl_peak_time;  /* 36.12 PVL peak time */
    float p13_pvl_current_at_peak_displays_the_motor_current_at_the_moment_the_peak_value_was;  /* 36.13 PVL current at peak Displays the motor current at the moment the peak value was */
    float p14_pvl_dc_voltage_at;  /* 36.14 PVL DC voltage at */
    float p15_pvl_speed_at_peak;  /* 36.15 PVL speed at peak */
    float p16_pvl_reset_date;  /* 36.16 PVL reset date */
    float p17_pvl_reset_time;  /* 36.17 PVL reset time */
    float p20_al1_below_10;  /* 36.20 AL1 below 10% */
    float p21_al1_10_to_20;  /* 36.21 AL1 10 to 20% */
    float p22_al1_20_to_30;  /* 36.22 AL1 20 to 30% */
    float p23_al1_30_to_40;  /* 36.23 AL1 30 to 40% */
    float p24_al1_40_to_50;  /* 36.24 AL1 40 to 50% */
    float p25_al1_50_to_60;  /* 36.25 AL1 50 to 60% */
    float p26_al1_60_to_70;  /* 36.26 AL1 60 to 70% */
    float p27_al1_70_to_80;  /* 36.27 AL1 70 to 80% */
    float p28_al1_80_to_90;  /* 36.28 AL1 80 to 90% */
    float p29_al1_over_90;  /* 36.29 AL1 over 90% */
    float p40_al2_below_10;  /* 36.40 AL2 below 10% */
    float p41_al2_10_to_20;  /* 36.41 AL2 10 to 20% */
    float p42_al2_20_to_30;  /* 36.42 AL2 20 to 30% */
    float p43_al2_30_to_40;  /* 36.43 AL2 30 to 40% */
    float p44_al2_40_to_50;  /* 36.44 AL2 40 to 50% */
    float p45_al2_50_to_60;  /* 36.45 AL2 50 to 60% */
    float p46_al2_60_to_70;  /* 36.46 AL2 60 to 70% */
    float p47_al2_70_to_80;  /* 36.47 AL2 70 to 80% */
    float p48_al2_80_to_90;  /* 36.48 AL2 80 to 90% */
    float p49_al2_over_90;  /* 36.49 AL2 over 90% */
    float p50_al2_reset_date;  /* 36.50 AL2 reset date */
    float p51_al2_reset_time;  /* 36.51 AL2 reset time */
} param_group_36_t;

extern param_group_36_t g_param_grp36;

void param_grp36_init(void);
void param_grp36_load_defaults(void);
int  param_grp36_get(uint8_t index, float *out_value);
int  param_grp36_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP36_LOAD_ANALYZER_H */
