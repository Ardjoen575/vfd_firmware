#ifndef VFD_PARAM_GRP28_FREQUENCY_REFERENCE_CHAIN_H
#define VFD_PARAM_GRP28_FREQUENCY_REFERENCE_CHAIN_H

/* Parameter group 28: Frequency reference chain
 * Auto-generated from ACS880 primary control program firmware manual
 * 39 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 28) ---- */
typedef enum {
    PARAM_28_01_FREQUENCY_REF_RAMP = 1, /* 28.01 Frequency ref ramp */
    PARAM_28_02_FREQUENCY_REF_RAMP = 2, /* 28.02 Frequency ref ramp */
    PARAM_28_11_FREQUENCY_REF1 = 11, /* 28.11 Frequency ref1 */
    PARAM_28_12_FREQUENCY_REF2 = 12, /* 28.12 Frequency ref2 */
    PARAM_28_13_FREQUENCY_REF1 = 13, /* 28.13 Frequency ref1 */
    PARAM_28_14_FREQUENCY_REF1_2 = 14, /* 28.14 Frequency ref1/2 */
    PARAM_28_21_CONSTANT_FREQUENCY = 21, /* 28.21 Constant frequency */
    PARAM_28_22_CONSTANT_FREQUENCY = 22, /* 28.22 Constant frequency */
    PARAM_28_23_CONSTANT_FREQUENCY = 23, /* 28.23 Constant frequency */
    PARAM_28_24_CONSTANT_FREQUENCY = 24, /* 28.24 Constant frequency */
    PARAM_28_26_CONSTANT_FREQUENCY = 26, /* 28.26 Constant frequency */
    PARAM_28_27_CONSTANT_FREQUENCY = 27, /* 28.27 Constant frequency */
    PARAM_28_28_CONSTANT_FREQUENCY = 28, /* 28.28 Constant frequency */
    PARAM_28_29_CONSTANT_FREQUENCY = 29, /* 28.29 Constant frequency */
    PARAM_28_30_CONSTANT_FREQUENCY = 30, /* 28.30 Constant frequency */
    PARAM_28_31_CONSTANT_FREQUENCY = 31, /* 28.31 Constant frequency */
    PARAM_28_32_CONSTANT_FREQUENCY = 32, /* 28.32 Constant frequency */
    PARAM_28_41_FREQUENCY_REF_SAFE = 41, /* 28.41 Frequency ref safe */
    PARAM_28_51_CRITICAL_FREQUENCY = 51, /* 28.51 Critical frequency */
    PARAM_28_52_CRITICAL_FREQUENCY_1 = 52, /* 28.52 Critical frequency 1 */
    PARAM_28_53_CRITICAL_FREQUENCY_1 = 53, /* 28.53 Critical frequency 1 */
    PARAM_28_54_CRITICAL_FREQUENCY_2 = 54, /* 28.54 Critical frequency 2 */
    PARAM_28_55_CRITICAL_FREQUENCY_2 = 55, /* 28.55 Critical frequency 2 */
    PARAM_28_56_CRITICAL_FREQUENCY_3 = 56, /* 28.56 Critical frequency 3 */
    PARAM_28_57_CRITICAL_FREQUENCY_3 = 57, /* 28.57 Critical frequency 3 */
    PARAM_28_71_FREQ_RAMP_SET = 71, /* 28.71 Freq ramp set */
    PARAM_28_72_FREQ_ACCELERATION = 72, /* 28.72 Freq acceleration */
    PARAM_28_73_FREQ_DECELERATION = 73, /* 28.73 Freq deceleration */
    PARAM_28_74_FREQ_ACCELERATION = 74, /* 28.74 Freq acceleration */
    PARAM_28_75_FREQ_DECELERATION = 75, /* 28.75 Freq deceleration */
    PARAM_28_76_FREQ_RAMP_IN_ZERO = 76, /* 28.76 Freq ramp in zero */
    PARAM_28_77_FREQ_RAMP_HOLD = 77, /* 28.77 Freq ramp hold */
    PARAM_28_78_FREQ_RAMP_OUTPUT = 78, /* 28.78 Freq ramp output */
    PARAM_28_79_FREQ_RAMP_OUT = 79, /* 28.79 Freq ramp out */
    PARAM_28_90_FREQUENCY_REF_ACT_1 = 90, /* 28.90 Frequency ref act 1 */
    PARAM_28_91_FREQUENCY_REF_ACT_2 = 91, /* 28.91 Frequency ref act 2 */
    PARAM_28_92_FREQUENCY_REF_ACT_3 = 92, /* 28.92 Frequency ref act 3 */
    PARAM_28_96_FREQUENCY_REF_ACT_7 = 96, /* 28.96 Frequency ref act 7 */
    PARAM_28_97_FREQUENCY_REF = 97, /* 28.97 Frequency ref */
} param_group_28_index_t;

/* ---- Live value storage (group 28) ---- */
typedef struct {
    float p01_frequency_ref_ramp;  /* 28.01 Frequency ref ramp */
    float p02_frequency_ref_ramp;  /* 28.02 Frequency ref ramp */
    float p11_frequency_ref1;  /* 28.11 Frequency ref1 */
    float p12_frequency_ref2;  /* 28.12 Frequency ref2 */
    float p13_frequency_ref1;  /* 28.13 Frequency ref1 */
    float p14_frequency_ref1_2;  /* 28.14 Frequency ref1/2 */
    float p21_constant_frequency;  /* 28.21 Constant frequency */
    float p22_constant_frequency;  /* 28.22 Constant frequency */
    float p23_constant_frequency;  /* 28.23 Constant frequency */
    float p24_constant_frequency;  /* 28.24 Constant frequency */
    float p26_constant_frequency;  /* 28.26 Constant frequency */
    float p27_constant_frequency;  /* 28.27 Constant frequency */
    float p28_constant_frequency;  /* 28.28 Constant frequency */
    float p29_constant_frequency;  /* 28.29 Constant frequency */
    float p30_constant_frequency;  /* 28.30 Constant frequency */
    float p31_constant_frequency;  /* 28.31 Constant frequency */
    float p32_constant_frequency;  /* 28.32 Constant frequency */
    float p41_frequency_ref_safe;  /* 28.41 Frequency ref safe */
    float p51_critical_frequency;  /* 28.51 Critical frequency */
    float p52_critical_frequency_1;  /* 28.52 Critical frequency 1 */
    float p53_critical_frequency_1;  /* 28.53 Critical frequency 1 */
    float p54_critical_frequency_2;  /* 28.54 Critical frequency 2 */
    float p55_critical_frequency_2;  /* 28.55 Critical frequency 2 */
    float p56_critical_frequency_3;  /* 28.56 Critical frequency 3 */
    float p57_critical_frequency_3;  /* 28.57 Critical frequency 3 */
    float p71_freq_ramp_set;  /* 28.71 Freq ramp set */
    float p72_freq_acceleration;  /* 28.72 Freq acceleration */
    float p73_freq_deceleration;  /* 28.73 Freq deceleration */
    float p74_freq_acceleration;  /* 28.74 Freq acceleration */
    float p75_freq_deceleration;  /* 28.75 Freq deceleration */
    float p76_freq_ramp_in_zero;  /* 28.76 Freq ramp in zero */
    float p77_freq_ramp_hold;  /* 28.77 Freq ramp hold */
    float p78_freq_ramp_output;  /* 28.78 Freq ramp output */
    float p79_freq_ramp_out;  /* 28.79 Freq ramp out */
    float p90_frequency_ref_act_1;  /* 28.90 Frequency ref act 1 */
    float p91_frequency_ref_act_2;  /* 28.91 Frequency ref act 2 */
    float p92_frequency_ref_act_3;  /* 28.92 Frequency ref act 3 */
    float p96_frequency_ref_act_7;  /* 28.96 Frequency ref act 7 */
    float p97_frequency_ref;  /* 28.97 Frequency ref */
} param_group_28_t;

extern param_group_28_t g_param_grp28;

void param_grp28_init(void);
void param_grp28_load_defaults(void);
int  param_grp28_get(uint8_t index, float *out_value);
int  param_grp28_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP28_FREQUENCY_REFERENCE_CHAIN_H */
