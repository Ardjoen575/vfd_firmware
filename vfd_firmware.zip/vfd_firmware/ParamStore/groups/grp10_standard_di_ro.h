#ifndef VFD_PARAM_GRP10_STANDARD_DI_RO_H
#define VFD_PARAM_GRP10_STANDARD_DI_RO_H

/* Parameter group 10: Standard DI RO
 * Auto-generated from ACS880 primary control program firmware manual
 * 28 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 10) ---- */
typedef enum {
    PARAM_10_01_DI_STATUS = 1, /* 10.01 DI status */
    PARAM_10_02_DI_DELAYED_STATUS = 2, /* 10.02 DI delayed status */
    PARAM_10_03_DI_FORCE_SELECTION = 3, /* 10.03 DI force selection */
    PARAM_10_04_DI_FORCE_DATA = 4, /* 10.04 DI force data */
    PARAM_10_05_DI1_ON_DELAY = 5, /* 10.05 DI1 ON delay */
    PARAM_10_06_DI1_OFF_DELAY = 6, /* 10.06 DI1 OFF delay */
    PARAM_10_07_DI2_ON_DELAY = 7, /* 10.07 DI2 ON delay */
    PARAM_10_08_DI2_OFF_DELAY = 8, /* 10.08 DI2 OFF delay */
    PARAM_10_09_DI3_ON_DELAY = 9, /* 10.09 DI3 ON delay */
    PARAM_10_10_DI3_OFF_DELAY = 10, /* 10.10 DI3 OFF delay */
    PARAM_10_11_DI4_ON_DELAY = 11, /* 10.11 DI4 ON delay */
    PARAM_10_12_DI4_OFF_DELAY = 12, /* 10.12 DI4 OFF delay */
    PARAM_10_13_DI5_ON_DELAY = 13, /* 10.13 DI5 ON delay */
    PARAM_10_14_DI5_OFF_DELAY = 14, /* 10.14 DI5 OFF delay */
    PARAM_10_15_DI6_ON_DELAY = 15, /* 10.15 DI6 ON delay */
    PARAM_10_16_DI6_OFF_DELAY = 16, /* 10.16 DI6 OFF delay */
    PARAM_10_21_RO_STATUS = 21, /* 10.21 RO status */
    PARAM_10_24_RO1_SOURCE = 24, /* 10.24 RO1 source */
    PARAM_10_25_RO1_ON_DELAY = 25, /* 10.25 RO1 ON delay */
    PARAM_10_26_RO1_OFF_DELAY = 26, /* 10.26 RO1 OFF delay */
    PARAM_10_27_RO2_SOURCE = 27, /* 10.27 RO2 source */
    PARAM_10_28_RO2_ON_DELAY = 28, /* 10.28 RO2 ON delay */
    PARAM_10_29_RO2_OFF_DELAY = 29, /* 10.29 RO2 OFF delay */
    PARAM_10_30_RO3_SOURCE = 30, /* 10.30 RO3 source */
    PARAM_10_31_RO3_ON_DELAY = 31, /* 10.31 RO3 ON delay */
    PARAM_10_32_RO3_OFF_DELAY = 32, /* 10.32 RO3 OFF delay */
    PARAM_10_51_DI_FILTER_TIME = 51, /* 10.51 DI filter time */
    PARAM_10_99_RO_DIO_CONTROL = 99, /* 10.99 RO/DIO control */
} param_group_10_index_t;

/* ---- Live value storage (group 10) ---- */
typedef struct {
    float p01_di_status;  /* 10.01 DI status */
    float p02_di_delayed_status;  /* 10.02 DI delayed status */
    float p03_di_force_selection;  /* 10.03 DI force selection */
    float p04_di_force_data;  /* 10.04 DI force data */
    float p05_di1_on_delay;  /* 10.05 DI1 ON delay */
    float p06_di1_off_delay;  /* 10.06 DI1 OFF delay */
    float p07_di2_on_delay;  /* 10.07 DI2 ON delay */
    float p08_di2_off_delay;  /* 10.08 DI2 OFF delay */
    float p09_di3_on_delay;  /* 10.09 DI3 ON delay */
    float p10_di3_off_delay;  /* 10.10 DI3 OFF delay */
    float p11_di4_on_delay;  /* 10.11 DI4 ON delay */
    float p12_di4_off_delay;  /* 10.12 DI4 OFF delay */
    float p13_di5_on_delay;  /* 10.13 DI5 ON delay */
    float p14_di5_off_delay;  /* 10.14 DI5 OFF delay */
    float p15_di6_on_delay;  /* 10.15 DI6 ON delay */
    float p16_di6_off_delay;  /* 10.16 DI6 OFF delay */
    float p21_ro_status;  /* 10.21 RO status */
    float p24_ro1_source;  /* 10.24 RO1 source */
    float p25_ro1_on_delay;  /* 10.25 RO1 ON delay */
    float p26_ro1_off_delay;  /* 10.26 RO1 OFF delay */
    float p27_ro2_source;  /* 10.27 RO2 source */
    float p28_ro2_on_delay;  /* 10.28 RO2 ON delay */
    float p29_ro2_off_delay;  /* 10.29 RO2 OFF delay */
    float p30_ro3_source;  /* 10.30 RO3 source */
    float p31_ro3_on_delay;  /* 10.31 RO3 ON delay */
    float p32_ro3_off_delay;  /* 10.32 RO3 OFF delay */
    float p51_di_filter_time;  /* 10.51 DI filter time */
    float p99_ro_dio_control;  /* 10.99 RO/DIO control */
} param_group_10_t;

extern param_group_10_t g_param_grp10;

void param_grp10_init(void);
void param_grp10_load_defaults(void);
int  param_grp10_get(uint8_t index, float *out_value);
int  param_grp10_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP10_STANDARD_DI_RO_H */
