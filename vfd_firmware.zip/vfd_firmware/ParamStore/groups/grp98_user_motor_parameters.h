#ifndef VFD_PARAM_GRP98_USER_MOTOR_PARAMETERS_H
#define VFD_PARAM_GRP98_USER_MOTOR_PARAMETERS_H

/* Parameter group 98: User motor parameters
 * Auto-generated from ACS880 primary control program firmware manual
 * 15 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 98) ---- */
typedef enum {
    PARAM_98_01_USER_MOTOR_MODEL = 1, /* 98.01 User motor model */
    PARAM_98_02_RS_USER = 2, /* 98.02 Rs user */
    PARAM_98_03_RR_USER = 3, /* 98.03 Rr user */
    PARAM_98_04_LM_USER = 4, /* 98.04 Lm user */
    PARAM_98_05_SIGMAL_USER = 5, /* 98.05 SigmaL user */
    PARAM_98_06_LD_USER = 6, /* 98.06 Ld user */
    PARAM_98_07_LQ_USER = 7, /* 98.07 Lq user */
    PARAM_98_08_PM_FLUX_USER = 8, /* 98.08 PM flux user */
    PARAM_98_09_RS_USER_SI = 9, /* 98.09 Rs user SI */
    PARAM_98_10_RR_USER_SI = 10, /* 98.10 Rr user SI */
    PARAM_98_11_LM_USER_SI = 11, /* 98.11 Lm user SI */
    PARAM_98_12_SIGMAL_USER_SI = 12, /* 98.12 SigmaL user SI */
    PARAM_98_13_LD_USER_SI = 13, /* 98.13 Ld user SI */
    PARAM_98_14_LQ_USER_SI = 14, /* 98.14 Lq user SI */
    PARAM_98_15_POSITION_OFFSET_USER = 15, /* 98.15 Position offset user */
} param_group_98_index_t;

/* ---- Live value storage (group 98) ---- */
typedef struct {
    float p01_user_motor_model;  /* 98.01 User motor model */
    float p02_rs_user;  /* 98.02 Rs user */
    float p03_rr_user;  /* 98.03 Rr user */
    float p04_lm_user;  /* 98.04 Lm user */
    float p05_sigmal_user;  /* 98.05 SigmaL user */
    float p06_ld_user;  /* 98.06 Ld user */
    float p07_lq_user;  /* 98.07 Lq user */
    float p08_pm_flux_user;  /* 98.08 PM flux user */
    float p09_rs_user_si;  /* 98.09 Rs user SI */
    float p10_rr_user_si;  /* 98.10 Rr user SI */
    float p11_lm_user_si;  /* 98.11 Lm user SI */
    float p12_sigmal_user_si;  /* 98.12 SigmaL user SI */
    float p13_ld_user_si;  /* 98.13 Ld user SI */
    float p14_lq_user_si;  /* 98.14 Lq user SI */
    float p15_position_offset_user;  /* 98.15 Position offset user */
} param_group_98_t;

extern param_group_98_t g_param_grp98;

void param_grp98_init(void);
void param_grp98_load_defaults(void);
int  param_grp98_get(uint8_t index, float *out_value);
int  param_grp98_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP98_USER_MOTOR_PARAMETERS_H */
