#ifndef VFD_PARAM_GRP32_SUPERVISION_H
#define VFD_PARAM_GRP32_SUPERVISION_H

/* Parameter group 32: Supervision
 * Auto-generated from ACS880 primary control program firmware manual
 * 19 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 32) ---- */
typedef enum {
    PARAM_32_01_SUPERVISION_STATUS = 1, /* 32.01 Supervision status */
    PARAM_32_05_SUPERVISION_1 = 5, /* 32.05 Supervision 1 */
    PARAM_32_06_SUPERVISION_1 = 6, /* 32.06 Supervision 1 */
    PARAM_32_07_SUPERVISION_1 = 7, /* 32.07 Supervision 1 */
    PARAM_32_08_SUPERVISION_1_FILTER = 8, /* 32.08 Supervision 1 filter */
    PARAM_32_09_SUPERVISION_1_LOW = 9, /* 32.09 Supervision 1 low */
    PARAM_32_10_SUPERVISION_1_HIGH = 10, /* 32.10 Supervision 1 high */
    PARAM_32_15_SUPERVISION_2 = 15, /* 32.15 Supervision 2 */
    PARAM_32_16_SUPERVISION_2 = 16, /* 32.16 Supervision 2 */
    PARAM_32_17_SUPERVISION_2 = 17, /* 32.17 Supervision 2 */
    PARAM_32_18_SUPERVISION_2_FILTER = 18, /* 32.18 Supervision 2 filter */
    PARAM_32_19_SUPERVISION_2_LOW = 19, /* 32.19 Supervision 2 low */
    PARAM_32_20_SUPERVISION_2_HIGH = 20, /* 32.20 Supervision 2 high */
    PARAM_32_25_SUPERVISION_3 = 25, /* 32.25 Supervision 3 */
    PARAM_32_26_SUPERVISION_3 = 26, /* 32.26 Supervision 3 */
    PARAM_32_27_SUPERVISION_3 = 27, /* 32.27 Supervision 3 */
    PARAM_32_28_SUPERVISION_3_FILTER = 28, /* 32.28 Supervision 3 filter */
    PARAM_32_29_SUPERVISION_3_LOW = 29, /* 32.29 Supervision 3 low */
    PARAM_32_30_SUPERVISION_3_HIGH = 30, /* 32.30 Supervision 3 high */
} param_group_32_index_t;

/* ---- Live value storage (group 32) ---- */
typedef struct {
    float p01_supervision_status;  /* 32.01 Supervision status */
    float p05_supervision_1;  /* 32.05 Supervision 1 */
    float p06_supervision_1;  /* 32.06 Supervision 1 */
    float p07_supervision_1;  /* 32.07 Supervision 1 */
    float p08_supervision_1_filter;  /* 32.08 Supervision 1 filter */
    float p09_supervision_1_low;  /* 32.09 Supervision 1 low */
    float p10_supervision_1_high;  /* 32.10 Supervision 1 high */
    float p15_supervision_2;  /* 32.15 Supervision 2 */
    float p16_supervision_2;  /* 32.16 Supervision 2 */
    float p17_supervision_2;  /* 32.17 Supervision 2 */
    float p18_supervision_2_filter;  /* 32.18 Supervision 2 filter */
    float p19_supervision_2_low;  /* 32.19 Supervision 2 low */
    float p20_supervision_2_high;  /* 32.20 Supervision 2 high */
    float p25_supervision_3;  /* 32.25 Supervision 3 */
    float p26_supervision_3;  /* 32.26 Supervision 3 */
    float p27_supervision_3;  /* 32.27 Supervision 3 */
    float p28_supervision_3_filter;  /* 32.28 Supervision 3 filter */
    float p29_supervision_3_low;  /* 32.29 Supervision 3 low */
    float p30_supervision_3_high;  /* 32.30 Supervision 3 high */
} param_group_32_t;

extern param_group_32_t g_param_grp32;

void param_grp32_init(void);
void param_grp32_load_defaults(void);
int  param_grp32_get(uint8_t index, float *out_value);
int  param_grp32_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP32_SUPERVISION_H */
