#ifndef VFD_PARAM_GRP49_PANEL_PORT_COMMUNICATION_H
#define VFD_PARAM_GRP49_PANEL_PORT_COMMUNICATION_H

/* Parameter group 49: Panel port communication
 * Auto-generated from ACS880 primary control program firmware manual
 * 13 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 49) ---- */
typedef enum {
    PARAM_49_01_NODE_ID_NUMBER = 1, /* 49.01 Node ID number */
    PARAM_49_03_BAUD_RATE = 3, /* 49.03 Baud rate */
    PARAM_49_04_COMMUNICATION = 4, /* 49.04 Communication */
    PARAM_49_05_COMMUNICATION = 5, /* 49.05 Communication */
    PARAM_49_06_REFRESH_SETTINGS = 6, /* 49.06 Refresh settings */
    PARAM_49_07_PANEL_COMM = 7, /* 49.07 Panel comm */
    PARAM_49_08_SECONDARY_COMM = 8, /* 49.08 Secondary comm. */
    PARAM_49_14_PANEL_SPEED = 14, /* 49.14 Panel speed */
    PARAM_49_15_MINIMUM_EXT_SPEED = 15, /* 49.15 Minimum ext speed */
    PARAM_49_16_MAXIMUM_EXT = 16, /* 49.16 Maximum ext */
    PARAM_49_17_MINIMUM_EXT = 17, /* 49.17 Minimum ext */
    PARAM_49_18_MAXIMUM_EXT = 18, /* 49.18 Maximum ext */
    PARAM_49_24_PANEL_ACTUAL_SOURCE_SELECTS_AN_ACTUAL_VALUE_TO_BE_DISPLAYED_IN_THE_TOP_RIGHT_CORNER = 24, /* 49.24 Panel actual source Selects an actual value to be displayed in the top right corner */
} param_group_49_index_t;

/* ---- Live value storage (group 49) ---- */
typedef struct {
    float p01_node_id_number;  /* 49.01 Node ID number */
    float p03_baud_rate;  /* 49.03 Baud rate */
    float p04_communication;  /* 49.04 Communication */
    float p05_communication;  /* 49.05 Communication */
    float p06_refresh_settings;  /* 49.06 Refresh settings */
    float p07_panel_comm;  /* 49.07 Panel comm */
    float p08_secondary_comm;  /* 49.08 Secondary comm. */
    float p14_panel_speed;  /* 49.14 Panel speed */
    float p15_minimum_ext_speed;  /* 49.15 Minimum ext speed */
    float p16_maximum_ext;  /* 49.16 Maximum ext */
    float p17_minimum_ext;  /* 49.17 Minimum ext */
    float p18_maximum_ext;  /* 49.18 Maximum ext */
    float p24_panel_actual_source_selects_an_actual_value_to_be_displayed_in_the_top_right_corner;  /* 49.24 Panel actual source Selects an actual value to be displayed in the top right corner */
} param_group_49_t;

extern param_group_49_t g_param_grp49;

void param_grp49_init(void);
void param_grp49_load_defaults(void);
int  param_grp49_get(uint8_t index, float *out_value);
int  param_grp49_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP49_PANEL_PORT_COMMUNICATION_H */
