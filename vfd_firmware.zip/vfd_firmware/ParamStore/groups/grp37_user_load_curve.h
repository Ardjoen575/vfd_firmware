#ifndef VFD_PARAM_GRP37_USER_LOAD_CURVE_H
#define VFD_PARAM_GRP37_USER_LOAD_CURVE_H

/* Parameter group 37: User load curve
 * Auto-generated from ACS880 primary control program firmware manual
 * 26 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 37) ---- */
typedef enum {
    PARAM_37_01_ULC_OUTPUT_STATUS = 1, /* 37.01 ULC output status */
    PARAM_37_02_ULC_SUPERVISION = 2, /* 37.02 ULC supervision */
    PARAM_37_03_ULC_OVERLOAD = 3, /* 37.03 ULC overload */
    PARAM_37_04_ULC_UNDERLOAD = 4, /* 37.04 ULC underload */
    PARAM_37_11_ULC_SPEED_TABLE = 11, /* 37.11 ULC speed table */
    PARAM_37_12_ULC_SPEED_TABLE = 12, /* 37.12 ULC speed table */
    PARAM_37_13_ULC_SPEED_TABLE = 13, /* 37.13 ULC speed table */
    PARAM_37_14_ULC_SPEED_TABLE = 14, /* 37.14 ULC speed table */
    PARAM_37_15_ULC_SPEED_TABLE = 15, /* 37.15 ULC speed table */
    PARAM_37_16_ULC_FREQUENCY = 16, /* 37.16 ULC frequency */
    PARAM_37_17_ULC_FREQUENCY = 17, /* 37.17 ULC frequency */
    PARAM_37_18_ULC_FREQUENCY = 18, /* 37.18 ULC frequency */
    PARAM_37_19_ULC_FREQUENCY = 19, /* 37.19 ULC frequency */
    PARAM_37_20_ULC_FREQUENCY = 20, /* 37.20 ULC frequency */
    PARAM_37_21_ULC_UNDERLOAD = 21, /* 37.21 ULC underload */
    PARAM_37_22_ULC_UNDERLOAD = 22, /* 37.22 ULC underload */
    PARAM_37_23_ULC_UNDERLOAD = 23, /* 37.23 ULC underload */
    PARAM_37_24_ULC_UNDERLOAD = 24, /* 37.24 ULC underload */
    PARAM_37_25_ULC_UNDERLOAD = 25, /* 37.25 ULC underload */
    PARAM_37_31_ULC_OVERLOAD_POINT = 31, /* 37.31 ULC overload point */
    PARAM_37_32_ULC_OVERLOAD_POINT = 32, /* 37.32 ULC overload point */
    PARAM_37_33_ULC_OVERLOAD_POINT = 33, /* 37.33 ULC overload point */
    PARAM_37_34_ULC_OVERLOAD_POINT = 34, /* 37.34 ULC overload point */
    PARAM_37_35_ULC_OVERLOAD_POINT = 35, /* 37.35 ULC overload point */
    PARAM_37_41_ULC_OVERLOAD_TIMER = 41, /* 37.41 ULC overload timer */
    PARAM_37_42_ULC_UNDERLOAD = 42, /* 37.42 ULC underload */
} param_group_37_index_t;

/* ---- Live value storage (group 37) ---- */
typedef struct {
    float p01_ulc_output_status;  /* 37.01 ULC output status */
    float p02_ulc_supervision;  /* 37.02 ULC supervision */
    float p03_ulc_overload;  /* 37.03 ULC overload */
    float p04_ulc_underload;  /* 37.04 ULC underload */
    float p11_ulc_speed_table;  /* 37.11 ULC speed table */
    float p12_ulc_speed_table;  /* 37.12 ULC speed table */
    float p13_ulc_speed_table;  /* 37.13 ULC speed table */
    float p14_ulc_speed_table;  /* 37.14 ULC speed table */
    float p15_ulc_speed_table;  /* 37.15 ULC speed table */
    float p16_ulc_frequency;  /* 37.16 ULC frequency */
    float p17_ulc_frequency;  /* 37.17 ULC frequency */
    float p18_ulc_frequency;  /* 37.18 ULC frequency */
    float p19_ulc_frequency;  /* 37.19 ULC frequency */
    float p20_ulc_frequency;  /* 37.20 ULC frequency */
    float p21_ulc_underload;  /* 37.21 ULC underload */
    float p22_ulc_underload;  /* 37.22 ULC underload */
    float p23_ulc_underload;  /* 37.23 ULC underload */
    float p24_ulc_underload;  /* 37.24 ULC underload */
    float p25_ulc_underload;  /* 37.25 ULC underload */
    float p31_ulc_overload_point;  /* 37.31 ULC overload point */
    float p32_ulc_overload_point;  /* 37.32 ULC overload point */
    float p33_ulc_overload_point;  /* 37.33 ULC overload point */
    float p34_ulc_overload_point;  /* 37.34 ULC overload point */
    float p35_ulc_overload_point;  /* 37.35 ULC overload point */
    float p41_ulc_overload_timer;  /* 37.41 ULC overload timer */
    float p42_ulc_underload;  /* 37.42 ULC underload */
} param_group_37_t;

extern param_group_37_t g_param_grp37;

void param_grp37_init(void);
void param_grp37_load_defaults(void);
int  param_grp37_get(uint8_t index, float *out_value);
int  param_grp37_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP37_USER_LOAD_CURVE_H */
