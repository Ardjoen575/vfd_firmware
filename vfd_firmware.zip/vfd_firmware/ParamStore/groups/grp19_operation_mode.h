#ifndef VFD_PARAM_GRP19_OPERATION_MODE_H
#define VFD_PARAM_GRP19_OPERATION_MODE_H

/* Parameter group 19: Operation mode
 * Auto-generated from ACS880 primary control program firmware manual
 * 7 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 19) ---- */
typedef enum {
    PARAM_19_01_ACTUAL_OPERATION = 1, /* 19.01 Actual operation */
    PARAM_19_11_EXT1_EXT2_SELECTION = 11, /* 19.11 Ext1/Ext2 selection */
    PARAM_19_12_EXT1_CONTROL_MODE = 12, /* 19.12 Ext1 control mode */
    PARAM_19_14_EXT2_CONTROL_MODE = 14, /* 19.14 Ext2 control mode */
    PARAM_19_16_LOCAL_CONTROL_MODE = 16, /* 19.16 Local control mode */
    PARAM_19_17_LOCAL_CONTROL = 17, /* 19.17 Local control */
    PARAM_19_20_SCALAR_CONTROL = 20, /* 19.20 Scalar control */
} param_group_19_index_t;

/* ---- Live value storage (group 19) ---- */
typedef struct {
    float p01_actual_operation;  /* 19.01 Actual operation */
    float p11_ext1_ext2_selection;  /* 19.11 Ext1/Ext2 selection */
    float p12_ext1_control_mode;  /* 19.12 Ext1 control mode */
    float p14_ext2_control_mode;  /* 19.14 Ext2 control mode */
    float p16_local_control_mode;  /* 19.16 Local control mode */
    float p17_local_control;  /* 19.17 Local control */
    float p20_scalar_control;  /* 19.20 Scalar control */
} param_group_19_t;

extern param_group_19_t g_param_grp19;

void param_grp19_init(void);
void param_grp19_load_defaults(void);
int  param_grp19_get(uint8_t index, float *out_value);
int  param_grp19_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP19_OPERATION_MODE_H */
