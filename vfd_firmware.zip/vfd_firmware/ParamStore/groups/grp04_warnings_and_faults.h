#ifndef VFD_PARAM_GRP04_WARNINGS_AND_FAULTS_H
#define VFD_PARAM_GRP04_WARNINGS_AND_FAULTS_H

/* Parameter group 04: Warnings and faults
 * Auto-generated from ACS880 primary control program firmware manual
 * 32 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 04) ---- */
typedef enum {
    PARAM_04_01_TRIPPING_FAULT = 1, /* 04.01 Tripping fault */
    PARAM_04_02_ACTIVE_FAULT_2 = 2, /* 04.02 Active fault 2 */
    PARAM_04_03_ACTIVE_FAULT_3 = 3, /* 04.03 Active fault 3 */
    PARAM_04_04_ACTIVE_FAULT_4 = 4, /* 04.04 Active fault 4 */
    PARAM_04_05_ACTIVE_FAULT_5 = 5, /* 04.05 Active fault 5 */
    PARAM_04_06_ACTIVE_WARNING_1 = 6, /* 04.06 Active warning 1 */
    PARAM_04_07_ACTIVE_WARNING_2 = 7, /* 04.07 Active warning 2 */
    PARAM_04_08_ACTIVE_WARNING_3 = 8, /* 04.08 Active warning 3 */
    PARAM_04_09_ACTIVE_WARNING_4 = 9, /* 04.09 Active warning 4 */
    PARAM_04_10_ACTIVE_WARNING_5 = 10, /* 04.10 Active warning 5 */
    PARAM_04_11_LATEST_FAULT = 11, /* 04.11 Latest fault */
    PARAM_04_12__2ND_LATEST_FAULT = 12, /* 04.12 2nd latest fault */
    PARAM_04_13__3RD_LATEST_FAULT = 13, /* 04.13 3rd latest fault */
    PARAM_04_14__4TH_LATEST_FAULT = 14, /* 04.14 4th latest fault */
    PARAM_04_15__5TH_LATEST_FAULT = 15, /* 04.15 5th latest fault */
    PARAM_04_16_LATEST_WARNING = 16, /* 04.16 Latest warning */
    PARAM_04_17__2ND_LATEST_WARNING = 17, /* 04.17 2nd latest warning */
    PARAM_04_18__3RD_LATEST_WARNING = 18, /* 04.18 3rd latest warning */
    PARAM_04_19__4TH_LATEST_WARNING = 19, /* 04.19 4th latest warning */
    PARAM_04_20__5TH_LATEST_WARNING = 20, /* 04.20 5th latest warning */
    PARAM_04_21_FAULT_WORD_1 = 21, /* 04.21 Fault word 1 */
    PARAM_04_22_FAULT_WORD_2 = 22, /* 04.22 Fault word 2 */
    PARAM_04_25_FAULTED_MODULES = 25, /* 04.25 Faulted modules */
    PARAM_04_31_WARNING_WORD_1 = 31, /* 04.31 Warning word 1 */
    PARAM_04_32_WARNING_WORD_2 = 32, /* 04.32 Warning word 2 */
    PARAM_04_40_EVENT_WORD_1 = 40, /* 04.40 Event word 1 */
    PARAM_04_41_EVENT_WORD_1_BIT_0 = 41, /* 04.41 Event word 1 bit 0 */
    PARAM_04_42_EVENT_WORD_1_BIT_0 = 42, /* 04.42 Event word 1 bit 0 */
    PARAM_04_43_EVENT_WORD_1_BIT_1 = 43, /* 04.43 Event word 1 bit 1 */
    PARAM_04_44_EVENT_WORD_1_BIT_1 = 44, /* 04.44 Event word 1 bit 1 */
    PARAM_04_71_EVENT_WORD_1_BIT_15 = 71, /* 04.71 Event word 1 bit 15 */
    PARAM_04_72_EVENT_WORD_1_BIT_15 = 72, /* 04.72 Event word 1 bit 15 */
} param_group_04_index_t;

/* ---- Live value storage (group 04) ---- */
typedef struct {
    float p01_tripping_fault;  /* 04.01 Tripping fault */
    float p02_active_fault_2;  /* 04.02 Active fault 2 */
    float p03_active_fault_3;  /* 04.03 Active fault 3 */
    float p04_active_fault_4;  /* 04.04 Active fault 4 */
    float p05_active_fault_5;  /* 04.05 Active fault 5 */
    float p06_active_warning_1;  /* 04.06 Active warning 1 */
    float p07_active_warning_2;  /* 04.07 Active warning 2 */
    float p08_active_warning_3;  /* 04.08 Active warning 3 */
    float p09_active_warning_4;  /* 04.09 Active warning 4 */
    float p10_active_warning_5;  /* 04.10 Active warning 5 */
    float p11_latest_fault;  /* 04.11 Latest fault */
    float p12__2nd_latest_fault;  /* 04.12 2nd latest fault */
    float p13__3rd_latest_fault;  /* 04.13 3rd latest fault */
    float p14__4th_latest_fault;  /* 04.14 4th latest fault */
    float p15__5th_latest_fault;  /* 04.15 5th latest fault */
    float p16_latest_warning;  /* 04.16 Latest warning */
    float p17__2nd_latest_warning;  /* 04.17 2nd latest warning */
    float p18__3rd_latest_warning;  /* 04.18 3rd latest warning */
    float p19__4th_latest_warning;  /* 04.19 4th latest warning */
    float p20__5th_latest_warning;  /* 04.20 5th latest warning */
    float p21_fault_word_1;  /* 04.21 Fault word 1 */
    float p22_fault_word_2;  /* 04.22 Fault word 2 */
    float p25_faulted_modules;  /* 04.25 Faulted modules */
    float p31_warning_word_1;  /* 04.31 Warning word 1 */
    float p32_warning_word_2;  /* 04.32 Warning word 2 */
    float p40_event_word_1;  /* 04.40 Event word 1 */
    float p41_event_word_1_bit_0;  /* 04.41 Event word 1 bit 0 */
    float p42_event_word_1_bit_0;  /* 04.42 Event word 1 bit 0 */
    float p43_event_word_1_bit_1;  /* 04.43 Event word 1 bit 1 */
    float p44_event_word_1_bit_1;  /* 04.44 Event word 1 bit 1 */
    float p71_event_word_1_bit_15;  /* 04.71 Event word 1 bit 15 */
    float p72_event_word_1_bit_15;  /* 04.72 Event word 1 bit 15 */
} param_group_04_t;

extern param_group_04_t g_param_grp04;

void param_grp04_init(void);
void param_grp04_load_defaults(void);
int  param_grp04_get(uint8_t index, float *out_value);
int  param_grp04_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP04_WARNINGS_AND_FAULTS_H */
