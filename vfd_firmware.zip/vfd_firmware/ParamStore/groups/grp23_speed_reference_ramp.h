#ifndef VFD_PARAM_GRP23_SPEED_REFERENCE_RAMP_H
#define VFD_PARAM_GRP23_SPEED_REFERENCE_RAMP_H

/* Parameter group 23: Speed reference ramp
 * Auto-generated from ACS880 primary control program firmware manual
 * 23 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 23) ---- */
typedef enum {
    PARAM_23_01_SPEED_REF_RAMP = 1, /* 23.01 Speed ref ramp */
    PARAM_23_02_SPEED_REF_RAMP = 2, /* 23.02 Speed ref ramp */
    PARAM_23_11_RAMP_SET_SELECTION = 11, /* 23.11 Ramp set selection */
    PARAM_23_12_ACCELERATION_TIME_1 = 12, /* 23.12 Acceleration time 1 */
    PARAM_23_13_DECELERATION_TIME_1 = 13, /* 23.13 Deceleration time 1 */
    PARAM_23_14_ACCELERATION_TIME_2 = 14, /* 23.14 Acceleration time 2 */
    PARAM_23_15_DECELERATION_TIME_2 = 15, /* 23.15 Deceleration time 2 */
    PARAM_23_16_SHAPE_TIME_ACC_1 = 16, /* 23.16 Shape time acc 1 */
    PARAM_23_17_SHAPE_TIME_ACC_2 = 17, /* 23.17 Shape time acc 2 */
    PARAM_23_18_SHAPE_TIME_DEC_1 = 18, /* 23.18 Shape time dec 1 */
    PARAM_23_19_SHAPE_TIME_DEC_2 = 19, /* 23.19 Shape time dec 2 */
    PARAM_23_20_ACC_TIME_JOGGING = 20, /* 23.20 Acc time jogging */
    PARAM_23_21_DEC_TIME_JOGGING = 21, /* 23.21 Dec time jogging */
    PARAM_23_23_EMERGENCY_STOP = 23, /* 23.23 Emergency stop */
    PARAM_23_24_SPEED_RAMP_IN_ZERO = 24, /* 23.24 Speed ramp in zero */
    PARAM_23_26_RAMP_OUT_BALANCING = 26, /* 23.26 Ramp out balancing */
    PARAM_23_27_RAMP_OUT_BALANCING = 27, /* 23.27 Ramp out balancing */
    PARAM_23_28_VARIABLE_SLOPE = 28, /* 23.28 Variable slope */
    PARAM_23_29_VARIABLE_SLOPE_RATE = 29, /* 23.29 Variable slope rate */
    PARAM_23_39_FOLLOWER_SPEED = 39, /* 23.39 Follower speed */
    PARAM_23_40_FOLLOWER_SPEED = 40, /* 23.40 Follower speed */
    PARAM_23_41_FOLLOWER_SPEED = 41, /* 23.41 Follower speed */
    PARAM_23_42_FOLLOWER_SPEED_CORR = 42, /* 23.42 Follower speed corr */
} param_group_23_index_t;

/* ---- Live value storage (group 23) ---- */
typedef struct {
    float p01_speed_ref_ramp;  /* 23.01 Speed ref ramp */
    float p02_speed_ref_ramp;  /* 23.02 Speed ref ramp */
    float p11_ramp_set_selection;  /* 23.11 Ramp set selection */
    float p12_acceleration_time_1;  /* 23.12 Acceleration time 1 */
    float p13_deceleration_time_1;  /* 23.13 Deceleration time 1 */
    float p14_acceleration_time_2;  /* 23.14 Acceleration time 2 */
    float p15_deceleration_time_2;  /* 23.15 Deceleration time 2 */
    float p16_shape_time_acc_1;  /* 23.16 Shape time acc 1 */
    float p17_shape_time_acc_2;  /* 23.17 Shape time acc 2 */
    float p18_shape_time_dec_1;  /* 23.18 Shape time dec 1 */
    float p19_shape_time_dec_2;  /* 23.19 Shape time dec 2 */
    float p20_acc_time_jogging;  /* 23.20 Acc time jogging */
    float p21_dec_time_jogging;  /* 23.21 Dec time jogging */
    float p23_emergency_stop;  /* 23.23 Emergency stop */
    float p24_speed_ramp_in_zero;  /* 23.24 Speed ramp in zero */
    float p26_ramp_out_balancing;  /* 23.26 Ramp out balancing */
    float p27_ramp_out_balancing;  /* 23.27 Ramp out balancing */
    float p28_variable_slope;  /* 23.28 Variable slope */
    float p29_variable_slope_rate;  /* 23.29 Variable slope rate */
    float p39_follower_speed;  /* 23.39 Follower speed */
    float p40_follower_speed;  /* 23.40 Follower speed */
    float p41_follower_speed;  /* 23.41 Follower speed */
    float p42_follower_speed_corr;  /* 23.42 Follower speed corr */
} param_group_23_t;

extern param_group_23_t g_param_grp23;

void param_grp23_init(void);
void param_grp23_load_defaults(void);
int  param_grp23_get(uint8_t index, float *out_value);
int  param_grp23_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP23_SPEED_REFERENCE_RAMP_H */
