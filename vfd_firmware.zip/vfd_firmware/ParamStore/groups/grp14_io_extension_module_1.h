#ifndef VFD_PARAM_GRP14_IO_EXTENSION_MODULE_1_H
#define VFD_PARAM_GRP14_IO_EXTENSION_MODULE_1_H

/* Parameter group 14: IO extension module 1
 * Auto-generated from ACS880 primary control program firmware manual
 * 73 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 14) ---- */
typedef enum {
    PARAM_14_01_MODULE_1_TYPE = 1, /* 14.01 Module 1 type */
    PARAM_14_02_MODULE_1_LOCATION = 2, /* 14.02 Module 1 location */
    PARAM_14_03_MODULE_1_STATUS = 3, /* 14.03 Module 1 status */
    PARAM_14_05_DI_STATUS = 5, /* 14.05 DI status */
    PARAM_14_06_DI_DELAYED_STATUS = 6, /* 14.06 DI delayed status */
    PARAM_14_08_DI_FILTER_TIME = 8, /* 14.08 DI filter time */
    PARAM_14_09_DIO1_FUNCTION = 9, /* 14.09 DIO1 function */
    PARAM_14_11_DIO1_OUTPUT_SOURCE = 11, /* 14.11 DIO1 output source */
    PARAM_14_12_DI1_ON_DELAY = 12, /* 14.12 DI1 ON delay */
    PARAM_14_13_DI1_OFF_DELAY = 13, /* 14.13 DI1 OFF delay */
    PARAM_14_14_DIO2_FUNCTION = 14, /* 14.14 DIO2 function */
    PARAM_14_16_DIO2_OUTPUT_SOURCE = 16, /* 14.16 DIO2 output source */
    PARAM_14_17_DI2_ON_DELAY = 17, /* 14.17 DI2 ON delay */
    PARAM_14_18_DI2_OFF_DELAY = 18, /* 14.18 DI2 OFF delay */
    PARAM_14_19_DIO3_FUNCTION = 19, /* 14.19 DIO3 function */
    PARAM_14_20_AI_SUPERVISION = 20, /* 14.20 AI supervision */
    PARAM_14_21_DIO3_OUTPUT_SOURCE = 21, /* 14.21 DIO3 output source */
    PARAM_14_22_DI3_ON_DELAY = 22, /* 14.22 DI3 ON delay */
    PARAM_14_23_DI3_OFF_DELAY = 23, /* 14.23 DI3 OFF delay */
    PARAM_14_24_DIO4_FUNCTION = 24, /* 14.24 DIO4 function */
    PARAM_14_26_DIO4_OUTPUT_SOURCE = 26, /* 14.26 DIO4 output source */
    PARAM_14_27_DIO4_ON_DELAY = 27, /* 14.27 DIO4 ON delay */
    PARAM_14_28_DIO4_OFF_DELAY = 28, /* 14.28 DIO4 OFF delay */
    PARAM_14_29_AI1_HW_SWITCH = 29, /* 14.29 AI1 HW switch */
    PARAM_14_30_AI1_UNIT_SELECTION = 30, /* 14.30 AI1 unit selection */
    PARAM_14_31_RO_STATUS = 31, /* 14.31 RO status */
    PARAM_14_32_AI1_FILTER_TIME = 32, /* 14.32 AI1 filter time */
    PARAM_14_33_AI1_MIN = 33, /* 14.33 AI1 min */
    PARAM_14_34_RO1_SOURCE = 34, /* 14.34 RO1 source */
    PARAM_14_35_RO1_ON_DELAY = 35, /* 14.35 RO1 ON delay */
    PARAM_14_36_RO1_OFF_DELAY = 36, /* 14.36 RO1 OFF delay */
    PARAM_14_37_RO2_SOURCE = 37, /* 14.37 RO2 source */
    PARAM_14_38_RO2_ON_DELAY = 38, /* 14.38 RO2 ON delay */
    PARAM_14_39_RO2_OFF_DELAY = 39, /* 14.39 RO2 OFF delay */
    PARAM_14_41_AI2_ACTUAL_VALUE = 41, /* 14.41 AI2 actual value */
    PARAM_14_42_AI2_SCALED_VALUE = 42, /* 14.42 AI2 scaled value */
    PARAM_14_43_AI2_FORCE_DATA = 43, /* 14.43 AI2 force data */
    PARAM_14_44_AI2_HW_SWITCH = 44, /* 14.44 AI2 HW switch */
    PARAM_14_45_AI2_UNIT_SELECTION = 45, /* 14.45 AI2 unit selection */
    PARAM_14_46_AI2_FILTER_GAIN = 46, /* 14.46 AI2 filter gain */
    PARAM_14_47_AI2_FILTER_TIME = 47, /* 14.47 AI2 filter time */
    PARAM_14_48_AI2_MIN = 48, /* 14.48 AI2 min */
    PARAM_14_49_AI2_MAX = 49, /* 14.49 AI2 max */
    PARAM_14_50_AI2_SCALED_AT_AI2 = 50, /* 14.50 AI2 scaled at AI2 */
    PARAM_14_51_AI2_SCALED_AT_AI2 = 51, /* 14.51 AI2 scaled at AI2 */
    PARAM_14_56_AI3_ACTUAL_VALUE = 56, /* 14.56 AI3 actual value */
    PARAM_14_57_AI3_SCALED_VALUE = 57, /* 14.57 AI3 scaled value */
    PARAM_14_58_AI3_FORCE_DATA = 58, /* 14.58 AI3 force data */
    PARAM_14_59_AI3_HW_SWITCH = 59, /* 14.59 AI3 HW switch */
    PARAM_14_60_AI3_UNIT_SELECTION = 60, /* 14.60 AI3 unit selection */
    PARAM_14_61_AI3_FILTER_GAIN = 61, /* 14.61 AI3 filter gain */
    PARAM_14_62_AI3_FILTER_TIME = 62, /* 14.62 AI3 filter time */
    PARAM_14_63_AI3_MIN = 63, /* 14.63 AI3 min */
    PARAM_14_64_AI3_MAX = 64, /* 14.64 AI3 max */
    PARAM_14_65_AI3_SCALED_AT_AI3 = 65, /* 14.65 AI3 scaled at AI3 */
    PARAM_14_66_AI3_SCALED_AT_AI3 = 66, /* 14.66 AI3 scaled at AI3 */
    PARAM_14_71_AO_FORCE_SELECTION = 71, /* 14.71 AO force selection */
    PARAM_14_76_AO1_ACTUAL_VALUE = 76, /* 14.76 AO1 actual value */
    PARAM_14_77_AO1_SOURCE = 77, /* 14.77 AO1 source */
    PARAM_14_78_AO1_FORCE_DATA = 78, /* 14.78 AO1 force data */
    PARAM_14_79_AO1_FILTER_TIME = 79, /* 14.79 AO1 filter time */
    PARAM_14_80_AO1_SOURCE_MIN = 80, /* 14.80 AO1 source min */
    PARAM_14_81_AO1_SOURCE_MAX = 81, /* 14.81 AO1 source max */
    PARAM_14_82_AO1_OUT_AT_AO1_SRC = 82, /* 14.82 AO1 out at AO1 src */
    PARAM_14_83_AO1_OUT_AT_AO1_SRC = 83, /* 14.83 AO1 out at AO1 src */
    PARAM_14_86_AO2_ACTUAL_VALUE = 86, /* 14.86 AO2 actual value */
    PARAM_14_87_AO2_SOURCE = 87, /* 14.87 AO2 source */
    PARAM_14_88_AO2_FORCE_DATA = 88, /* 14.88 AO2 force data */
    PARAM_14_89_AO2_FILTER_TIME = 89, /* 14.89 AO2 filter time */
    PARAM_14_90_AO2_SOURCE_MIN = 90, /* 14.90 AO2 source min */
    PARAM_14_91_AO2_SOURCE_MAX = 91, /* 14.91 AO2 source max */
    PARAM_14_92_AO2_OUT_AT_AO2_SRC = 92, /* 14.92 AO2 out at AO2 src */
    PARAM_14_93_AO2_OUT_AT_AO2_SRC = 93, /* 14.93 AO2 out at AO2 src */
} param_group_14_index_t;

/* ---- Live value storage (group 14) ---- */
typedef struct {
    float p01_module_1_type;  /* 14.01 Module 1 type */
    float p02_module_1_location;  /* 14.02 Module 1 location */
    float p03_module_1_status;  /* 14.03 Module 1 status */
    float p05_di_status;  /* 14.05 DI status */
    float p06_di_delayed_status;  /* 14.06 DI delayed status */
    float p08_di_filter_time;  /* 14.08 DI filter time */
    float p09_dio1_function;  /* 14.09 DIO1 function */
    float p11_dio1_output_source;  /* 14.11 DIO1 output source */
    float p12_di1_on_delay;  /* 14.12 DI1 ON delay */
    float p13_di1_off_delay;  /* 14.13 DI1 OFF delay */
    float p14_dio2_function;  /* 14.14 DIO2 function */
    float p16_dio2_output_source;  /* 14.16 DIO2 output source */
    float p17_di2_on_delay;  /* 14.17 DI2 ON delay */
    float p18_di2_off_delay;  /* 14.18 DI2 OFF delay */
    float p19_dio3_function;  /* 14.19 DIO3 function */
    float p20_ai_supervision;  /* 14.20 AI supervision */
    float p21_dio3_output_source;  /* 14.21 DIO3 output source */
    float p22_di3_on_delay;  /* 14.22 DI3 ON delay */
    float p23_di3_off_delay;  /* 14.23 DI3 OFF delay */
    float p24_dio4_function;  /* 14.24 DIO4 function */
    float p26_dio4_output_source;  /* 14.26 DIO4 output source */
    float p27_dio4_on_delay;  /* 14.27 DIO4 ON delay */
    float p28_dio4_off_delay;  /* 14.28 DIO4 OFF delay */
    float p29_ai1_hw_switch;  /* 14.29 AI1 HW switch */
    float p30_ai1_unit_selection;  /* 14.30 AI1 unit selection */
    float p31_ro_status;  /* 14.31 RO status */
    float p32_ai1_filter_time;  /* 14.32 AI1 filter time */
    float p33_ai1_min;  /* 14.33 AI1 min */
    float p34_ro1_source;  /* 14.34 RO1 source */
    float p35_ro1_on_delay;  /* 14.35 RO1 ON delay */
    float p36_ro1_off_delay;  /* 14.36 RO1 OFF delay */
    float p37_ro2_source;  /* 14.37 RO2 source */
    float p38_ro2_on_delay;  /* 14.38 RO2 ON delay */
    float p39_ro2_off_delay;  /* 14.39 RO2 OFF delay */
    float p41_ai2_actual_value;  /* 14.41 AI2 actual value */
    float p42_ai2_scaled_value;  /* 14.42 AI2 scaled value */
    float p43_ai2_force_data;  /* 14.43 AI2 force data */
    float p44_ai2_hw_switch;  /* 14.44 AI2 HW switch */
    float p45_ai2_unit_selection;  /* 14.45 AI2 unit selection */
    float p46_ai2_filter_gain;  /* 14.46 AI2 filter gain */
    float p47_ai2_filter_time;  /* 14.47 AI2 filter time */
    float p48_ai2_min;  /* 14.48 AI2 min */
    float p49_ai2_max;  /* 14.49 AI2 max */
    float p50_ai2_scaled_at_ai2;  /* 14.50 AI2 scaled at AI2 */
    float p51_ai2_scaled_at_ai2;  /* 14.51 AI2 scaled at AI2 */
    float p56_ai3_actual_value;  /* 14.56 AI3 actual value */
    float p57_ai3_scaled_value;  /* 14.57 AI3 scaled value */
    float p58_ai3_force_data;  /* 14.58 AI3 force data */
    float p59_ai3_hw_switch;  /* 14.59 AI3 HW switch */
    float p60_ai3_unit_selection;  /* 14.60 AI3 unit selection */
    float p61_ai3_filter_gain;  /* 14.61 AI3 filter gain */
    float p62_ai3_filter_time;  /* 14.62 AI3 filter time */
    float p63_ai3_min;  /* 14.63 AI3 min */
    float p64_ai3_max;  /* 14.64 AI3 max */
    float p65_ai3_scaled_at_ai3;  /* 14.65 AI3 scaled at AI3 */
    float p66_ai3_scaled_at_ai3;  /* 14.66 AI3 scaled at AI3 */
    float p71_ao_force_selection;  /* 14.71 AO force selection */
    float p76_ao1_actual_value;  /* 14.76 AO1 actual value */
    float p77_ao1_source;  /* 14.77 AO1 source */
    float p78_ao1_force_data;  /* 14.78 AO1 force data */
    float p79_ao1_filter_time;  /* 14.79 AO1 filter time */
    float p80_ao1_source_min;  /* 14.80 AO1 source min */
    float p81_ao1_source_max;  /* 14.81 AO1 source max */
    float p82_ao1_out_at_ao1_src;  /* 14.82 AO1 out at AO1 src */
    float p83_ao1_out_at_ao1_src;  /* 14.83 AO1 out at AO1 src */
    float p86_ao2_actual_value;  /* 14.86 AO2 actual value */
    float p87_ao2_source;  /* 14.87 AO2 source */
    float p88_ao2_force_data;  /* 14.88 AO2 force data */
    float p89_ao2_filter_time;  /* 14.89 AO2 filter time */
    float p90_ao2_source_min;  /* 14.90 AO2 source min */
    float p91_ao2_source_max;  /* 14.91 AO2 source max */
    float p92_ao2_out_at_ao2_src;  /* 14.92 AO2 out at AO2 src */
    float p93_ao2_out_at_ao2_src;  /* 14.93 AO2 out at AO2 src */
} param_group_14_t;

extern param_group_14_t g_param_grp14;

void param_grp14_init(void);
void param_grp14_load_defaults(void);
int  param_grp14_get(uint8_t index, float *out_value);
int  param_grp14_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP14_IO_EXTENSION_MODULE_1_H */
