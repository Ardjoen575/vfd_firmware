#ifndef VFD_PARAM_GRP21_START_STOP_MODE_H
#define VFD_PARAM_GRP21_START_STOP_MODE_H

/* Parameter group 21: Start stop mode
 * Auto-generated from ACS880 primary control program firmware manual
 * 18 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 21) ---- */
typedef enum {
    PARAM_21_01_START_MODE = 1, /* 21.01 Start mode */
    PARAM_21_02_MAGNETIZATION_TIME = 2, /* 21.02 Magnetization time */
    PARAM_21_03_STOP_MODE = 3, /* 21.03 Stop mode */
    PARAM_21_04_EMERGENCY_STOP = 4, /* 21.04 Emergency stop */
    PARAM_21_05_EMERGENCY_STOP = 5, /* 21.05 Emergency stop */
    PARAM_21_06_ZERO_SPEED_LIMIT = 6, /* 21.06 Zero speed limit */
    PARAM_21_07_ZERO_SPEED_DELAY = 7, /* 21.07 Zero speed delay */
    PARAM_21_08_DC_CURRENT_CONTROL = 8, /* 21.08 DC current control */
    PARAM_21_09_DC_HOLD_SPEED = 9, /* 21.09 DC hold speed */
    PARAM_21_10_DC_CURRENT = 10, /* 21.10 DC current */
    PARAM_21_11_POST_MAGNETIZATION = 11, /* 21.11 Post magnetization */
    PARAM_21_12_CONTINUOUS = 12, /* 21.12 Continuous */
    PARAM_21_13_AUTOPHASING_MODE = 13, /* 21.13 Autophasing mode */
    PARAM_21_14_PRE_HEATING_INPUT = 14, /* 21.14 Pre-heating input */
    PARAM_21_16_PRE_HEATING_CURRENT = 16, /* 21.16 Pre-heating current */
    PARAM_21_18_AUTO_RESTART_TIME = 18, /* 21.18 Auto restart time */
    PARAM_21_19_SCALAR_START_MODE = 19, /* 21.19 Scalar start mode */
    PARAM_21_20_FOLLOWER_FORCE_RAMP = 20, /* 21.20 Follower force ramp */
} param_group_21_index_t;

/* ---- Live value storage (group 21) ---- */
typedef struct {
    float p01_start_mode;  /* 21.01 Start mode */
    float p02_magnetization_time;  /* 21.02 Magnetization time */
    float p03_stop_mode;  /* 21.03 Stop mode */
    float p04_emergency_stop;  /* 21.04 Emergency stop */
    float p05_emergency_stop;  /* 21.05 Emergency stop */
    float p06_zero_speed_limit;  /* 21.06 Zero speed limit */
    float p07_zero_speed_delay;  /* 21.07 Zero speed delay */
    float p08_dc_current_control;  /* 21.08 DC current control */
    float p09_dc_hold_speed;  /* 21.09 DC hold speed */
    float p10_dc_current;  /* 21.10 DC current */
    float p11_post_magnetization;  /* 21.11 Post magnetization */
    float p12_continuous;  /* 21.12 Continuous */
    float p13_autophasing_mode;  /* 21.13 Autophasing mode */
    float p14_pre_heating_input;  /* 21.14 Pre-heating input */
    float p16_pre_heating_current;  /* 21.16 Pre-heating current */
    float p18_auto_restart_time;  /* 21.18 Auto restart time */
    float p19_scalar_start_mode;  /* 21.19 Scalar start mode */
    float p20_follower_force_ramp;  /* 21.20 Follower force ramp */
} param_group_21_t;

extern param_group_21_t g_param_grp21;

void param_grp21_init(void);
void param_grp21_load_defaults(void);
int  param_grp21_get(uint8_t index, float *out_value);
int  param_grp21_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP21_START_STOP_MODE_H */
