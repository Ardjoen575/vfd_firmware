#ifndef VFD_PARAM_GRP56_FBA_B_DATA_OUT_H
#define VFD_PARAM_GRP56_FBA_B_DATA_OUT_H

/* Parameter group 56: FBA B data out
 * Auto-generated from ACS880 primary control program firmware manual
 * 2 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 56) ---- */
typedef enum {
    PARAM_56_01_FBA_B_DATA_OUT1 = 1, /* 56.01 FBA B data out1 */
    PARAM_56_12_FBA_B_DATA_OUT12 = 12, /* 56.12 FBA B data out12 */
} param_group_56_index_t;

/* ---- Live value storage (group 56) ---- */
typedef struct {
    float p01_fba_b_data_out1;  /* 56.01 FBA B data out1 */
    float p12_fba_b_data_out12;  /* 56.12 FBA B data out12 */
} param_group_56_t;

extern param_group_56_t g_param_grp56;

void param_grp56_init(void);
void param_grp56_load_defaults(void);
int  param_grp56_get(uint8_t index, float *out_value);
int  param_grp56_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP56_FBA_B_DATA_OUT_H */
