#ifndef VFD_PARAM_GRP96_SYSTEM_H
#define VFD_PARAM_GRP96_SYSTEM_H

/* Parameter group 96: System
 * Auto-generated from ACS880 primary control program firmware manual
 * 35 parameters
 */

#include <stdint.h>

/* ---- Parameter index enum (group 96) ---- */
typedef enum {
    PARAM_96_01_LANGUAGE = 1, /* 96.01 Language */
    PARAM_96_02_PASS_CODE = 2, /* 96.02 Pass code */
    PARAM_96_03_ACCESS_LEVELS = 3, /* 96.03 Access levels */
    PARAM_96_04_MACRO_SELECT = 4, /* 96.04 Macro select */
    PARAM_96_05_MACRO_ACTIVE = 5, /* 96.05 Macro active */
    PARAM_96_06_PARAMETER_RESTORE = 6, /* 96.06 Parameter restore */
    PARAM_96_07_PARAMETER_SAVE = 7, /* 96.07 Parameter save */
    PARAM_96_08_CONTROL_BOARD_BOOT = 8, /* 96.08 Control board boot */
    PARAM_96_09_FSO_REBOOT = 9, /* 96.09 FSO reboot */
    PARAM_96_10_USER_SET_STATUS = 10, /* 96.10 User set status */
    PARAM_96_11_USER_SET_SAVE_LOAD = 11, /* 96.11 User set save/load */
    PARAM_96_12_USER_SET_I_O_MODE = 12, /* 96.12 User set I/O mode */
    PARAM_96_13_USER_SET_I_O_MODE = 13, /* 96.13 User set I/O mode */
    PARAM_96_16_UNIT_SELECTION = 16, /* 96.16 Unit selection */
    PARAM_96_20_TIME_SYNC_PRIMARY = 20, /* 96.20 Time sync primary */
    PARAM_96_23_M_F_AND_D2D_CLOCK = 23, /* 96.23 M/F and D2D clock */
    PARAM_96_24_FULL_DAYS_SINCE_1ST = 24, /* 96.24 Full days since 1st */
    PARAM_96_25_TIME_IN_MINUTES = 25, /* 96.25 Time in minutes */
    PARAM_96_26_TIME_IN_MS_WITHIN = 26, /* 96.26 Time in ms within */
    PARAM_96_29_TIME_SYNC_SOURCE = 29, /* 96.29 Time sync source */
    PARAM_96_31_DRIVE_ID_NUMBER = 31, /* 96.31 Drive ID number */
    PARAM_96_39_POWER_UP_EVENT = 39, /* 96.39 Power up event */
    PARAM_96_51_CLEAR_FAULT_AND = 51, /* 96.51 Clear fault and */
    PARAM_96_53_ACTUAL_CHECKSUM = 53, /* 96.53 Actual checksum */
    PARAM_96_54_CHECKSUM_ACTION = 54, /* 96.54 Checksum action */
    PARAM_96_55_CHECKSUM_CONTROL = 55, /* 96.55 Checksum control */
    PARAM_96_56_APPROVED = 56, /* 96.56 Approved */
    PARAM_96_57_APPROVED = 57, /* 96.57 Approved */
    PARAM_96_58_APPROVED = 58, /* 96.58 Approved */
    PARAM_96_59_APPROVED = 59, /* 96.59 Approved */
    PARAM_96_61_USER_DATA_LOGGER = 61, /* 96.61 User data logger */
    PARAM_96_63_USER_DATA_LOGGER = 63, /* 96.63 User data logger */
    PARAM_96_64_USER_DATA_LOGGER = 64, /* 96.64 User data logger */
    PARAM_96_65_FACTORY_DATA_LOGGER = 65, /* 96.65 Factory data logger */
    PARAM_96_70_DISABLE_ADAPTIVE = 70, /* 96.70 Disable adaptive */
} param_group_96_index_t;

/* ---- Live value storage (group 96) ---- */
typedef struct {
    float p01_language;  /* 96.01 Language */
    float p02_pass_code;  /* 96.02 Pass code */
    float p03_access_levels;  /* 96.03 Access levels */
    float p04_macro_select;  /* 96.04 Macro select */
    float p05_macro_active;  /* 96.05 Macro active */
    float p06_parameter_restore;  /* 96.06 Parameter restore */
    float p07_parameter_save;  /* 96.07 Parameter save */
    float p08_control_board_boot;  /* 96.08 Control board boot */
    float p09_fso_reboot;  /* 96.09 FSO reboot */
    float p10_user_set_status;  /* 96.10 User set status */
    float p11_user_set_save_load;  /* 96.11 User set save/load */
    float p12_user_set_i_o_mode;  /* 96.12 User set I/O mode */
    float p13_user_set_i_o_mode;  /* 96.13 User set I/O mode */
    float p16_unit_selection;  /* 96.16 Unit selection */
    float p20_time_sync_primary;  /* 96.20 Time sync primary */
    float p23_m_f_and_d2d_clock;  /* 96.23 M/F and D2D clock */
    float p24_full_days_since_1st;  /* 96.24 Full days since 1st */
    float p25_time_in_minutes;  /* 96.25 Time in minutes */
    float p26_time_in_ms_within;  /* 96.26 Time in ms within */
    float p29_time_sync_source;  /* 96.29 Time sync source */
    float p31_drive_id_number;  /* 96.31 Drive ID number */
    float p39_power_up_event;  /* 96.39 Power up event */
    float p51_clear_fault_and;  /* 96.51 Clear fault and */
    float p53_actual_checksum;  /* 96.53 Actual checksum */
    float p54_checksum_action;  /* 96.54 Checksum action */
    float p55_checksum_control;  /* 96.55 Checksum control */
    float p56_approved;  /* 96.56 Approved */
    float p57_approved;  /* 96.57 Approved */
    float p58_approved;  /* 96.58 Approved */
    float p59_approved;  /* 96.59 Approved */
    float p61_user_data_logger;  /* 96.61 User data logger */
    float p63_user_data_logger;  /* 96.63 User data logger */
    float p64_user_data_logger;  /* 96.64 User data logger */
    float p65_factory_data_logger;  /* 96.65 Factory data logger */
    float p70_disable_adaptive;  /* 96.70 Disable adaptive */
} param_group_96_t;

extern param_group_96_t g_param_grp96;

void param_grp96_init(void);
void param_grp96_load_defaults(void);
int  param_grp96_get(uint8_t index, float *out_value);
int  param_grp96_set(uint8_t index, float value);

#endif /* VFD_PARAM_GRP96_SYSTEM_H */
