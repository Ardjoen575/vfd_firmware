#ifndef PARAMSTORE_DATA_STORAGE_PARAMS_H
#define PARAMSTORE_DATA_STORAGE_PARAMS_H

/* Data storage parameters (grp 47) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} data_storage_params_state_t;

void data_storage_params_init(data_storage_params_state_t *state);
void data_storage_params_update(data_storage_params_state_t *state);
void data_storage_get(data_storage_params_state_t *state);
void data_storage_set(data_storage_params_state_t *state);

#endif /* PARAMSTORE_DATA_STORAGE_PARAMS_H */
