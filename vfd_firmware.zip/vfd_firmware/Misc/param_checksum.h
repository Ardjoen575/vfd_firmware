#ifndef MISC_PARAM_CHECKSUM_H
#define MISC_PARAM_CHECKSUM_H

/* Parameter checksum calculation */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} param_checksum_state_t;

void param_checksum_init(param_checksum_state_t *state);
void param_checksum_update(param_checksum_state_t *state);
void param_checksum_compute(param_checksum_state_t *state);

#endif /* MISC_PARAM_CHECKSUM_H */
