#ifndef MISC_REDUCED_RUN_H
#define MISC_REDUCED_RUN_H

/* Reduced run function */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} reduced_run_state_t;

void reduced_run_init(reduced_run_state_t *state);
void reduced_run_update(reduced_run_state_t *state);
void reduced_run_apply(reduced_run_state_t *state);

#endif /* MISC_REDUCED_RUN_H */
