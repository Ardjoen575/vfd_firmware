#ifndef MISC_USER_PARAMETER_SETS_H
#define MISC_USER_PARAMETER_SETS_H

/* User parameter sets save/load */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} user_parameter_sets_state_t;

void user_parameter_sets_init(user_parameter_sets_state_t *state);
void user_parameter_sets_update(user_parameter_sets_state_t *state);
void userset_save(user_parameter_sets_state_t *state);
void userset_load(user_parameter_sets_state_t *state);

#endif /* MISC_USER_PARAMETER_SETS_H */
