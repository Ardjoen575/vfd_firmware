#ifndef MISC_ROUTER_MODE_BCU_H
#define MISC_ROUTER_MODE_BCU_H

/* Router mode for BCU control unit */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} router_mode_bcu_state_t;

void router_mode_bcu_init(router_mode_bcu_state_t *state);
void router_mode_bcu_update(router_mode_bcu_state_t *state);
void router_mode_forward(router_mode_bcu_state_t *state);

#endif /* MISC_ROUTER_MODE_BCU_H */
