#ifndef MISC_USER_LOCK_H
#define MISC_USER_LOCK_H

/* User lock function */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} user_lock_state_t;

void user_lock_init(user_lock_state_t *state);
void user_lock_update(user_lock_state_t *state);
void user_lock_check_pin(user_lock_state_t *state);

#endif /* MISC_USER_LOCK_H */
