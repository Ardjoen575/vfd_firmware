#ifndef DIAGNOSTICS_EDITABLE_MESSAGES_H
#define DIAGNOSTICS_EDITABLE_MESSAGES_H

/* Editable message support */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} editable_messages_state_t;

void editable_messages_init(editable_messages_state_t *state);
void editable_messages_update(editable_messages_state_t *state);
void editable_msg_set(editable_messages_state_t *state);

#endif /* DIAGNOSTICS_EDITABLE_MESSAGES_H */
