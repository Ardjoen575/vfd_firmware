#ifndef DIAGNOSTICS_MAINTENANCE_COUNTERS_H
#define DIAGNOSTICS_MAINTENANCE_COUNTERS_H

/* Maintenance timers and counters */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} maintenance_counters_state_t;

void maintenance_counters_init(maintenance_counters_state_t *state);
void maintenance_counters_update(maintenance_counters_state_t *state);
void maint_counter_tick(maintenance_counters_state_t *state);

#endif /* DIAGNOSTICS_MAINTENANCE_COUNTERS_H */
