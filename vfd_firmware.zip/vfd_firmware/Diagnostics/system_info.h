#ifndef DIAGNOSTICS_SYSTEM_INFO_H
#define DIAGNOSTICS_SYSTEM_INFO_H

/* System info (grp 07) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} system_info_state_t;

void system_info_init(system_info_state_t *state);
void system_info_update(system_info_state_t *state);
void sysinfo_update(system_info_state_t *state);

#endif /* DIAGNOSTICS_SYSTEM_INFO_H */
