#ifndef DIAGNOSTICS_CONTROL_STATUS_WORDS_H
#define DIAGNOSTICS_CONTROL_STATUS_WORDS_H

/* Control and status words (grp 06) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} control_status_words_state_t;

void control_status_words_init(control_status_words_state_t *state);
void control_status_words_update(control_status_words_state_t *state);
void ctrlstatus_update(control_status_words_state_t *state);

#endif /* DIAGNOSTICS_CONTROL_STATUS_WORDS_H */
