#ifndef DIAGNOSTICS_WARNINGS_FAULTS_H
#define DIAGNOSTICS_WARNINGS_FAULTS_H

/* Warnings and faults tracking (grp 04) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} warnings_faults_state_t;

void warnings_faults_init(warnings_faults_state_t *state);
void warnings_faults_update(warnings_faults_state_t *state);
void warnfault_update(warnings_faults_state_t *state);

#endif /* DIAGNOSTICS_WARNINGS_FAULTS_H */
