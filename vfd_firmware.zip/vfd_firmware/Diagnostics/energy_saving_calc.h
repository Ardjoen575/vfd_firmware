#ifndef DIAGNOSTICS_ENERGY_SAVING_CALC_H
#define DIAGNOSTICS_ENERGY_SAVING_CALC_H

/* Energy saving calculators (grp 45) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} energy_saving_calc_state_t;

void energy_saving_calc_init(energy_saving_calc_state_t *state);
void energy_saving_calc_update(energy_saving_calc_state_t *state);
void energy_calc_update(energy_saving_calc_state_t *state);

#endif /* DIAGNOSTICS_ENERGY_SAVING_CALC_H */
