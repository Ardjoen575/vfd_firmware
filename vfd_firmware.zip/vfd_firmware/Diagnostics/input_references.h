#ifndef DIAGNOSTICS_INPUT_REFERENCES_H
#define DIAGNOSTICS_INPUT_REFERENCES_H

/* Input references (grp 03) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} input_references_state_t;

void input_references_init(input_references_state_t *state);
void input_references_update(input_references_state_t *state);
void inputref_update(input_references_state_t *state);

#endif /* DIAGNOSTICS_INPUT_REFERENCES_H */
