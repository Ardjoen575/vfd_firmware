#ifndef DIAGNOSTICS_RUNTIME_STATS_H
#define DIAGNOSTICS_RUNTIME_STATS_H

/* kWh, hours, run counters */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} runtime_stats_state_t;

void runtime_stats_init(runtime_stats_state_t *state);
void runtime_stats_update(runtime_stats_state_t *state);
void runtime_stats_tick(runtime_stats_state_t *state);

#endif /* DIAGNOSTICS_RUNTIME_STATS_H */
