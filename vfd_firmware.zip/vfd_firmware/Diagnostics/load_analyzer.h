#ifndef DIAGNOSTICS_LOAD_ANALYZER_H
#define DIAGNOSTICS_LOAD_ANALYZER_H

/* Load analyzer (grp 36) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} load_analyzer_state_t;

void load_analyzer_init(load_analyzer_state_t *state);
void load_analyzer_update(load_analyzer_state_t *state);
void load_analyzer_sample(load_analyzer_state_t *state);

#endif /* DIAGNOSTICS_LOAD_ANALYZER_H */
