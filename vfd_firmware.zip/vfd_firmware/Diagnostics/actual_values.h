#ifndef DIAGNOSTICS_ACTUAL_VALUES_H
#define DIAGNOSTICS_ACTUAL_VALUES_H

/* Actual values group (grp 01) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} actual_values_state_t;

void actual_values_init(actual_values_state_t *state);
void actual_values_update(actual_values_state_t *state);
void actval_update_all(actual_values_state_t *state);

#endif /* DIAGNOSTICS_ACTUAL_VALUES_H */
