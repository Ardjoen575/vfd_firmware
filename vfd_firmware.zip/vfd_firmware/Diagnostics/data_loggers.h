#ifndef DIAGNOSTICS_DATA_LOGGERS_H
#define DIAGNOSTICS_DATA_LOGGERS_H

/* Other data loggers */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} data_loggers_state_t;

void data_loggers_init(data_loggers_state_t *state);
void data_loggers_update(data_loggers_state_t *state);
void data_logger_capture(data_loggers_state_t *state);

#endif /* DIAGNOSTICS_DATA_LOGGERS_H */
