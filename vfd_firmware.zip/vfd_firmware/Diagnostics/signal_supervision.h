#ifndef DIAGNOSTICS_SIGNAL_SUPERVISION_H
#define DIAGNOSTICS_SIGNAL_SUPERVISION_H

/* Signal supervision (grp 32) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} signal_supervision_state_t;

void signal_supervision_init(signal_supervision_state_t *state);
void signal_supervision_update(signal_supervision_state_t *state);
void supervision_check(signal_supervision_state_t *state);

#endif /* DIAGNOSTICS_SIGNAL_SUPERVISION_H */
