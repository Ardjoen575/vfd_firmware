#ifndef DIAGNOSTICS_WARNING_CODE_TABLE_H
#define DIAGNOSTICS_WARNING_CODE_TABLE_H

/* Warning message code table */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} warning_code_table_state_t;

void warning_code_table_init(warning_code_table_state_t *state);
void warning_code_table_update(warning_code_table_state_t *state);
void warning_code_lookup(warning_code_table_state_t *state);

#endif /* DIAGNOSTICS_WARNING_CODE_TABLE_H */
