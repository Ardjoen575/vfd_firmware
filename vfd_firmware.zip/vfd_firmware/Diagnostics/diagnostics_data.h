#ifndef DIAGNOSTICS_DIAGNOSTICS_DATA_H
#define DIAGNOSTICS_DIAGNOSTICS_DATA_H

/* Diagnostics data (grp 05) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} diagnostics_data_state_t;

void diagnostics_data_init(diagnostics_data_state_t *state);
void diagnostics_data_update(diagnostics_data_state_t *state);
void diag_update(diagnostics_data_state_t *state);

#endif /* DIAGNOSTICS_DIAGNOSTICS_DATA_H */
