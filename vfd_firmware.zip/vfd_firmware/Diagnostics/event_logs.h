#ifndef DIAGNOSTICS_EVENT_LOGS_H
#define DIAGNOSTICS_EVENT_LOGS_H

/* Event logs (faults/warnings/pure events) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} event_logs_state_t;

void event_logs_init(event_logs_state_t *state);
void event_logs_update(event_logs_state_t *state);
void event_log_append(event_logs_state_t *state);

#endif /* DIAGNOSTICS_EVENT_LOGS_H */
