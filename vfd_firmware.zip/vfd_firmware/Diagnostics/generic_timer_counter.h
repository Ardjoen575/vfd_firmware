#ifndef DIAGNOSTICS_GENERIC_TIMER_COUNTER_H
#define DIAGNOSTICS_GENERIC_TIMER_COUNTER_H

/* Generic timer & counter (grp 33) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} generic_timer_counter_state_t;

void generic_timer_counter_init(generic_timer_counter_state_t *state);
void generic_timer_counter_update(generic_timer_counter_state_t *state);
void gtc_tick(generic_timer_counter_state_t *state);

#endif /* DIAGNOSTICS_GENERIC_TIMER_COUNTER_H */
