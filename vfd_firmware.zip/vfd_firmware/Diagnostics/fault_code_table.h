#ifndef DIAGNOSTICS_FAULT_CODE_TABLE_H
#define DIAGNOSTICS_FAULT_CODE_TABLE_H

/* Fault message code table */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} fault_code_table_state_t;

void fault_code_table_init(fault_code_table_state_t *state);
void fault_code_table_update(fault_code_table_state_t *state);
void fault_code_lookup(fault_code_table_state_t *state);

#endif /* DIAGNOSTICS_FAULT_CODE_TABLE_H */
