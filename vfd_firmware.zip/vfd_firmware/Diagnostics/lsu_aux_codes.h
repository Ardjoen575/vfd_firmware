#ifndef DIAGNOSTICS_LSU_AUX_CODES_H
#define DIAGNOSTICS_LSU_AUX_CODES_H

/* Auxiliary codes for LSU warnings/faults */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} lsu_aux_codes_state_t;

void lsu_aux_codes_init(lsu_aux_codes_state_t *state);
void lsu_aux_codes_update(lsu_aux_codes_state_t *state);
void lsu_aux_code_lookup(lsu_aux_codes_state_t *state);

#endif /* DIAGNOSTICS_LSU_AUX_CODES_H */
