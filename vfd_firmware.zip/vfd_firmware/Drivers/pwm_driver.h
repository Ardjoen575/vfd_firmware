#ifndef DRIVERS_PWM_DRIVER_H
#define DRIVERS_PWM_DRIVER_H

/* HRTIM SVPWM + braking chopper PWM */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} pwm_driver_state_t;

void pwm_driver_init(pwm_driver_state_t *state);
void pwm_driver_update(pwm_driver_state_t *state);
void pwm_svm_update(pwm_driver_state_t *state);
void pwm_chopper_update(pwm_driver_state_t *state);

#endif /* DRIVERS_PWM_DRIVER_H */
