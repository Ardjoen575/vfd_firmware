#include "adc_driver.h"

/* Current, DC bus, analog input sampling
 * Implementation stub - fill in per manual section referenced in header.
 */

void adc_driver_init(adc_driver_state_t *state)
{
    state->initialized = 1;
    /* TODO: initialize module state */
}

void adc_driver_update(adc_driver_state_t *state)
{
    /* TODO: periodic update logic */
    (void)state;
}

void adc_sample_all(adc_driver_state_t *state)
{
    /* TODO: implement adc_sample_all */
    (void)state;
}

void adc_calibrate(adc_driver_state_t *state)
{
    /* TODO: implement adc_calibrate */
    (void)state;
}
