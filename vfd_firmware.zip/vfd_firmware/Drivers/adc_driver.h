#ifndef DRIVERS_ADC_DRIVER_H
#define DRIVERS_ADC_DRIVER_H

/* Current, DC bus, analog input sampling */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} adc_driver_state_t;

void adc_driver_init(adc_driver_state_t *state);
void adc_driver_update(adc_driver_state_t *state);
void adc_sample_all(adc_driver_state_t *state);
void adc_calibrate(adc_driver_state_t *state);

#endif /* DRIVERS_ADC_DRIVER_H */
