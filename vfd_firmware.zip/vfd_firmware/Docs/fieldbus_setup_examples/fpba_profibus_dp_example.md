# FPBA (PROFIBUS DP) parameter setting example

TODO: document your own fieldbus adapter setup sequence (Ch.10 reference).
