# Master/Follower communication II (Follower)

TODO: reproduce this control chain block diagram (Ch.11) in your own notation.
