# Reference selection for torque controller

TODO: reproduce this control chain block diagram (Ch.11) in your own notation.
