# Master/Follower communication I (Master)

TODO: reproduce this control chain block diagram (Ch.11) in your own notation.
