# Torque reference source selection and modification

TODO: reproduce this control chain block diagram (Ch.11) in your own notation.
