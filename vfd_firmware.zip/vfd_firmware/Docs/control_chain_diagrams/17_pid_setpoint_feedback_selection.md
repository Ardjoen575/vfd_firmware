# Process PID setpoint and feedback source selection

TODO: reproduce this control chain block diagram (Ch.11) in your own notation.
