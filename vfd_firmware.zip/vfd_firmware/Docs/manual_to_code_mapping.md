# Manual-to-code mapping

TODO: populate table of {manual section/page -> source file} as you implement.
