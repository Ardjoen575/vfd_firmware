#include "state_machine.h"
void state_machine_init(void) { /* TODO */ }
void state_machine_run(void) { /* TODO */ }
