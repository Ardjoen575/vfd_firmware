#ifndef CORE_VF_CONTROL_H
#define CORE_VF_CONTROL_H
#include <stdint.h>
/* Shared types, enums, structures used across modules */
typedef enum {
    DRIVE_STATE_NOT_READY = 0,
    DRIVE_STATE_READY,
    DRIVE_STATE_RUNNING,
    DRIVE_STATE_FAULT
} drive_state_t;
#endif
