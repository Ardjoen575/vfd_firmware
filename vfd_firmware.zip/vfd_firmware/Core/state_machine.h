#ifndef CORE_STATE_MACHINE_H
#define CORE_STATE_MACHINE_H
void state_machine_init(void);
void state_machine_run(void);
#endif
