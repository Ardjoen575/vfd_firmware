#include "system_config.h"
#include "vf_control.h"
#include "rtos_scheduler.h"
#include "state_machine.h"

int main(void)
{
    /* TODO: BSP init, scheduler init, state machine init, scheduler start */
    for (;;) {
        /* main loop / scheduler tick */
    }
    return 0;
}
