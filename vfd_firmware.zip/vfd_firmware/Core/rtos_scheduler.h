#ifndef CORE_RTOS_SCHEDULER_H
#define CORE_RTOS_SCHEDULER_H
void rtos_scheduler_init(void);
void rtos_scheduler_run(void);
#endif
