#ifndef CORE_SYSTEM_CONFIG_H
#define CORE_SYSTEM_CONFIG_H
/* TODO: hardware definitions (MCU, clocks, memory map) */
#endif
