#ifndef REFERENCECHAINS_VOLTAGE_REF_CHAIN_H
#define REFERENCECHAINS_VOLTAGE_REF_CHAIN_H

/* Voltage reference chain (grp 29) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} voltage_ref_chain_state_t;

void voltage_ref_chain_init(voltage_ref_chain_state_t *state);
void voltage_ref_chain_update(voltage_ref_chain_state_t *state);
void voltage_ref_compute(voltage_ref_chain_state_t *state);

#endif /* REFERENCECHAINS_VOLTAGE_REF_CHAIN_H */
