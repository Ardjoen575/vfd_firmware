#ifndef REFERENCECHAINS_TORQUE_REF_CHAIN_H
#define REFERENCECHAINS_TORQUE_REF_CHAIN_H

/* Torque reference chain (grp 26) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} torque_ref_chain_state_t;

void torque_ref_chain_init(torque_ref_chain_state_t *state);
void torque_ref_chain_update(torque_ref_chain_state_t *state);
void torque_ref_compute(torque_ref_chain_state_t *state);

#endif /* REFERENCECHAINS_TORQUE_REF_CHAIN_H */
