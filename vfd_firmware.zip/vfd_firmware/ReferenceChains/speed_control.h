#ifndef REFERENCECHAINS_SPEED_CONTROL_H
#define REFERENCECHAINS_SPEED_CONTROL_H

/* Speed controller (grp 25) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} speed_control_state_t;

void speed_control_init(speed_control_state_t *state);
void speed_control_update(speed_control_state_t *state);
void speed_ctrl_step(speed_control_state_t *state);
void speed_ctrl_pid(speed_control_state_t *state);

#endif /* REFERENCECHAINS_SPEED_CONTROL_H */
