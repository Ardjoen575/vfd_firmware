#ifndef REFERENCECHAINS_FREQ_REF_CHAIN_H
#define REFERENCECHAINS_FREQ_REF_CHAIN_H

/* Frequency reference chain (grp 28) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} freq_ref_chain_state_t;

void freq_ref_chain_init(freq_ref_chain_state_t *state);
void freq_ref_chain_update(freq_ref_chain_state_t *state);
void freq_ref_compute(freq_ref_chain_state_t *state);

#endif /* REFERENCECHAINS_FREQ_REF_CHAIN_H */
