#ifndef REFERENCECHAINS_LIMITS_H
#define REFERENCECHAINS_LIMITS_H

/* Torque/current/speed limits (grp 30) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} limits_state_t;

void limits_init(limits_state_t *state);
void limits_update(limits_state_t *state);
void limits_clamp(limits_state_t *state);

#endif /* REFERENCECHAINS_LIMITS_H */
