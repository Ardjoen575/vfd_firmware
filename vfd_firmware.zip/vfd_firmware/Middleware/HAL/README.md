Drop your MCU vendor's HAL files here.
