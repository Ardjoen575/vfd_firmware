Drop your MCU vendor's CMSIS files here.
