#ifndef HWCONFIG_MOTOR_DATA_H
#define HWCONFIG_MOTOR_DATA_H

/* Motor nameplate data (grp 99) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} motor_data_state_t;

void motor_data_init(motor_data_state_t *state);
void motor_data_update(motor_data_state_t *state);
void motor_data_apply(motor_data_state_t *state);

#endif /* HWCONFIG_MOTOR_DATA_H */
