#ifndef HWCONFIG_MOTOR_CONTROL_SETTINGS_H
#define HWCONFIG_MOTOR_CONTROL_SETTINGS_H

/* Motor control settings (grp 97) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} motor_control_settings_state_t;

void motor_control_settings_init(motor_control_settings_state_t *state);
void motor_control_settings_update(motor_control_settings_state_t *state);
void motorctrl_cfg_apply(motor_control_settings_state_t *state);

#endif /* HWCONFIG_MOTOR_CONTROL_SETTINGS_H */
