#ifndef HWCONFIG_SYSTEM_SETTINGS_H
#define HWCONFIG_SYSTEM_SETTINGS_H

/* System settings (grp 96) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} system_settings_state_t;

void system_settings_init(system_settings_state_t *state);
void system_settings_update(system_settings_state_t *state);
void syscfg_apply(system_settings_state_t *state);

#endif /* HWCONFIG_SYSTEM_SETTINGS_H */
