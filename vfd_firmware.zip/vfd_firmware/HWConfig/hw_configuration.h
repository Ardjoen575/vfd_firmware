#ifndef HWCONFIG_HW_CONFIGURATION_H
#define HWCONFIG_HW_CONFIGURATION_H

/* HW configuration (grp 95) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} hw_configuration_state_t;

void hw_configuration_init(hw_configuration_state_t *state);
void hw_configuration_update(hw_configuration_state_t *state);
void hwcfg_apply(hw_configuration_state_t *state);

#endif /* HWCONFIG_HW_CONFIGURATION_H */
