#ifndef HWCONFIG_USER_MOTOR_PARAMS_H
#define HWCONFIG_USER_MOTOR_PARAMS_H

/* User motor parameters (grp 98) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} user_motor_params_state_t;

void user_motor_params_init(user_motor_params_state_t *state);
void user_motor_params_update(user_motor_params_state_t *state);
void user_motor_params_apply(user_motor_params_state_t *state);

#endif /* HWCONFIG_USER_MOTOR_PARAMS_H */
