/* TODO: test_protection.c */
#include <assert.h>

int main(void) {
    /* TODO: test cases */
    return 0;
}
