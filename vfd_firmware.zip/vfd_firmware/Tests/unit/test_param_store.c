/* TODO: test_param_store.c */
#include <assert.h>

int main(void) {
    /* TODO: test cases */
    return 0;
}
