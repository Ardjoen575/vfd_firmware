/* TODO: test_modbus_rtu.c */
#include <assert.h>

int main(void) {
    /* TODO: test cases */
    return 0;
}
