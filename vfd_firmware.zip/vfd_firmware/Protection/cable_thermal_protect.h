#ifndef PROTECTION_CABLE_THERMAL_PROTECT_H
#define PROTECTION_CABLE_THERMAL_PROTECT_H

/* Thermal protection of motor cable */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} cable_thermal_protect_state_t;

void cable_thermal_protect_init(cable_thermal_protect_state_t *state);
void cable_thermal_protect_update(cable_thermal_protect_state_t *state);
void cable_thermal_check(cable_thermal_protect_state_t *state);

#endif /* PROTECTION_CABLE_THERMAL_PROTECT_H */
