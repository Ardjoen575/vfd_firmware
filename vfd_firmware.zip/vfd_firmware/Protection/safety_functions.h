#ifndef PROTECTION_SAFETY_FUNCTIONS_H
#define PROTECTION_SAFETY_FUNCTIONS_H

/* Safety functions / STO (grp 200) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} safety_functions_state_t;

void safety_functions_init(safety_functions_state_t *state);
void safety_functions_update(safety_functions_state_t *state);
void safety_check_sto(safety_functions_state_t *state);

#endif /* PROTECTION_SAFETY_FUNCTIONS_H */
