#ifndef PROTECTION_PROTECTION_H
#define PROTECTION_PROTECTION_H

/* Central fault detection + history */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} protection_state_t;

void protection_init(protection_state_t *state);
void protection_update(protection_state_t *state);
void protection_check_all(protection_state_t *state);
void protection_log_fault(protection_state_t *state);

#endif /* PROTECTION_PROTECTION_H */
