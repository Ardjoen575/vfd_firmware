#ifndef PROTECTION_EMERGENCY_STOP_H
#define PROTECTION_EMERGENCY_STOP_H

/* Emergency stop handling */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} emergency_stop_state_t;

void emergency_stop_init(emergency_stop_state_t *state);
void emergency_stop_update(emergency_stop_state_t *state);
void estop_trigger(emergency_stop_state_t *state);

#endif /* PROTECTION_EMERGENCY_STOP_H */
