#ifndef PROTECTION_MOTOR_OVERLOAD_PROTECT_H
#define PROTECTION_MOTOR_OVERLOAD_PROTECT_H

/* Motor overload protection */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} motor_overload_protect_state_t;

void motor_overload_protect_init(motor_overload_protect_state_t *state);
void motor_overload_protect_update(motor_overload_protect_state_t *state);
void motor_overload_check(motor_overload_protect_state_t *state);

#endif /* PROTECTION_MOTOR_OVERLOAD_PROTECT_H */
