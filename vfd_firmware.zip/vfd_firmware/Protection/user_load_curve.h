#ifndef PROTECTION_USER_LOAD_CURVE_H
#define PROTECTION_USER_LOAD_CURVE_H

/* User load curve (grp 37) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} user_load_curve_state_t;

void user_load_curve_init(user_load_curve_state_t *state);
void user_load_curve_update(user_load_curve_state_t *state);
void load_curve_check(user_load_curve_state_t *state);

#endif /* PROTECTION_USER_LOAD_CURVE_H */
