#ifndef PROTECTION_FAULT_FUNCTIONS_H
#define PROTECTION_FAULT_FUNCTIONS_H

/* Fault functions configuration (grp 31) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} fault_functions_state_t;

void fault_functions_init(fault_functions_state_t *state);
void fault_functions_update(fault_functions_state_t *state);
void fault_func_evaluate(fault_functions_state_t *state);

#endif /* PROTECTION_FAULT_FUNCTIONS_H */
