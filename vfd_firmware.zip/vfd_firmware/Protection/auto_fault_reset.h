#ifndef PROTECTION_AUTO_FAULT_RESET_H
#define PROTECTION_AUTO_FAULT_RESET_H

/* Automatic fault reset logic */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} auto_fault_reset_state_t;

void auto_fault_reset_init(auto_fault_reset_state_t *state);
void auto_fault_reset_update(auto_fault_reset_state_t *state);
void auto_reset_attempt(auto_fault_reset_state_t *state);

#endif /* PROTECTION_AUTO_FAULT_RESET_H */
