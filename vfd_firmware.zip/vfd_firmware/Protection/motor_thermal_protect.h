#ifndef PROTECTION_MOTOR_THERMAL_PROTECT_H
#define PROTECTION_MOTOR_THERMAL_PROTECT_H

/* Motor thermal protection (grp 35) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} motor_thermal_protect_state_t;

void motor_thermal_protect_init(motor_thermal_protect_state_t *state);
void motor_thermal_protect_update(motor_thermal_protect_state_t *state);
void motor_thermal_model_step(motor_thermal_protect_state_t *state);

#endif /* PROTECTION_MOTOR_THERMAL_PROTECT_H */
