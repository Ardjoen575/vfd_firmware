#ifndef CONTROLINTERFACES_MASTER_FOLLOWER_H
#define CONTROLINTERFACES_MASTER_FOLLOWER_H

/* Master/follower link functionality */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} master_follower_state_t;

void master_follower_init(master_follower_state_t *state);
void master_follower_update(master_follower_state_t *state);
void mf_sync_step(master_follower_state_t *state);

#endif /* CONTROLINTERFACES_MASTER_FOLLOWER_H */
