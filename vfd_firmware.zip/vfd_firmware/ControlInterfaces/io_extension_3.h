#ifndef CONTROLINTERFACES_IO_EXTENSION_3_H
#define CONTROLINTERFACES_IO_EXTENSION_3_H

/* I/O extension module 3 (grp 16) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} io_extension_3_state_t;

void io_extension_3_init(io_extension_3_state_t *state);
void io_extension_3_update(io_extension_3_state_t *state);
void io_ext3_poll(io_extension_3_state_t *state);

#endif /* CONTROLINTERFACES_IO_EXTENSION_3_H */
