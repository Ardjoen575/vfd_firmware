#ifndef CONTROLINTERFACES_LSU_CONTROL_H
#define CONTROLINTERFACES_LSU_CONTROL_H

/* Control of a supply unit / LSU (grp 94) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} lsu_control_state_t;

void lsu_control_init(lsu_control_state_t *state);
void lsu_control_update(lsu_control_state_t *state);
void lsu_send_command(lsu_control_state_t *state);

#endif /* CONTROLINTERFACES_LSU_CONTROL_H */
