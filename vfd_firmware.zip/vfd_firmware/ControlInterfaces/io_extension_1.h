#ifndef CONTROLINTERFACES_IO_EXTENSION_1_H
#define CONTROLINTERFACES_IO_EXTENSION_1_H

/* I/O extension module 1 (grp 14) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} io_extension_1_state_t;

void io_extension_1_init(io_extension_1_state_t *state);
void io_extension_1_update(io_extension_1_state_t *state);
void io_ext1_poll(io_extension_1_state_t *state);

#endif /* CONTROLINTERFACES_IO_EXTENSION_1_H */
