#ifndef CONTROLINTERFACES_RELAY_OUTPUT_H
#define CONTROLINTERFACES_RELAY_OUTPUT_H

/* Programmable relay outputs */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} relay_output_state_t;

void relay_output_init(relay_output_state_t *state);
void relay_output_update(relay_output_state_t *state);
void relay_set_state(relay_output_state_t *state);

#endif /* CONTROLINTERFACES_RELAY_OUTPUT_H */
