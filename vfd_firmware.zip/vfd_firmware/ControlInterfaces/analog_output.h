#ifndef CONTROLINTERFACES_ANALOG_OUTPUT_H
#define CONTROLINTERFACES_ANALOG_OUTPUT_H

/* Programmable analog outputs (grp 13) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} analog_output_state_t;

void analog_output_init(analog_output_state_t *state);
void analog_output_update(analog_output_state_t *state);
void ao_write_value(analog_output_state_t *state);

#endif /* CONTROLINTERFACES_ANALOG_OUTPUT_H */
