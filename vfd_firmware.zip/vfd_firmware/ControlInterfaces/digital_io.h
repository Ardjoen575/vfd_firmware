#ifndef CONTROLINTERFACES_DIGITAL_IO_H
#define CONTROLINTERFACES_DIGITAL_IO_H

/* Standard DI/DO (grp 10) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} digital_io_state_t;

void digital_io_init(digital_io_state_t *state);
void digital_io_update(digital_io_state_t *state);
void dio_read_input(digital_io_state_t *state);
void dio_write_output(digital_io_state_t *state);

#endif /* CONTROLINTERFACES_DIGITAL_IO_H */
