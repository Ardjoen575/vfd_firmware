#ifndef CONTROLINTERFACES_IO_EXTENSION_2_H
#define CONTROLINTERFACES_IO_EXTENSION_2_H

/* I/O extension module 2 (grp 15) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} io_extension_2_state_t;

void io_extension_2_init(io_extension_2_state_t *state);
void io_extension_2_update(io_extension_2_state_t *state);
void io_ext2_poll(io_extension_2_state_t *state);

#endif /* CONTROLINTERFACES_IO_EXTENSION_2_H */
