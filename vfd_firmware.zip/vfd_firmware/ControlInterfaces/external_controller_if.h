#ifndef CONTROLINTERFACES_EXTERNAL_CONTROLLER_IF_H
#define CONTROLINTERFACES_EXTERNAL_CONTROLLER_IF_H

/* External controller interface */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} external_controller_if_state_t;

void external_controller_if_init(external_controller_if_state_t *state);
void external_controller_if_update(external_controller_if_state_t *state);
void extctrl_exchange(external_controller_if_state_t *state);

#endif /* CONTROLINTERFACES_EXTERNAL_CONTROLLER_IF_H */
