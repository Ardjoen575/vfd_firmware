#ifndef CONTROLINTERFACES_ANALOG_INPUT_H
#define CONTROLINTERFACES_ANALOG_INPUT_H

/* Programmable analog inputs (grp 12) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} analog_input_state_t;

void analog_input_init(analog_input_state_t *state);
void analog_input_update(analog_input_state_t *state);
void ai_scale_value(analog_input_state_t *state);

#endif /* CONTROLINTERFACES_ANALOG_INPUT_H */
