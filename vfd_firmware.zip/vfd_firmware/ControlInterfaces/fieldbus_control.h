#ifndef CONTROLINTERFACES_FIELDBUS_CONTROL_H
#define CONTROLINTERFACES_FIELDBUS_CONTROL_H

/* Fieldbus control overview/dispatch */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} fieldbus_control_state_t;

void fieldbus_control_init(fieldbus_control_state_t *state);
void fieldbus_control_update(fieldbus_control_state_t *state);
void fbctrl_dispatch(fieldbus_control_state_t *state);

#endif /* CONTROLINTERFACES_FIELDBUS_CONTROL_H */
