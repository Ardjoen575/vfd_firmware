#ifndef CONTROLINTERFACES_DIGITAL_IO_EXT_H
#define CONTROLINTERFACES_DIGITAL_IO_EXT_H

/* Standard DIO/FI/FO (grp 11) */

#include <stdint.h>

typedef struct {
    uint8_t initialized;
    /* TODO: module-specific state fields */
} digital_io_ext_state_t;

void digital_io_ext_init(digital_io_ext_state_t *state);
void digital_io_ext_update(digital_io_ext_state_t *state);
void dio_ext_configure(digital_io_ext_state_t *state);

#endif /* CONTROLINTERFACES_DIGITAL_IO_EXT_H */
